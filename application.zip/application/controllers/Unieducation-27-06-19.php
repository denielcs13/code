<?php
defined('BASEPATH') OR exit('No direct script access allowed');
error_reporting(E_ALL);
ini_set('display_errors',1);
header('Content-type: text/html; charset=utf-8');
class Unieducation extends MY_Controller {

	public function __construct()
    {
		parent::__construct();
			$this->load->library(array('session'));
			
			$this->load->helper('form');
            $this->load->helper('question');
            $this->load->helper('question_helper');
			$this->load->helper('get_counter_helper');
			$this->load->helper(array('url','form'));
			$this->load->model('Login_model');	
			date_default_timezone_set('Pacific/Auckland');
			$this->load->library("pagination");			
			$this->load->library('form_validation');
			if($this->uri->segment(1)=='order-history')
			{
				
				if($this->session->userdata('user_id')!="")
				{
					$sqlchkuyear=$this->db->query("select year_id from user_details where user_id='".$this->session->userdata('user_id')."'");
					$row_chkuyear=$sqlchkuyear->row();					
					$this->session->set_userdata('loginyear', $row_chkuyear->year_id);			
					
					
				}
			}
			/*---end of after ats payment update user current year---*/
			
    }
	public function index($sub="",$year='')
	{	
	
		
        if($this->uri->segment(1)=='math')
        {
        $obj=$this->math;
        $data["obj"]= $obj;  
        }elseif($this->uri->segment(1)=='english'){
         $obj=$this->english;
         $objdata["obj"]= $obj;     
        }	
		
        if($year!="")
        {
			$data["year"]=$year;
			$data["year_dtl"] = $this->main_model->get_detail('master_class','class_slug',$year);	
			$year_id=$data["year_dtl"]->class_id;
			$this->questions_model->CLASSID = $year_id;
			$data["year"]=$year;
		}
		
		
		  
		$data['error']='';
		$this->load->view('frontend/public/index',$data);
		
	}
    public function _404(){
		$this->load->view("frontend/public/404");
	}
public function math($year="",$slug=""){
		if($this->session->userdata('profile_update')=='no')
        {
            redirect(base_url('profile-update')); 
        }
        if($this->uri->segment(1)=='math')
                {
                $obj=$this->math;
                $objdata["obj"]= $obj;  
                }elseif($this->uri->segment(1)=='english'){
                 $obj=$this->english;
                 $objdata['obj'];   
                }
                $year=$this->uri->segment(2);
                $data['class_slug']=$year;
                $data['year']=$this->uri->segment(2);
                
                $year_id=$this->main_model->getsid(TBL_CLASS,$objdata['obj'],$year); 
                $data['year_id']=$year_id;
                $data['year_dtl']=$this->main_model->get_detail($obj,TBL_CLASS,array('class_id'=>$year_id),"single");
                $data['SylList']=$this->main_model->get_detail($obj,'master_skill',array('skill_class'=>$year_id,'skill_parent'=>'0'),$insgle=null,'skill_order','asc');
                if($slug)
                {
                    
                    $subskill=$this->uri->segment(3);
                    $data['subskill']=$subskill;
                    $skill=$this->main_model->get_detail($obj,'master_skill',array('skill_class'=>$year_id,'skill_slug'=>$subskill),"single");
                    $data['skill']=$skill;
                    //$this->main_model->getall($obj,'manage_question','*',$col=null,$data['paging']["limit"], $data['paging']['offset']);
                    //unset value
                    $this->session->set_userdata('attempt', '0');
                    $ansattempt = $this->session->set_userdata('ansattempt','0');
                    //unset value
                    $data["Questionlist"] = $this->main_model->random_question($obj,$year_id,$skill->skill_id);
					$this->load->view('frontend/public/header',$objdata);
                    $this->load->view('frontend/private/play',$data);
                    $this->load->view('frontend/public/footer');
                    
                }else{
                   $this->load->view('frontend/public/header',$objdata);
                   $this->load->view('frontend/public/syllabus_list',$data);
                   $this->load->view('frontend/public/footer',$data);
                }
	}
public function english($year="",$slug=""){
		
        if($this->session->userdata('profile_update')=='no')
        {
            redirect(base_url('profile-update')); 
        }
        if($this->uri->segment(1)=='math')
                {
                $obj=$this->math;
                $objdata["obj"]= $obj;  
                }elseif($this->uri->segment(1)=='english'){
                 $obj=$this->english;
                 $objdata["obj"]= $obj;  
                }
                $year=$this->uri->segment(2);
                $data['year']=$this->uri->segment(2);
                
                $year_id=$this->main_model->getsid(TBL_CLASS,$objdata['obj'],$year); 
                $data['year_id']=$year_id;
                $data['year_dtl']=$this->main_model->get_detail($obj,TBL_CLASS,array('class_id'=>$year_id),"single");
                $data['SylList']=$this->main_model->get_detail($obj,'master_skill',array('skill_class'=>$year_id,'skill_parent'=>'0'),$insgle=null,'skill_order','asc');
                
                if($slug)
                {
                    
                    $subskill=$this->uri->segment(3);
                    $data['subskill']=$subskill;
                    $skill=$this->main_model->get_detail($obj,'master_skill',array('skill_class'=>$year_id,'skill_slug'=>$subskill),"single");
                    $data['skill']=$skill;
                    //$this->main_model->getall($obj,'manage_question','*',$col=null,$data['paging']["limit"], $data['paging']['offset']);
                    //unset value
                    $this->session->set_userdata('attempt', '0');
                    $ansattempt = $this->session->set_userdata('ansattempt','0');
                    //unset value
                    $data["Questionlist"] = $this->main_model->random_question($obj,$year_id,$skill->skill_id);
					$this->load->view('frontend/public/header',$objdata);
                    $this->load->view('frontend/private/play',$data);
                    $this->load->view('frontend/public/footer');
                    
                }else{
                   $this->load->view('frontend/public/header',$objdata);
                   $this->load->view('frontend/public/syllabus_list',$data);
                   $this->load->view('frontend/public/footer',$data);
                }
	}
public function random_password() 
	{
		$alphabet = 'abcdefghijkmnopqrstuvwxyzABCDEFGHJKLMNOPQRSTUVWXYZ1234567890';
		$password = array(); 
		$alpha_length = strlen($alphabet) - 1; 
		for ($i = 0; $i < 8; $i++) 
		{
			$n = rand(0, $alpha_length);
			$password[] = $alphabet[$n];
		}
		return implode($password); 
	}
    

public function register() 
	{
       $data['const']='';
       $data['consts']='';
       $data['desgn']='';	
       $data['cntr']='';
       $data['cls_st']='';	   
	   if($this->input->post('etype')=='pwov'){
        		   
        $this->form_validation->set_rules('country', 'Country', 'required');
        $this->form_validation->set_rules('state', 'State', 'required');
        $this->form_validation->set_rules('reg_city_stdn', 'City', 'required');
        $this->form_validation->set_rules('reg_zip_stdn', 'Zip', 'required');		
		$this->form_validation->set_rules('reg_email_stdn', 'Email', 'required|valid_email|is_unique[main_user.email]|callback_checkEmail');	
		$this->form_validation->set_rules('reg_fname_stdn', 'Full Name', 'required');		
		$this->form_validation->set_rules('reg_class_stdn', 'Class', 'required');
        $this->form_validation->set_rules('reg_pwd_stdn', 'Password', 'required');
        $this->form_validation->set_rules('reg_cpwd_stdn', 'Confirm Password', 'required|matches[reg_pwd_stdn]');
		$terms = $this->input->post('etype');
		$this->form_validation->set_rules('etype','Check' , 'required');
		if ($this->input->post('etype') == 'pwov'){
			$data['is_active'] = 'checked';
			$cls_id = $this->input->post('reg_class_stdn');
			if($cls_id==1){
				$data['cls_st']='Kindergarten';
			}else{
				$data['cls_st']='Year '.($cls_id-1);
			}
			$country_id = $this->input->post('country');
			$state_id = $this->input->post('state');
			$data['const']=$this->main_model->country_by_id($country_id,'countries');
			$data['consts']=$this->main_model->state_by_id($state_id,'states');
			
			
		}else{
			$data['is_active'] = '';			
		}
//var_dump($terms);die; //Just to see the value, then remove this line.
		
		if($this->form_validation->run())
		{	
		   $post = $this->input->post();
		   
			// $row_user=$this->main_model->get_detail('main_user','email',$this->input->post('reg_email_stdn'));
			// if($row_user->user_id!=""){
				// $this->session->set_flashdata('msg','This email id already exist');
			// } 
			
			$createdate=date("Y-m-d H:i:s");
			//$password=$this->random_password();		

			$user_data=array(
							'email'=>$this->input->post('reg_email_stdn'),
							'password'=>md5($this->input->post('reg_pwd_stdn')),
							'user_name'=>$this->input->post('reg_email_stdn'),
							'user_type'=>'6',
							'first_name'=>$this->input->post('reg_fname_stdn'),
                            'phone'=>$this->input->post('reg_phn_stdn'),								
							'city'=>$this->input->post('reg_city_stdn'),
							'state'=>$state_id,
							'zipcode'=>$this->input->post('reg_zip_stdn'),
							'country'=>$country_id,
							'role_type'=>'user',
                            'profile_update'=>'yes',
                            'class_name'=>$this->input->post('reg_class_stdn'),							
							'edate'=>$createdate,
							'status'=>'1',							
							);
					//var_dump($user_data);die;
							
			$last_insert_is=$this->main_model->save($this->db,'main_user',$user_data);
			        // if($last_insert_is)
            // {
                // $senderemail=$this->input->post('reg_email_stdn');
				// $emailarr=explode('@',$senderemail);
				// global $class_arr;
				// $username=$emailarr[0].'M'.$class_arr[date('Y')].rand(10,99);
				// /*----update user id----*/
				// $r=false;
				// while($r==false){
					// $row_uname=$this->main_model->get_detail($this->db,'temp_main_user',array('user_name'=>$username),'single');
					// if($row_uname==""){
						// $r=true;
					// }
					// else{
						// $username=$emailarr[0].'M'.$class_arr[date('Y')].rand(10,99);
					// }
				// } 
				// $username_data=array(
				// 'user_name'=>$username							
				// );
               // $this->main_model->update($this->db,'temp_main_user',$username_data,array('user_id'=>$last_insert_is)); 	
	         // } 
			// $data['firstname']=$this->input->post('reg_fname_stdn');
			// $data['fullname']=$this->input->post('reg_fname_stdn');
			// $data['username']=$this->input->post('reg_email_stdn');
			// $data['password']= md5($this->input->post('reg_pwd_stdn'));		
			// $body = $this->load->view('emails/signup-to-student',$data,TRUE);

			// $this->e_mail($senderemail,basic_from_email,basic_from_name,register_subject,$body);
			redirect(base_url('registered'));
		      
		}
	   
	   }else if($this->input->post('etype')=='pwv'){
		   /* $post = $this->input->post();
			var_dump($post);die; */
		  
        $this->form_validation->set_rules('country1', 'Country', 'required');
        $this->form_validation->set_rules('state1', 'State', 'required');
        $this->form_validation->set_rules('reg_city', 'City', 'required');
        $this->form_validation->set_rules('reg_zip', 'Zip', 'required');
        $this->form_validation->set_rules('reg_phn', 'Phone', 'required');		
		$this->form_validation->set_rules('reg_email_prnt', 'Email', 'required|valid_email|is_unique[main_user.email]|callback_checkEmail');	
		$this->form_validation->set_rules('reg_fname', 'Full Name', 'required');		
		$this->form_validation->set_rules('reg_cnum', 'Childrens', 'required');
        $this->form_validation->set_rules('reg_pwd_prnt', 'Password', 'required');
        $this->form_validation->set_rules('reg_cpwd_prnt', 'Confirm Password', 'required|matches[reg_pwd_prnt]');
		if ($this->input->post('etype') == 'pwv'){
			$data['is_active1'] = 'checked';
			
			$country_id = $this->input->post('country1');
			$state_id = $this->input->post('state1');
			$data['const']=$this->main_model->country_by_id($country_id,'countries');
			$data['consts']=$this->main_model->state_by_id($state_id,'states');                    
								 
			
		}else{
			$data['is_active1'] = '';
		}
		if($this->form_validation->run())
		{	
		   $post = $this->input->post();
			// $row_user=$this->main_model->get_detail('main_user','email',$this->input->post('reg_email_stdn'));
			// if($row_user->user_id!=""){
				// $this->session->set_flashdata('msg','This email id already exist');
			// } 
			
			$createdate=date("Y-m-d H:i:s");
			//$password=$this->random_password();
			

			$user_data=array(
							'email'=>$this->input->post('reg_email_prnt'),
							'password'=>md5($this->input->post('reg_pwd_prnt')),
							'user_name'=>$this->input->post('reg_email_prnt'),
							'user_type'=>'7',
							'first_name'=>$this->input->post('reg_fname'),
                            'phone'=>$this->input->post('reg_phn'),							
							'city'=>$this->input->post('reg_city'),
							'state'=>$state_id,
							'zipcode'=>$this->input->post('reg_zip'),
							'country'=>$country_id,
							'role_type'=>'parents',
                            'profile_update'=>'yes',
                            'chldr_num'=>$this->input->post('reg_cnum'),
							'edate'=>$createdate,
							'status'=>'1',							
							);
					//var_dump($user_data);die;
							
			$last_insert_is=$this->main_model->save($this->db,'main_user',$user_data);
			        // if($last_insert_is)
            // {
                // $senderemail=$this->input->post('reg_email_prnt');
				// $emailarr=explode('@',$senderemail);
				// global $class_arr;
				// $username=$emailarr[0].'M'.$class_arr[date('Y')].rand(10,99);
				// /*----update user id----*/
				// $r=false;
				// while($r==false){
					// $row_uname=$this->main_model->get_detail($this->db,'temp_main_user',array('user_name'=>$username),'single');
					// if($row_uname==""){
						// $r=true;
					// }
					// else{
						// $username=$emailarr[0].'M'.$class_arr[date('Y')].rand(10,99);
					// }
				// } 
				// $username_data=array(
				// 'user_name'=>$username							
				// );
               // $this->main_model->update($this->db,'temp_main_user',$username_data,array('user_id'=>$last_insert_is)); 	
	         // } 
			// $data['firstname']=$this->input->post('reg_fname');
			// $data['fullname']=$this->input->post('reg_fname');
			// $data['username']=$this->input->post('reg_email_prnt');
			// $data['password']= md5($this->input->post('reg_pwd_prnt'));		
			// $body = $this->load->view('emails/signup-to-student',$data,TRUE);

			// $this->e_mail($senderemail,basic_from_email,basic_from_name,register_subject,$body);
			redirect(base_url('registered'));
		      
		}
		
		
	   }else if($this->input->post('etype')=='pwvi'){
		   /* $post = $this->input->post();
			var_dump($post);die; */
		$rd=$this->input->post('etype'); 
        $this->form_validation->set_rules('country3', 'Country', 'required');
		
        $this->form_validation->set_rules('state3', 'State', 'required');
        $this->form_validation->set_rules('reg_city_ins', 'City', 'required');        
        $this->form_validation->set_rules('reg_zip_ins', 'Zip', 'required');
        $this->form_validation->set_rules('inst_dsgn_type', 'Designation', 'required');		
		$this->form_validation->set_rules('reg_email_ins', 'Email', 'required|valid_email|is_unique[main_user.email]|callback_checkEmail');	
		$this->form_validation->set_rules('reg_fname_ins', 'Full Name', 'required');		
		$this->form_validation->set_rules('reg_phn_ins', 'Phone', 'required');
        $this->form_validation->set_rules('reg_pwd_ins', 'Password', 'required');
        $this->form_validation->set_rules('reg_cpwd_ins', 'Confirm Password', 'required|matches[reg_pwd_ins]');
		
		if ($this->input->post('etype') == 'pwvi'){
			$data['is_active2'] = 'checked';
			
			$country_id = $this->input->post('country3');
			$state_id = $this->input->post('state3');
			$data['const']=$this->main_model->country_by_id($country_id,'countries');
			//var_dump($data['const']);die;
			$data['consts']=$this->main_model->state_by_id($state_id,'states');
			$data['desgn'] = $this->input->post('inst_dsgn_type');
			$data['cntr'] = $this->input->post('inst_cntr_type');
			
		}else{
			$data['is_active2'] = '';
		}
		
		if($this->form_validation->run())
		{	
		   $post = $this->input->post();
			// $row_user=$this->main_model->get_detail('main_user','email',$this->input->post('reg_email_stdn'));
			// if($row_user->user_id!=""){
				// $this->session->set_flashdata('msg','This email id already exist');
			// } 
			
			$createdate=date("Y-m-d H:i:s");
			//$password=$this->random_password();
			

			$user_data=array(
							'email'=>$this->input->post('reg_email_ins'),
							'password'=>md5($this->input->post('reg_pwd_ins')),
							'user_name'=>$this->input->post('reg_email_ins'),
							'user_type'=>'8',
							'first_name'=>$this->input->post('reg_fname_ins'),
							'phone'=>$this->input->post('reg_phn_ins'),
							'inst_name'=>$this->input->post('reg_instname'),
							'city'=>$this->input->post('reg_city_ins'),
							'state'=>$state_id,
							'zipcode'=>$this->input->post('reg_zip_ins'),
							'country'=>$country_id,										
							'role_type'=>'institute',
                            'profile_update'=>'yes',
                            'dsgn_name'=>$this->input->post('inst_dsgn_type'),
                            'inst_type'=>$this->input->post('inst_cntr_type'),							
							'edate'=>$createdate,
							'status'=>'1',
							);
					//var_dump($user_data);die;
							
			$last_insert_is=$this->main_model->save($this->db,'main_user',$user_data);
			        // if($last_insert_is)
            // {
                // $senderemail=$this->input->post('reg_email_ins');
				// $emailarr=explode('@',$senderemail);
				// global $class_arr;
				// $username=$emailarr[0].'M'.$class_arr[date('Y')].rand(10,99);
				// /*----update user id----*/
				// $r=false;
				// while($r==false){
					// $row_uname=$this->main_model->get_detail($this->db,'temp_main_user',array('user_name'=>$username),'single');
					// if($row_uname==""){
						// $r=true;
					// }
					// else{
						// $username=$emailarr[0].'M'.$class_arr[date('Y')].rand(10,99);
					// }
				// } 
				// $username_data=array(
				// 'user_name'=>$username							
				// );
               // $this->main_model->update($this->db,'temp_main_user',$username_data,array('user_id'=>$last_insert_is)); 	
	         // } 
			// $data['firstname']=$this->input->post('reg_fname_ins');
			// $data['fullname']=$this->input->post('reg_fname_ins');
			// $data['username']=$this->input->post('reg_email_ins');
			// $data['password']= md5($this->input->post('reg_pwd_ins'));		
			// $body = $this->load->view('emails/signup-to-student',$data,TRUE);

			// $this->e_mail($senderemail,basic_from_email,basic_from_name,register_subject,$body);
			redirect(base_url('registered'));
		      
		}
		
	   }
	   
		
	     $obj=$this->english;
                 //$objdata["obj"]= $obj;  
                
        $data['year_dtl']=$this->main_model->student_class($obj,'master_class');
		//$data['stdn_list']=$this->main_model->all_student_list($prnt_id);
		$data['country_dtl']=$this->main_model->county_all('countries');
		$myip = $_SERVER['REMOTE_ADDR'];
		$result_ip = @json_decode(file_get_contents("http://ip-api.com/json/{$myip}"));
		//var_dump($result_ip);
		$data['ipinfo']=$result_ip;
		$obj=$this->main;
		$ipcountry=$this->main_model->get_detail($obj,'countries',array('name'=>$result_ip->country),"single");
		
		$data['ip_country']=$ipcountry->id;
		$data['phone_code']=$ipcountry->phonecode;
		$data['shortname']=$ipcountry->sortname;
		
		
        $this->load->view('frontend/public/header');
		$this->load->view('frontend/public/register',$data);
        $this->load->view('frontend/public/footer');
		
  }
  //04-26-19
  public function add_user() 
	{	
        if($this->session->userdata('user_id')==""){
			redirect(base_url()); 
		} 
		
		$this->form_validation->set_rules('reg_email', 'Email', 'required|valid_email|is_unique[main_user.email]|callback_checkEmail');	
		$this->form_validation->set_rules('reg_fname', 'Full Name', 'required');
		$this->form_validation->set_rules('reg_pwd', 'Password', 'required');
		$this->form_validation->set_rules('reg_class', 'Class Name', 'required');
		
		if($this->form_validation->run())
		{	
			//var_dump($this->session->userdata);die;
			//$post = $this->input->post();die;
			//var_dump($post);die;
			//Check mail existence
			/* $row_user=$this->main_model->get_detail('user_details','email',$this->input->post('reg_email'));
			if($row_user->user_id!=""){
				$this->session->set_flashdata('msg','This email id already exist');
			} */
			
			$createdate=date("Y-m-d H:i:s");
			//$password=$this->random_password();
			if($this->session->userdata('user_id')!=""){

			$user_data=array(
							'email'=>$this->input->post('reg_email'),
							'password'=>md5($this->input->post('reg_pwd')),
							'user_name'=>$this->input->post('reg_email'),
							'user_type'=>'6',							
							'role_type'=>'user',
							'profile_update'=>'yes',
							'first_name'=>$this->input->post('reg_fname'),
							'class_name'=>$this->input->post('reg_class'),
							'parent_id'=>$this->session->userdata('user_id'),						
							'edate'=>$createdate,
							'status'=>'1',							
							);
		       }
		     
		       //var_dump($user_data);die;
            
            $last_insert_is=$this->main_model->save($this->db,'main_user',$user_data);
			redirect(base_url('registered'));
    }
    
        $obj=$this->english;
                 //$objdata["obj"]= $obj;  
                
        $data['year_dtl']=$this->main_model->student_class($obj,'master_class');
        //var_dump($data);die;
        $this->load->view('frontend/public/header');
		$this->load->view('frontend/public/adduser',$data);
        $this->load->view('frontend/public/footer');
		
  }

  public function student_list()
  {
  if($this->session->userdata('user_id')=="")
	  {
		  redirect(base_url()); 
	  }
 else{
	 $prnt_id=$this->session->userdata('user_id');	
     $data['stdn_list']=$this->main_model->all_student_list($prnt_id);
		//$data[]
		// echo '<pre>';
		// var_dump($data);die;
        $this->load->view('frontend/public/header');
        $this->load->view('frontend/public/studentlist',$data);
        $this->load->view('frontend/public/footer');
    }
		
  }

 public function checkEmail($email)
		{
			
			
			if($email !="")
			{	
			
			 $pricedata=$this->main_model->student_emailcheck($email);	
			//var_dump($pricedata);
			 if($pricedata > 0)
			 {
				 
				  $this->form_validation->set_message('checkEmail', 'Email already registered with us');
                 return false;
			 }
			 else
			 {
				 
                 return true;
			 }
			}
			else
			{
				
                $this->form_validation->set_message('checkEmail', 'Enter valid email id');
                 return false;
			}	
			
		}
public function login()
	{
		
		$this->form_validation->set_rules('username', 'login ID', 'required');
		$this->form_validation->set_rules('password', 'Password', 'required');		
		if($this->form_validation->run())
		{
			
			$username = $this->input->post('username');
			$password = $this->input->post('password');
			$res=$res=$this->main_model->signin($username,$password);			
			
			if ($res) 
			{	
                if ($res->login_status=='no')
                {
				if($res->lastlogin!='' && $res->lastlogin!=null)
				{	
					$lastlogintime = strtotime($res->lastlogin);				
					$mylastlogin = date("m/d/y g:i A", $lastlogintime);
				}
				else
				{
					$mylastlogin='';
				}
                
				if($res->profile_update=='no')
                {
                    $updateLoginStatus=$this->main_model->Update($this->db,'temp_main_user',array('login_status'=>'yes','last_login_deviceid'=>$_SERVER['REMOTE_ADDR']),array('user_id'=>$res->user_id));
                }else{
                    
                  $updateLoginStatus=$this->main_model->Update($this->db,'main_user',array('login_status'=>'yes','last_login_deviceid'=>$_SERVER['REMOTE_ADDR']),array('user_id'=>$res->user_id));  
                }
				$userlogindata = array( 
									'username' => $res->user_name,
									'logged_in' => true,
									'user_id' => $res->user_id,
									'email' => $res->email,
									'user_type'=>$res->user_type,
									'fullname'=>$res->first_name.' '.$res->last_name,
									//'lastlogedin'=>$mylastlogin,
									'profile_update'=>$res->profile_update,
                                    'login_status'=>'yes',
                                    'login_deviceid'=>$res->last_login_deviceid,
                                    'last_active_time'=>$res->last_active_time,
									'parent_id'=>$res->parent_id,
									);						
				$this->session->set_userdata($userlogindata);
				/*$logindate=date("Y-m-d H:i:s");
				$lastlogin_data=array(					
							'lastlogin'=>$logindate	
							
							);	
				
				$lastlogin=$this->Login_model->lastlogin($lastlogin_data);*/
			if($res->profile_update=='no')
            {
                redirect(base_url('profile-update'));  
            }else{
              redirect(base_url().'dashboard');   
            }
			
				
			}else{
			 $data['error']='Sorry You are Login Another Device .<br/> Please Logout that device then try to login.';
			 $this->load->view('frontend/public/login',$data);
			}					
			} 
			else
			{
				$data['error']='Sorry your login ID and password did not match.<br/> <br/>Please try again.';
				$this->load->view('frontend/public/login',$data);
			}	
			
		}		
		else
		{
		$data['error']='';
		$this->load->view('frontend/public/login',$data);

		}	
		
	}
public function registered() 
    {	
    	$data['regthank']='';
    	$this->load->view('frontend/public/thanks-signup',$data);
    }
public function mynoticeboard() 
	{	
	   
		if($this->session->userdata('username')!='')
		{	
			$user_id=$this->session->userdata('user_id');
			
			//Redirect(base_url('dashboard-user'));
		$data['user']=$this->main_model->get_login_user_from_main(); 
        $this->load->view('frontend/public/header');
		$this->load->view('frontend/public/dashboard',$data);
        $this->load->view('frontend/public/footer');
		}
		else
		{
			redirect(base_url().'login');
		}
	
	}
public function logout() 
    {	
    	if($this->session->userdata('profile_update')=='no')
                {
                    $updateLoginStatus=$this->main_model->Update($this->db,'temp_main_user',array('login_status'=>'no','last_login_deviceid'=>$_SERVER['REMOTE_ADDR']),array('user_id'=>$this->session->userdata('user_id')));
                }else{
                    
                  $updateLoginStatus=$this->main_model->Update($this->db,'main_user',array('login_status'=>'no','last_login_deviceid'=>$_SERVER['REMOTE_ADDR']),array('user_id'=>$this->session->userdata('user_id')));  
                }
        $this->session->sess_destroy();
        Redirect(base_url());
    }
public function useremailcheck1()
		{
			
			$email=$this->input->post('email');
          	if(filter_var($email, FILTER_VALIDATE_EMAIL))
			{	
			
			 $pricedata=$this->main_model->student_emailcheck($email);	
			//var_dump($pricedata);
			 if($pricedata > 0)
			 {
				 
				 $msg="<span style='color:red'>Email already registered with us.</span>";
			 }
			 else
			 {
				 $msg="<span style='color:green'>You can register with us.</span>";
			 }
			}
			else
			{
				$msg="<span style='color:red'>Enter valid email id.</span>";
			}	
			echo $msg;
		}
public function profile_update() 
	{	
	     if($this->session->userdata('user_id')=='')
        {
            redirect(base_url()); 
        } 
	    $this->form_validation->set_rules('f_name', 'Full Name', 'required');
		//$this->form_validation->set_rules('last_name', 'Last Name', 'required');
        $this->form_validation->set_rules('dob', 'Date of Birth', 'required');
		$this->form_validation->set_rules('phone', 'phone', 'required');
        $this->form_validation->set_rules('address', 'address', 'required');
		$this->form_validation->set_rules('Country', 'Country', 'required');
		$this->form_validation->set_rules('city', 'City', 'required');
        $this->form_validation->set_rules('state', 'State', 'required');
		$this->form_validation->set_rules('zip', 'Zip Code', 'required');
        if($this->form_validation->run())
		{
			$country_id = $this->input->post('Country');
			$state_id = $this->input->post('state');
			if(!empty($country_id))
			{	
				//$data['const']=$this->main_model->country_by_id($country_id,'countries');
				$country_name=$country_id;
			}
			else
			{
				$country_name='';
			}
			
			if(!empty($state_id))
			{
				//$data['consts']=$this->main_model->state_by_id($state_id,'states');
				//$state_name=$data['consts'][0]->name;
				$state_name=$state_id;
			}
			else
			{
				$state_name='';
			}
			
	
			 //'last_name'=>$this->input->post('class_name'),
			 if($this->input->post('class_name')!='')
			 {
         $user=array(
                    'first_name'=>$this->input->post('f_name'),                    
                    'dob'=>$this->input->post('dob'),
                    'phone'=>$this->input->post('phone'),
                    'address'=>$this->input->post('address'),
                    'country'=>$country_name,
                    'city'=>$this->input->post('city'),
                    'state'=>$state_name,
                    'zipcode'=>$this->input->post('zip'),
                    'profile_update'=>'yes',
					'class_name'=>$this->input->post('class_name'),
                   );
			 }else if($this->input->post('inst_name')!='')
			 {
         $user=array(
                    'first_name'=>$this->input->post('f_name'),                    
                    'dob'=>$this->input->post('dob'),
                    'phone'=>$this->input->post('phone'),
                    'address'=>$this->input->post('address'),
                    'country'=>$country_name,
                    'city'=>$this->input->post('city'),
                    'state'=>$state_name,
                    'zipcode'=>$this->input->post('zip'),
                    'profile_update'=>'yes',
					'inst_name'=>$this->input->post('inst_name'),
					'inst_type'=>$this->input->post('inst_type'),
					'dsgn_name'=>$this->input->post('dsgn_name'),
                   );
			 }else{
				 $user=array(
                    'first_name'=>$this->input->post('f_name'),                    
                    'dob'=>$this->input->post('dob'),
                    'phone'=>$this->input->post('phone'),
                    'address'=>$this->input->post('address'),
                    'country'=>$data['const'][0]->name,
                    'city'=>$this->input->post('city'),
                    'state'=>$data['consts'][0]->name,
                    'zipcode'=>$this->input->post('zip'),
                    'profile_update'=>'yes',
					'chldr_num'=>$this->input->post('chldr_num')
                   );
			 }
			 //var_dump($user);die;
		$updete_temp=$this->main_model->update($this->db,'main_user',$user,array('user_id'=>$this->session->userdata('user_id'))); 
    /*      if($_FILES['file']['name']!="")
         {    			 
				 $path="./assets/images/userprofile/";
				 $inputname="file";
				 $type='gif|jpg|png|jpeg|bmp';
				 $file_upload=$this->upload_file($path,$inputname,$type);
				 $user['upload_path']=$file_upload['file_name'];
				 
				 if(!$file_upload['error'])
				 {
					
					 $user1=array(
				 'upload_path'=>$file_upload['file_name']); 
				   $updete_temp=$this->main_model->update($this->db,'main_user',$user1,array('user_id'=>$this->session->userdata('user_id'))); 
				   
				 }else{
					//upload not 
					redirect($_SERVER['HTTP_REFERER']);
				 }
         } */
		  $this->session->set_flashdata('mpfl','<p class="alert alert-success"><a href="#" class="close" data-dismiss="alert" aria-label="close">×</a> Profile details updated successfully!</p>');  
		  redirect(base_url('profile-update'));
		 
        
         
        }
        else
        {
          
        }
        //changing the table for login get_login_user_from_main
        //$data['user']=$this->main_model->get_login_user_from_temp(); 
        //04-26-19
		$obj=$this->english;
                 //$objdata["obj"]= $obj;  
                
        $data['year_dtl']=$this->main_model->student_class($obj,'master_class');
		
        $userinfo=$this->main_model->get_login_user_from_main(); 
		$data['user']=$userinfo;
		$data['country_list']=$this->main_model->get_countries($obj);
		$data['state_list']=$this->main_model->get_states($obj,$userinfo->country);
        $this->load->view('frontend/public/header');
		$this->load->view('frontend/public/profile_update',$data);
        $this->load->view('frontend/public/footer');
		
	}
 public function testimonial() 
	{	
	   $this->load->view('frontend/public/header');
	   $this->load->view('frontend/public/testimonial');
	   $this->load->view('frontend/public/footer');
	}
public function contactus() 
	{	
		$this->form_validation->set_rules('fname', 'Please fill detail in first name', 'trim|required');
		$this->form_validation->set_rules('lname', 'Please fill detail in Last name', 'trim|required');
		$this->form_validation->set_rules('email', 'Please fill detail in Email', 'trim|required|valid_email');
		$this->form_validation->set_rules('msg', 'Please fill detail in Message box', 'required');
		if($this->form_validation->run() == false)
		{
	  
           $this->load->view('frontend/public/header');
    	   $this->load->view('frontend/public/contact-us');
    	   $this->load->view('frontend/public/footer');
		}
		else
		{
			
            $insert=$this->main_model->save($this->db,'contctus',$this->input->post());
			if($insert)
			{
				$this->session->set_flashdata('msg','Your requst submitted');
				$to=contact_toemail;
				$from=basic_from_email;
				$sub=contact_subject;
				$data=array('Name' => $this->input->post('fname').' '.$this->input->post('lname'),
							'Email'  => $this->input->post('email'),
							'Message'  => $this->input->post('msg'),
 							);
				$msg='';
				$msg.='<table>';
				
				foreach ($data as $key => $value) 
				{
					$msg.='<tr><td>'.$key.'</td><td>'.$value.'</td></tr>';

				}
				$msg.='</table>';
				
				//$this->e_mail($to,$from,'CONTACT US',$sub,$msg);
				redirect($_SERVER['HTTP_REFERER']);

			}else{
				$this->session->set_flashdata('msg','Your requst not submitted');
				redirect($_SERVER['HTTP_REFERER']);
			}

		}
	
	}
public function our_centers() 
	{		
		$this->load->view('frontend/public/header');
        $this->load->view('frontend/public/our-centers');
        $this->load->view('frontend/public/footer');
	} 
 	public function forgotpassword() 
	{		
		$this->form_validation->set_rules('emailid', 'Login ID', 'required');
		
		if($this->form_validation->run())
		{
			$emailid = $this->input->post('emailid');
			
            $usertable=$this->main_model->get_detail($this->db,'temp_main_user',array('email'=>$emailid,'user_type'=>'6'),'single');			
			if($usertable)
            {
             $res=$usertable;
             
                
            }else{
             $usertable=$this->main_model->get_detail($this->db,'main_user',array('email'=>$emailid,'user_type'=>'6'),'single');   
             $res=$usertable;
             
            }
            
            if ($res) 
			{	 
				
				
				
				$password=$this->random_password();
			
				$user_data=array(							
							'password'=>md5($password)						
							
							);	
	            $userid=$this->main_model->update($this->db,'main_user',$user_data,array('user_id'=>$res->user_id));
				$data1['fullname']=$res->first_name;
				$data1['username']=$res->user_name;
				$data1['password']=$password;
				
				$senderemail=$res->email;
			
				$body = $this->load->view('emails/forgotpassword',$data1,TRUE);
				$this->e_mail($senderemail,basic_from_email, basic_from_name,forgotpassword_subject.' '.$res->user_name.' '.site_name,$body);
				$data['error']='Password sent to your email. Please check your inbox.';
			     
				
								
			} 
			else
			{
				$data['error']='Login ID not found.';
				
			}
		}
		else
		{
			$data['error']='';
		}
		$this->load->view('frontend/public/header');
		$this->load->view('frontend/public/forget-password',$data);
        $this->load->view('frontend/public/footer');
		
	} 
public function disclaimer() 
	{		
		
        $this->load->view('frontend/public/header');
		$this->load->view('frontend/public/disclaimer');
        $this->load->view('frontend/public/footer');
	
	} 
 public function helpcenter() 
	{		
		
        $this->load->view('frontend/public/header');
		$this->load->view('frontend/public/help-center');
        $this->load->view('frontend/public/footer');
	
	}
 public function faqs() 
	{		
		
        $this->load->view('frontend/public/header');
		$this->load->view('frontend/public/faqs');
        $this->load->view('frontend/public/footer');
	
	}
public function termconditions() 
	{		
		$this->load->view('frontend/public/header');
		$this->load->view('frontend/public/term-conditions');
        $this->load->view('frontend/public/footer');
	
	}
public function privacypolicy() 
	{		
		$this->load->view('frontend/public/header');
		$this->load->view('frontend/public/privacy-policy');
        $this->load->view('frontend/public/footer-test');
	
	}	
public function logout1() 
    {	
    	if($this->session->userdata('profile_update')=='no')
                {
                    $updateLoginStatus=$this->main_model->Update($this->db,'temp_main_user',array('login_status'=>'no','last_login_deviceid'=>$_SERVER['REMOTE_ADDR']),array('user_id'=>$this->session->userdata('user_id')));
                }else{
                    
                  $updateLoginStatus=$this->main_model->Update($this->db,'main_user',array('login_status'=>'no','last_login_deviceid'=>$_SERVER['REMOTE_ADDR']),array('user_id'=>$this->session->userdata('user_id')));  
                }
        $this->session->sess_destroy();
        $this->session->set_flashdata('error','We Found you are Inactive from 10 second <br> Session expired !!!');
        echo true;
    }	
public function test()
{
   date_default_timezone_set('Asia/Kolkata');
   $all=$this->db->select('last_active_time,user_id')->get('main_user')->result();
   foreach($all as $row)
   {
    
    if($row->last_active_time)
    {
      $last=strtotime($row->last_active_time);
      $current=strtotime(date('y-m-d h:i:s'));
      $diff1=($current-$last)/60;
      $diff=round($diff1,0);
      if($diff>59)
      {
        $update=$this->db->where(array('login_status'=>'yes','user_id'=>$row->user_id))->update('main_user',array('login_status'=>'no'));
      }
       
    }
   }  
      
       
}

//04-27-19
   
   public function delete_student($id)
   {
	  if($this->main_model->delete_s('main_user','user_id',$id)){
		$this->session->set_flashdata('msgdelete','<p class="alert alert-danger"><a href="#" class="close" data-dismiss="alert" aria-label="close">×</a> Student deleted successfully.</p>');
		}
		redirect(base_url('student-list')); 
   }
   
   public function edit_student($id){
		
		if(!$this->session->userdata('user_id')){
			redirect(base_url());
		}
		else{
		  $data['stud_detail']=$this->main_model->get_stud_detail('main_user','user_id',$id);
		  $obj=$this->english;              
          $data['year_dtl']=$this->main_model->student_class($obj,'master_class');
		  
			if(isset($_POST['submit'])){
					
				$this->form_validation->set_rules('reg_email', 'Email', 'required');
				//$this->form_validation->set_rules('reg_pwd', 'Password', 'required');		
				$this->form_validation->set_rules('reg_fname', 'Full Name', 'required');
                $this->form_validation->set_rules('reg_class', 'Class', 'required');				
	
				if($this->form_validation->run())
				{
					if($this->session->userdata('user_id')!="")
					{
						
						if(!empty($this->input->post('reg_pwd')))
						{	
						
						$user_data=array(
							'email'=>$this->input->post('reg_email'),
							'password'=>md5($this->input->post('reg_pwd')),
							'user_name'=>$this->input->post('reg_email'),							
							'first_name'=>$this->input->post('reg_fname'),
							'class_name'=>$this->input->post('reg_class')
							);
						}
						else
						{
							$user_data=array(
							'email'=>$this->input->post('reg_email'),							
							'user_name'=>$this->input->post('reg_email'),							
							'first_name'=>$this->input->post('reg_fname'),
							'class_name'=>$this->input->post('reg_class')
							);
						}	
					}		 
						
						$this->main_model->Update_stud('main_user',$user_data,'user_id',$id);
						$this->session->set_flashdata('msgadd','<p class="alert alert-success"><a href="#" class="close" data-dismiss="alert" aria-label="close">×</a> Student details updated successfully!</p>');
						redirect(base_url('student-list'));	
				}
				else{
					$this->load->view('frontend/public/header');
					$this->load->view('frontend/public/edit-student',$data);
					$this->load->view('frontend/public/footer');
					}
			
			}
			
			
			
			
			else{
				    $this->load->view('frontend/public/header');
					$this->load->view('frontend/public/edit-student',$data);
					$this->load->view('frontend/public/footer');
					//$this->load->view('edit-student',$data);
			}
		}
	}
	
	public function user_dashboard() 
	{	
	    /* if($this->session->userdata('profile_update')=='yes')
        {
            redirect(base_url());
        } */
	    
        //changing the table for login get_login_user_from_main
        //$data['user']=$this->main_model->get_login_user_from_temp(); 
        //04-26-19
        $data['user']=$this->main_model->get_login_user_from_main(); 
        $this->load->view('frontend/public/header');
		$this->load->view('frontend/public/dashboard',$data);
        $this->load->view('frontend/public/footer');
	}
	//user subject category
	
	public function user_math($year="",$slug=""){
		if($this->session->userdata('profile_update')=='no')
        {
            redirect(base_url('profile-update')); 
        }
		
		$obj=$this->english;                  
        $data['year_dtl']=$this->main_model->student_class($obj,'master_class');        
		$this->load->view('frontend/public/header');
		$this->load->view('frontend/public/math-classes',$data);
        $this->load->view('frontend/public/footer');
                
	}
	
	public function user_english($year="",$slug=""){
		if($this->session->userdata('profile_update')=='no')
        {
            redirect(base_url('profile-update')); 
        }
		
		$obj=$this->english;                  
        $data['year_dtl']=$this->main_model->student_class($obj,'master_class');        
		$this->load->view('frontend/public/header');
		$this->load->view('frontend/public/english-classes',$data);
        $this->load->view('frontend/public/footer');
                
	}
	//04-29-19
	
	public function user_score($year="",$slug=""){
		if($this->session->userdata('user_id')=='')
        {
            redirect(base_url()); 
        }
		$usrid=$this->session->userdata('user_id');
		//$obj=$this->english; 
		$data['ttl_cnt']= count($this->main_model->student_score($usrid,'quiz_user'));
		//echo $ttl_cnt.'<br>';                
        $data['score_dtl']=$this->main_model->student_score($usrid,'quiz_user');

        //var_dump($data['score_dtl']);die;        
		$this->load->view('frontend/public/header');
		$this->load->view('frontend/public/user-score',$data);
        $this->load->view('frontend/public/footer');
                
	}
	//04-30-19
	
	public function send_add_request(){
		if($this->session->userdata('user_id')=='')
        {
            redirect(base_url()); 
        }
		$usrid=$this->session->userdata('user_id');		                
        $data['inst_lst']=$this->main_model->institute_details('main_user');            
		$this->load->view('frontend/public/header');
		$this->load->view('frontend/public/send-request',$data);
        $this->load->view('frontend/public/footer');
                
	}

	public function send_email_inst()
	{       
		  if($this->session->userdata('user_id')=='')
	        { 
		      redirect(base_url());
		    }
		  if($this->session->userdata('user_id')!='')
		  {
		  	$userids=$this->session->userdata('user_id');
		    $user_info=$this->main_model->getUserDetail_by_id($userids,'main_user'); 
            
           }
           if(isset($_POST['submit'])){
           	$instid=$this->input->post('institute');
           	$ins_info=$this->main_model->getUserDetail_by_id($instid,'main_user'); 
           }           
             $to_inst=$ins_info->email;
             $from_stnd=$user_info->email;             
			 $body = $this->load->view('emails/request-to-institute',$user_info,TRUE);
			//$this->e_mail($to,$from,'CONTACT US',$sub,$msg);
			//$this->e_mail($to_inst,$from_stnd,'Mail From User','Request to Add',$body);
			
			$this->session->set_flashdata('msgsnd','<p class="alert alert-success"><a href="#" class="close" data-dismiss="alert" aria-label="close">×</a> Request has been send successfully!</p>');
			
			redirect(base_url('dashboard'));
	}
	
	//05-01-19
	
	public function approve_add_request(){
		if($this->session->userdata('user_id')=='')
        {
            redirect(base_url()); 
        }
		$usrid=$this->session->userdata('user_id');
		
        if(isset($_POST['approve'])){
			
				$this->form_validation->set_rules('reg_email', 'Student Email', 'required');						
	
				if($this->form_validation->run())
				{
					$email=trim($_POST['reg_email']);
					
					$dt=array('parent_id'=>$usrid						
						);
						//var_dump($dt);die;
						$prnt_id=$this->main_model->getUserDetail_by_email($email,'main_user');
						$this->main_model->Update_approve('main_user',$dt,'email',$email);
						$this->session->set_flashdata('msgappr','<p class="alert alert-success"><a href="#" class="close" data-dismiss="alert" aria-label="close">×</a> Student Approved successfully!</p>');
						$to_stnd=$email;
						$from_inst=$this->session->userdata('email');             
						$body = $this->load->view('emails/approve-from-institute',$prnt_id,TRUE);
						//$this->e_mail($to,$from,'CONTACT US',$sub,$msg);
						//$this->e_mail($to_stnd,$from_inst,'Mail From Institute','Request to Approve',$body);
						redirect(base_url('dashboard'));
				}
		
		}
        
        if(isset($_POST['remove'])){
			
				$this->form_validation->set_rules('reg_email', 'Student Email', 'required');
										
	
				if($this->form_validation->run())
				{
					$email=trim($_POST['reg_email']);
					
					$prnt_id=$this->main_model->getUserDetail_by_email($email,'main_user');
					//$prnt_id->parent_id;die;
					$dt=array('parent_id'=>0						
						);
						if($prnt_id->parent_id==$usrid){
						$this->main_model->Update_approve('main_user',$dt,'email',$email);
						$this->session->set_flashdata('msgrm','<p class="alert alert-success"><a href="#" class="close" data-dismiss="alert" aria-label="close">×</a> Student Removed successfully!</p>');
						$to_stnd=$email;
						$from_inst=$this->session->userdata('email');             
						$body = $this->load->view('emails/delete-student-account',$prnt_id,TRUE);
						
						//$this->e_mail($to_stnd,$from_inst,'Mail From Institute','Request to Remove',$body);
						redirect(base_url('dashboard'));						
						}else{
						$this->session->set_flashdata('msgrme','<p class="alert alert-danger"><a href="#" class="close" data-dismiss="alert" aria-label="close">×</a> Invalid Student Removed Request!</p>');
						redirect(base_url('dashboard'));
						}
						
				}
		
		}		
		
		
		
                    
		$this->load->view('frontend/public/header');
		$this->load->view('frontend/public/approve-student');
        $this->load->view('frontend/public/footer');
                
	}
	
	public function studentemailcheck()
		{
			
			$email=$this->input->post('email');
          	if(filter_var($email, FILTER_VALIDATE_EMAIL))
			{	
			 $echeck=$this->main_model->student_emailcheck($email);
			 $pricedata=$this->main_model->approve_emailcheck($email);	
			//var_dump($pricedata);
			 if($echeck > 0){
			 if($pricedata > 0)
			 {
				 
				 $msg="<span style='color:green'>Email is available to add with you.</span>";
			 }
			 else
			 {
				 $msg="<span style='color:red'>Email allready exist.</span>";
			 }
			}
			else
			{
				$msg="<span style='color:red'>Email Doesn't Exist Anymore?</span>";
			}
			 
			}
			else
			{
				$msg="<span style='color:red'>Enter valid email id.</span>";
			}	
			echo $msg; 
		}
		
		//05-02-19
		public function add_syllabus(){
		if($this->session->userdata('user_id')=='')
        {
            redirect(base_url()); 
        }
		$usrid=$this->session->userdata('user_id');
		
        if(isset($_POST['submit'])){
			    
				$this->form_validation->set_rules('syllb_name', 'Syllabus Name', 'required');
				$this->form_validation->set_rules('class_type', 'Subkect', 'required');
				$this->form_validation->set_rules('class_name', 'Class Name', 'required');
				//$this->form_validation->set_rules('t_name', 'Search Field', 'required');
										
	
				if($this->form_validation->run())
				{   
			         $userid = $this->session->userdata('user_id');
					
					   $data['yl']=$this->main_model->save_syllabus_institute($userid);					
                       $this->session->set_flashdata('msgsyl','<p class="alert alert-success"><a href="#" class="close" data-dismiss="alert" aria-label="close">×</a> Syllabus Added successfully!</p>');						
						
						redirect(base_url('dashboard'));
				}
		
		}
        $obj=$this->english;
        //$objdata["obj"]= $obj;                
        $data['year_dtl']=$this->main_model->student_class($obj,'master_class');		
                      
		$this->load->view('frontend/public/header');
		$this->load->view('frontend/public/add-syllabus',$data);
        $this->load->view('frontend/public/footer');
                
	}
    public function classnamecheck(){
		if(!empty($_POST['cls_type'])){
		$clstype=$_POST['cls_type'];	
		
		$clstype=$_POST['cls_type'];
		$year_id=$_POST['id'];
		$rsname=$_POST['search_data'];
        $obj=$this->$clstype;		
/* 		$SylList=$this->main_model->get_detail($obj,'master_skill',array('skill_class'=>$year_id,'skill_parent'=>'0'),$insgle=null,'skill_order','asc'); */
$SylList=$this->main_model->get_detail($obj,'master_skill',array('skill_parent'=>'0'),$insgle=null,'skill_order','asc');

				if (!empty($SylList))
     {
          foreach ($SylList as $SylListDetail):
		  $parent_skill=$SylListDetail->skill_id;
          $subskill=$this->main_model->get_detail_topic($obj,'master_skill',$rsname,array('skill_class'=>$year_id,'skill_parent'=>$parent_skill),$insgle=null,'skill_order','asc');
                                   $j=1;
               foreach($subskill as $subskilldatail): 
               echo "<li><a href='#'>" . $subskilldatail->skill_name . "</a>"."<input type='checkbox' name='skill_id[]' value='".$subskilldatail->skill_id."'>"."<input type='hidden' name='skill_name[]' value='".$subskilldatail->skill_name."'>"."<input type='hidden' name='skill_slug[]' value='".$subskilldatail->skill_slug."'>"."<input type='hidden' name='cls_name' value='".$clstype."'>"."<input type='hidden' name='yr_name' value='".$subskilldatail->skill_class."'></li>";
		  endforeach;	   
          endforeach;
       }else
     {
           echo "<li> <em> Not found ... </em> </li>";
     }
		}  
     else
     {
           echo "<li> <em> Not found ... </em> </li>";
     }
	
	}
  
     
    //05-03-19
  
   public function institute_syllabus_list(){
		if($this->session->userdata('user_id')=='')
        {
            redirect(base_url()); 
        }
		$usrid=$this->session->userdata('user_id');		                
        $data['syl_lst']=$this->main_model->institute_syllabus_details('inst_syllabus',$usrid);            
		$this->load->view('frontend/public/header');
		$this->load->view('frontend/public/institute-syllabus-list',$data);
        $this->load->view('frontend/public/footer');
                
	}
   
   public function delete_inst_syllabus($id)
   {
	  
	  $delskill=$this->main_model->delete_sylskill_inst('inst_skill','sid',$id);
	  if($this->main_model->delete_syl_inst('inst_syllabus','sid',$id)){
		$this->session->set_flashdata('msgdelinst','<p class="alert alert-danger"><a href="#" class="close" data-dismiss="alert" aria-label="close">×</a> Syllabus deleted successfully.</p>'); 
		}
		redirect(base_url('institute-syllabus-list')); 
   }  

//05-06-19
   
	public function student_question_list(){
		if($this->session->userdata('user_id')=='')
        {
            redirect(base_url()); 
        }
		$prntid=$this->session->userdata('parent_id');
		$userid=$this->session->userdata('user_id');
		$usrcls=$this->main_model->user_class_name($userid,'main_user');
		$clsid=$usrcls->class_name;		
        $data['ques_lst']=$this->main_model->student_question_details('inst_skill',array('user_id'=>$prntid));  
        /* echo '<pre>';
		print_r($data['ques_lst']);die;
		echo '</pre>';	 */	
		$this->load->view('frontend/public/header');
		$this->load->view('frontend/public/institute-question',$data);
        $this->load->view('frontend/public/footer');
                
	}
	
	//05-07-19
	
	public function math_inst($year="",$slug=""){
		//echo 'hello';
		if($this->session->userdata('user_id')=='')
        {
            redirect(base_url()); 
        }
        if($this->uri->segment(1)=='math_inst')
                {
				$ctype="math";	
                $obj=$this->math;
                $objdata["obj"]= $obj;  
                }elseif($this->uri->segment(1)=='english_inst'){
                 $obj=$this->english;
                 $objdata['obj'];   
                }
				$prntid=$this->session->userdata('parent_id');
                $year=$this->uri->segment(2);
                $data['class_slug']=$year;
                $data['year']=$this->uri->segment(2);
                
                $year_id=$this->main_model->getsid(TBL_CLASS,$objdata['obj'],$year); 
               $data['year_id']=$year_id;
                $data['year_dtl']=$this->main_model->get_detail($obj,TBL_CLASS,array('class_id'=>$year_id),"single"); 
                //$data['SylList']=$this->main_model->get_detail($obj,'master_skill',array('skill_class'=>$year_id,'skill_parent'=>'0'),$insgle=null,'skill_order','asc');
				$data['ques_lst']=$this->main_model->student_question_details('inst_skill',array('	year_id'=>$year_id,'user_id'=>$prntid,'class_type'=>$ctype));
                /* echo '<pre>';
		print_r($data['ques_lst']);die;
		echo '</pre>'; */	  
                   $this->load->view('frontend/public/header');
                   $this->load->view('frontend/public/inst_syllabus_list',$data);
                   $this->load->view('frontend/public/footer');
                
	}
	
public function english_inst($year="",$slug=""){
		
		if($this->session->userdata('user_id')=='')
        {
            redirect(base_url()); 
        }
        if($this->uri->segment(1)=='math_inst')
                {
				$ctype="math";	
                $obj=$this->math;
                $objdata["obj"]= $obj;  
                }elseif($this->uri->segment(1)=='english_inst'){
				 $ctype="english";	
                 $obj=$this->english;
                 $objdata["obj"]= $obj;   
                }
				$prntid=$this->session->userdata('parent_id');
                $year=$this->uri->segment(2);
                $data['class_slug']=$year;
                $data['year']=$this->uri->segment(2);
                
                $year_id=$this->main_model->getsid(TBL_CLASS,$objdata['obj'],$year); 
                $data['year_id']=$year_id;
                $data['year_dtl']=$this->main_model->get_detail($obj,TBL_CLASS,array('class_id'=>$year_id),"single"); 
                //$data['SylList']=$this->main_model->get_detail($obj,'master_skill',array('skill_class'=>$year_id,'skill_parent'=>'0'),$insgle=null,'skill_order','asc');
				$data['ques_lst']=$this->main_model->student_question_details('inst_skill',array('	year_id'=>$year_id,'user_id'=>$prntid,'class_type'=>$ctype));
                /* echo '<pre>';
		print_r($data['ques_lst']);die;
		echo '</pre>'; */	  
                   $this->load->view('frontend/public/header');
                   $this->load->view('frontend/public/inst_syllabus_list',$data);
                   $this->load->view('frontend/public/footer');
		
        
	}
	
	/*get state name by id*/
	public function all_country_list(){
		
        //print_r($_POST);		
        $data['country_lst']=$this->main_model->county_all('countries');            
		//var_dump($data['state_lst']);		
		$data['success'] = true; 
		echo json_encode($data);die;
                
	}
	public function all_states_list($country_id=""){
		$country_id=$_POST['country_id'];
        //print_r($_POST);		
        $data['state_lst']=$this->main_model->country_state_name($country_id,'states');            
		//var_dump($data['state_lst']);		
		$data['success'] = true; 
		echo json_encode($data);die;
                
	}
	
	/*----For Chinese----*/
	public function user_chinese($year="",$slug="")
	{
		$data=array();
		
		$this->load->view('frontend/public/header');
		$this->load->view('frontend/public/chinese-classes','');
        $this->load->view('frontend/public/footer');
		
	}	
	/*----End For Chinese----*/
	
	/*----For chemistry----*/
	public function user_chemistry($year="",$slug="")
	{
		$data=array();
		
		$this->load->view('frontend/public/header');
		$this->load->view('frontend/public/chemistry-classes','');
        $this->load->view('frontend/public/footer');
		
	}	
	/*----End For chemistry----*/
	
	/*----For physics----*/
	public function user_physics($year="",$slug="")
	{
		$data=array();
		
		$this->load->view('frontend/public/header');
		$this->load->view('frontend/public/physics-classes','');
        $this->load->view('frontend/public/footer');
		
	}	
	/*----End For physics----*/
	
	/*----For biology----*/
	public function user_biology($year="",$slug="")
	{
		$data=array();
		
		$this->load->view('frontend/public/header');
		$this->load->view('frontend/public/biology-classes','');
        $this->load->view('frontend/public/footer');
		
	}	
	/*----End For biology----*/
	
	/*----For spanish----*/
	public function user_spanish($year="",$slug="")
	{
		$data=array();
		
		$this->load->view('frontend/public/header');
		$this->load->view('frontend/public/spanish-classes','');
        $this->load->view('frontend/public/footer');
		
	}	
	/*----End For spanish----*/
	
	
	/*----For test----*/
	public function user_test()
	{
		$data=array();
		
$this->load->view('frontend/public/header-test');
		$this->load->view('frontend/public/test/index','');
		 $this->load->view('frontend/public/footer');
       
		
	}	
	/*----End For test----*/
/*------ add syllabus skill by inst----*/
		public function add_syllabus_skills($id=''){
		if($this->session->userdata('user_id')=='')
        {
            redirect(base_url()); 
        }
		$usrid=$this->session->userdata('user_id');
		
        if(isset($_POST['submit'])){
			    
			
				$this->form_validation->set_rules('class_name', 'Class Name', 'required');
				//$this->form_validation->set_rules('t_name', 'Search Field', 'required');
										
	
				if($this->form_validation->run())
				{   
			         $userid = $this->session->userdata('user_id');
					 $post = $this->input->post();
					extract($post);
					 if($mysubskill)
					 {
						$sid=$sid;
						$year_id=$year_id;
						$user_id=$user_id;
						$skill_year=$class_name;
						
						if($class_type=='math')
						{
						$obj=$this->math;
						$objdata["obj"]= $obj;  
						}
						elseif($class_type=='english')
						{
						 $obj=$this->english;     
						} 
						 $dt=date('y-m-d h:i:s');
						 foreach($mysubskill as $subskill)
						 {
							   $skillinfo=$this->main_model->get_detail($obj,'master_skill',array('skill_class'=>$skill_year,'skill_id'=>$subskill),"single"); 
							   $skill_parent=$skillinfo->skill_parent;
							   $skill_name=$skillinfo->skill_name;
							   $skill_slug=$skillinfo->skill_slug;
							   
							   $data=array(
									'sid'     =>  $sid,	
						            'year_id'     =>  $year_id,
									'skill_id'    =>  $subskill,
                                    'skill_name'  =>  $skillinfo->skill_name,
									'skill_slug'  =>  $skillinfo->skill_slug,
									'user_id'     =>  $user_id,
                                    'createdon'   =>  $dt,
                                    'class_type'  =>  $class_type,
                                    'skill_year'  =>  $skill_year,
									'skill_parent'  =>  $skill_parent,		
  									); 
					
									
						
						$qry=$this->db->insert('inst_skill',$data);		
							 
						 }
						 
					 }
					
					   //$data['yl']=$this->main_model->save_syllabus_institute($userid);					
                       $this->session->set_flashdata('msgsyl','<p class="alert alert-success"><a href="#" class="close" data-dismiss="alert" aria-label="close">×</a> Syllabus Added successfully!</p>');						
						
						redirect(base_url('dashboard'));
				}
		
		}
        $obj=$this->english;
        //$objdata["obj"]= $obj;                
        $data['year_dtl']=$this->main_model->student_class($obj,'master_class');
		$data['sylb_info']=$this->main_model->get_syllabusinfo($obj,$id,$usrid);	
                      
		$this->load->view('frontend/public/header');
		$this->load->view('frontend/public/add-syllabus-skills',$data);
        $this->load->view('frontend/public/footer');
                
	}
/*-----end of add syllabus skill by inst---*/	


	public function inst_syllabus_skills($sid=""){
		//echo 'hello';
		if($this->session->userdata('user_id')=='')
        {
            redirect(base_url()); 
        }
		$userid=$this->session->userdata('user_id');
		 $obj=$this->english;
		
		$syllinfo=$this->main_model->get_syllabusinfo($obj,$sid,$userid); 
		$data['syllinfo']=$syllinfo;
        if($this->uri->segment(1)=='math_inst')
                {
				$ctype="math";	
                $obj=$this->math;
                $objdata["obj"]= $obj;  
                }elseif($this->uri->segment(1)=='english_inst'){
                 $obj=$this->english;
                 $objdata['obj'];   
                }
				$prntid=$this->session->userdata('parent_id');
                $year=$this->uri->segment(2);
                $data['class_slug']=$year;
                $data['year']=$this->uri->segment(2);
                
                //$year_id=$this->main_model->getsid(TBL_CLASS,$objdata['obj'],$year); 
               $data['year_id']=$syllinfo->year_id;
               /*  $data['year_dtl']=$this->main_model->get_detail($obj,TBL_CLASS,array('class_id'=>$syllinfo->year_id),"single");  */
                //$data['SylList']=$this->main_model->get_detail($obj,'master_skill',array('skill_class'=>$year_id,'skill_parent'=>'0'),$insgle=null,'skill_order','asc');
				$data['ques_lst']=$this->main_model->student_question_details('inst_skill',array('sid'=>$sid));
                /* echo '<pre>';
		print_r($data['ques_lst']);die;
		echo '</pre>'; */	  
                   $this->load->view('frontend/public/header');
                   $this->load->view('frontend/public/inst_syllabus_skills',$data);
                   $this->load->view('frontend/public/footer');
                
	}
	
}
