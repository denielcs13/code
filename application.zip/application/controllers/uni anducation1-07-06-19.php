<?php
defined('BASEPATH') OR exit('No direct script access allowed');
error_reporting(E_ALL);
ini_set('display_errors',1);
header('Content-type: text/html; charset=utf-8');
class Unieducation extends MY_Controller {

	public function __construct()
    {
		parent::__construct();
			$this->load->library(array('session'));
			
			$this->load->helper('form');
			$this->load->helper(array('url','form'));
			//$this->load->helper('question_helper');
			//$this->load->helper('get_counter_helper');
			$this->load->model('Login_model');	
			//$this->load->model('classes_model');
//			$this->load->model('center_model');	
//			$this->load->model('User_model');
//			$this->load->model('syllabus_model');
//			$this->load->model('questions_model');	
//			$this->load->model('weeks_model');
//			$this->load->model('students_model');
//			$this->load->model('plan_model');
//			$this->load->model('order_model');
//			$this->load->model('exam_model');
//			$this->load->model('skill_model');
//			$this->load->model('years_model');			
					
			$this->load->database();				
				
			//date_default_timezone_set('America/New_York');
			date_default_timezone_set('Pacific/Auckland');
			$this->load->library("pagination");			
			$this->load->library('form_validation');
			//$this->load->library("Pdf");
			/*---after ats payment update user current year---*/
			if($this->uri->segment(1)=='order-history')
			{
				
				if($this->session->userdata('user_id')!="")
				{
					$sqlchkuyear=$this->db->query("select year_id from user_details where user_id='".$this->session->userdata('user_id')."'");
					$row_chkuyear=$sqlchkuyear->row();					
					$this->session->set_userdata('loginyear', $row_chkuyear->year_id);			
					
					
				}
			}
			/*---end of after ats payment update user current year---*/
			
    }
	public function index($year='')
	{	
	
		if($year!=""){
			$data["year"]=$year;
			$data["year_dtl"] = $this->main_model->get_detail('master_class','class_slug',$year);	
			$year_id=$data["year_dtl"]->class_id;
			$this->questions_model->CLASSID = $year_id;
			$data["year"]=$year;
			
			
		}
		
		
		  
		$data['error']='';
		$this->load->view('frontend/public/index',$data);
		
	}
	public function error()
	{
		//$this->load->view('frontend/public/page_system_404.php');
	}

	public function _404(){
		$yearid=$this->session->userdata('loginyear');
			$yeardata=$this->classes_model->classes_details($yearid);
			if($yeardata)
			{
				$data['year_name']=$yeardata[0]->class_name;
				$data['year_slug']=$yeardata[0]->class_slug;
			}
		$this->load->view("frontend/public/404");
	}
	
	public function login()
	{
		
		$this->form_validation->set_rules('username', 'login ID', 'required');
		$this->form_validation->set_rules('password', 'Password', 'required');		
		if($this->form_validation->run())
		{
			
			$username = $this->input->post('username');
			$password = $this->input->post('password');
			$user_type = $this->input->post('user_type');
			$data=array('val'=>'',
						'table'=>'user_details',
						'where'=>array('user_name'=>$username,'password'=>md5($password),'status'=>'1'),
						'where_in'=>'user_type',array('6','3')
						);
			$res=$this->Login_model->signin($data);			
			
			if ($res['res']) 
			{	
				if($res['rows']->lastlogin!='' && $res['rows']->lastlogin!=null)
				{	
					$lastlogintime = strtotime($res['rows']->lastlogin);				
					$mylastlogin = date("m/d/y g:i A", $lastlogintime);
				}
				else
				{
					$mylastlogin='';
				}
				
				$userlogindata = array( 
									'username' => $res['rows']->user_name,
									'logged_in' => true,
									'user_id' => $res['rows']->user_id,
									'email' => $res['rows']->email,
									'user_type'=>$res['rows']->user_type,
									'fullname'=>$res['rows']->first_name.' '.$res['rows']->last_name,
									'lastlogedin'=>$mylastlogin,
									'loginyear'=>$res['rows']->year_id,
									'department_id'=>$res['rows']->department_id
									);						
				$this->session->set_userdata($userlogindata);
				$logindate=date("Y-m-d H:i:s");
				$lastlogin_data=array(					
							'lastlogin'=>$logindate	
							
							);	
				
				$lastlogin=$this->Login_model->lastlogin($lastlogin_data);
				
			redirect(base_url().'dashboard');
				
								
			} 
			else
			{
				$data['error']='Sorry your login ID and password did not match.<br/> <br/>Please try again.';
				$this->load->view('frontend/public/login',$data);
			}	
			
		}		
		else
		{
		$data['error']='';
		$this->load->view('frontend/public/login',$data);

		}	
		
	}
	
	
	
	
	public function logout() 
	{		
		$data = new stdClass();			
		@session_destroy();
		//redirect(BASE_URL,'redirect');
		$this->session->unset_userdata('username');
		$this->session->unset_userdata('user_id');
		$this->session->sess_destroy();
		$this->load->view('frontend/private/logout');
		
	}	
	
	public function whoarewe() 
	{		
		$this->load->view('frontend/public/who-are-we');
		
	}
	public function admissions() 
	{		
		$this->load->view('frontend/public/admissions');
		
	}
	public function students() 
	{		
		$this->load->view('frontend/public/students');
		
	}
	public function parents() 
	{		
		$this->load->view('frontend/public/parents');
		
	}
	public function curriculum() 
	{		
		$this->load->view('frontend/public/curriculum');
		
	}
	public function bookingpayment() 
	{		
	if($this->session->userdata('username')!='')
		{		
			
			$userid=$this->session->userdata('user_id');
			$yearid=$this->session->userdata('loginyear');
			$user_year=$this->User_model->user_year($userid);
			$year_id=$user_year->year_id;			
			$yeardata=$this->classes_model->classes_details($year_id);
			if($yeardata)
			{
				$data['year_name']=$yeardata[0]->class_name;
				$data['year_slug']=$yeardata[0]->class_slug;
			}
			$config["base_url"] =  BASE_URL_ADMIN. "order-history";
			$config["total_rows"] = $this->order_model->orderlist_currentyear_count($year_id,$userid);
			$config["per_page"] = 20;
			
			$this->pagination->initialize($config);

			$page = ($_REQUEST['page']) ? $_REQUEST['page'] : 0;
			$data["orderlist"] = $this->order_model->orderlist_currentyear($config["per_page"], $page,$year_id,$userid);
			$data["classlist"] = $this->main_model->getall('seat_allotment_info','user_id',$userid);
			$data["links"] = $this->pagination->create_links();
			$data['aatcount']=$this->exam_model->checkuser_aat_status($yearid,$userid);
			$this->load->view('frontend/private/booking-payment',$data);
		}
		else
		{
			redirect(base_url().'login');
		}
		
		
	}
	
	public function forgotpassword() 
	{		
		$this->form_validation->set_rules('emailid', 'Login ID', 'required');
		
		if($this->form_validation->run())
		{
			$emailid = $this->input->post('emailid');
			
			$data=array('val'=>'',
						'table'=>'user_details',
						'where'=>array('user_name'=>$emailid,'status'=>'1','user_type'=>'6')
						);
			$res=$this->Login_model->signin($data);			
			
			if ($res['res']) 
			{	
				
				
				
				$password=$this->random_password();
			
				$user_data=array(							
							'password'=>md5($password)						
							
							);	
	            $userid=$this->User_model->Save_Password($user_data,$res['rows']->user_id);
				$data1['fullname']=$res['rows']->first_name;
				$data1['username']=$res['rows']->user_name;
				$data1['password']=$password;
				
				$this->load->library('email');
				$config = array (
				'mailtype' => 'html',
				'charset' => 'utf-8',
				'priority' => '1'
				);
				$this->email->initialize($config);
				
				$senderemail=$res['rows']->email;
			
				$body = $this->load->view('emails/forgotpassword',$data1,TRUE);
				$this->email->from(basic_from_email, basic_from_name);
				$this->email->to($senderemail);
				$this->email->subject(forgotpassword_subject.' '.$res['rows']->user_name.' '.site_name);
				$this->email->message($body);
				$this->email->send();
				
				$data['success']='Password sent to your email. Please check your inbox.';
			
				
								
			} 
			else
			{
				$data['error']='Login ID not found.';
				
			}
		}
		else
		{
			$data['error']='';
		}
		
		$this->load->view('frontend/public/forget-password',$data);
		
	}
		
	public function mediaevent() 
	{	
		$this->load->view('frontend/public/event');
		
	}
	public function register() 
	{		
		
	
				/*----Submit registration----*/
		
		$this->form_validation->set_rules('reg_email', 'Student’s Email', 'required|valid_email');	
		$this->form_validation->set_rules('reg_fname', 'Student’s First Name', 'required');
		$this->form_validation->set_rules('reg_lname', 'Student’s Last Name', 'required');
		$this->form_validation->set_rules('reg_year', 'Year', 'required');		
								
		if($this->form_validation->run())
		{	
			if(($this->input->post('reg_year')==1) ||($this->input->post('reg_year')>9)){
				$this->session->set_flashdata('msg','Unfortunately, we are only offering English classes for year 1-8 students at the moment. We will make announcement once other years are also opened for enrolment. Please stay with us and thank you for your support.');
				redirect(BASE_URL.'register');
				exit;
			}
			//Check mail existence
			/* $row_user=$this->main_model->get_detail('user_details','email',$this->input->post('reg_email'));
			if($row_user->user_id!=""){
				$this->session->set_flashdata('msg','This email id already exist');
			} */
			
			$createdate=date("Y-m-d H:i:s");
			$password=$this->random_password();
			
			$user_data=array(
							'email'=>$this->input->post('reg_email'),
							'user_type'=>'6',
							'user_name'=>$this->input->post('reg_userid'),
							'first_name'=>$this->input->post('reg_fname'),							
							'last_name'=>$this->input->post('reg_lname'),							
							'phone'=>$this->input->post('reg_mobile'),
							'edate'=>$createdate,
							'status'=>'1',
							'password'=>md5($password),
							'address'=>$this->input->post('reg_address'),
							'state'=>$this->input->post('reg_state'),
							'city'=>$this->input->post('reg_city'),
							'zipcode'=>$this->input->post('reg_zipcode'),
							'year_id'=>$this->input->post('reg_year'),
							'center_id'=>$this->input->post('reg_center'),	
							'paystatus'=>'complete'
							
							);	
	           $userid=$this->User_model->Save_Update($user_data);
			   if($userid!="" && $userid!=null)
			   {
					/*-----Add user payment detail------*/
					
					$user_pay=array(
							'pay_userid'=>$userid,
							'pay_yearid'=>$this->input->post('reg_year'),
							'pay_location'=>$this->input->post('reg_center'),
							'pay_amount'=>'',							
							'pay_status'=>'complete',							
							'pay_date'=>$createdate
							
							);
						$payid=$this->User_model->Save_payment($user_pay);	
						if($payid!="")
						{
							
							$this->load->library('email');
							$config = array (
							'mailtype' => 'html',
							'charset' => 'utf-8',
							'priority' => '1'
							);
							$this->email->initialize($config);
							$senderemail=$this->input->post('reg_email');
							$emailarr=explode('@',$senderemail);
							global $class_arr;
							$username=$emailarr[0].'E'.$class_arr[$this->input->post('reg_year')].rand(10,99);
							/*----update user id----*/
							$r=false;
							while($r==false){
								$row_uname=$this->main_model->get_detail('user_details','user_name',$username);
								if($row_uname==""){
									$r=true;
								}
								else{
									$username=$emailarr[0].'E'.$class_arr[$this->input->post('reg_year')].rand(10,99);
								}
							}
							/*----update user id----*/
								$username_data=array(
							'user_name'=>$username							
							);
						$userquery=$this->User_model->update_staff($userid,$username_data);	
							/*----end of update user id----*/
							
							$data['firstname']=$this->input->post('reg_fname');
							$data['fullname']=$this->input->post('reg_fname').' '.$this->input->post('reg_lname');
							$data['username']=$username;
							$data['password']=$password;
							$body = $this->load->view('emails/signup-to-student',$data,TRUE);
							//$this->email->from('info@maths.com', 'maths');
							$this->email->from(basic_from_email, basic_from_name);
							$this->email->to($senderemail);
							$this->email->subject(register_subject);
							$this->email->message($body);
							$this->email->send();
							redirect(BASE_URL.'registered');
	
	/*						
							
 <!--<form name="myForm" id="myForm" method="post" class="form-horizontal" role="form" action="paypal/create_payment_with_paypal">
                    <fieldset>
                        <input title="item_name" name="item_name" type="hidden" value="ahmed fakhr">
                        <input title="item_number" name="item_number" type="hidden" value="12345">
                        <input title="item_description" name="item_description" type="hidden" value="to buy samsung smart tv">
                        <input title="item_tax" name="item_tax" type="hidden" value="1">
                        <input title="item_price" name="item_price" type="hidden" value="7">
                        <input title="details_tax" name="details_tax" type="hidden" value="7">
                        <input title="details_subtotal" name="details_subtotal" type="hidden" value="7">

                        <div class="form-group">
                            <div class="col-sm-offset-5">
                                <input type="submit" name="submit" value="Submit" />
                            </div>
                        </div>
                    </fieldset>
                </form>

    <script>

    var auto_refresh = setInterval(
    function()
    {
    submitform();
    }, 10000);

    function submitform()
    {
      alert('test');
      document.myForm.submit();
    }
    </script>-->*/
						
							
						}
							
					/*----End of Add user payment detail-----*/
			   }
			   
			
		}
		/*----End Submit registration----*/
		$data['year_list']=$this->classes_model->classes_dropdown();
		$data['center_list']=$this->center_model->center_dropdown();
		
		$this->load->view('frontend/public/register',$data);
		
	}
	public function kg($subskill='') 
	{	
		
		$yearid=$this->session->userdata('loginyear');
			$yeardata=$this->classes_model->classes_details($yearid);
			if($yeardata)
			{
				$data['year_name']=$yeardata[0]->class_name;
				$data['year_slug']=$yeardata[0]->class_slug;
			}
		$year_id=1;
		$data['year_id']=$year_id;
		
		$userid2=$this->session->userdata('user_id');			
		$data['aatcount']=$this->exam_model->checkuser_aat_status($yearid,$userid2);
		
		$this->questions_model->CLASSID = $year_id;
		$data["year_dtl"] = $this->main_model->get_detail('master_class','class_id',$year_id);	
		if($subskill!=""){
			/*---Start Assessment Test -----*/
				if($subskill=="assessment")
			{		
					 $this->session->set_userdata('attempt_ques', 0);
					 
					 //Page reload truncate table
					if($this->session->userdata('ass_attempt') > 0)
					{
					$checkasstest=$this->db->query("select exam_status from student_assessment_test  where year_id='".$year_id."' and user_id='".$this->session->userdata('user_id')."' 
							");
					$rowchecktest_status=$checkasstest->row();
					if($rowchecktest_status->exam_status=='pending')
					{						
					$del_asshistory=$this->db->query("delete  from sasstest_history  where year_id='".$year_id."' and user_id='".$this->session->userdata('user_id')."' 
							");
					$del_assmasterhistory=$this->db->query("delete  from student_assessment_test  where year_id='".$year_id."' and user_id='".$this->session->userdata('user_id')."' 
							");	
					$data['err_reload']=1;	
					$this->session->unset_userdata('ass_attempt');	
					}
					else
					{
						$data['err_reload']='';
					}						
					}
					else
					{
						$data['err_reload']='';	
					}
					
					/*---get all past year of assessment list----*/
					$pastyear=$this->questions_model->assessment_pastyear($year_id);
						/*echo '<pre>';
						var_dump($pastyear);
						echo '</pre>';
						*/
					$todaydate=date("Y-m-d H:i:s");	
					$userid=$this->session->userdata('user_id');
					$asstime_query=$this->questions_model->assessment_time($year_id,$userid);
					$yourstart=$asstime_query->start_time;
					if($yourstart!="" && $yourstart!=null)
					{
						$seconds = strtotime($todaydate) - strtotime($yourstart);
						$days    = floor($seconds / 86400);
						$hours   = floor(($seconds - ($days * 86400)) / 3600);
						$minutes = floor(($seconds - ($days * 86400) - ($hours * 3600))/60);
						
						if($minutes >30)
						{
							//echo $minutes;
							$exam_status=array(
								'exam_status'=>'pass',							
								'end_time'=>$todaydate,
								);
						
						$updateexam_status=$this->questions_model->Update_Asstterm_status($exam_status,$asstime_query->exam_id);
						$data['timeover']=1;
						}
						else
						{
							$totalminutes=30-$minutes;
							$data['showtimer']='Duration Left: '.$totalminutes;
						}
					}
					else
					{
						$data['showtimer']='Duration: 30';
					}
					
					/*---end of get all past year of assessment list----*/	
					if($this->input->post('action')=='submitanswer')	
					{
						//var_dump($this->input->post());
					$this->session->unset_userdata('ass_attempt');	
					 $questionid=$this->input->post('questionid');
					 $answerid=$this->input->post('answerid');
					 $year_id=$this->input->post('year_id');
					 $ass_year_id=$this->input->post('ass_year_id');
				
					
					$data["ques_dtl"] = $this->main_model->get_detail('manage_question_'.$ass_year_id,'ques_id',$questionid);					
					//var_dump($data["ques_dtl"]);
					$data["correct_ans"] = $this->main_model->get_detail('manage_answer_'.$ass_year_id,'ans_id',$data["ques_dtl"]->ques_rightanswer);					
										
					if($data["ques_dtl"]->ques_rightanswer==$answerid)
					{
						
						$data['correct']=1;
						/*----insert user exam list---------*/
						
						$createdate=date("Y-m-d H:i:s");
						$chkrow_exam=$this->questions_model->check_userassessment($userid,$year_id,1);	
						
						if($chkrow_exam->exam_id!="" )
						{
							$exam_id=$chkrow_exam->exam_id;
						}
						else
						{
							$user_exam=array(
									'user_id'=>$userid,
									'year_id'=>$year_id,
									'assyear_id'=>$ass_year_id,													
									'exam_date'=>$createdate,
									'start_time'=>$createdate
									
									);
							$exam_id=$this->questions_model->Save_Userassessment($user_exam);	
						}
						
						if($exam_id!="")
						{
							$uexam_history=array(
								'exam_id'=>$exam_id,
								'user_id'=>$userid,
								'year_id'=>$year_id,
								'assyear_id'=>$ass_year_id,													
								'question_id'=>$questionid,
								'answer_id'=>$answerid,
								'answer_status'=>'true',
								
								);
							$historyexam_id=$this->questions_model->Save_Assessmenthistory($uexam_history);		
						}
						
						/*----End of insert user exam list-------*/
										
					/*----Get user exam question array------*/
					$exam_questermArr=array();
					$exam_questions=$this->questions_model->check_asstesthistory_question($userid,$year_id,1);
					if($exam_questions)
					{
						
						foreach($exam_questions as $examdata)
						{
							array_push($exam_questermArr,$examdata->question_id);
						}
					}
					
					if($year_id ==1)
						{
							$firstyear=$year_id;
							$secondyear=$year_id;
						}
						else if($year_id ==2)
						{
							$firstyear=$year_id-1;
							$secondyear=$year_id-1;
						}
						else if($year_id >2)
						{
							$firstyear=$year_id-2;
							$secondyear=$year_id-1;
						}
						
					/*----End of get user exam question array----*/
					$term_questermArr=array();
					$term_questions=$this->questions_model->assessment_exam($year_id,1);
					if($term_questions)
					{
						
						foreach($term_questions as $tquestion)
						{
							array_push($term_questermArr,$tquestion->ass_question);
						}
						
					}
					$total_exam_question=count($exam_questermArr);
					$total_term_question=count($term_questermArr);
					/*---update term by exam completed status----*/
					if($total_term_question==$total_exam_question)
					{
						$exam_status=array(
								'exam_status'=>'pass',							
								'end_time'=>$createdate,
								);
						
						$updateexam_status=$this->questions_model->Update_Asstterm_status($exam_status,$exam_id);
						$data['completed']=1;
					}
					/*---update term by exam completed status----*/
					$exam_output = array_merge(array_diff($term_questermArr, $exam_questermArr), array_diff($exam_questermArr, $term_questermArr));
					$exam_random=array_rand($exam_output);
					$randquestion=$exam_output[$exam_random];
					/* $exam_random=array_shift($exam_output);		
					$randquestion=$exam_random; */
					/*---End of check user not applied question list---*/
					$data['Questionlist']=$this->questions_model->asstest_exam_question($year_id,1,$randquestion);
						//$data['Questionlist']=$this->questions_model->term_exam($year_id,1);
						$data['exam_id']=$exam_id;
						$this->load->view('frontend/private/assessmentplay',$data);

					}
					else
					{
			
						/*----insert user exam list---------*/
						$userid=$this->session->userdata('user_id');
						$createdate=date("Y-m-d H:i:s");
						$chkrow_exam=$this->questions_model->check_userassessment($userid,$year_id,1);	
						
						if($chkrow_exam->exam_id!="" )
						{
							$exam_id=$chkrow_exam->exam_id;
						}
						else
						{
							$user_exam=array(
									'user_id'=>$userid,
									'year_id'=>$year_id,
									'assyear_id'=>$ass_year_id,													
									'exam_date'=>$createdate,
									'start_time'=>$createdate
									
									);
							$exam_id=$this->questions_model->Save_Userassessment($user_exam);	
						}
						
						if($exam_id!="")
						{
							$uexam_history=array(
								'exam_id'=>$exam_id,
								'user_id'=>$userid,
								'year_id'=>$year_id,
								'assyear_id'=>$ass_year_id,													
								'question_id'=>$questionid,
								'answer_id'=>$answerid,
								'answer_status'=>'false',
								
								);
							$hexam_id=$this->questions_model->Save_Assessmenthistory($uexam_history);		
						}
						
								/*----Get user exam question array------*/
					$exam_questermArr=array();
					$exam_questions=$this->questions_model->check_asstesthistory_question($userid,$year_id,$term_id);
					if($exam_questions)
					{
						
						foreach($exam_questions as $examdata)
						{
							array_push($exam_questermArr,$examdata->question_id);
						}
					}
					
					
					/*----End of get user exam question array----*/
					$term_questermArr=array();
					$term_questions=$this->questions_model->assessment_exam($year_id,1);
					if($term_questions)
					{
						
						foreach($term_questions as $tquestion)
						{
							array_push($term_questermArr,$tquestion->ass_question);
						}
						
					}
					$total_exam_question=count($exam_questermArr);
					$total_term_question=count($term_questermArr);
					/*---update term by exam completed status----*/
					if(30==$total_exam_question)
					{
						$exam_status=array(
								'exam_status'=>'pass',
								'end_time'=>$createdate,	
								
								);
						
						$updateexam_status=$this->questions_model->Update_Asstterm_status($exam_status,$exam_id);
						$data['completed']=1;
					}
					/*---update term by exam completed status----*/
						
						/*----End of insert user exam list-------*/
					
						$data["yourans"] = $this->main_model->get_detail('manage_answer_'.$ass_year_id,'ans_id',$answerid);	
						$data['exam_id']=$exam_id;
						$this->load->view('frontend/private/asstestexplanation',$data);
					}
					
								
					}
				else
				{
					$userid=$this->session->userdata('user_id');
					/*---check user not applied question list---*/
					$userexams=$this->questions_model->check_uasstestbyyear($userid,$year_id);
					$data['exam_id']=$userexams->exam_id;
					if($userexams->exam_id!="" && $userexams->exam_status=='pending')
					{	
						$data['assyear_id']=$userexams->assyear_id;
					}
					
					else if($userexams->exam_id!="" && $userexams->exam_status=='pass')
					{	
						$data['assyear_id']=$userexams->assyear_id+1;
					}
				
					else
					{
						$data['assyear_id']=$pastyear[0]->ass_year_id;
						//echo $pastyear[0]->ass_year_id;
					}
					
					/*----Get user exam question array------*/
					$exam_questermArr=array();
					$exam_questions=$this->questions_model->check_asstesthistory_question($userid,$year_id,1);
					if($exam_questions)
					{
						
						foreach($exam_questions as $examdata)
						{
							array_push($exam_questermArr,$examdata->question_id);
						}
					}
					
					
					/*----End of get user exam question array----*/
					
					if($year_id ==1)
						{
							$firstyear=$year_id;
							$secondyear=$year_id;
						}
						else if($year_id ==2)
						{
							$firstyear=$year_id-1;
							$secondyear=$year_id-1;
						}
						else if($year_id >2)
						{
							$firstyear=$year_id-2;
							$secondyear=$year_id-1;
						}
						
					$term_questermArr=array();
					$term_questions=$this->questions_model->assessment_exam($year_id,1,$firstyear);
					
					if($term_questions)
					{
						
						foreach($term_questions as $tquestion)
						{
							array_push($term_questermArr,$tquestion->ass_question);
						}
						
					}
					//var_dump($term_questermArr);
					
					$exam_output = array_merge(array_diff($term_questermArr, $exam_questermArr), array_diff($exam_questermArr, $term_questermArr));
					$exam_random=array_rand($exam_output);
					$randquestion=$exam_output[$exam_random];
					/* $exam_random=array_shift($exam_output);
					$randquestion=$exam_random; */
					/*---End of check user not applied question list---*/
					if($userexams->exam_status!='pass')
					{
					$data['Questionlist']=$this->questions_model->asstest_exam_question($year_id,1,$randquestion);
					}
					else
					{
						$data['Questionlist']='';
						$data['completed']=1;
					}
					//var_dump($data['Questionlist']);
					$this->load->view('frontend/private/assessmentplay',$data);
				}
			
			}
		/*---End Assessment Test -----*/
			/*---final year exam-----*/
			else if($subskill=="exam")
			{
				$this->session->set_userdata('ansattempt', '0');
				
			if($this->input->post('action')=='submitanswer')	
					{
					 $questionid=$this->input->post('questionid');
					 $answerid=$this->input->post('answerid');
					 $year_id=$this->input->post('year_id');
					 
					 $term_id=$this->input->post('term_id');
				
					
					$data["ques_dtl"] = $this->main_model->get_detail('manage_question_'.$year_id,'ques_id',$questionid);					
					
					$data["correct_ans"] = $this->main_model->get_detail('manage_answer_'.$year_id,'ans_id',$data["ques_dtl"]->ques_rightanswer);					
										
					if($data["ques_dtl"]->ques_rightanswer==$answerid)
					{
						
						$data['correct']=1;
						/*----insert user exam list---------*/
						$userid=$this->session->userdata('user_id');
						$createdate=date("Y-m-d H:i:s");
						$chkrow_exam=$this->questions_model->check_userexam($userid,$year_id,$term_id);	
						
						if($chkrow_exam->exam_id!="" )
						{
							$exam_id=$chkrow_exam->exam_id;
						}
						else
						{
							$user_exam=array(
									'user_id'=>$userid,
									'year_id'=>$year_id,
									'term_id'=>$term_id,													
									'exam_date'=>$createdate
									
									);
							$exam_id=$this->questions_model->Save_Userexam($user_exam);	
						}
						
						if($exam_id!="")
						{
							$uexam_history=array(
								'exam_id'=>$exam_id,
								'user_id'=>$userid,
								'year_id'=>$year_id,
								'term_id'=>$term_id,													
								'question_id'=>$questionid,
								'answer_id'=>$answerid,
								'answer_status'=>'false',
								
								);
							$historyexam_id=$this->questions_model->Save_Examhistory($uexam_history);		
						}
						
						/*----End of insert user exam list-------*/
						
										/*---check user not applied question list---*/
					$userexams=$this->questions_model->check_uexambyyear($userid,$year_id);
					if($userexams->exam_id!="" && $userexams->exam_status=='pending')
					{	
						$data['term_id']=$userexams->term_id;
					}
					else if($userexams->exam_id!="" && $userexams->exam_status=='pass')
					{	
						$data['term_id']=$userexams->term_id+1;
					}
					else
					{
						$data['term_id']=1;
					}
					
					/*----Get user exam question array------*/
					$exam_questermArr=array();
					$exam_questions=$this->questions_model->check_examhistory_question($userid,$year_id,$data['term_id']);
					if($exam_questions)
					{
						
						foreach($exam_questions as $examdata)
						{
							array_push($exam_questermArr,$examdata->question_id);
						}
					}
					
					
					/*----End of get user exam question array----*/
					$term_questermArr=array();
					$term_questions=$this->questions_model->term_exam($year_id,$data['term_id']);
					if($term_questions)
					{
						
						foreach($term_questions as $tquestion)
						{
							array_push($term_questermArr,$tquestion->question_id);
						}
						
					}
					$total_exam_question=count($exam_questermArr);
					$total_term_question=count($exam_questermArr);
					/*---update term by exam completed status----*/
					if($total_term_question==$total_exam_question)
					{
						$exam_status=array(
								'exam_status'=>'pass',							
								
								);
						
						$updateexam_status=$this->questions_model->Update_Examterm_status($exam_status,$exam_id);
					}
					/*---update term by exam completed status----*/
					$exam_output = array_merge(array_diff($term_questermArr, $exam_questermArr), array_diff($exam_questermArr, $term_questermArr));
					$exam_random=array_rand($exam_output);					
					$randquestion=$exam_output[$exam_random];
					/*---End of check user not applied question list---*/
					$data['Questionlist']=$this->questions_model->term_exam_question($year_id,$data['term_id'],$randquestion);
						//$data['Questionlist']=$this->questions_model->term_exam($year_id,1);
						$this->load->view('frontend/private/examplay',$data);

					}
					else
					{
			
						/*----insert user exam list---------*/
						$userid=$this->session->userdata('user_id');
						$createdate=date("Y-m-d H:i:s");
						$chkrow_exam=$this->questions_model->check_userexam($userid,$year_id,$term_id);	
						
						if($chkrow_exam->exam_id!="" )
						{
							$exam_id=$chkrow_exam->exam_id;
						}
						else
						{
							$user_exam=array(
									'user_id'=>$userid,
									'year_id'=>$year_id,
									'term_id'=>$term_id,													
									'exam_date'=>$createdate
									
									);
							$exam_id=$this->questions_model->Save_Userexam($user_exam);	
						}
						
						if($exam_id!="")
						{
							$uexam_history=array(
								'exam_id'=>$exam_id,
								'user_id'=>$userid,
								'year_id'=>$year_id,
								'term_id'=>$term_id,													
								'question_id'=>$questionid,
								'answer_id'=>$answerid,
								'answer_status'=>'true',
								
								);
							$hexam_id=$this->questions_model->Save_Examhistory($uexam_history);		
						}
						
								/*----Get user exam question array------*/
					$exam_questermArr=array();
					$exam_questions=$this->questions_model->check_examhistory_question($userid,$year_id,$term_id);
					if($exam_questions)
					{
						
						foreach($exam_questions as $examdata)
						{
							array_push($exam_questermArr,$examdata->question_id);
						}
					}
					
					
					/*----End of get user exam question array----*/
					$term_questermArr=array();
					$term_questions=$this->questions_model->term_exam($year_id,$term_id);
					if($term_questions)
					{
						
						foreach($term_questions as $tquestion)
						{
							array_push($term_questermArr,$tquestion->question_id);
						}
						
					}
					$total_exam_question=count($exam_questermArr);
					$total_term_question=count($exam_questermArr);
					/*---update term by exam completed status----*/
					if($total_term_question==$total_exam_question)
					{
						$exam_status=array(
								'exam_status'=>'pass',							
								
								);
						
						$updateexam_status=$this->questions_model->Update_Examterm_status($exam_status,$exam_id);
					}
					/*---update term by exam completed status----*/
						
						/*----End of insert user exam list-------*/
						$data["yourans"] = $this->main_model->get_detail('manage_answer_'.$year_id,'ans_id',$answerid);	
						$this->load->view('frontend/private/explanation',$data);
					}
					
								
					}
				else
				{
					$userid=$this->session->userdata('user_id');
					$this->session->set_userdata('ansattempt', '0');
					/*---check user not applied question list---*/
					$userexams=$this->questions_model->check_uexambyyear($userid,$year_id);
					$check_termexam_date=$this->questions_model->check_termexam_date($year_id);
					
					if($check_termexam_date->date!="0000-00-00 00:00:00")
					{	
						$cur_date=date("m/d/Y");
						$date=date("m/d/Y", strtotime($check_termexam_date->date));
						if($date==$cur_date){
						$data['term_id']=$check_termexam_date->term_id;
						
						}
						else{ $data['no_exam']=1;}
					}
					else
					{
						$data['no_exam']=1;
					}
					
					/*----Get user exam question array------*/
					$exam_questermArr=array();
					$exam_questions=$this->questions_model->check_examhistory_question($userid,$year_id,$data['term_id']);
					if($exam_questions)
					{
						
						foreach($exam_questions as $examdata)
						{
							array_push($exam_questermArr,$examdata->question_id);
						}
					}
					
					
					/*----End of get user exam question array----*/
					$term_questermArr=array();
					$term_questions=$this->questions_model->term_exam($year_id,$data['term_id']);
					if($term_questions)
					{
						
						foreach($term_questions as $tquestion)
						{
							array_push($term_questermArr,$tquestion->question_id);
						}
						
					}
					//var_dump($term_questermArr);
					
					$exam_output = array_merge(array_diff($term_questermArr, $exam_questermArr), array_diff($exam_questermArr, $term_questermArr));
					$exam_random=array_rand($exam_output);					
					$randquestion=$exam_output[$exam_random];
					/*---End of check user not applied question list---*/
					$data['Questionlist']=$this->questions_model->term_exam_question($year_id,$data['term_id'],$randquestion);
	
					$this->load->view('frontend/private/examplay',$data);
				}
			
			
			
			
			}
			/*---end final year exam-----*/
			else
			{
				$this->session->unset_userdata('attempt');
				$this->session->unset_userdata('ansattempt');
			
			$data['subskill']=$subskill;
			$data["skill_dtl"] =$this->main_model->get_skill('master_skill','skill_slug',$subskill,'skill_class',$year_id);		
			  $subskill_id=$data["skill_dtl"]->skill_id;
			$this->questions_model->CLASSID = $year_id;
				//$data["Questionlist"] = $this->questions_model->question_list_subskill($subskill_id);
		
				if($this->input->post('action')=='submitanswer')	
					{
					 $questionid=$this->input->post('questionid');
					 $answerid=$this->input->post('answerid');
				
					
					$data["ques_dtl"] = $this->main_model->get_detail('manage_question_'.$year_id,'ques_id',$questionid);
					//print_r($data["ques_dtl"]);
					
					$data["correct_ans"] = $this->main_model->get_detail('manage_answer_'.$year_id,'ans_id',$data["ques_dtl"]->ques_rightanswer);
					//print_r($data["correct_ans"]);
					//echo $data["correct_ans"]->ans_name;
										
					if($data["ques_dtl"]->ques_rightanswer==$answerid)
					{
						
					$data['correct']=1;
					$data["Questionlist"] = $this->questions_model->random_question($subskill_id);
					$this->load->view('frontend/private/play',$data);

					}
					else{
			
					$data["yourans"] = $this->main_model->get_detail('manage_answer_'.$year_id,'ans_id',$answerid);	
					$this->load->view('frontend/private/explanation',$data);
					}
					
								
					}
				else{
					$data["Questionlist"] = $this->questions_model->random_question($subskill_id);
					$this->load->view('frontend/private/play',$data);
					}
			
				}
			}
			else{
				
				if($this->session->userdata('user_id')!='' and $this->session->userdata('username')!='')
				{

				$data["SylList"] = $this->main_model->getall('master_syllabus','class_id',$year_id);
				
				
				

				$data["SylList1"] = $this->syllabus_model->syllabus_list($year_id,1);
				$data["SylList2"] = $this->syllabus_model->syllabus_list($year_id,2);
				$data["SylList3"] = $this->syllabus_model->syllabus_list($year_id,3);
				$data["SylList4"] = $this->syllabus_model->syllabus_list($year_id,4);

				$this->load->view('frontend/private/kindergarten', $data);
				}
				else{
				$data["SylList1"] = $this->syllabus_model->syllabus_list($year_id,1);
				$data["SylList2"] = $this->syllabus_model->syllabus_list($year_id,2);
				$data["SylList3"] = $this->syllabus_model->syllabus_list($year_id,3);
				$data["SylList4"] = $this->syllabus_model->syllabus_list($year_id,4);

				$this->load->view('frontend/public/kg_wtht_login', $data);	
					
				}

			}
		
	}
	
	public function year1($subskill='') 
	{
		$yearid=$this->session->userdata('loginyear');
			$yeardata=$this->classes_model->classes_details($yearid);
			if($yeardata)
			{
				$data['year_name']=$yeardata[0]->class_name;
				$data['year_slug']=$yeardata[0]->class_slug;
			}	
		
		$year_id=2;
		$data['year_id']=$year_id;
		
		$userid2=$this->session->userdata('user_id');			
		$data['aatcount']=$this->exam_model->checkuser_aat_status($yearid,$userid2);
		
		$this->questions_model->CLASSID = $year_id;
		$data["year_dtl"] = $this->main_model->get_detail('master_class','class_id',$year_id);	
		$data['subskill']=$subskill;
		if($subskill!=""){
			/*---Start Assessment Test -----*/
				if($subskill=="assessment")
			{		
					 $this->session->set_userdata('attempt_ques', 0);
					 
					 //Page reload truncate table
					if($this->session->userdata('ass_attempt') > 0)
					{
					$checkasstest=$this->db->query("select exam_status from student_assessment_test  where year_id='".$year_id."' and user_id='".$this->session->userdata('user_id')."' 
							");
					$rowchecktest_status=$checkasstest->row();
					if($rowchecktest_status->exam_status=='pending')
					{						
					$del_asshistory=$this->db->query("delete  from sasstest_history  where year_id='".$year_id."' and user_id='".$this->session->userdata('user_id')."' 
							");
					$del_assmasterhistory=$this->db->query("delete  from student_assessment_test  where year_id='".$year_id."' and user_id='".$this->session->userdata('user_id')."' 
							");	
					$data['err_reload']=1;	
					$this->session->unset_userdata('ass_attempt');	
					}
					else
					{
						$data['err_reload']='';
					}						
					}
					else
					{
						$data['err_reload']='';	
					}
					
					/*---get all past year of assessment list----*/
					$pastyear=$this->questions_model->assessment_pastyear($year_id);
						/*echo '<pre>';
						var_dump($pastyear);
						echo '</pre>';
						*/
					$todaydate=date("Y-m-d H:i:s");	
					$userid=$this->session->userdata('user_id');
					$asstime_query=$this->questions_model->assessment_time($year_id,$userid);
					$yourstart=$asstime_query->start_time;
					if($yourstart!="" && $yourstart!=null)
					{
						$seconds = strtotime($todaydate) - strtotime($yourstart);
						$days    = floor($seconds / 86400);
						$hours   = floor(($seconds - ($days * 86400)) / 3600);
						$minutes = floor(($seconds - ($days * 86400) - ($hours * 3600))/60);
						
						if($minutes >30)
						{
							//echo $minutes;
							$exam_status=array(
								'exam_status'=>'pass',							
								'end_time'=>$todaydate,
								);
						
						$updateexam_status=$this->questions_model->Update_Asstterm_status($exam_status,$asstime_query->exam_id);
						$data['timeover']=1;
						}
						else
						{
							$totalminutes=30-$minutes;
							$data['showtimer']='Duration Left: '.$totalminutes;
						}
					}
					else
					{
						$data['showtimer']='Duration: 30';
					}
					
					/*---end of get all past year of assessment list----*/	
					if($this->input->post('action')=='submitanswer')	
					{
						//var_dump($this->input->post());
					$this->session->unset_userdata('ass_attempt');	
					 $questionid=$this->input->post('questionid');
					 $answerid=$this->input->post('answerid');
					 $year_id=$this->input->post('year_id');
					 $ass_year_id=$this->input->post('ass_year_id');
				
					
					$data["ques_dtl"] = $this->main_model->get_detail('manage_question_'.$ass_year_id,'ques_id',$questionid);					
					//var_dump($data["ques_dtl"]);
					$data["correct_ans"] = $this->main_model->get_detail('manage_answer_'.$ass_year_id,'ans_id',$data["ques_dtl"]->ques_rightanswer);					
										
					if($data["ques_dtl"]->ques_rightanswer==$answerid)
					{
						
						$data['correct']=1;
						/*----insert user exam list---------*/
						
						$createdate=date("Y-m-d H:i:s");
						$chkrow_exam=$this->questions_model->check_userassessment($userid,$year_id,1);	
						
						if($chkrow_exam->exam_id!="" )
						{
							$exam_id=$chkrow_exam->exam_id;
						}
						else
						{
							$user_exam=array(
									'user_id'=>$userid,
									'year_id'=>$year_id,
									'assyear_id'=>$ass_year_id,													
									'exam_date'=>$createdate,
									'start_time'=>$createdate
									
									);
							$exam_id=$this->questions_model->Save_Userassessment($user_exam);	
						}
						
						if($exam_id!="")
						{
							$uexam_history=array(
								'exam_id'=>$exam_id,
								'user_id'=>$userid,
								'year_id'=>$year_id,
								'assyear_id'=>$ass_year_id,													
								'question_id'=>$questionid,
								'answer_id'=>$answerid,
								'answer_status'=>'true',
								
								);
							$historyexam_id=$this->questions_model->Save_Assessmenthistory($uexam_history);		
						}
						
						/*----End of insert user exam list-------*/
										
					/*----Get user exam question array------*/
					$exam_questermArr=array();
					$exam_questions=$this->questions_model->check_asstesthistory_question($userid,$year_id,1);
					if($exam_questions)
					{
						
						foreach($exam_questions as $examdata)
						{
							array_push($exam_questermArr,$examdata->question_id);
						}
					}
					
					if($year_id ==1)
						{
							$firstyear=$year_id;
							$secondyear=$year_id;
						}
						else if($year_id ==2)
						{
							$firstyear=$year_id-1;
							$secondyear=$year_id-1;
						}
						else if($year_id >2)
						{
							$firstyear=$year_id-2;
							$secondyear=$year_id-1;
						}
						
					/*----End of get user exam question array----*/
					$term_questermArr=array();
					$term_questions=$this->questions_model->assessment_exam($year_id,1);
					if($term_questions)
					{
						
						foreach($term_questions as $tquestion)
						{
							array_push($term_questermArr,$tquestion->ass_question);
						}
						
					}
					$total_exam_question=count($exam_questermArr);
					$total_term_question=count($term_questermArr);
					/*---update term by exam completed status----*/
					if($total_term_question==$total_exam_question)
					{
						$exam_status=array(
								'exam_status'=>'pass',							
								'end_time'=>$createdate,
								);
						
						$updateexam_status=$this->questions_model->Update_Asstterm_status($exam_status,$exam_id);
						$data['completed']=1;
					}
					/*---update term by exam completed status----*/
					$exam_output = array_merge(array_diff($term_questermArr, $exam_questermArr), array_diff($exam_questermArr, $term_questermArr));
					$exam_random=array_rand($exam_output);
					$randquestion=$exam_output[$exam_random];
					/* $exam_random=array_shift($exam_output);		
					$randquestion=$exam_random; */
					/*---End of check user not applied question list---*/
					$data['Questionlist']=$this->questions_model->asstest_exam_question($year_id,1,$randquestion);
						//$data['Questionlist']=$this->questions_model->term_exam($year_id,1);
						$data['exam_id']=$exam_id;
						$this->load->view('frontend/private/assessmentplay',$data);

					}
					else
					{
			
						/*----insert user exam list---------*/
						$userid=$this->session->userdata('user_id');
						$createdate=date("Y-m-d H:i:s");
						$chkrow_exam=$this->questions_model->check_userassessment($userid,$year_id,1);	
						
						if($chkrow_exam->exam_id!="" )
						{
							$exam_id=$chkrow_exam->exam_id;
						}
						else
						{
							$user_exam=array(
									'user_id'=>$userid,
									'year_id'=>$year_id,
									'assyear_id'=>$ass_year_id,													
									'exam_date'=>$createdate,
									'start_time'=>$createdate
									
									);
							$exam_id=$this->questions_model->Save_Userassessment($user_exam);	
						}
						
						if($exam_id!="")
						{
							$uexam_history=array(
								'exam_id'=>$exam_id,
								'user_id'=>$userid,
								'year_id'=>$year_id,
								'assyear_id'=>$ass_year_id,													
								'question_id'=>$questionid,
								'answer_id'=>$answerid,
								'answer_status'=>'false',
								
								);
							$hexam_id=$this->questions_model->Save_Assessmenthistory($uexam_history);		
						}
						
								/*----Get user exam question array------*/
					$exam_questermArr=array();
					$exam_questions=$this->questions_model->check_asstesthistory_question($userid,$year_id,$term_id);
					if($exam_questions)
					{
						
						foreach($exam_questions as $examdata)
						{
							array_push($exam_questermArr,$examdata->question_id);
						}
					}
					
					
					/*----End of get user exam question array----*/
					$term_questermArr=array();
					$term_questions=$this->questions_model->assessment_exam($year_id,1);
					if($term_questions)
					{
						
						foreach($term_questions as $tquestion)
						{
							array_push($term_questermArr,$tquestion->ass_question);
						}
						
					}
					$total_exam_question=count($exam_questermArr);
					$total_term_question=count($term_questermArr);
					/*---update term by exam completed status----*/
					if(30==$total_exam_question)
					{
						$exam_status=array(
								'exam_status'=>'pass',
								'end_time'=>$createdate,	
								
								);
						
						$updateexam_status=$this->questions_model->Update_Asstterm_status($exam_status,$exam_id);
						$data['completed']=1;
					}
					/*---update term by exam completed status----*/
						
						/*----End of insert user exam list-------*/
					
						$data["yourans"] = $this->main_model->get_detail('manage_answer_'.$ass_year_id,'ans_id',$answerid);	
						$data['exam_id']=$exam_id;
						$this->load->view('frontend/private/asstestexplanation',$data);
					}
					
								
					}
				else
				{
					$userid=$this->session->userdata('user_id');
					/*---check user not applied question list---*/
					$userexams=$this->questions_model->check_uasstestbyyear($userid,$year_id);
					$data['exam_id']=$userexams->exam_id;
					if($userexams->exam_id!="" && $userexams->exam_status=='pending')
					{	
						$data['assyear_id']=$userexams->assyear_id;
					}
					
					else if($userexams->exam_id!="" && $userexams->exam_status=='pass')
					{	
						$data['assyear_id']=$userexams->assyear_id+1;
					}
				
					else
					{
						$data['assyear_id']=$pastyear[0]->ass_year_id;
						//echo $pastyear[0]->ass_year_id;
					}
					
					/*----Get user exam question array------*/
					$exam_questermArr=array();
					$exam_questions=$this->questions_model->check_asstesthistory_question($userid,$year_id,1);
					if($exam_questions)
					{
						
						foreach($exam_questions as $examdata)
						{
							array_push($exam_questermArr,$examdata->question_id);
						}
					}
					
					
					/*----End of get user exam question array----*/
					
					if($year_id ==1)
						{
							$firstyear=$year_id;
							$secondyear=$year_id;
						}
						else if($year_id ==2)
						{
							$firstyear=$year_id-1;
							$secondyear=$year_id-1;
						}
						else if($year_id >2)
						{
							$firstyear=$year_id-2;
							$secondyear=$year_id-1;
						}
						
					$term_questermArr=array();
					$term_questions=$this->questions_model->assessment_exam($year_id,1,$firstyear);
					
					if($term_questions)
					{
						
						foreach($term_questions as $tquestion)
						{
							array_push($term_questermArr,$tquestion->ass_question);
						}
						
					}
					//var_dump($term_questermArr);
					
					$exam_output = array_merge(array_diff($term_questermArr, $exam_questermArr), array_diff($exam_questermArr, $term_questermArr));
					$exam_random=array_rand($exam_output);
					$randquestion=$exam_output[$exam_random];
					/* $exam_random=array_shift($exam_output);
					$randquestion=$exam_random; */
					/*---End of check user not applied question list---*/
					if($userexams->exam_status!='pass')
					{
					$data['Questionlist']=$this->questions_model->asstest_exam_question($year_id,1,$randquestion);
					}
					else
					{
						$data['Questionlist']='';
						$data['completed']=1;
					}
					//var_dump($data['Questionlist']);
					$this->load->view('frontend/private/assessmentplay',$data);
				}
			
			}
		/*---End Assessment Test -----*/
			/*---final year exam-----*/
		else if($subskill=="exam")
			{
				$this->session->set_userdata('ansattempt', '0');
				
			if($this->input->post('action')=='submitanswer')	
					{
					 $questionid=$this->input->post('questionid');
					 $answerid=$this->input->post('answerid');
					 $year_id=$this->input->post('year_id');
					 
					 $term_id=$this->input->post('term_id');
				
					
					$data["ques_dtl"] = $this->main_model->get_detail('manage_question_'.$year_id,'ques_id',$questionid);					
					
					$data["correct_ans"] = $this->main_model->get_detail('manage_answer_'.$year_id,'ans_id',$data["ques_dtl"]->ques_rightanswer);					
										
					if($data["ques_dtl"]->ques_rightanswer==$answerid)
					{
						
						$data['correct']=1;
						/*----insert user exam list---------*/
						$userid=$this->session->userdata('user_id');
						$createdate=date("Y-m-d H:i:s");
						$chkrow_exam=$this->questions_model->check_userexam($userid,$year_id,$term_id);	
						
						if($chkrow_exam->exam_id!="" )
						{
							$exam_id=$chkrow_exam->exam_id;
						}
						else
						{
							$user_exam=array(
									'user_id'=>$userid,
									'year_id'=>$year_id,
									'term_id'=>$term_id,													
									'exam_date'=>$createdate
									
									);
							$exam_id=$this->questions_model->Save_Userexam($user_exam);	
						}
						
						if($exam_id!="")
						{
							$uexam_history=array(
								'exam_id'=>$exam_id,
								'user_id'=>$userid,
								'year_id'=>$year_id,
								'term_id'=>$term_id,													
								'question_id'=>$questionid,
								'answer_id'=>$answerid,
								'answer_status'=>'false',
								
								);
							$historyexam_id=$this->questions_model->Save_Examhistory($uexam_history);		
						}
						
						/*----End of insert user exam list-------*/
						
										/*---check user not applied question list---*/
					$userexams=$this->questions_model->check_uexambyyear($userid,$year_id);
					if($userexams->exam_id!="" && $userexams->exam_status=='pending')
					{	
						$data['term_id']=$userexams->term_id;
					}
					else if($userexams->exam_id!="" && $userexams->exam_status=='pass')
					{	
						$data['term_id']=$userexams->term_id+1;
					}
					else
					{
						$data['term_id']=1;
					}
					
					/*----Get user exam question array------*/
					$exam_questermArr=array();
					$exam_questions=$this->questions_model->check_examhistory_question($userid,$year_id,$data['term_id']);
					if($exam_questions)
					{
						
						foreach($exam_questions as $examdata)
						{
							array_push($exam_questermArr,$examdata->question_id);
						}
					}
					
					
					/*----End of get user exam question array----*/
					$term_questermArr=array();
					$term_questions=$this->questions_model->term_exam($year_id,$data['term_id']);
					if($term_questions)
					{
						
						foreach($term_questions as $tquestion)
						{
							array_push($term_questermArr,$tquestion->question_id);
						}
						
					}
					$total_exam_question=count($exam_questermArr);
					$total_term_question=count($exam_questermArr);
					/*---update term by exam completed status----*/
					if($total_term_question==$total_exam_question)
					{
						$exam_status=array(
								'exam_status'=>'pass',							
								
								);
						
						$updateexam_status=$this->questions_model->Update_Examterm_status($exam_status,$exam_id);
					}
					/*---update term by exam completed status----*/
					$exam_output = array_merge(array_diff($term_questermArr, $exam_questermArr), array_diff($exam_questermArr, $term_questermArr));
					$exam_random=array_rand($exam_output);					
					$randquestion=$exam_output[$exam_random];
					/*---End of check user not applied question list---*/
					$data['Questionlist']=$this->questions_model->term_exam_question($year_id,$data['term_id'],$randquestion);
						//$data['Questionlist']=$this->questions_model->term_exam($year_id,1);
						$this->load->view('frontend/private/examplay',$data);

					}
					else
					{
			
						/*----insert user exam list---------*/
						$userid=$this->session->userdata('user_id');
						$createdate=date("Y-m-d H:i:s");
						$chkrow_exam=$this->questions_model->check_userexam($userid,$year_id,$term_id);	
						
						if($chkrow_exam->exam_id!="" )
						{
							$exam_id=$chkrow_exam->exam_id;
						}
						else
						{
							$user_exam=array(
									'user_id'=>$userid,
									'year_id'=>$year_id,
									'term_id'=>$term_id,													
									'exam_date'=>$createdate
									
									);
							$exam_id=$this->questions_model->Save_Userexam($user_exam);	
						}
						
						if($exam_id!="")
						{
							$uexam_history=array(
								'exam_id'=>$exam_id,
								'user_id'=>$userid,
								'year_id'=>$year_id,
								'term_id'=>$term_id,													
								'question_id'=>$questionid,
								'answer_id'=>$answerid,
								'answer_status'=>'true',
								
								);
							$hexam_id=$this->questions_model->Save_Examhistory($uexam_history);		
						}
						
								/*----Get user exam question array------*/
					$exam_questermArr=array();
					$exam_questions=$this->questions_model->check_examhistory_question($userid,$year_id,$term_id);
					if($exam_questions)
					{
						
						foreach($exam_questions as $examdata)
						{
							array_push($exam_questermArr,$examdata->question_id);
						}
					}
					
					
					/*----End of get user exam question array----*/
					$term_questermArr=array();
					$term_questions=$this->questions_model->term_exam($year_id,$term_id);
					if($term_questions)
					{
						
						foreach($term_questions as $tquestion)
						{
							array_push($term_questermArr,$tquestion->question_id);
						}
						
					}
					$total_exam_question=count($exam_questermArr);
					$total_term_question=count($exam_questermArr);
					/*---update term by exam completed status----*/
					if($total_term_question==$total_exam_question)
					{
						$exam_status=array(
								'exam_status'=>'pass',							
								
								);
						
						$updateexam_status=$this->questions_model->Update_Examterm_status($exam_status,$exam_id);
					}
					/*---update term by exam completed status----*/
						
						/*----End of insert user exam list-------*/
						$data["yourans"] = $this->main_model->get_detail('manage_answer_'.$year_id,'ans_id',$answerid);	
						$this->load->view('frontend/private/explanation',$data);
					}
					
								
					}
				else
				{
					$userid=$this->session->userdata('user_id');
					$this->session->set_userdata('ansattempt', '0');
					/*---check user not applied question list---*/
					$userexams=$this->questions_model->check_uexambyyear($userid,$year_id);
					$check_termexam_date=$this->questions_model->check_termexam_date($year_id);
					
					if($check_termexam_date->date!="0000-00-00 00:00:00")
					{	
						$cur_date=date("m/d/Y");
						$date=date("m/d/Y", strtotime($check_termexam_date->date));
						if($date==$cur_date){
						$data['term_id']=$check_termexam_date->term_id;
						
						}
						else{ $data['no_exam']=1;}
					}
					else
					{
						$data['no_exam']=1;
					}
					
					/*----Get user exam question array------*/
					$exam_questermArr=array();
					$exam_questions=$this->questions_model->check_examhistory_question($userid,$year_id,$data['term_id']);
					if($exam_questions)
					{
						
						foreach($exam_questions as $examdata)
						{
							array_push($exam_questermArr,$examdata->question_id);
						}
					}
					
					
					/*----End of get user exam question array----*/
					$term_questermArr=array();
					$term_questions=$this->questions_model->term_exam($year_id,$data['term_id']);
					if($term_questions)
					{
						
						foreach($term_questions as $tquestion)
						{
							array_push($term_questermArr,$tquestion->question_id);
						}
						
					}
					//var_dump($term_questermArr);
					
					$exam_output = array_merge(array_diff($term_questermArr, $exam_questermArr), array_diff($exam_questermArr, $term_questermArr));
					$exam_random=array_rand($exam_output);					
					$randquestion=$exam_output[$exam_random];
					/*---End of check user not applied question list---*/
					$data['Questionlist']=$this->questions_model->term_exam_question($year_id,$data['term_id'],$randquestion);
	
					$this->load->view('frontend/private/examplay',$data);
				}
			
			
			
			
			}
				/*---end final year exam-----*/
			else
			{	
				$this->session->unset_userdata('attempt');
				$this->session->unset_userdata('ansattempt');
			$data["skill_dtl"] =$this->main_model->get_skill('master_skill','skill_slug',$subskill,'skill_class',$year_id);		
			  $subskill_id=$data["skill_dtl"]->skill_id;
			$this->questions_model->CLASSID = $year_id;
				//$data["Questionlist"] = $this->questions_model->question_list_subskill($subskill_id);
		
				if($this->input->post('action')=='submitanswer')	
					{
					 $questionid=$this->input->post('questionid');
					 $answerid=$this->input->post('answerid');
				
					
					$data["ques_dtl"] = $this->main_model->get_detail('manage_question_'.$year_id,'ques_id',$questionid);
					//print_r($data["ques_dtl"]);
					
					$data["correct_ans"] = $this->main_model->get_detail('manage_answer_'.$year_id,'ans_id',$data["ques_dtl"]->ques_rightanswer);
					//print_r($data["correct_ans"]);
					//echo $data["correct_ans"]->ans_name;
										
					if($data["ques_dtl"]->ques_rightanswer==$answerid)
					{
						
					$data['correct']=1;
					$data["Questionlist"] = $this->questions_model->random_question($subskill_id);
					$this->load->view('frontend/private/play',$data);

					}
					else{
			
					$data["yourans"] = $this->main_model->get_detail('manage_answer_'.$year_id,'ans_id',$answerid);	
					$this->load->view('frontend/private/explanation',$data);
					}
					
								
					}
				else{
					$data["Questionlist"] = $this->questions_model->random_question($subskill_id);
					$this->load->view('frontend/private/play',$data);
					}
			
				}
			}
			else{
				
				if($this->session->userdata('user_id')!='' and $this->session->userdata('username')!='')
				{

				$data["SylList1"] = $this->syllabus_model->syllabus_list($year_id,1);
				$data["SylList2"] = $this->syllabus_model->syllabus_list($year_id,2);
				$data["SylList3"] = $this->syllabus_model->syllabus_list($year_id,3);
				$data["SylList4"] = $this->syllabus_model->syllabus_list($year_id,4);

				$this->load->view('frontend/private/kindergarten', $data);
				}
				else{
				$data["SylList1"] = $this->syllabus_model->syllabus_list($year_id,1);
				$data["SylList2"] = $this->syllabus_model->syllabus_list($year_id,2);
				$data["SylList3"] = $this->syllabus_model->syllabus_list($year_id,3);
				$data["SylList4"] = $this->syllabus_model->syllabus_list($year_id,4);

				$this->load->view('frontend/public/kg_wtht_login', $data);	
					
				}

			}
		
	}
	
	public function year2($subskill='') 
	{
			
		$yearid=$this->session->userdata('loginyear');
			$yeardata=$this->classes_model->classes_details($yearid);
			if($yeardata)
			{
				$data['year_name']=$yeardata[0]->class_name;
				$data['year_slug']=$yeardata[0]->class_slug;
			}
		$year_id=3;
		$data['year_id']=$year_id;
		
		$userid2=$this->session->userdata('user_id');			
		$data['aatcount']=$this->exam_model->checkuser_aat_status($yearid,$userid2);
		
		$this->questions_model->CLASSID = $year_id;
		$data["year_dtl"] = $this->main_model->get_detail('master_class','class_id',$year_id);	
		$data['subskill']=$subskill;
		if($subskill!=""){
			/*---Start Assessment Test -----*/
				if($subskill=="assessment")
			{		
					 $this->session->set_userdata('attempt_ques', 0);
					 
					 //Page reload truncate table
					if($this->session->userdata('ass_attempt') > 0)
					{
					$checkasstest=$this->db->query("select exam_status from student_assessment_test  where year_id='".$year_id."' and user_id='".$this->session->userdata('user_id')."' 
							");
					$rowchecktest_status=$checkasstest->row();
					if($rowchecktest_status->exam_status=='pending')
					{						
					$del_asshistory=$this->db->query("delete  from sasstest_history  where year_id='".$year_id."' and user_id='".$this->session->userdata('user_id')."' 
							");
					$del_assmasterhistory=$this->db->query("delete  from student_assessment_test  where year_id='".$year_id."' and user_id='".$this->session->userdata('user_id')."' 
							");	
					$data['err_reload']=1;	
					$this->session->unset_userdata('ass_attempt');	
					}
					else
					{
						$data['err_reload']='';
					}						
					}
					else
					{
						$data['err_reload']='';	
					}
					
					/*---get all past year of assessment list----*/
					$pastyear=$this->questions_model->assessment_pastyear($year_id);
						/*echo '<pre>';
						var_dump($pastyear);
						echo '</pre>';
						*/
					$todaydate=date("Y-m-d H:i:s");	
					$userid=$this->session->userdata('user_id');
					$asstime_query=$this->questions_model->assessment_time($year_id,$userid);
					$yourstart=$asstime_query->start_time;
					if($yourstart!="" && $yourstart!=null)
					{
						$seconds = strtotime($todaydate) - strtotime($yourstart);
						$days    = floor($seconds / 86400);
						$hours   = floor(($seconds - ($days * 86400)) / 3600);
						$minutes = floor(($seconds - ($days * 86400) - ($hours * 3600))/60);
						
						if($minutes >30)
						{
							//echo $minutes;
							$exam_status=array(
								'exam_status'=>'pass',							
								'end_time'=>$todaydate,
								);
						
						$updateexam_status=$this->questions_model->Update_Asstterm_status($exam_status,$asstime_query->exam_id);
						$data['timeover']=1;
						}
						else
						{
							$totalminutes=30-$minutes;
							$data['showtimer']='Duration Left: '.$totalminutes;
						}
					}
					else
					{
						$data['showtimer']='Duration: 30';
					}
					
					/*---end of get all past year of assessment list----*/	
					if($this->input->post('action')=='submitanswer')	
					{
						//var_dump($this->input->post());
					$this->session->unset_userdata('ass_attempt');	
					 $questionid=$this->input->post('questionid');
					 $answerid=$this->input->post('answerid');
					 $year_id=$this->input->post('year_id');
					 $ass_year_id=$this->input->post('ass_year_id');
				
					
					$data["ques_dtl"] = $this->main_model->get_detail('manage_question_'.$ass_year_id,'ques_id',$questionid);					
					//var_dump($data["ques_dtl"]);
					$data["correct_ans"] = $this->main_model->get_detail('manage_answer_'.$ass_year_id,'ans_id',$data["ques_dtl"]->ques_rightanswer);					
										
					if($data["ques_dtl"]->ques_rightanswer==$answerid)
					{
						
						$data['correct']=1;
						/*----insert user exam list---------*/
						
						$createdate=date("Y-m-d H:i:s");
						$chkrow_exam=$this->questions_model->check_userassessment($userid,$year_id,1);	
						
						if($chkrow_exam->exam_id!="" )
						{
							$exam_id=$chkrow_exam->exam_id;
						}
						else
						{
							$user_exam=array(
									'user_id'=>$userid,
									'year_id'=>$year_id,
									'assyear_id'=>$ass_year_id,													
									'exam_date'=>$createdate,
									'start_time'=>$createdate
									
									);
							$exam_id=$this->questions_model->Save_Userassessment($user_exam);	
						}
						
						if($exam_id!="")
						{
							$uexam_history=array(
								'exam_id'=>$exam_id,
								'user_id'=>$userid,
								'year_id'=>$year_id,
								'assyear_id'=>$ass_year_id,													
								'question_id'=>$questionid,
								'answer_id'=>$answerid,
								'answer_status'=>'true',
								
								);
							$historyexam_id=$this->questions_model->Save_Assessmenthistory($uexam_history);		
						}
						
						/*----End of insert user exam list-------*/
										
					/*----Get user exam question array------*/
					$exam_questermArr=array();
					$exam_questions=$this->questions_model->check_asstesthistory_question($userid,$year_id,1);
					if($exam_questions)
					{
						
						foreach($exam_questions as $examdata)
						{
							array_push($exam_questermArr,$examdata->question_id);
						}
					}
					
					if($year_id ==1)
						{
							$firstyear=$year_id;
							$secondyear=$year_id;
						}
						else if($year_id ==2)
						{
							$firstyear=$year_id-1;
							$secondyear=$year_id-1;
						}
						else if($year_id >2)
						{
							$firstyear=$year_id-2;
							$secondyear=$year_id-1;
						}
						
					/*----End of get user exam question array----*/
					$term_questermArr=array();
					$term_questions=$this->questions_model->assessment_exam($year_id,1);
					if($term_questions)
					{
						
						foreach($term_questions as $tquestion)
						{
							array_push($term_questermArr,$tquestion->ass_question);
						}
						
					}
					$total_exam_question=count($exam_questermArr);
					$total_term_question=count($term_questermArr);
					/*---update term by exam completed status----*/
					if($total_term_question==$total_exam_question)
					{
						$exam_status=array(
								'exam_status'=>'pass',							
								'end_time'=>$createdate,
								);
						
						$updateexam_status=$this->questions_model->Update_Asstterm_status($exam_status,$exam_id);
						$data['completed']=1;
					}
					/*---update term by exam completed status----*/
					$exam_output = array_merge(array_diff($term_questermArr, $exam_questermArr), array_diff($exam_questermArr, $term_questermArr));
					$exam_random=array_rand($exam_output);
					$randquestion=$exam_output[$exam_random];
					/* $exam_random=array_shift($exam_output);		
					$randquestion=$exam_random; */
					/*---End of check user not applied question list---*/
					$data['Questionlist']=$this->questions_model->asstest_exam_question($year_id,1,$randquestion);
						//$data['Questionlist']=$this->questions_model->term_exam($year_id,1);
						$data['exam_id']=$exam_id;
						$this->load->view('frontend/private/assessmentplay',$data);

					}
					else
					{
			
						/*----insert user exam list---------*/
						$userid=$this->session->userdata('user_id');
						$createdate=date("Y-m-d H:i:s");
						$chkrow_exam=$this->questions_model->check_userassessment($userid,$year_id,1);	
						
						if($chkrow_exam->exam_id!="" )
						{
							$exam_id=$chkrow_exam->exam_id;
						}
						else
						{
							$user_exam=array(
									'user_id'=>$userid,
									'year_id'=>$year_id,
									'assyear_id'=>$ass_year_id,													
									'exam_date'=>$createdate,
									'start_time'=>$createdate
									
									);
							$exam_id=$this->questions_model->Save_Userassessment($user_exam);	
						}
						
						if($exam_id!="")
						{
							$uexam_history=array(
								'exam_id'=>$exam_id,
								'user_id'=>$userid,
								'year_id'=>$year_id,
								'assyear_id'=>$ass_year_id,													
								'question_id'=>$questionid,
								'answer_id'=>$answerid,
								'answer_status'=>'false',
								
								);
							$hexam_id=$this->questions_model->Save_Assessmenthistory($uexam_history);		
						}
						
								/*----Get user exam question array------*/
					$exam_questermArr=array();
					$exam_questions=$this->questions_model->check_asstesthistory_question($userid,$year_id,$term_id);
					if($exam_questions)
					{
						
						foreach($exam_questions as $examdata)
						{
							array_push($exam_questermArr,$examdata->question_id);
						}
					}
					
					
					/*----End of get user exam question array----*/
					$term_questermArr=array();
					$term_questions=$this->questions_model->assessment_exam($year_id,1);
					if($term_questions)
					{
						
						foreach($term_questions as $tquestion)
						{
							array_push($term_questermArr,$tquestion->ass_question);
						}
						
					}
					$total_exam_question=count($exam_questermArr);
					$total_term_question=count($term_questermArr);
					/*---update term by exam completed status----*/
					if(30==$total_exam_question)
					{
						$exam_status=array(
								'exam_status'=>'pass',
								'end_time'=>$createdate,	
								
								);
						
						$updateexam_status=$this->questions_model->Update_Asstterm_status($exam_status,$exam_id);
						$data['completed']=1;
					}
					/*---update term by exam completed status----*/
						
						/*----End of insert user exam list-------*/
					
						$data["yourans"] = $this->main_model->get_detail('manage_answer_'.$ass_year_id,'ans_id',$answerid);	
						$data['exam_id']=$exam_id;
						$this->load->view('frontend/private/asstestexplanation',$data);
					}
					
								
					}
				else
				{
					$userid=$this->session->userdata('user_id');
					/*---check user not applied question list---*/
					$userexams=$this->questions_model->check_uasstestbyyear($userid,$year_id);
					$data['exam_id']=$userexams->exam_id;
					if($userexams->exam_id!="" && $userexams->exam_status=='pending')
					{	
						$data['assyear_id']=$userexams->assyear_id;
					}
					
					else if($userexams->exam_id!="" && $userexams->exam_status=='pass')
					{	
						$data['assyear_id']=$userexams->assyear_id+1;
					}
				
					else
					{
						$data['assyear_id']=$pastyear[0]->ass_year_id;
						//echo $pastyear[0]->ass_year_id;
					}
					
					/*----Get user exam question array------*/
					$exam_questermArr=array();
					$exam_questions=$this->questions_model->check_asstesthistory_question($userid,$year_id,1);
					if($exam_questions)
					{
						
						foreach($exam_questions as $examdata)
						{
							array_push($exam_questermArr,$examdata->question_id);
						}
					}
					
					
					/*----End of get user exam question array----*/
					
					if($year_id ==1)
						{
							$firstyear=$year_id;
							$secondyear=$year_id;
						}
						else if($year_id ==2)
						{
							$firstyear=$year_id-1;
							$secondyear=$year_id-1;
						}
						else if($year_id >2)
						{
							$firstyear=$year_id-2;
							$secondyear=$year_id-1;
						}
						
					$term_questermArr=array();
					$term_questions=$this->questions_model->assessment_exam($year_id,1,$firstyear);
					
					if($term_questions)
					{
						
						foreach($term_questions as $tquestion)
						{
							array_push($term_questermArr,$tquestion->ass_question);
						}
						
					}
					//var_dump($term_questermArr);
					
					$exam_output = array_merge(array_diff($term_questermArr, $exam_questermArr), array_diff($exam_questermArr, $term_questermArr));
					$exam_random=array_rand($exam_output);
					$randquestion=$exam_output[$exam_random];
					/* $exam_random=array_shift($exam_output);
					$randquestion=$exam_random; */
					/*---End of check user not applied question list---*/
					if($userexams->exam_status!='pass')
					{
					$data['Questionlist']=$this->questions_model->asstest_exam_question($year_id,1,$randquestion);
					}
					else
					{
						$data['Questionlist']='';
						$data['completed']=1;
					}
					//var_dump($data['Questionlist']);
					$this->load->view('frontend/private/assessmentplay',$data);
				}
			
			}
		/*---End Assessment Test -----*/
			/*---final year exam-----*/
			else if($subskill=="exam")
			{
				$this->session->set_userdata('ansattempt', '0');
				
			if($this->input->post('action')=='submitanswer')	
					{
					 $questionid=$this->input->post('questionid');
					 $answerid=$this->input->post('answerid');
					 $year_id=$this->input->post('year_id');
					 
					 $term_id=$this->input->post('term_id');
				
					
					$data["ques_dtl"] = $this->main_model->get_detail('manage_question_'.$year_id,'ques_id',$questionid);					
					
					$data["correct_ans"] = $this->main_model->get_detail('manage_answer_'.$year_id,'ans_id',$data["ques_dtl"]->ques_rightanswer);					
										
					if($data["ques_dtl"]->ques_rightanswer==$answerid)
					{
						
						$data['correct']=1;
						/*----insert user exam list---------*/
						$userid=$this->session->userdata('user_id');
						$createdate=date("Y-m-d H:i:s");
						$chkrow_exam=$this->questions_model->check_userexam($userid,$year_id,$term_id);	
						
						if($chkrow_exam->exam_id!="" )
						{
							$exam_id=$chkrow_exam->exam_id;
						}
						else
						{
							$user_exam=array(
									'user_id'=>$userid,
									'year_id'=>$year_id,
									'term_id'=>$term_id,													
									'exam_date'=>$createdate
									
									);
							$exam_id=$this->questions_model->Save_Userexam($user_exam);	
						}
						
						if($exam_id!="")
						{
							$uexam_history=array(
								'exam_id'=>$exam_id,
								'user_id'=>$userid,
								'year_id'=>$year_id,
								'term_id'=>$term_id,													
								'question_id'=>$questionid,
								'answer_id'=>$answerid,
								'answer_status'=>'false',
								
								);
							$historyexam_id=$this->questions_model->Save_Examhistory($uexam_history);		
						}
						
						/*----End of insert user exam list-------*/
						
										/*---check user not applied question list---*/
					$userexams=$this->questions_model->check_uexambyyear($userid,$year_id);
					if($userexams->exam_id!="" && $userexams->exam_status=='pending')
					{	
						$data['term_id']=$userexams->term_id;
					}
					else if($userexams->exam_id!="" && $userexams->exam_status=='pass')
					{	
						$data['term_id']=$userexams->term_id+1;
					}
					else
					{
						$data['term_id']=1;
					}
					
					/*----Get user exam question array------*/
					$exam_questermArr=array();
					$exam_questions=$this->questions_model->check_examhistory_question($userid,$year_id,$data['term_id']);
					if($exam_questions)
					{
						
						foreach($exam_questions as $examdata)
						{
							array_push($exam_questermArr,$examdata->question_id);
						}
					}
					
					
					/*----End of get user exam question array----*/
					$term_questermArr=array();
					$term_questions=$this->questions_model->term_exam($year_id,$data['term_id']);
					if($term_questions)
					{
						
						foreach($term_questions as $tquestion)
						{
							array_push($term_questermArr,$tquestion->question_id);
						}
						
					}
					$total_exam_question=count($exam_questermArr);
					$total_term_question=count($exam_questermArr);
					/*---update term by exam completed status----*/
					if($total_term_question==$total_exam_question)
					{
						$exam_status=array(
								'exam_status'=>'pass',							
								
								);
						
						$updateexam_status=$this->questions_model->Update_Examterm_status($exam_status,$exam_id);
					}
					/*---update term by exam completed status----*/
					$exam_output = array_merge(array_diff($term_questermArr, $exam_questermArr), array_diff($exam_questermArr, $term_questermArr));
					$exam_random=array_rand($exam_output);					
					$randquestion=$exam_output[$exam_random];
					/*---End of check user not applied question list---*/
					$data['Questionlist']=$this->questions_model->term_exam_question($year_id,$data['term_id'],$randquestion);
						//$data['Questionlist']=$this->questions_model->term_exam($year_id,1);
						$this->load->view('frontend/private/examplay',$data);

					}
					else
					{
			
						/*----insert user exam list---------*/
						$userid=$this->session->userdata('user_id');
						$createdate=date("Y-m-d H:i:s");
						$chkrow_exam=$this->questions_model->check_userexam($userid,$year_id,$term_id);	
						
						if($chkrow_exam->exam_id!="" )
						{
							$exam_id=$chkrow_exam->exam_id;
						}
						else
						{
							$user_exam=array(
									'user_id'=>$userid,
									'year_id'=>$year_id,
									'term_id'=>$term_id,													
									'exam_date'=>$createdate
									
									);
							$exam_id=$this->questions_model->Save_Userexam($user_exam);	
						}
						
						if($exam_id!="")
						{
							$uexam_history=array(
								'exam_id'=>$exam_id,
								'user_id'=>$userid,
								'year_id'=>$year_id,
								'term_id'=>$term_id,													
								'question_id'=>$questionid,
								'answer_id'=>$answerid,
								'answer_status'=>'true',
								
								);
							$hexam_id=$this->questions_model->Save_Examhistory($uexam_history);		
						}
						
								/*----Get user exam question array------*/
					$exam_questermArr=array();
					$exam_questions=$this->questions_model->check_examhistory_question($userid,$year_id,$term_id);
					if($exam_questions)
					{
						
						foreach($exam_questions as $examdata)
						{
							array_push($exam_questermArr,$examdata->question_id);
						}
					}
					
					
					/*----End of get user exam question array----*/
					$term_questermArr=array();
					$term_questions=$this->questions_model->term_exam($year_id,$term_id);
					if($term_questions)
					{
						
						foreach($term_questions as $tquestion)
						{
							array_push($term_questermArr,$tquestion->question_id);
						}
						
					}
					$total_exam_question=count($exam_questermArr);
					$total_term_question=count($exam_questermArr);
					/*---update term by exam completed status----*/
					if($total_term_question==$total_exam_question)
					{
						$exam_status=array(
								'exam_status'=>'pass',							
								
								);
						
						$updateexam_status=$this->questions_model->Update_Examterm_status($exam_status,$exam_id);
					}
					/*---update term by exam completed status----*/
						
						/*----End of insert user exam list-------*/
						$data["yourans"] = $this->main_model->get_detail('manage_answer_'.$year_id,'ans_id',$answerid);	
						$this->load->view('frontend/private/explanation',$data);
					}
					
								
					}
				else
				{
					$userid=$this->session->userdata('user_id');
					$this->session->set_userdata('ansattempt', '0');
					/*---check user not applied question list---*/
					$userexams=$this->questions_model->check_uexambyyear($userid,$year_id);
					$check_termexam_date=$this->questions_model->check_termexam_date($year_id);
					
					if($check_termexam_date->date!="0000-00-00 00:00:00")
					{	
						$cur_date=date("m/d/Y");
						$date=date("m/d/Y", strtotime($check_termexam_date->date));
						if($date==$cur_date){
						$data['term_id']=$check_termexam_date->term_id;
						
						}
						else{ $data['no_exam']=1;}
					}
					else
					{
						$data['no_exam']=1;
					}
					
					/*----Get user exam question array------*/
					$exam_questermArr=array();
					$exam_questions=$this->questions_model->check_examhistory_question($userid,$year_id,$data['term_id']);
					if($exam_questions)
					{
						
						foreach($exam_questions as $examdata)
						{
							array_push($exam_questermArr,$examdata->question_id);
						}
					}
					
					
					/*----End of get user exam question array----*/
					$term_questermArr=array();
					$term_questions=$this->questions_model->term_exam($year_id,$data['term_id']);
					if($term_questions)
					{
						
						foreach($term_questions as $tquestion)
						{
							array_push($term_questermArr,$tquestion->question_id);
						}
						
					}
					//var_dump($term_questermArr);
					
					$exam_output = array_merge(array_diff($term_questermArr, $exam_questermArr), array_diff($exam_questermArr, $term_questermArr));
					$exam_random=array_rand($exam_output);					
					$randquestion=$exam_output[$exam_random];
					/*---End of check user not applied question list---*/
					$data['Questionlist']=$this->questions_model->term_exam_question($year_id,$data['term_id'],$randquestion);
	
					$this->load->view('frontend/private/examplay',$data);
				}
			
			
			
			
			}
			/*---end final year exam-----*/
			else
			{	
				$this->session->unset_userdata('attempt');
				$this->session->unset_userdata('ansattempt');
			$data["skill_dtl"] =$this->main_model->get_skill('master_skill','skill_slug',$subskill,'skill_class',$year_id);		
			  $subskill_id=$data["skill_dtl"]->skill_id;
			$this->questions_model->CLASSID = $year_id;
				//$data["Questionlist"] = $this->questions_model->question_list_subskill($subskill_id);
		
				if($this->input->post('action')=='submitanswer')	
					{
					 $questionid=$this->input->post('questionid');
					 $answerid=$this->input->post('answerid');
				
					
					$data["ques_dtl"] = $this->main_model->get_detail('manage_question_'.$year_id,'ques_id',$questionid);
					//print_r($data["ques_dtl"]);
					
					$data["correct_ans"] = $this->main_model->get_detail('manage_answer_'.$year_id,'ans_id',$data["ques_dtl"]->ques_rightanswer);
					//print_r($data["correct_ans"]);
					//echo $data["correct_ans"]->ans_name;
										
					if($data["ques_dtl"]->ques_rightanswer==$answerid)
					{
						
					$data['correct']=1;
					$data["Questionlist"] = $this->questions_model->random_question($subskill_id);
					$this->load->view('frontend/private/play',$data);

					}
					else{
			
					$data["yourans"] = $this->main_model->get_detail('manage_answer_'.$year_id,'ans_id',$answerid);	
					$this->load->view('frontend/private/explanation',$data);
					}
					
								
					}
				else{
					$data["Questionlist"] = $this->questions_model->random_question($subskill_id);
					$this->load->view('frontend/private/play',$data);
					}
			
				}
			}
			else{
				
				if($this->session->userdata('user_id')!='' and $this->session->userdata('username')!='')
				{

				$data["SylList1"] = $this->syllabus_model->syllabus_list($year_id,1);
				$data["SylList2"] = $this->syllabus_model->syllabus_list($year_id,2);
				$data["SylList3"] = $this->syllabus_model->syllabus_list($year_id,3);
				$data["SylList4"] = $this->syllabus_model->syllabus_list($year_id,4);

				$this->load->view('frontend/private/kindergarten', $data);
				}
				else{
				$data["SylList1"] = $this->syllabus_model->syllabus_list($year_id,1);
				$data["SylList2"] = $this->syllabus_model->syllabus_list($year_id,2);
				$data["SylList3"] = $this->syllabus_model->syllabus_list($year_id,3);
				$data["SylList4"] = $this->syllabus_model->syllabus_list($year_id,4);

				$this->load->view('frontend/public/kg_wtht_login', $data);	
					
				}

			}
		
		
	}
	public function year3($subskill='') 
	{	
		$yearid=$this->session->userdata('loginyear');
			$yeardata=$this->classes_model->classes_details($yearid);
			if($yeardata)
			{
				$data['year_name']=$yeardata[0]->class_name;
				$data['year_slug']=$yeardata[0]->class_slug;
			}
		$year_id=4;
		$data['year_id']=$year_id;
		
		$userid2=$this->session->userdata('user_id');			
		$data['aatcount']=$this->exam_model->checkuser_aat_status($yearid,$userid2);
		
		$this->questions_model->CLASSID = $year_id;
		$data["year_dtl"] = $this->main_model->get_detail('master_class','class_id',$year_id);	
		$data['subskill']=$subskill;
		if($subskill!=""){
			/*---Start Assessment Test -----*/
			if($subskill=="assessment")
			{		
					 $this->session->set_userdata('attempt_ques', 0);
					 
					 //Page reload truncate table
					if($this->session->userdata('ass_attempt') > 0)
					{
					$checkasstest=$this->db->query("select exam_status from student_assessment_test  where year_id='".$year_id."' and user_id='".$this->session->userdata('user_id')."' 
							");
					$rowchecktest_status=$checkasstest->row();
					if($rowchecktest_status->exam_status=='pending')
					{						
					$del_asshistory=$this->db->query("delete  from sasstest_history  where year_id='".$year_id."' and user_id='".$this->session->userdata('user_id')."' 
							");
					$del_assmasterhistory=$this->db->query("delete  from student_assessment_test  where year_id='".$year_id."' and user_id='".$this->session->userdata('user_id')."' 
							");	
					$data['err_reload']=1;	
					$this->session->unset_userdata('ass_attempt');	
					}
					else
					{
						$data['err_reload']='';
					}						
					}
					else
					{
						$data['err_reload']='';	
					}
					
					/*---get all past year of assessment list----*/
					$pastyear=$this->questions_model->assessment_pastyear($year_id);
						/*echo '<pre>';
						var_dump($pastyear);
						echo '</pre>';
						*/
					$todaydate=date("Y-m-d H:i:s");	
					$userid=$this->session->userdata('user_id');
					$asstime_query=$this->questions_model->assessment_time($year_id,$userid);
					$yourstart=$asstime_query->start_time;
					if($yourstart!="" && $yourstart!=null)
					{
						$seconds = strtotime($todaydate) - strtotime($yourstart);
						$days    = floor($seconds / 86400);
						$hours   = floor(($seconds - ($days * 86400)) / 3600);
						$minutes = floor(($seconds - ($days * 86400) - ($hours * 3600))/60);
						
						if($minutes >30)
						{
							//echo $minutes;
							$exam_status=array(
								'exam_status'=>'pass',							
								'end_time'=>$todaydate,
								);
						
						$updateexam_status=$this->questions_model->Update_Asstterm_status($exam_status,$asstime_query->exam_id);
						$data['timeover']=1;
						}
						else
						{
							$totalminutes=30-$minutes;
							$data['showtimer']='Duration Left: '.$totalminutes;
						}
					}
					else
					{
						$data['showtimer']='Duration: 30';
					}
					
					/*---end of get all past year of assessment list----*/	
					if($this->input->post('action')=='submitanswer')	
					{
						//var_dump($this->input->post());
					$this->session->unset_userdata('ass_attempt');	
					 $questionid=$this->input->post('questionid');
					 $answerid=$this->input->post('answerid');
					 $year_id=$this->input->post('year_id');
					 $ass_year_id=$this->input->post('ass_year_id');
				
					
					$data["ques_dtl"] = $this->main_model->get_detail('manage_question_'.$ass_year_id,'ques_id',$questionid);					
					//var_dump($data["ques_dtl"]);
					$data["correct_ans"] = $this->main_model->get_detail('manage_answer_'.$ass_year_id,'ans_id',$data["ques_dtl"]->ques_rightanswer);					
										
					if($data["ques_dtl"]->ques_rightanswer==$answerid)
					{
						
						$data['correct']=1;
						/*----insert user exam list---------*/
						
						$createdate=date("Y-m-d H:i:s");
						$chkrow_exam=$this->questions_model->check_userassessment($userid,$year_id,1);	
						
						if($chkrow_exam->exam_id!="" )
						{
							$exam_id=$chkrow_exam->exam_id;
						}
						else
						{
							$user_exam=array(
									'user_id'=>$userid,
									'year_id'=>$year_id,
									'assyear_id'=>$ass_year_id,													
									'exam_date'=>$createdate,
									'start_time'=>$createdate
									
									);
							$exam_id=$this->questions_model->Save_Userassessment($user_exam);	
						}
						
						if($exam_id!="")
						{
							$uexam_history=array(
								'exam_id'=>$exam_id,
								'user_id'=>$userid,
								'year_id'=>$year_id,
								'assyear_id'=>$ass_year_id,													
								'question_id'=>$questionid,
								'answer_id'=>$answerid,
								'answer_status'=>'true',
								
								);
							$historyexam_id=$this->questions_model->Save_Assessmenthistory($uexam_history);		
						}
						
						/*----End of insert user exam list-------*/
										
					/*----Get user exam question array------*/
					$exam_questermArr=array();
					$exam_questions=$this->questions_model->check_asstesthistory_question($userid,$year_id,1);
					if($exam_questions)
					{
						
						foreach($exam_questions as $examdata)
						{
							array_push($exam_questermArr,$examdata->question_id);
						}
					}
					
					if($year_id ==1)
						{
							$firstyear=$year_id;
							$secondyear=$year_id;
						}
						else if($year_id ==2)
						{
							$firstyear=$year_id-1;
							$secondyear=$year_id-1;
						}
						else if($year_id >2)
						{
							$firstyear=$year_id-2;
							$secondyear=$year_id-1;
						}
						
					/*----End of get user exam question array----*/
					$term_questermArr=array();
					$term_questions=$this->questions_model->assessment_exam($year_id,1);
					if($term_questions)
					{
						
						foreach($term_questions as $tquestion)
						{
							array_push($term_questermArr,$tquestion->ass_question);
						}
						
					}
					$total_exam_question=count($exam_questermArr);
					$total_term_question=count($term_questermArr);
					/*---update term by exam completed status----*/
					if($total_term_question==$total_exam_question)
					{
						$exam_status=array(
								'exam_status'=>'pass',							
								'end_time'=>$createdate,
								);
						
						$updateexam_status=$this->questions_model->Update_Asstterm_status($exam_status,$exam_id);
						$data['completed']=1;
					}
					/*---update term by exam completed status----*/
					$exam_output = array_merge(array_diff($term_questermArr, $exam_questermArr), array_diff($exam_questermArr, $term_questermArr));
					$exam_random=array_rand($exam_output);
					$randquestion=$exam_output[$exam_random];
					/* $exam_random=array_shift($exam_output);		
					$randquestion=$exam_random; */
					/*---End of check user not applied question list---*/
					$data['Questionlist']=$this->questions_model->asstest_exam_question($year_id,1,$randquestion);
						//$data['Questionlist']=$this->questions_model->term_exam($year_id,1);
						$data['exam_id']=$exam_id;
						$this->load->view('frontend/private/assessmentplay',$data);

					}
					else
					{
			
						/*----insert user exam list---------*/
						$userid=$this->session->userdata('user_id');
						$createdate=date("Y-m-d H:i:s");
						$chkrow_exam=$this->questions_model->check_userassessment($userid,$year_id,1);	
						
						if($chkrow_exam->exam_id!="" )
						{
							$exam_id=$chkrow_exam->exam_id;
						}
						else
						{
							$user_exam=array(
									'user_id'=>$userid,
									'year_id'=>$year_id,
									'assyear_id'=>$ass_year_id,													
									'exam_date'=>$createdate,
									'start_time'=>$createdate
									
									);
							$exam_id=$this->questions_model->Save_Userassessment($user_exam);	
						}
						
						if($exam_id!="")
						{
							$uexam_history=array(
								'exam_id'=>$exam_id,
								'user_id'=>$userid,
								'year_id'=>$year_id,
								'assyear_id'=>$ass_year_id,													
								'question_id'=>$questionid,
								'answer_id'=>$answerid,
								'answer_status'=>'false',
								
								);
							$hexam_id=$this->questions_model->Save_Assessmenthistory($uexam_history);		
						}
						
								/*----Get user exam question array------*/
					$exam_questermArr=array();
					$exam_questions=$this->questions_model->check_asstesthistory_question($userid,$year_id,$term_id);
					if($exam_questions)
					{
						
						foreach($exam_questions as $examdata)
						{
							array_push($exam_questermArr,$examdata->question_id);
						}
					}
					
					
					/*----End of get user exam question array----*/
					$term_questermArr=array();
					$term_questions=$this->questions_model->assessment_exam($year_id,1);
					if($term_questions)
					{
						
						foreach($term_questions as $tquestion)
						{
							array_push($term_questermArr,$tquestion->ass_question);
						}
						
					}
					$total_exam_question=count($exam_questermArr);
					$total_term_question=count($term_questermArr);
					/*---update term by exam completed status----*/
					if(30==$total_exam_question)
					{
						$exam_status=array(
								'exam_status'=>'pass',
								'end_time'=>$createdate,	
								
								);
						
						$updateexam_status=$this->questions_model->Update_Asstterm_status($exam_status,$exam_id);
						$data['completed']=1;
					}
					/*---update term by exam completed status----*/
						
						/*----End of insert user exam list-------*/
					
						$data["yourans"] = $this->main_model->get_detail('manage_answer_'.$ass_year_id,'ans_id',$answerid);	
						$data['exam_id']=$exam_id;
						$this->load->view('frontend/private/asstestexplanation',$data);
					}
					
								
					}
				else
				{
					$userid=$this->session->userdata('user_id');
					/*---check user not applied question list---*/
					$userexams=$this->questions_model->check_uasstestbyyear($userid,$year_id);
					$data['exam_id']=$userexams->exam_id;
					if($userexams->exam_id!="" && $userexams->exam_status=='pending')
					{	
						$data['assyear_id']=$userexams->assyear_id;
					}
					
					else if($userexams->exam_id!="" && $userexams->exam_status=='pass')
					{	
						$data['assyear_id']=$userexams->assyear_id+1;
					}
				
					else
					{
						$data['assyear_id']=$pastyear[0]->ass_year_id;
						//echo $pastyear[0]->ass_year_id;
					}
					
					/*----Get user exam question array------*/
					$exam_questermArr=array();
					$exam_questions=$this->questions_model->check_asstesthistory_question($userid,$year_id,1);
					if($exam_questions)
					{
						
						foreach($exam_questions as $examdata)
						{
							array_push($exam_questermArr,$examdata->question_id);
						}
					}
					
					
					/*----End of get user exam question array----*/
					
					if($year_id ==1)
						{
							$firstyear=$year_id;
							$secondyear=$year_id;
						}
						else if($year_id ==2)
						{
							$firstyear=$year_id-1;
							$secondyear=$year_id-1;
						}
						else if($year_id >2)
						{
							$firstyear=$year_id-2;
							$secondyear=$year_id-1;
						}
						
					$term_questermArr=array();
					$term_questions=$this->questions_model->assessment_exam($year_id,1,$firstyear);
					
					if($term_questions)
					{
						
						foreach($term_questions as $tquestion)
						{
							array_push($term_questermArr,$tquestion->ass_question);
						}
						
					}
					//var_dump($term_questermArr);
					
					$exam_output = array_merge(array_diff($term_questermArr, $exam_questermArr), array_diff($exam_questermArr, $term_questermArr));
					$exam_random=array_rand($exam_output);
					$randquestion=$exam_output[$exam_random];
					/* $exam_random=array_shift($exam_output);
					$randquestion=$exam_random; */
					/*---End of check user not applied question list---*/
					if($userexams->exam_status!='pass')
					{
					$data['Questionlist']=$this->questions_model->asstest_exam_question($year_id,1,$randquestion);
					}
					else
					{
						$data['Questionlist']='';
						$data['completed']=1;
					}
					//var_dump($data['Questionlist']);
					$this->load->view('frontend/private/assessmentplay',$data);
				}
			
			}
			/*---End Assessment Test -----*/
			/*---final year exam-----*/
			else if($subskill=="exam")
			{
				$this->session->set_userdata('ansattempt', '0');
				
			if($this->input->post('action')=='submitanswer')	
					{
					 $questionid=$this->input->post('questionid');
					 $answerid=$this->input->post('answerid');
					 $year_id=$this->input->post('year_id');
					 
					 $term_id=$this->input->post('term_id');
				
					
					$data["ques_dtl"] = $this->main_model->get_detail('manage_question_'.$year_id,'ques_id',$questionid);					
					
					$data["correct_ans"] = $this->main_model->get_detail('manage_answer_'.$year_id,'ans_id',$data["ques_dtl"]->ques_rightanswer);					
										
					if($data["ques_dtl"]->ques_rightanswer==$answerid)
					{
						
						$data['correct']=1;
						/*----insert user exam list---------*/
						$userid=$this->session->userdata('user_id');
						$createdate=date("Y-m-d H:i:s");
						$chkrow_exam=$this->questions_model->check_userexam($userid,$year_id,$term_id);	
						
						if($chkrow_exam->exam_id!="" )
						{
							$exam_id=$chkrow_exam->exam_id;
						}
						else
						{
							$user_exam=array(
									'user_id'=>$userid,
									'year_id'=>$year_id,
									'term_id'=>$term_id,													
									'exam_date'=>$createdate
									
									);
							$exam_id=$this->questions_model->Save_Userexam($user_exam);	
						}
						
						if($exam_id!="")
						{
							$uexam_history=array(
								'exam_id'=>$exam_id,
								'user_id'=>$userid,
								'year_id'=>$year_id,
								'term_id'=>$term_id,													
								'question_id'=>$questionid,
								'answer_id'=>$answerid,
								'answer_status'=>'false',
								
								);
							$historyexam_id=$this->questions_model->Save_Examhistory($uexam_history);		
						}
						
						/*----End of insert user exam list-------*/
						
										/*---check user not applied question list---*/
					$userexams=$this->questions_model->check_uexambyyear($userid,$year_id);
					if($userexams->exam_id!="" && $userexams->exam_status=='pending')
					{	
						$data['term_id']=$userexams->term_id;
					}
					else if($userexams->exam_id!="" && $userexams->exam_status=='pass')
					{	
						$data['term_id']=$userexams->term_id+1;
					}
					else
					{
						$data['term_id']=1;
					}
					
					/*----Get user exam question array------*/
					$exam_questermArr=array();
					$exam_questions=$this->questions_model->check_examhistory_question($userid,$year_id,$data['term_id']);
					if($exam_questions)
					{
						
						foreach($exam_questions as $examdata)
						{
							array_push($exam_questermArr,$examdata->question_id);
						}
					}
					
					
					/*----End of get user exam question array----*/
					$term_questermArr=array();
					$term_questions=$this->questions_model->term_exam($year_id,$data['term_id']);
					if($term_questions)
					{
						
						foreach($term_questions as $tquestion)
						{
							array_push($term_questermArr,$tquestion->question_id);
						}
						
					}
					$total_exam_question=count($exam_questermArr);
					$total_term_question=count($exam_questermArr);
					/*---update term by exam completed status----*/
					if($total_term_question==$total_exam_question)
					{
						$exam_status=array(
								'exam_status'=>'pass',							
								
								);
						
						$updateexam_status=$this->questions_model->Update_Examterm_status($exam_status,$exam_id);
					}
					/*---update term by exam completed status----*/
					$exam_output = array_merge(array_diff($term_questermArr, $exam_questermArr), array_diff($exam_questermArr, $term_questermArr));
					$exam_random=array_rand($exam_output);					
					$randquestion=$exam_output[$exam_random];
					/*---End of check user not applied question list---*/
					$data['Questionlist']=$this->questions_model->term_exam_question($year_id,$data['term_id'],$randquestion);
						//$data['Questionlist']=$this->questions_model->term_exam($year_id,1);
						$this->load->view('frontend/private/examplay',$data);

					}
					else
					{
			
						/*----insert user exam list---------*/
						$userid=$this->session->userdata('user_id');
						$createdate=date("Y-m-d H:i:s");
						$chkrow_exam=$this->questions_model->check_userexam($userid,$year_id,$term_id);	
						
						if($chkrow_exam->exam_id!="" )
						{
							$exam_id=$chkrow_exam->exam_id;
						}
						else
						{
							$user_exam=array(
									'user_id'=>$userid,
									'year_id'=>$year_id,
									'term_id'=>$term_id,													
									'exam_date'=>$createdate
									
									);
							$exam_id=$this->questions_model->Save_Userexam($user_exam);	
						}
						
						if($exam_id!="")
						{
							$uexam_history=array(
								'exam_id'=>$exam_id,
								'user_id'=>$userid,
								'year_id'=>$year_id,
								'term_id'=>$term_id,													
								'question_id'=>$questionid,
								'answer_id'=>$answerid,
								'answer_status'=>'true',
								
								);
							$hexam_id=$this->questions_model->Save_Examhistory($uexam_history);		
						}
						
								/*----Get user exam question array------*/
					$exam_questermArr=array();
					$exam_questions=$this->questions_model->check_examhistory_question($userid,$year_id,$term_id);
					if($exam_questions)
					{
						
						foreach($exam_questions as $examdata)
						{
							array_push($exam_questermArr,$examdata->question_id);
						}
					}
					
					
					/*----End of get user exam question array----*/
					$term_questermArr=array();
					$term_questions=$this->questions_model->term_exam($year_id,$term_id);
					if($term_questions)
					{
						
						foreach($term_questions as $tquestion)
						{
							array_push($term_questermArr,$tquestion->question_id);
						}
						
					}
					$total_exam_question=count($exam_questermArr);
					$total_term_question=count($exam_questermArr);
					/*---update term by exam completed status----*/
					if($total_term_question==$total_exam_question)
					{
						$exam_status=array(
								'exam_status'=>'pass',							
								
								);
						
						$updateexam_status=$this->questions_model->Update_Examterm_status($exam_status,$exam_id);
					}
					/*---update term by exam completed status----*/
						
						/*----End of insert user exam list-------*/
						$data["yourans"] = $this->main_model->get_detail('manage_answer_'.$year_id,'ans_id',$answerid);	
						$this->load->view('frontend/private/explanation',$data);
					}
					
								
					}
				else
				{
					$userid=$this->session->userdata('user_id');
					$this->session->set_userdata('ansattempt', '0');
					/*---check user not applied question list---*/
					$userexams=$this->questions_model->check_uexambyyear($userid,$year_id);
					$check_termexam_date=$this->questions_model->check_termexam_date($year_id);
					
					if($check_termexam_date->date!="0000-00-00 00:00:00")
					{	
						$cur_date=date("m/d/Y");
						$date=date("m/d/Y", strtotime($check_termexam_date->date));
						if($date==$cur_date){
						$data['term_id']=$check_termexam_date->term_id;
						
						}
						else{ $data['no_exam']=1;}
					}
					else
					{
						$data['no_exam']=1;
					}
					
					/*----Get user exam question array------*/
					$exam_questermArr=array();
					$exam_questions=$this->questions_model->check_examhistory_question($userid,$year_id,$data['term_id']);
					if($exam_questions)
					{
						
						foreach($exam_questions as $examdata)
						{
							array_push($exam_questermArr,$examdata->question_id);
						}
					}
					
					
					/*----End of get user exam question array----*/
					$term_questermArr=array();
					$term_questions=$this->questions_model->term_exam($year_id,$data['term_id']);
					if($term_questions)
					{
						
						foreach($term_questions as $tquestion)
						{
							array_push($term_questermArr,$tquestion->question_id);
						}
						
					}
					//var_dump($term_questermArr);
					
					$exam_output = array_merge(array_diff($term_questermArr, $exam_questermArr), array_diff($exam_questermArr, $term_questermArr));
					$exam_random=array_rand($exam_output);					
					$randquestion=$exam_output[$exam_random];
					/*---End of check user not applied question list---*/
					$data['Questionlist']=$this->questions_model->term_exam_question($year_id,$data['term_id'],$randquestion);
	
					$this->load->view('frontend/private/examplay',$data);
				}
			
			
			
			
			}
			/*---end final year exam-----*/
			else
			{	
				$this->session->unset_userdata('attempt');
				$this->session->unset_userdata('ansattempt');
			$data["skill_dtl"] =$this->main_model->get_skill('master_skill','skill_slug',$subskill,'skill_class',$year_id);		
			  $subskill_id=$data["skill_dtl"]->skill_id;
			 $this->questions_model->CLASSID = $year_id;
				//$data["Questionlist"] = $this->questions_model->question_list_subskill($subskill_id);
		
				if($this->input->post('action')=='submitanswer')	
					{
					 $questionid=$this->input->post('questionid');
					
					 
					$ques_detail= $this->questions_model->question_details($questionid);
					$ques_type=explode(',',$ques_detail->ques_type);
					if(in_array(1,$ques_type)){  
						
					 $answerid=$this->input->post('answerid');
					$answerid=$this->input->post('answerid');
				
					
					$data["ques_dtl"] = $this->main_model->get_detail('manage_question_'.$year_id,'ques_id',$questionid);
					//print_r($data["ques_dtl"]);
					
					$data["correct_ans"] = $this->main_model->get_detail('manage_answer_'.$year_id,'ans_id',$data["ques_dtl"]->ques_rightanswer);
					//print_r($data["correct_ans"]);
					//echo $data["correct_ans"]->ans_name;
										
					if($data["ques_dtl"]->ques_rightanswer==$answerid)
					{
						
					$data['correct']=1;
					$data["Questionlist"] = $this->questions_model->random_question($subskill_id);
					$this->load->view('frontend/private/play',$data);

					}
					else{
			
					$data["yourans"] = $this->main_model->get_detail('manage_answer_'.$year_id,'ans_id',$answerid);	
					$this->load->view('frontend/private/explanation',$data);
					}
					}
					elseif(in_array(26,$ques_type))
					{
						
					$all_answer = $this->main_model->getall('manage_answer_'.$year_id,'ans_quesid',$questionid);
					$answer_count = count($all_answer);
					
					$cnt_post_input=count($_POST)-3;
					if($answer_count==$cnt_post_input){
					$correct=true;
					 for($i=0;$i<count($all_answer);$i++){
						 
						$incount=$i+1;
						if($all_answer[$i]->ans_name!=$this->input->post('input'.$incount))
						{ 
							$correct=false;
							
						}
						
					 	
					 }
					}
					else{$correct=false;}
					 if($correct){
						$data['correct']=1;
						$data["Questionlist"] = $this->questions_model->random_question($subskill_id);
						$this->load->view('frontend/private/play',$data);
					 }
					 else{
						$data["yourans"] = $this->main_model->get_detail('manage_answer_'.$year_id,'ans_id',$answerid);	
						$this->load->view('frontend/private/explanation',$data);
					 }
					 
					}
					 
					
					else{
						$data["yourans"] = $this->main_model->get_detail('manage_answer_'.$year_id,'ans_id',$answerid);	
						$this->load->view('frontend/private/explanation',$data);
						}
						
					}
				else{
					$data["Questionlist"] = $this->questions_model->random_question($subskill_id);
					$this->load->view('frontend/private/play',$data);
					}
			
				}
			}
			else{
				
				if($this->session->userdata('user_id')!='' and $this->session->userdata('username')!='')
				{

				$data["SylList1"] = $this->syllabus_model->syllabus_list($year_id,1);
				$data["SylList2"] = $this->syllabus_model->syllabus_list($year_id,2);
				$data["SylList3"] = $this->syllabus_model->syllabus_list($year_id,3);
				$data["SylList4"] = $this->syllabus_model->syllabus_list($year_id,4);

				$this->load->view('frontend/private/kindergarten', $data);
				}
				else{
				$data["SylList1"] = $this->syllabus_model->syllabus_list($year_id,1);
				$data["SylList2"] = $this->syllabus_model->syllabus_list($year_id,2);
				$data["SylList3"] = $this->syllabus_model->syllabus_list($year_id,3);
				$data["SylList4"] = $this->syllabus_model->syllabus_list($year_id,4);

				$this->load->view('frontend/public/kg_wtht_login', $data);	
					
				}

			}
		
	}
	public function year4($subskill='') 
	{	
		$yearid=$this->session->userdata('loginyear');
			$yeardata=$this->classes_model->classes_details($yearid);
			if($yeardata)
			{
				$data['year_name']=$yeardata[0]->class_name;
				$data['year_slug']=$yeardata[0]->class_slug;
			}
		$year_id=5;
		$data['year_id']=$year_id;
		
		$userid2=$this->session->userdata('user_id');			
		$data['aatcount']=$this->exam_model->checkuser_aat_status($yearid,$userid2);
		
		$this->questions_model->CLASSID = $year_id;
		$data["year_dtl"] = $this->main_model->get_detail('master_class','class_id',$year_id);	
		$data['subskill']=$subskill;
		if($subskill!=""){
			/*---Start Assessment Test -----*/
				if($subskill=="assessment")
			{		
					 $this->session->set_userdata('attempt_ques', 0);
					 
					 //Page reload truncate table
					if($this->session->userdata('ass_attempt') > 0)
					{
					$checkasstest=$this->db->query("select exam_status from student_assessment_test  where year_id='".$year_id."' and user_id='".$this->session->userdata('user_id')."' 
							");
					$rowchecktest_status=$checkasstest->row();
					if($rowchecktest_status->exam_status=='pending')
					{						
					$del_asshistory=$this->db->query("delete  from sasstest_history  where year_id='".$year_id."' and user_id='".$this->session->userdata('user_id')."' 
							");
					$del_assmasterhistory=$this->db->query("delete  from student_assessment_test  where year_id='".$year_id."' and user_id='".$this->session->userdata('user_id')."' 
							");	
					$data['err_reload']=1;	
					$this->session->unset_userdata('ass_attempt');	
					}
					else
					{
						$data['err_reload']='';
					}						
					}
					else
					{
						$data['err_reload']='';	
					}
					
					/*---get all past year of assessment list----*/
					$pastyear=$this->questions_model->assessment_pastyear($year_id);
						/*echo '<pre>';
						var_dump($pastyear);
						echo '</pre>';
						*/
					$todaydate=date("Y-m-d H:i:s");	
					$userid=$this->session->userdata('user_id');
					$asstime_query=$this->questions_model->assessment_time($year_id,$userid);
					$yourstart=$asstime_query->start_time;
					if($yourstart!="" && $yourstart!=null)
					{
						$seconds = strtotime($todaydate) - strtotime($yourstart);
						$days    = floor($seconds / 86400);
						$hours   = floor(($seconds - ($days * 86400)) / 3600);
						$minutes = floor(($seconds - ($days * 86400) - ($hours * 3600))/60);
						
						if($minutes >30)
						{
							//echo $minutes;
							$exam_status=array(
								'exam_status'=>'pass',							
								'end_time'=>$todaydate,
								);
						
						$updateexam_status=$this->questions_model->Update_Asstterm_status($exam_status,$asstime_query->exam_id);
						$data['timeover']=1;
						}
						else
						{
							$totalminutes=30-$minutes;
							$data['showtimer']='Duration Left: '.$totalminutes;
						}
					}
					else
					{
						$data['showtimer']='Duration: 30';
					}
					
					/*---end of get all past year of assessment list----*/	
					if($this->input->post('action')=='submitanswer')	
					{
						//var_dump($this->input->post());
					$this->session->unset_userdata('ass_attempt');	
					 $questionid=$this->input->post('questionid');
					 $answerid=$this->input->post('answerid');
					 $year_id=$this->input->post('year_id');
					 $ass_year_id=$this->input->post('ass_year_id');
				
					
					$data["ques_dtl"] = $this->main_model->get_detail('manage_question_'.$ass_year_id,'ques_id',$questionid);					
					//var_dump($data["ques_dtl"]);
					$data["correct_ans"] = $this->main_model->get_detail('manage_answer_'.$ass_year_id,'ans_id',$data["ques_dtl"]->ques_rightanswer);					
										
					if($data["ques_dtl"]->ques_rightanswer==$answerid)
					{
						
						$data['correct']=1;
						/*----insert user exam list---------*/
						
						$createdate=date("Y-m-d H:i:s");
						$chkrow_exam=$this->questions_model->check_userassessment($userid,$year_id,1);	
						
						if($chkrow_exam->exam_id!="" )
						{
							$exam_id=$chkrow_exam->exam_id;
						}
						else
						{
							$user_exam=array(
									'user_id'=>$userid,
									'year_id'=>$year_id,
									'assyear_id'=>$ass_year_id,													
									'exam_date'=>$createdate,
									'start_time'=>$createdate
									
									);
							$exam_id=$this->questions_model->Save_Userassessment($user_exam);	
						}
						
						if($exam_id!="")
						{
							$uexam_history=array(
								'exam_id'=>$exam_id,
								'user_id'=>$userid,
								'year_id'=>$year_id,
								'assyear_id'=>$ass_year_id,													
								'question_id'=>$questionid,
								'answer_id'=>$answerid,
								'answer_status'=>'true',
								
								);
							$historyexam_id=$this->questions_model->Save_Assessmenthistory($uexam_history);		
						}
						
						/*----End of insert user exam list-------*/
										
					/*----Get user exam question array------*/
					$exam_questermArr=array();
					$exam_questions=$this->questions_model->check_asstesthistory_question($userid,$year_id,1);
					if($exam_questions)
					{
						
						foreach($exam_questions as $examdata)
						{
							array_push($exam_questermArr,$examdata->question_id);
						}
					}
					
					if($year_id ==1)
						{
							$firstyear=$year_id;
							$secondyear=$year_id;
						}
						else if($year_id ==2)
						{
							$firstyear=$year_id-1;
							$secondyear=$year_id-1;
						}
						else if($year_id >2)
						{
							$firstyear=$year_id-2;
							$secondyear=$year_id-1;
						}
						
					/*----End of get user exam question array----*/
					$term_questermArr=array();
					$term_questions=$this->questions_model->assessment_exam($year_id,1);
					if($term_questions)
					{
						
						foreach($term_questions as $tquestion)
						{
							array_push($term_questermArr,$tquestion->ass_question);
						}
						
					}
					$total_exam_question=count($exam_questermArr);
					$total_term_question=count($term_questermArr);
					/*---update term by exam completed status----*/
					if($total_term_question==$total_exam_question)
					{
						$exam_status=array(
								'exam_status'=>'pass',							
								'end_time'=>$createdate,
								);
						
						$updateexam_status=$this->questions_model->Update_Asstterm_status($exam_status,$exam_id);
						$data['completed']=1;
					}
					/*---update term by exam completed status----*/
					$exam_output = array_merge(array_diff($term_questermArr, $exam_questermArr), array_diff($exam_questermArr, $term_questermArr));
					$exam_random=array_rand($exam_output);
					$randquestion=$exam_output[$exam_random];
					/* $exam_random=array_shift($exam_output);		
					$randquestion=$exam_random; */
					/*---End of check user not applied question list---*/
					$data['Questionlist']=$this->questions_model->asstest_exam_question($year_id,1,$randquestion);
						//$data['Questionlist']=$this->questions_model->term_exam($year_id,1);
						$data['exam_id']=$exam_id;
						$this->load->view('frontend/private/assessmentplay',$data);

					}
					else
					{
			
						/*----insert user exam list---------*/
						$userid=$this->session->userdata('user_id');
						$createdate=date("Y-m-d H:i:s");
						$chkrow_exam=$this->questions_model->check_userassessment($userid,$year_id,1);	
						
						if($chkrow_exam->exam_id!="" )
						{
							$exam_id=$chkrow_exam->exam_id;
						}
						else
						{
							$user_exam=array(
									'user_id'=>$userid,
									'year_id'=>$year_id,
									'assyear_id'=>$ass_year_id,													
									'exam_date'=>$createdate,
									'start_time'=>$createdate
									
									);
							$exam_id=$this->questions_model->Save_Userassessment($user_exam);	
						}
						
						if($exam_id!="")
						{
							$uexam_history=array(
								'exam_id'=>$exam_id,
								'user_id'=>$userid,
								'year_id'=>$year_id,
								'assyear_id'=>$ass_year_id,													
								'question_id'=>$questionid,
								'answer_id'=>$answerid,
								'answer_status'=>'false',
								
								);
							$hexam_id=$this->questions_model->Save_Assessmenthistory($uexam_history);		
						}
						
								/*----Get user exam question array------*/
					$exam_questermArr=array();
					$exam_questions=$this->questions_model->check_asstesthistory_question($userid,$year_id,$term_id);
					if($exam_questions)
					{
						
						foreach($exam_questions as $examdata)
						{
							array_push($exam_questermArr,$examdata->question_id);
						}
					}
					
					
					/*----End of get user exam question array----*/
					$term_questermArr=array();
					$term_questions=$this->questions_model->assessment_exam($year_id,1);
					if($term_questions)
					{
						
						foreach($term_questions as $tquestion)
						{
							array_push($term_questermArr,$tquestion->ass_question);
						}
						
					}
					$total_exam_question=count($exam_questermArr);
					$total_term_question=count($term_questermArr);
					/*---update term by exam completed status----*/
					if(30==$total_exam_question)
					{
						$exam_status=array(
								'exam_status'=>'pass',
								'end_time'=>$createdate,	
								
								);
						
						$updateexam_status=$this->questions_model->Update_Asstterm_status($exam_status,$exam_id);
						$data['completed']=1;
					}
					/*---update term by exam completed status----*/
						
						/*----End of insert user exam list-------*/
					
						$data["yourans"] = $this->main_model->get_detail('manage_answer_'.$ass_year_id,'ans_id',$answerid);	
						$data['exam_id']=$exam_id;
						$this->load->view('frontend/private/asstestexplanation',$data);
					}
					
								
					}
				else
				{
					$userid=$this->session->userdata('user_id');
					/*---check user not applied question list---*/
					$userexams=$this->questions_model->check_uasstestbyyear($userid,$year_id);
					$data['exam_id']=$userexams->exam_id;
					if($userexams->exam_id!="" && $userexams->exam_status=='pending')
					{	
						$data['assyear_id']=$userexams->assyear_id;
					}
					
					else if($userexams->exam_id!="" && $userexams->exam_status=='pass')
					{	
						$data['assyear_id']=$userexams->assyear_id+1;
					}
				
					else
					{
						$data['assyear_id']=$pastyear[0]->ass_year_id;
						//echo $pastyear[0]->ass_year_id;
					}
					
					/*----Get user exam question array------*/
					$exam_questermArr=array();
					$exam_questions=$this->questions_model->check_asstesthistory_question($userid,$year_id,1);
					if($exam_questions)
					{
						
						foreach($exam_questions as $examdata)
						{
							array_push($exam_questermArr,$examdata->question_id);
						}
					}
					
					
					/*----End of get user exam question array----*/
					
					if($year_id ==1)
						{
							$firstyear=$year_id;
							$secondyear=$year_id;
						}
						else if($year_id ==2)
						{
							$firstyear=$year_id-1;
							$secondyear=$year_id-1;
						}
						else if($year_id >2)
						{
							$firstyear=$year_id-2;
							$secondyear=$year_id-1;
						}
						
					$term_questermArr=array();
					$term_questions=$this->questions_model->assessment_exam($year_id,1,$firstyear);
					
					if($term_questions)
					{
						
						foreach($term_questions as $tquestion)
						{
							array_push($term_questermArr,$tquestion->ass_question);
						}
						
					}
					//var_dump($term_questermArr);
					
					$exam_output = array_merge(array_diff($term_questermArr, $exam_questermArr), array_diff($exam_questermArr, $term_questermArr));
					$exam_random=array_rand($exam_output);
					$randquestion=$exam_output[$exam_random];
					/* $exam_random=array_shift($exam_output);
					$randquestion=$exam_random; */
					/*---End of check user not applied question list---*/
					if($userexams->exam_status!='pass')
					{
					$data['Questionlist']=$this->questions_model->asstest_exam_question($year_id,1,$randquestion);
					}
					else
					{
						$data['Questionlist']='';
						$data['completed']=1;
					}
					//var_dump($data['Questionlist']);
					$this->load->view('frontend/private/assessmentplay',$data);
				}
			
			}
		/*---End Assessment Test -----*/
			/*---final year exam-----*/
			else if($subskill=="exam")
			{
				$this->session->set_userdata('ansattempt', '0');
				
			if($this->input->post('action')=='submitanswer')	
					{
					 $questionid=$this->input->post('questionid');
					 $answerid=$this->input->post('answerid');
					 $year_id=$this->input->post('year_id');
					 
					 $term_id=$this->input->post('term_id');
				
					
					$data["ques_dtl"] = $this->main_model->get_detail('manage_question_'.$year_id,'ques_id',$questionid);					
					
					$data["correct_ans"] = $this->main_model->get_detail('manage_answer_'.$year_id,'ans_id',$data["ques_dtl"]->ques_rightanswer);					
										
					if($data["ques_dtl"]->ques_rightanswer==$answerid)
					{
						
						$data['correct']=1;
						/*----insert user exam list---------*/
						$userid=$this->session->userdata('user_id');
						$createdate=date("Y-m-d H:i:s");
						$chkrow_exam=$this->questions_model->check_userexam($userid,$year_id,$term_id);	
						
						if($chkrow_exam->exam_id!="" )
						{
							$exam_id=$chkrow_exam->exam_id;
						}
						else
						{
							$user_exam=array(
									'user_id'=>$userid,
									'year_id'=>$year_id,
									'term_id'=>$term_id,													
									'exam_date'=>$createdate
									
									);
							$exam_id=$this->questions_model->Save_Userexam($user_exam);	
						}
						
						if($exam_id!="")
						{
							$uexam_history=array(
								'exam_id'=>$exam_id,
								'user_id'=>$userid,
								'year_id'=>$year_id,
								'term_id'=>$term_id,													
								'question_id'=>$questionid,
								'answer_id'=>$answerid,
								'answer_status'=>'false',
								
								);
							$historyexam_id=$this->questions_model->Save_Examhistory($uexam_history);		
						}
						
						/*----End of insert user exam list-------*/
						
										/*---check user not applied question list---*/
					$userexams=$this->questions_model->check_uexambyyear($userid,$year_id);
					if($userexams->exam_id!="" && $userexams->exam_status=='pending')
					{	
						$data['term_id']=$userexams->term_id;
					}
					else if($userexams->exam_id!="" && $userexams->exam_status=='pass')
					{	
						$data['term_id']=$userexams->term_id+1;
					}
					else
					{
						$data['term_id']=1;
					}
					
					/*----Get user exam question array------*/
					$exam_questermArr=array();
					$exam_questions=$this->questions_model->check_examhistory_question($userid,$year_id,$data['term_id']);
					if($exam_questions)
					{
						
						foreach($exam_questions as $examdata)
						{
							array_push($exam_questermArr,$examdata->question_id);
						}
					}
					
					
					/*----End of get user exam question array----*/
					$term_questermArr=array();
					$term_questions=$this->questions_model->term_exam($year_id,$data['term_id']);
					if($term_questions)
					{
						
						foreach($term_questions as $tquestion)
						{
							array_push($term_questermArr,$tquestion->question_id);
						}
						
					}
					$total_exam_question=count($exam_questermArr);
					$total_term_question=count($exam_questermArr);
					/*---update term by exam completed status----*/
					if($total_term_question==$total_exam_question)
					{
						$exam_status=array(
								'exam_status'=>'pass',							
								
								);
						
						$updateexam_status=$this->questions_model->Update_Examterm_status($exam_status,$exam_id);
					}
					/*---update term by exam completed status----*/
					$exam_output = array_merge(array_diff($term_questermArr, $exam_questermArr), array_diff($exam_questermArr, $term_questermArr));
					$exam_random=array_rand($exam_output);					
					$randquestion=$exam_output[$exam_random];
					/*---End of check user not applied question list---*/
					$data['Questionlist']=$this->questions_model->term_exam_question($year_id,$data['term_id'],$randquestion);
						//$data['Questionlist']=$this->questions_model->term_exam($year_id,1);
						$this->load->view('frontend/private/examplay',$data);

					}
					else
					{
			
						/*----insert user exam list---------*/
						$userid=$this->session->userdata('user_id');
						$createdate=date("Y-m-d H:i:s");
						$chkrow_exam=$this->questions_model->check_userexam($userid,$year_id,$term_id);	
						
						if($chkrow_exam->exam_id!="" )
						{
							$exam_id=$chkrow_exam->exam_id;
						}
						else
						{
							$user_exam=array(
									'user_id'=>$userid,
									'year_id'=>$year_id,
									'term_id'=>$term_id,													
									'exam_date'=>$createdate
									
									);
							$exam_id=$this->questions_model->Save_Userexam($user_exam);	
						}
						
						if($exam_id!="")
						{
							$uexam_history=array(
								'exam_id'=>$exam_id,
								'user_id'=>$userid,
								'year_id'=>$year_id,
								'term_id'=>$term_id,													
								'question_id'=>$questionid,
								'answer_id'=>$answerid,
								'answer_status'=>'true',
								
								);
							$hexam_id=$this->questions_model->Save_Examhistory($uexam_history);		
						}
						
								/*----Get user exam question array------*/
					$exam_questermArr=array();
					$exam_questions=$this->questions_model->check_examhistory_question($userid,$year_id,$term_id);
					if($exam_questions)
					{
						
						foreach($exam_questions as $examdata)
						{
							array_push($exam_questermArr,$examdata->question_id);
						}
					}
					
					
					/*----End of get user exam question array----*/
					$term_questermArr=array();
					$term_questions=$this->questions_model->term_exam($year_id,$term_id);
					if($term_questions)
					{
						
						foreach($term_questions as $tquestion)
						{
							array_push($term_questermArr,$tquestion->question_id);
						}
						
					}
					$total_exam_question=count($exam_questermArr);
					$total_term_question=count($exam_questermArr);
					/*---update term by exam completed status----*/
					if($total_term_question==$total_exam_question)
					{
						$exam_status=array(
								'exam_status'=>'pass',							
								
								);
						
						$updateexam_status=$this->questions_model->Update_Examterm_status($exam_status,$exam_id);
					}
					/*---update term by exam completed status----*/
						
						/*----End of insert user exam list-------*/
						$data["yourans"] = $this->main_model->get_detail('manage_answer_'.$year_id,'ans_id',$answerid);	
						$this->load->view('frontend/private/explanation',$data);
					}
					
								
					}
				else
				{
					$userid=$this->session->userdata('user_id');
					$this->session->set_userdata('ansattempt', '0');
					/*---check user not applied question list---*/
					$userexams=$this->questions_model->check_uexambyyear($userid,$year_id);
					$check_termexam_date=$this->questions_model->check_termexam_date($year_id);
					
					if($check_termexam_date->date!="0000-00-00 00:00:00")
					{	
						$cur_date=date("m/d/Y");
						$date=date("m/d/Y", strtotime($check_termexam_date->date));
						if($date==$cur_date){
						$data['term_id']=$check_termexam_date->term_id;
						
						}
						else{ $data['no_exam']=1;}
					}
					else
					{
						$data['no_exam']=1;
					}
					
					/*----Get user exam question array------*/
					$exam_questermArr=array();
					$exam_questions=$this->questions_model->check_examhistory_question($userid,$year_id,$data['term_id']);
					if($exam_questions)
					{
						
						foreach($exam_questions as $examdata)
						{
							array_push($exam_questermArr,$examdata->question_id);
						}
					}
					
					
					/*----End of get user exam question array----*/
					$term_questermArr=array();
					$term_questions=$this->questions_model->term_exam($year_id,$data['term_id']);
					if($term_questions)
					{
						
						foreach($term_questions as $tquestion)
						{
							array_push($term_questermArr,$tquestion->question_id);
						}
						
					}
					//var_dump($term_questermArr);
					
					$exam_output = array_merge(array_diff($term_questermArr, $exam_questermArr), array_diff($exam_questermArr, $term_questermArr));
					$exam_random=array_rand($exam_output);					
					$randquestion=$exam_output[$exam_random];
					/*---End of check user not applied question list---*/
					$data['Questionlist']=$this->questions_model->term_exam_question($year_id,$data['term_id'],$randquestion);
	
					$this->load->view('frontend/private/examplay',$data);
				}
			
			
			
			
			}
			/*---end final year exam-----*/
			else
			{	
				$this->session->unset_userdata('attempt');
				$this->session->unset_userdata('ansattempt');
			$data["skill_dtl"] =$this->main_model->get_skill('master_skill','skill_slug',$subskill,'skill_class',$year_id);		
			  $subskill_id=$data["skill_dtl"]->skill_id;
			 
			 $this->questions_model->CLASSID = $year_id;
				//$data["Questionlist"] = $this->questions_model->question_list_subskill($subskill_id);
		
				if($this->input->post('action')=='submitanswer')	
					{
					 $questionid=$this->input->post('questionid');
					
					 
					$ques_detail= $this->questions_model->question_details($questionid);
					$ques_type=explode(',',$ques_detail->ques_type);
					if(in_array(1,$ques_type)){  
						
					 $answerid=$this->input->post('answerid');
					$answerid=$this->input->post('answerid');
				
					
					$data["ques_dtl"] = $this->main_model->get_detail('manage_question_'.$year_id,'ques_id',$questionid);
					//print_r($data["ques_dtl"]);
					
					$data["correct_ans"] = $this->main_model->get_detail('manage_answer_'.$year_id,'ans_id',$data["ques_dtl"]->ques_rightanswer);
					//print_r($data["correct_ans"]);
					//echo $data["correct_ans"]->ans_name;
										
					if($data["ques_dtl"]->ques_rightanswer==$answerid)
					{
						
					$data['correct']=1;
					$data["Questionlist"] = $this->questions_model->random_question($subskill_id);
					$this->load->view('frontend/private/play',$data);

					}
					else{
			
					$data["yourans"] = $this->main_model->get_detail('manage_answer_'.$year_id,'ans_id',$answerid);	
					$this->load->view('frontend/private/explanation',$data);
					}
					}
					elseif(in_array(26,$ques_type))
					{
						
					$all_answer = $this->main_model->getall('manage_answer_'.$year_id,'ans_quesid',$questionid);
					$correct=true;
					 for($i=0;$i<count($all_answer);$i++){
						 
						$incount=$i+1;
						if($all_answer[$i]->ans_name!=$this->input->post('input'.$incount))
						{ 
							$correct=false;
							
						}
						
					 	
					 }
					 
					 if($correct){
						$data['correct']=1;
						$data["Questionlist"] = $this->questions_model->random_question($subskill_id);
						$this->load->view('frontend/private/play',$data);
					 }
					 else{
						$data["yourans"] = $this->main_model->get_detail('manage_answer_'.$year_id,'ans_id',$answerid);	
						$this->load->view('frontend/private/explanation',$data);
					 }
					 
					}
					 
					
					else{
						$data["yourans"] = $this->main_model->get_detail('manage_answer_'.$year_id,'ans_id',$answerid);	
						$this->load->view('frontend/private/explanation',$data);
						}
						
					}
				else{
					$data["Questionlist"] = $this->questions_model->random_question($subskill_id);
					$this->load->view('frontend/private/play',$data);
					}
			
				}
			}
			else{
				
				if($this->session->userdata('user_id')!='' && $this->session->userdata('username')!='')
				{
				
				$data["SylList1"] = $this->syllabus_model->syllabus_list($year_id,1);
				$data["SylList2"] = $this->syllabus_model->syllabus_list($year_id,2);
				$data["SylList3"] = $this->syllabus_model->syllabus_list($year_id,3);
				$data["SylList4"] = $this->syllabus_model->syllabus_list($year_id,4);

				$this->load->view('frontend/private/kindergarten', $data);
				}
				else{
				$data["SylList1"] = $this->syllabus_model->syllabus_list($year_id,1);
				$data["SylList2"] = $this->syllabus_model->syllabus_list($year_id,2);
				$data["SylList3"] = $this->syllabus_model->syllabus_list($year_id,3);
				$data["SylList4"] = $this->syllabus_model->syllabus_list($year_id,4);

				$this->load->view('frontend/public/kg_wtht_login', $data);	
					
				}

			}
		
	}
	public function year5($subskill='') 
	{	
		$yearid=$this->session->userdata('loginyear');
			$yeardata=$this->classes_model->classes_details($yearid);
			if($yeardata)
			{
				$data['year_name']=$yeardata[0]->class_name;
				$data['year_slug']=$yeardata[0]->class_slug;
			}
		$year_id=6;
		$data['year_id']=$year_id;
		
		$userid2=$this->session->userdata('user_id');			
		$data['aatcount']=$this->exam_model->checkuser_aat_status($yearid,$userid2);
		
		$this->questions_model->CLASSID = $year_id;
		$data["year_dtl"] = $this->main_model->get_detail('master_class','class_id',$year_id);	
		$data['subskill']=$subskill;
		if($subskill!=""){
			/*---Start Assessment Test -----*/
				if($subskill=="assessment")
			{		
					 $this->session->set_userdata('attempt_ques', 0);
					 
					 //Page reload truncate table
					if($this->session->userdata('ass_attempt') > 0)
					{
					$checkasstest=$this->db->query("select exam_status from student_assessment_test  where year_id='".$year_id."' and user_id='".$this->session->userdata('user_id')."' 
							");
					$rowchecktest_status=$checkasstest->row();
					if($rowchecktest_status->exam_status=='pending')
					{						
					$del_asshistory=$this->db->query("delete  from sasstest_history  where year_id='".$year_id."' and user_id='".$this->session->userdata('user_id')."' 
							");
					$del_assmasterhistory=$this->db->query("delete  from student_assessment_test  where year_id='".$year_id."' and user_id='".$this->session->userdata('user_id')."' 
							");	
					$data['err_reload']=1;	
					$this->session->unset_userdata('ass_attempt');	
					}
					else
					{
						$data['err_reload']='';
					}						
					}
					else
					{
						$data['err_reload']='';	
					}
					
					/*---get all past year of assessment list----*/
					$pastyear=$this->questions_model->assessment_pastyear($year_id);
						/*echo '<pre>';
						var_dump($pastyear);
						echo '</pre>';
						*/
					$todaydate=date("Y-m-d H:i:s");	
					$userid=$this->session->userdata('user_id');
					$asstime_query=$this->questions_model->assessment_time($year_id,$userid);
					$yourstart=$asstime_query->start_time;
					if($yourstart!="" && $yourstart!=null)
					{
						$seconds = strtotime($todaydate) - strtotime($yourstart);
						$days    = floor($seconds / 86400);
						$hours   = floor(($seconds - ($days * 86400)) / 3600);
						$minutes = floor(($seconds - ($days * 86400) - ($hours * 3600))/60);
						
						if($minutes >30)
						{
							//echo $minutes;
							$exam_status=array(
								'exam_status'=>'pass',							
								'end_time'=>$todaydate,
								);
						
						$updateexam_status=$this->questions_model->Update_Asstterm_status($exam_status,$asstime_query->exam_id);
						$data['timeover']=1;
						}
						else
						{
							$totalminutes=30-$minutes;
							$data['showtimer']='Duration Left: '.$totalminutes;
						}
					}
					else
					{
						$data['showtimer']='Duration: 30';
					}
					
					/*---end of get all past year of assessment list----*/	
					if($this->input->post('action')=='submitanswer')	
					{
						//var_dump($this->input->post());
					$this->session->unset_userdata('ass_attempt');	
					 $questionid=$this->input->post('questionid');
					 $answerid=$this->input->post('answerid');
					 $year_id=$this->input->post('year_id');
					 $ass_year_id=$this->input->post('ass_year_id');
				
					
					$data["ques_dtl"] = $this->main_model->get_detail('manage_question_'.$ass_year_id,'ques_id',$questionid);					
					//var_dump($data["ques_dtl"]);
					$data["correct_ans"] = $this->main_model->get_detail('manage_answer_'.$ass_year_id,'ans_id',$data["ques_dtl"]->ques_rightanswer);					
										
					if($data["ques_dtl"]->ques_rightanswer==$answerid)
					{
						
						$data['correct']=1;
						/*----insert user exam list---------*/
						
						$createdate=date("Y-m-d H:i:s");
						$chkrow_exam=$this->questions_model->check_userassessment($userid,$year_id,1);	
						
						if($chkrow_exam->exam_id!="" )
						{
							$exam_id=$chkrow_exam->exam_id;
						}
						else
						{
							$user_exam=array(
									'user_id'=>$userid,
									'year_id'=>$year_id,
									'assyear_id'=>$ass_year_id,													
									'exam_date'=>$createdate,
									'start_time'=>$createdate
									
									);
							$exam_id=$this->questions_model->Save_Userassessment($user_exam);	
						}
						
						if($exam_id!="")
						{
							$uexam_history=array(
								'exam_id'=>$exam_id,
								'user_id'=>$userid,
								'year_id'=>$year_id,
								'assyear_id'=>$ass_year_id,													
								'question_id'=>$questionid,
								'answer_id'=>$answerid,
								'answer_status'=>'true',
								
								);
							$historyexam_id=$this->questions_model->Save_Assessmenthistory($uexam_history);		
						}
						
						/*----End of insert user exam list-------*/
										
					/*----Get user exam question array------*/
					$exam_questermArr=array();
					$exam_questions=$this->questions_model->check_asstesthistory_question($userid,$year_id,1);
					if($exam_questions)
					{
						
						foreach($exam_questions as $examdata)
						{
							array_push($exam_questermArr,$examdata->question_id);
						}
					}
					
					if($year_id ==1)
						{
							$firstyear=$year_id;
							$secondyear=$year_id;
						}
						else if($year_id ==2)
						{
							$firstyear=$year_id-1;
							$secondyear=$year_id-1;
						}
						else if($year_id >2)
						{
							$firstyear=$year_id-2;
							$secondyear=$year_id-1;
						}
						
					/*----End of get user exam question array----*/
					$term_questermArr=array();
					$term_questions=$this->questions_model->assessment_exam($year_id,1);
					if($term_questions)
					{
						
						foreach($term_questions as $tquestion)
						{
							array_push($term_questermArr,$tquestion->ass_question);
						}
						
					}
					$total_exam_question=count($exam_questermArr);
					$total_term_question=count($term_questermArr);
					/*---update term by exam completed status----*/
					if($total_term_question==$total_exam_question)
					{
						$exam_status=array(
								'exam_status'=>'pass',							
								'end_time'=>$createdate,
								);
						
						$updateexam_status=$this->questions_model->Update_Asstterm_status($exam_status,$exam_id);
						$data['completed']=1;
					}
					/*---update term by exam completed status----*/
					$exam_output = array_merge(array_diff($term_questermArr, $exam_questermArr), array_diff($exam_questermArr, $term_questermArr));
					$exam_random=array_rand($exam_output);
					$randquestion=$exam_output[$exam_random];
					/* $exam_random=array_shift($exam_output);		
					$randquestion=$exam_random; */
					/*---End of check user not applied question list---*/
					$data['Questionlist']=$this->questions_model->asstest_exam_question($year_id,1,$randquestion);
						//$data['Questionlist']=$this->questions_model->term_exam($year_id,1);
						$data['exam_id']=$exam_id;
						$this->load->view('frontend/private/assessmentplay',$data);

					}
					else
					{
			
						/*----insert user exam list---------*/
						$userid=$this->session->userdata('user_id');
						$createdate=date("Y-m-d H:i:s");
						$chkrow_exam=$this->questions_model->check_userassessment($userid,$year_id,1);	
						
						if($chkrow_exam->exam_id!="" )
						{
							$exam_id=$chkrow_exam->exam_id;
						}
						else
						{
							$user_exam=array(
									'user_id'=>$userid,
									'year_id'=>$year_id,
									'assyear_id'=>$ass_year_id,													
									'exam_date'=>$createdate,
									'start_time'=>$createdate
									
									);
							$exam_id=$this->questions_model->Save_Userassessment($user_exam);	
						}
						
						if($exam_id!="")
						{
							$uexam_history=array(
								'exam_id'=>$exam_id,
								'user_id'=>$userid,
								'year_id'=>$year_id,
								'assyear_id'=>$ass_year_id,													
								'question_id'=>$questionid,
								'answer_id'=>$answerid,
								'answer_status'=>'false',
								
								);
							$hexam_id=$this->questions_model->Save_Assessmenthistory($uexam_history);		
						}
						
								/*----Get user exam question array------*/
					$exam_questermArr=array();
					$exam_questions=$this->questions_model->check_asstesthistory_question($userid,$year_id,$term_id);
					if($exam_questions)
					{
						
						foreach($exam_questions as $examdata)
						{
							array_push($exam_questermArr,$examdata->question_id);
						}
					}
					
					
					/*----End of get user exam question array----*/
					$term_questermArr=array();
					$term_questions=$this->questions_model->assessment_exam($year_id,1);
					if($term_questions)
					{
						
						foreach($term_questions as $tquestion)
						{
							array_push($term_questermArr,$tquestion->ass_question);
						}
						
					}
					$total_exam_question=count($exam_questermArr);
					$total_term_question=count($term_questermArr);
					/*---update term by exam completed status----*/
					if(30==$total_exam_question)
					{
						$exam_status=array(
								'exam_status'=>'pass',
								'end_time'=>$createdate,	
								
								);
						
						$updateexam_status=$this->questions_model->Update_Asstterm_status($exam_status,$exam_id);
						$data['completed']=1;
					}
					/*---update term by exam completed status----*/
						
						/*----End of insert user exam list-------*/
					
						$data["yourans"] = $this->main_model->get_detail('manage_answer_'.$ass_year_id,'ans_id',$answerid);	
						$data['exam_id']=$exam_id;
						$this->load->view('frontend/private/asstestexplanation',$data);
					}
					
								
					}
				else
				{
					$userid=$this->session->userdata('user_id');
					/*---check user not applied question list---*/
					$userexams=$this->questions_model->check_uasstestbyyear($userid,$year_id);
					$data['exam_id']=$userexams->exam_id;
					if($userexams->exam_id!="" && $userexams->exam_status=='pending')
					{	
						$data['assyear_id']=$userexams->assyear_id;
					}
					
					else if($userexams->exam_id!="" && $userexams->exam_status=='pass')
					{	
						$data['assyear_id']=$userexams->assyear_id+1;
					}
				
					else
					{
						$data['assyear_id']=$pastyear[0]->ass_year_id;
						//echo $pastyear[0]->ass_year_id;
					}
					
					/*----Get user exam question array------*/
					$exam_questermArr=array();
					$exam_questions=$this->questions_model->check_asstesthistory_question($userid,$year_id,1);
					if($exam_questions)
					{
						
						foreach($exam_questions as $examdata)
						{
							array_push($exam_questermArr,$examdata->question_id);
						}
					}
					
					
					/*----End of get user exam question array----*/
					
					if($year_id ==1)
						{
							$firstyear=$year_id;
							$secondyear=$year_id;
						}
						else if($year_id ==2)
						{
							$firstyear=$year_id-1;
							$secondyear=$year_id-1;
						}
						else if($year_id >2)
						{
							$firstyear=$year_id-2;
							$secondyear=$year_id-1;
						}
						
					$term_questermArr=array();
					$term_questions=$this->questions_model->assessment_exam($year_id,1,$firstyear);
					
					if($term_questions)
					{
						
						foreach($term_questions as $tquestion)
						{
							array_push($term_questermArr,$tquestion->ass_question);
						}
						
					}
					//var_dump($term_questermArr);
					
					$exam_output = array_merge(array_diff($term_questermArr, $exam_questermArr), array_diff($exam_questermArr, $term_questermArr));
					$exam_random=array_rand($exam_output);
					$randquestion=$exam_output[$exam_random];
					/* $exam_random=array_shift($exam_output);
					$randquestion=$exam_random; */
					/*---End of check user not applied question list---*/
					if($userexams->exam_status!='pass')
					{
					$data['Questionlist']=$this->questions_model->asstest_exam_question($year_id,1,$randquestion);
					}
					else
					{
						$data['Questionlist']='';
						$data['completed']=1;
					}
					//var_dump($data['Questionlist']);
					$this->load->view('frontend/private/assessmentplay',$data);
				}
			
			}
		/*---End Assessment Test -----*/
			
			/*---end final year exam-----*/
			else
			{	
				$this->session->unset_userdata('attempt');
				$this->session->unset_userdata('ansattempt');
			$data["skill_dtl"] =$this->main_model->get_skill('master_skill','skill_slug',$subskill,'skill_class',$year_id);		
			  $subskill_id=$data["skill_dtl"]->skill_id;
			$this->questions_model->CLASSID = $year_id;
				//$data["Questionlist"] = $this->questions_model->question_list_subskill($subskill_id);
		
			
					$data["Questionlist"] = $this->questions_model->random_question($subskill_id);
					$this->load->view('frontend/private/play',$data);
					
			
				}
			}
			else{
				
				if($this->session->userdata('user_id')!='' and $this->session->userdata('username')!='')
				{

				$data["SylList1"] = $this->syllabus_model->syllabus_list($year_id,1);
				$data["SylList2"] = $this->syllabus_model->syllabus_list($year_id,2);
				$data["SylList3"] = $this->syllabus_model->syllabus_list($year_id,3);
				$data["SylList4"] = $this->syllabus_model->syllabus_list($year_id,4);

				$this->load->view('frontend/private/kindergarten', $data);
				}
				else{
				$data["SylList1"] = $this->syllabus_model->syllabus_list($year_id,1);
				$data["SylList2"] = $this->syllabus_model->syllabus_list($year_id,2);
				$data["SylList3"] = $this->syllabus_model->syllabus_list($year_id,3);
				$data["SylList4"] = $this->syllabus_model->syllabus_list($year_id,4);

				$this->load->view('frontend/public/kg_wtht_login', $data);	
					
				}

			}
		
	}
	public function year6($subskill='') 
	{	
		$yearid=$this->session->userdata('loginyear');
			$yeardata=$this->classes_model->classes_details($yearid);
			if($yeardata)
			{
				$data['year_name']=$yeardata[0]->class_name;
				$data['year_slug']=$yeardata[0]->class_slug;
			}
		$year_id=7;
		$data['year_id']=$year_id;
		
		$userid2=$this->session->userdata('user_id');			
		$data['aatcount']=$this->exam_model->checkuser_aat_status($yearid,$userid2);	
		
		$this->questions_model->CLASSID = $year_id;
		$data["year_dtl"] = $this->main_model->get_detail('master_class','class_id',$year_id);	
		$data['subskill']=$subskill;
		if($subskill!=""){
			/*---Start Assessment Test -----*/
			if($subskill=="assessment")
			{		
					 $this->session->set_userdata('attempt_ques', 0);
					 
					 //Page reload truncate table
					if($this->session->userdata('ass_attempt') > 0)
					{
					$checkasstest=$this->db->query("select exam_status from student_assessment_test  where year_id='".$year_id."' and user_id='".$this->session->userdata('user_id')."' 
							");
					$rowchecktest_status=$checkasstest->row();
					if($rowchecktest_status->exam_status=='pending')
					{						
					$del_asshistory=$this->db->query("delete  from sasstest_history  where year_id='".$year_id."' and user_id='".$this->session->userdata('user_id')."' 
							");
					$del_assmasterhistory=$this->db->query("delete  from student_assessment_test  where year_id='".$year_id."' and user_id='".$this->session->userdata('user_id')."' 
							");	
					$data['err_reload']=1;	
					$this->session->unset_userdata('ass_attempt');	
					}
					else
					{
						$data['err_reload']='';
					}						
					}
					else
					{
						$data['err_reload']='';	
					}
					
					/*---get all past year of assessment list----*/
					$pastyear=$this->questions_model->assessment_pastyear($year_id);
						/*echo '<pre>';
						var_dump($pastyear);
						echo '</pre>';
						*/
					$todaydate=date("Y-m-d H:i:s");	
					$userid=$this->session->userdata('user_id');
					$asstime_query=$this->questions_model->assessment_time($year_id,$userid);
					$yourstart=$asstime_query->start_time;
					if($yourstart!="" && $yourstart!=null)
					{
						$seconds = strtotime($todaydate) - strtotime($yourstart);
						$days    = floor($seconds / 86400);
						$hours   = floor(($seconds - ($days * 86400)) / 3600);
						$minutes = floor(($seconds - ($days * 86400) - ($hours * 3600))/60);
						
						if($minutes >30)
						{
							//echo $minutes;
							$exam_status=array(
								'exam_status'=>'pass',							
								'end_time'=>$todaydate,
								);
						
						$updateexam_status=$this->questions_model->Update_Asstterm_status($exam_status,$asstime_query->exam_id);
						$data['timeover']=1;
						}
						else
						{
							$totalminutes=30-$minutes;
							$data['showtimer']='Duration Left: '.$totalminutes;
						}
					}
					else
					{
						$data['showtimer']='Duration: 30';
					}
					
					/*---end of get all past year of assessment list----*/	
					if($this->input->post('action')=='submitanswer')	
					{
						//var_dump($this->input->post());
					$this->session->unset_userdata('ass_attempt');	
					 $questionid=$this->input->post('questionid');
					 $answerid=$this->input->post('answerid');
					 $year_id=$this->input->post('year_id');
					 $ass_year_id=$this->input->post('ass_year_id');
				
					
					$data["ques_dtl"] = $this->main_model->get_detail('manage_question_'.$ass_year_id,'ques_id',$questionid);					
					//var_dump($data["ques_dtl"]);
					$data["correct_ans"] = $this->main_model->get_detail('manage_answer_'.$ass_year_id,'ans_id',$data["ques_dtl"]->ques_rightanswer);					
										
					if($data["ques_dtl"]->ques_rightanswer==$answerid)
					{
						
						$data['correct']=1;
						/*----insert user exam list---------*/
						
						$createdate=date("Y-m-d H:i:s");
						$chkrow_exam=$this->questions_model->check_userassessment($userid,$year_id,1);	
						
						if($chkrow_exam->exam_id!="" )
						{
							$exam_id=$chkrow_exam->exam_id;
						}
						else
						{
							$user_exam=array(
									'user_id'=>$userid,
									'year_id'=>$year_id,
									'assyear_id'=>$ass_year_id,													
									'exam_date'=>$createdate,
									'start_time'=>$createdate
									
									);
							$exam_id=$this->questions_model->Save_Userassessment($user_exam);	
						}
						
						if($exam_id!="")
						{
							$uexam_history=array(
								'exam_id'=>$exam_id,
								'user_id'=>$userid,
								'year_id'=>$year_id,
								'assyear_id'=>$ass_year_id,													
								'question_id'=>$questionid,
								'answer_id'=>$answerid,
								'answer_status'=>'true',
								
								);
							$historyexam_id=$this->questions_model->Save_Assessmenthistory($uexam_history);		
						}
						
						/*----End of insert user exam list-------*/
										
					/*----Get user exam question array------*/
					$exam_questermArr=array();
					$exam_questions=$this->questions_model->check_asstesthistory_question($userid,$year_id,1);
					if($exam_questions)
					{
						
						foreach($exam_questions as $examdata)
						{
							array_push($exam_questermArr,$examdata->question_id);
						}
					}
					
					if($year_id ==1)
						{
							$firstyear=$year_id;
							$secondyear=$year_id;
						}
						else if($year_id ==2)
						{
							$firstyear=$year_id-1;
							$secondyear=$year_id-1;
						}
						else if($year_id >2)
						{
							$firstyear=$year_id-2;
							$secondyear=$year_id-1;
						}
						
					/*----End of get user exam question array----*/
					$term_questermArr=array();
					$term_questions=$this->questions_model->assessment_exam($year_id,1);
					if($term_questions)
					{
						
						foreach($term_questions as $tquestion)
						{
							array_push($term_questermArr,$tquestion->ass_question);
						}
						
					}
					$total_exam_question=count($exam_questermArr);
					$total_term_question=count($term_questermArr);
					/*---update term by exam completed status----*/
					if($total_term_question==$total_exam_question)
					{
						$exam_status=array(
								'exam_status'=>'pass',							
								'end_time'=>$createdate,
								);
						
						$updateexam_status=$this->questions_model->Update_Asstterm_status($exam_status,$exam_id);
						$data['completed']=1;
					}
					/*---update term by exam completed status----*/
					$exam_output = array_merge(array_diff($term_questermArr, $exam_questermArr), array_diff($exam_questermArr, $term_questermArr));
					$exam_random=array_rand($exam_output);
					$randquestion=$exam_output[$exam_random];
					/* $exam_random=array_shift($exam_output);		
					$randquestion=$exam_random; */
					/*---End of check user not applied question list---*/
					$data['Questionlist']=$this->questions_model->asstest_exam_question($year_id,1,$randquestion);
						//$data['Questionlist']=$this->questions_model->term_exam($year_id,1);
						$data['exam_id']=$exam_id;
						$this->load->view('frontend/private/assessmentplay',$data);

					}
					else
					{
			
						/*----insert user exam list---------*/
						$userid=$this->session->userdata('user_id');
						$createdate=date("Y-m-d H:i:s");
						$chkrow_exam=$this->questions_model->check_userassessment($userid,$year_id,1);	
						
						if($chkrow_exam->exam_id!="" )
						{
							$exam_id=$chkrow_exam->exam_id;
						}
						else
						{
							$user_exam=array(
									'user_id'=>$userid,
									'year_id'=>$year_id,
									'assyear_id'=>$ass_year_id,													
									'exam_date'=>$createdate,
									'start_time'=>$createdate
									
									);
							$exam_id=$this->questions_model->Save_Userassessment($user_exam);	
						}
						
						if($exam_id!="")
						{
							$uexam_history=array(
								'exam_id'=>$exam_id,
								'user_id'=>$userid,
								'year_id'=>$year_id,
								'assyear_id'=>$ass_year_id,													
								'question_id'=>$questionid,
								'answer_id'=>$answerid,
								'answer_status'=>'false',
								
								);
							$hexam_id=$this->questions_model->Save_Assessmenthistory($uexam_history);		
						}
						
								/*----Get user exam question array------*/
					$exam_questermArr=array();
					$exam_questions=$this->questions_model->check_asstesthistory_question($userid,$year_id,$term_id);
					if($exam_questions)
					{
						
						foreach($exam_questions as $examdata)
						{
							array_push($exam_questermArr,$examdata->question_id);
						}
					}
					
					
					/*----End of get user exam question array----*/
					$term_questermArr=array();
					$term_questions=$this->questions_model->assessment_exam($year_id,1);
					if($term_questions)
					{
						
						foreach($term_questions as $tquestion)
						{
							array_push($term_questermArr,$tquestion->ass_question);
						}
						
					}
					$total_exam_question=count($exam_questermArr);
					$total_term_question=count($term_questermArr);
					/*---update term by exam completed status----*/
					if(30==$total_exam_question)
					{
						$exam_status=array(
								'exam_status'=>'pass',
								'end_time'=>$createdate,	
								
								);
						
						$updateexam_status=$this->questions_model->Update_Asstterm_status($exam_status,$exam_id);
						$data['completed']=1;
					}
					/*---update term by exam completed status----*/
						
						/*----End of insert user exam list-------*/
					
						$data["yourans"] = $this->main_model->get_detail('manage_answer_'.$ass_year_id,'ans_id',$answerid);	
						$data['exam_id']=$exam_id;
						$this->load->view('frontend/private/asstestexplanation',$data);
					}
					
								
					}
				else
				{
					$userid=$this->session->userdata('user_id');
					/*---check user not applied question list---*/
					$userexams=$this->questions_model->check_uasstestbyyear($userid,$year_id);
					$data['exam_id']=$userexams->exam_id;
					if($userexams->exam_id!="" && $userexams->exam_status=='pending')
					{	
						$data['assyear_id']=$userexams->assyear_id;
					}
					
					else if($userexams->exam_id!="" && $userexams->exam_status=='pass')
					{	
						$data['assyear_id']=$userexams->assyear_id+1;
					}
				
					else
					{
						$data['assyear_id']=$pastyear[0]->ass_year_id;
						//echo $pastyear[0]->ass_year_id;
					}
					
					/*----Get user exam question array------*/
					$exam_questermArr=array();
					$exam_questions=$this->questions_model->check_asstesthistory_question($userid,$year_id,1);
					if($exam_questions)
					{
						
						foreach($exam_questions as $examdata)
						{
							array_push($exam_questermArr,$examdata->question_id);
						}
					}
					
					
					/*----End of get user exam question array----*/
					
					if($year_id ==1)
						{
							$firstyear=$year_id;
							$secondyear=$year_id;
						}
						else if($year_id ==2)
						{
							$firstyear=$year_id-1;
							$secondyear=$year_id-1;
						}
						else if($year_id >2)
						{
							$firstyear=$year_id-2;
							$secondyear=$year_id-1;
						}
						
					$term_questermArr=array();
					$term_questions=$this->questions_model->assessment_exam($year_id,1,$firstyear);
					
					if($term_questions)
					{
						
						foreach($term_questions as $tquestion)
						{
							array_push($term_questermArr,$tquestion->ass_question);
						}
						
					}
					//var_dump($term_questermArr);
					
					$exam_output = array_merge(array_diff($term_questermArr, $exam_questermArr), array_diff($exam_questermArr, $term_questermArr));
					$exam_random=array_rand($exam_output);
					$randquestion=$exam_output[$exam_random];
					/* $exam_random=array_shift($exam_output);
					$randquestion=$exam_random; */
					/*---End of check user not applied question list---*/
					if($userexams->exam_status!='pass')
					{
					$data['Questionlist']=$this->questions_model->asstest_exam_question($year_id,1,$randquestion);
					}
					else
					{
						$data['Questionlist']='';
						$data['completed']=1;
					}
					//var_dump($data['Questionlist']);
					$this->load->view('frontend/private/assessmentplay',$data);
				}
			
			}
		/*---End Assessment Test -----*/
			/*---final year exam-----*/
			else if($subskill=="exam")
			{
				$this->session->set_userdata('ansattempt', '0');
				
			if($this->input->post('action')=='submitanswer')	
					{
					 $questionid=$this->input->post('questionid');
					 $answerid=$this->input->post('answerid');
					 $year_id=$this->input->post('year_id');
					 
					 $term_id=$this->input->post('term_id');
				
					
					$data["ques_dtl"] = $this->main_model->get_detail('manage_question_'.$year_id,'ques_id',$questionid);					
					
					$data["correct_ans"] = $this->main_model->get_detail('manage_answer_'.$year_id,'ans_id',$data["ques_dtl"]->ques_rightanswer);					
										
					if($data["ques_dtl"]->ques_rightanswer==$answerid)
					{
						
						$data['correct']=1;
						/*----insert user exam list---------*/
						$userid=$this->session->userdata('user_id');
						$createdate=date("Y-m-d H:i:s");
						$chkrow_exam=$this->questions_model->check_userexam($userid,$year_id,$term_id);	
						
						if($chkrow_exam->exam_id!="" )
						{
							$exam_id=$chkrow_exam->exam_id;
						}
						else
						{
							$user_exam=array(
									'user_id'=>$userid,
									'year_id'=>$year_id,
									'term_id'=>$term_id,													
									'exam_date'=>$createdate
									
									);
							$exam_id=$this->questions_model->Save_Userexam($user_exam);	
						}
						
						if($exam_id!="")
						{
							$uexam_history=array(
								'exam_id'=>$exam_id,
								'user_id'=>$userid,
								'year_id'=>$year_id,
								'term_id'=>$term_id,													
								'question_id'=>$questionid,
								'answer_id'=>$answerid,
								'answer_status'=>'false',
								
								);
							$historyexam_id=$this->questions_model->Save_Examhistory($uexam_history);		
						}
						
						/*----End of insert user exam list-------*/
						
										/*---check user not applied question list---*/
					$userexams=$this->questions_model->check_uexambyyear($userid,$year_id);
					if($userexams->exam_id!="" && $userexams->exam_status=='pending')
					{	
						$data['term_id']=$userexams->term_id;
					}
					else if($userexams->exam_id!="" && $userexams->exam_status=='pass')
					{	
						$data['term_id']=$userexams->term_id+1;
					}
					else
					{
						$data['term_id']=1;
					}
					
					/*----Get user exam question array------*/
					$exam_questermArr=array();
					$exam_questions=$this->questions_model->check_examhistory_question($userid,$year_id,$data['term_id']);
					if($exam_questions)
					{
						
						foreach($exam_questions as $examdata)
						{
							array_push($exam_questermArr,$examdata->question_id);
						}
					}
					
					
					/*----End of get user exam question array----*/
					$term_questermArr=array();
					$term_questions=$this->questions_model->term_exam($year_id,$data['term_id']);
					if($term_questions)
					{
						
						foreach($term_questions as $tquestion)
						{
							array_push($term_questermArr,$tquestion->question_id);
						}
						
					}
					$total_exam_question=count($exam_questermArr);
					$total_term_question=count($exam_questermArr);
					/*---update term by exam completed status----*/
					if($total_term_question==$total_exam_question)
					{
						$exam_status=array(
								'exam_status'=>'pass',							
								
								);
						
						$updateexam_status=$this->questions_model->Update_Examterm_status($exam_status,$exam_id);
					}
					/*---update term by exam completed status----*/
					$exam_output = array_merge(array_diff($term_questermArr, $exam_questermArr), array_diff($exam_questermArr, $term_questermArr));
					$exam_random=array_rand($exam_output);					
					$randquestion=$exam_output[$exam_random];
					/*---End of check user not applied question list---*/
					$data['Questionlist']=$this->questions_model->term_exam_question($year_id,$data['term_id'],$randquestion);
						//$data['Questionlist']=$this->questions_model->term_exam($year_id,1);
						$this->load->view('frontend/private/examplay',$data);

					}
					else
					{
			
						/*----insert user exam list---------*/
						$userid=$this->session->userdata('user_id');
						$createdate=date("Y-m-d H:i:s");
						$chkrow_exam=$this->questions_model->check_userexam($userid,$year_id,$term_id);	
						
						if($chkrow_exam->exam_id!="" )
						{
							$exam_id=$chkrow_exam->exam_id;
						}
						else
						{
							$user_exam=array(
									'user_id'=>$userid,
									'year_id'=>$year_id,
									'term_id'=>$term_id,													
									'exam_date'=>$createdate
									
									);
							$exam_id=$this->questions_model->Save_Userexam($user_exam);	
						}
						
						if($exam_id!="")
						{
							$uexam_history=array(
								'exam_id'=>$exam_id,
								'user_id'=>$userid,
								'year_id'=>$year_id,
								'term_id'=>$term_id,													
								'question_id'=>$questionid,
								'answer_id'=>$answerid,
								'answer_status'=>'true',
								
								);
							$hexam_id=$this->questions_model->Save_Examhistory($uexam_history);		
						}
						
								/*----Get user exam question array------*/
					$exam_questermArr=array();
					$exam_questions=$this->questions_model->check_examhistory_question($userid,$year_id,$term_id);
					if($exam_questions)
					{
						
						foreach($exam_questions as $examdata)
						{
							array_push($exam_questermArr,$examdata->question_id);
						}
					}
					
					
					/*----End of get user exam question array----*/
					$term_questermArr=array();
					$term_questions=$this->questions_model->term_exam($year_id,$term_id);
					if($term_questions)
					{
						
						foreach($term_questions as $tquestion)
						{
							array_push($term_questermArr,$tquestion->question_id);
						}
						
					}
					$total_exam_question=count($exam_questermArr);
					$total_term_question=count($exam_questermArr);
					/*---update term by exam completed status----*/
					if($total_term_question==$total_exam_question)
					{
						$exam_status=array(
								'exam_status'=>'pass',							
								
								);
						
						$updateexam_status=$this->questions_model->Update_Examterm_status($exam_status,$exam_id);
					}
					/*---update term by exam completed status----*/
						
						/*----End of insert user exam list-------*/
						$data["yourans"] = $this->main_model->get_detail('manage_answer_'.$year_id,'ans_id',$answerid);	
						$this->load->view('frontend/private/explanation',$data);
					}
					
								
					}
				else
				{
					$userid=$this->session->userdata('user_id');
					$this->session->set_userdata('ansattempt', '0');
					/*---check user not applied question list---*/
					$userexams=$this->questions_model->check_uexambyyear($userid,$year_id);
					$check_termexam_date=$this->questions_model->check_termexam_date($year_id);
					
					if($check_termexam_date->date!="0000-00-00 00:00:00")
					{	
						$cur_date=date("m/d/Y");
						$date=date("m/d/Y", strtotime($check_termexam_date->date));
						if($date==$cur_date){
						$data['term_id']=$check_termexam_date->term_id;
						
						}
						else{ $data['no_exam']=1;}
					}
					else
					{
						$data['no_exam']=1;
					}
					
					/*----Get user exam question array------*/
					$exam_questermArr=array();
					$exam_questions=$this->questions_model->check_examhistory_question($userid,$year_id,$data['term_id']);
					if($exam_questions)
					{
						
						foreach($exam_questions as $examdata)
						{
							array_push($exam_questermArr,$examdata->question_id);
						}
					}
					
					
					/*----End of get user exam question array----*/
					$term_questermArr=array();
					$term_questions=$this->questions_model->term_exam($year_id,$data['term_id']);
					if($term_questions)
					{
						
						foreach($term_questions as $tquestion)
						{
							array_push($term_questermArr,$tquestion->question_id);
						}
						
					}
					//var_dump($term_questermArr);
					
					$exam_output = array_merge(array_diff($term_questermArr, $exam_questermArr), array_diff($exam_questermArr, $term_questermArr));
					$exam_random=array_rand($exam_output);					
					$randquestion=$exam_output[$exam_random];
					/*---End of check user not applied question list---*/
					$data['Questionlist']=$this->questions_model->term_exam_question($year_id,$data['term_id'],$randquestion);
	
					$this->load->view('frontend/private/examplay',$data);
				}
			
			
			
			
			}
			/*---end final year exam-----*/
			else
			{	
				$this->session->unset_userdata('attempt');
				$this->session->unset_userdata('ansattempt');
				$data["skill_dtl"] =$this->main_model->get_skill('master_skill','skill_slug',$subskill,'skill_class',$year_id);		
				$subskill_id=$data["skill_dtl"]->skill_id;
				$this->questions_model->CLASSID = $year_id;

				$data["Questionlist"] = $this->questions_model->random_question($subskill_id);
				$this->load->view('frontend/private/play',$data);
				}
			}
			else{
				
				if($this->session->userdata('user_id')!='' and $this->session->userdata('username')!='')
				{

				$data["SylList1"] = $this->syllabus_model->syllabus_list($year_id,1);
				$data["SylList2"] = $this->syllabus_model->syllabus_list($year_id,2);
				$data["SylList3"] = $this->syllabus_model->syllabus_list($year_id,3);
				$data["SylList4"] = $this->syllabus_model->syllabus_list($year_id,4);

				$this->load->view('frontend/private/kindergarten', $data);
				}
				else{
				$data["SylList1"] = $this->syllabus_model->syllabus_list($year_id,1);
				$data["SylList2"] = $this->syllabus_model->syllabus_list($year_id,2);
				$data["SylList3"] = $this->syllabus_model->syllabus_list($year_id,3);
				$data["SylList4"] = $this->syllabus_model->syllabus_list($year_id,4);

				$this->load->view('frontend/public/kg_wtht_login', $data);	
					
				}

			}
		
	}
	public function year7($subskill='') 
	{	
		$yearid=$this->session->userdata('loginyear');
		$yeardata=$this->classes_model->classes_details($yearid);
			if($yeardata)
			{
				$data['year_name']=$yeardata[0]->class_name;
				$data['year_slug']=$yeardata[0]->class_slug;
			}
		$year_id=8;
		$data['year_id']=$year_id;
		$userid2=$this->session->userdata('user_id');			
		$data['aatcount']=$this->exam_model->checkuser_aat_status($yearid,$userid2);
		$this->questions_model->CLASSID = $year_id;
		$data["year_dtl"] = $this->main_model->get_detail('master_class','class_id',$year_id);	
		$data['subskill']=$subskill;
		if($subskill!="")
		{
			/*---Start Assessment Test -----*/
				if($subskill=="assessment")
			{		
					 $this->session->set_userdata('attempt_ques', 0);
					 
					 //Page reload truncate table
					if($this->session->userdata('ass_attempt') > 0)
					{
					$checkasstest=$this->db->query("select exam_status from student_assessment_test  where year_id='".$year_id."' and user_id='".$this->session->userdata('user_id')."' 
							");
					$rowchecktest_status=$checkasstest->row();
					if($rowchecktest_status->exam_status=='pending')
					{						
					$del_asshistory=$this->db->query("delete  from sasstest_history  where year_id='".$year_id."' and user_id='".$this->session->userdata('user_id')."' 
							");
					$del_assmasterhistory=$this->db->query("delete  from student_assessment_test  where year_id='".$year_id."' and user_id='".$this->session->userdata('user_id')."' 
							");	
					$data['err_reload']=1;	
					$this->session->unset_userdata('ass_attempt');	
					}
					else
					{
						$data['err_reload']='';
					}						
					}
					else
					{
						$data['err_reload']='';	
					}
					
					/*---get all past year of assessment list----*/
					$pastyear=$this->questions_model->assessment_pastyear($year_id);
						/*echo '<pre>';
						var_dump($pastyear);
						echo '</pre>';
						*/
					$todaydate=date("Y-m-d H:i:s");	
					$userid=$this->session->userdata('user_id');
					$asstime_query=$this->questions_model->assessment_time($year_id,$userid);
					$yourstart=$asstime_query->start_time;
					if($yourstart!="" && $yourstart!=null)
					{
						$seconds = strtotime($todaydate) - strtotime($yourstart);
						$days    = floor($seconds / 86400);
						$hours   = floor(($seconds - ($days * 86400)) / 3600);
						$minutes = floor(($seconds - ($days * 86400) - ($hours * 3600))/60);
						
						if($minutes >30)
						{
							//echo $minutes;
							$exam_status=array(
								'exam_status'=>'pass',							
								'end_time'=>$todaydate,
								);
						
						$updateexam_status=$this->questions_model->Update_Asstterm_status($exam_status,$asstime_query->exam_id);
						$data['timeover']=1;
						}
						else
						{
							$totalminutes=30-$minutes;
							$data['showtimer']='Duration Left: '.$totalminutes;
						}
					}
					else
					{
						$data['showtimer']='Duration: 30';
					}
					
					/*---end of get all past year of assessment list----*/	
					if($this->input->post('action')=='submitanswer')	
					{
						//var_dump($this->input->post());
					$this->session->unset_userdata('ass_attempt');	
					 $questionid=$this->input->post('questionid');
					 $answerid=$this->input->post('answerid');
					 $year_id=$this->input->post('year_id');
					 $ass_year_id=$this->input->post('ass_year_id');
				
					
					$data["ques_dtl"] = $this->main_model->get_detail('manage_question_'.$ass_year_id,'ques_id',$questionid);					
					//var_dump($data["ques_dtl"]);
					$data["correct_ans"] = $this->main_model->get_detail('manage_answer_'.$ass_year_id,'ans_id',$data["ques_dtl"]->ques_rightanswer);					
										
					if($data["ques_dtl"]->ques_rightanswer==$answerid)
					{
						
						$data['correct']=1;
						/*----insert user exam list---------*/
						
						$createdate=date("Y-m-d H:i:s");
						$chkrow_exam=$this->questions_model->check_userassessment($userid,$year_id,1);	
						
						if($chkrow_exam->exam_id!="" )
						{
							$exam_id=$chkrow_exam->exam_id;
						}
						else
						{
							$user_exam=array(
									'user_id'=>$userid,
									'year_id'=>$year_id,
									'assyear_id'=>$ass_year_id,													
									'exam_date'=>$createdate,
									'start_time'=>$createdate
									
									);
							$exam_id=$this->questions_model->Save_Userassessment($user_exam);	
						}
						
						if($exam_id!="")
						{
							$uexam_history=array(
								'exam_id'=>$exam_id,
								'user_id'=>$userid,
								'year_id'=>$year_id,
								'assyear_id'=>$ass_year_id,													
								'question_id'=>$questionid,
								'answer_id'=>$answerid,
								'answer_status'=>'true',
								
								);
							$historyexam_id=$this->questions_model->Save_Assessmenthistory($uexam_history);		
						}
						
						/*----End of insert user exam list-------*/
										
					/*----Get user exam question array------*/
					$exam_questermArr=array();
					$exam_questions=$this->questions_model->check_asstesthistory_question($userid,$year_id,1);
					if($exam_questions)
					{
						
						foreach($exam_questions as $examdata)
						{
							array_push($exam_questermArr,$examdata->question_id);
						}
					}
					
					if($year_id ==1)
						{
							$firstyear=$year_id;
							$secondyear=$year_id;
						}
						else if($year_id ==2)
						{
							$firstyear=$year_id-1;
							$secondyear=$year_id-1;
						}
						else if($year_id >2)
						{
							$firstyear=$year_id-2;
							$secondyear=$year_id-1;
						}
						
					/*----End of get user exam question array----*/
					$term_questermArr=array();
					$term_questions=$this->questions_model->assessment_exam($year_id,1);
					if($term_questions)
					{
						
						foreach($term_questions as $tquestion)
						{
							array_push($term_questermArr,$tquestion->ass_question);
						}
						
					}
					$total_exam_question=count($exam_questermArr);
					$total_term_question=count($term_questermArr);
					/*---update term by exam completed status----*/
					if($total_term_question==$total_exam_question)
					{
						$exam_status=array(
								'exam_status'=>'pass',							
								'end_time'=>$createdate,
								);
						
						$updateexam_status=$this->questions_model->Update_Asstterm_status($exam_status,$exam_id);
						$data['completed']=1;
					}
					/*---update term by exam completed status----*/
					$exam_output = array_merge(array_diff($term_questermArr, $exam_questermArr), array_diff($exam_questermArr, $term_questermArr));
					$exam_random=array_rand($exam_output);
					$randquestion=$exam_output[$exam_random];
					/* $exam_random=array_shift($exam_output);		
					$randquestion=$exam_random; */
					/*---End of check user not applied question list---*/
					$data['Questionlist']=$this->questions_model->asstest_exam_question($year_id,1,$randquestion);
						//$data['Questionlist']=$this->questions_model->term_exam($year_id,1);
						$data['exam_id']=$exam_id;
						$this->load->view('frontend/private/assessmentplay',$data);

					}
					else
					{
			
						/*----insert user exam list---------*/
						$userid=$this->session->userdata('user_id');
						$createdate=date("Y-m-d H:i:s");
						$chkrow_exam=$this->questions_model->check_userassessment($userid,$year_id,1);	
						
						if($chkrow_exam->exam_id!="" )
						{
							$exam_id=$chkrow_exam->exam_id;
						}
						else
						{
							$user_exam=array(
									'user_id'=>$userid,
									'year_id'=>$year_id,
									'assyear_id'=>$ass_year_id,													
									'exam_date'=>$createdate,
									'start_time'=>$createdate
									
									);
							$exam_id=$this->questions_model->Save_Userassessment($user_exam);	
						}
						
						if($exam_id!="")
						{
							$uexam_history=array(
								'exam_id'=>$exam_id,
								'user_id'=>$userid,
								'year_id'=>$year_id,
								'assyear_id'=>$ass_year_id,													
								'question_id'=>$questionid,
								'answer_id'=>$answerid,
								'answer_status'=>'false',
								
								);
							$hexam_id=$this->questions_model->Save_Assessmenthistory($uexam_history);		
						}
						
								/*----Get user exam question array------*/
					$exam_questermArr=array();
					$exam_questions=$this->questions_model->check_asstesthistory_question($userid,$year_id,$term_id);
					if($exam_questions)
					{
						
						foreach($exam_questions as $examdata)
						{
							array_push($exam_questermArr,$examdata->question_id);
						}
					}
					
					
					/*----End of get user exam question array----*/
					$term_questermArr=array();
					$term_questions=$this->questions_model->assessment_exam($year_id,1);
					if($term_questions)
					{
						
						foreach($term_questions as $tquestion)
						{
							array_push($term_questermArr,$tquestion->ass_question);
						}
						
					}
					$total_exam_question=count($exam_questermArr);
					$total_term_question=count($term_questermArr);
					/*---update term by exam completed status----*/
					if(30==$total_exam_question)
					{
						$exam_status=array(
								'exam_status'=>'pass',
								'end_time'=>$createdate,	
								
								);
						
						$updateexam_status=$this->questions_model->Update_Asstterm_status($exam_status,$exam_id);
						$data['completed']=1;
					}
					/*---update term by exam completed status----*/
						
						/*----End of insert user exam list-------*/
					
						$data["yourans"] = $this->main_model->get_detail('manage_answer_'.$ass_year_id,'ans_id',$answerid);	
						$data['exam_id']=$exam_id;
						$this->load->view('frontend/private/asstestexplanation',$data);
					}
					
								
					}
				else
				{
					$userid=$this->session->userdata('user_id');
					/*---check user not applied question list---*/
					$userexams=$this->questions_model->check_uasstestbyyear($userid,$year_id);
					$data['exam_id']=$userexams->exam_id;
					if($userexams->exam_id!="" && $userexams->exam_status=='pending')
					{	
						$data['assyear_id']=$userexams->assyear_id;
					}
					
					else if($userexams->exam_id!="" && $userexams->exam_status=='pass')
					{	
						$data['assyear_id']=$userexams->assyear_id+1;
					}
				
					else
					{
						$data['assyear_id']=$pastyear[0]->ass_year_id;
						//echo $pastyear[0]->ass_year_id;
					}
					
					/*----Get user exam question array------*/
					$exam_questermArr=array();
					$exam_questions=$this->questions_model->check_asstesthistory_question($userid,$year_id,1);
					if($exam_questions)
					{
						
						foreach($exam_questions as $examdata)
						{
							array_push($exam_questermArr,$examdata->question_id);
						}
					}
					
					
					/*----End of get user exam question array----*/
					
					if($year_id ==1)
						{
							$firstyear=$year_id;
							$secondyear=$year_id;
						}
						else if($year_id ==2)
						{
							$firstyear=$year_id-1;
							$secondyear=$year_id-1;
						}
						else if($year_id >2)
						{
							$firstyear=$year_id-2;
							$secondyear=$year_id-1;
						}
						
					$term_questermArr=array();
					$term_questions=$this->questions_model->assessment_exam($year_id,1,$firstyear);
					
					if($term_questions)
					{
						
						foreach($term_questions as $tquestion)
						{
							array_push($term_questermArr,$tquestion->ass_question);
						}
						
					}
					//var_dump($term_questermArr);
					
					$exam_output = array_merge(array_diff($term_questermArr, $exam_questermArr), array_diff($exam_questermArr, $term_questermArr));
					$exam_random=array_rand($exam_output);
					$randquestion=$exam_output[$exam_random];
					/* $exam_random=array_shift($exam_output);
					$randquestion=$exam_random; */
					/*---End of check user not applied question list---*/
					if($userexams->exam_status!='pass')
					{
					$data['Questionlist']=$this->questions_model->asstest_exam_question($year_id,1,$randquestion);
					}
					else
					{
						$data['Questionlist']='';
						$data['completed']=1;
					}
					//var_dump($data['Questionlist']);
					$this->load->view('frontend/private/assessmentplay',$data);
				}
			
			}
		/*---End Assessment Test -----*/
			/*---final year exam-----*/
			else if($subskill=="exam")
			{
				$this->session->set_userdata('ansattempt', '0');
				
			if($this->input->post('action')=='submitanswer')	
					{
					 $questionid=$this->input->post('questionid');
					 $answerid=$this->input->post('answerid');
					 $year_id=$this->input->post('year_id');
					 
					 $term_id=$this->input->post('term_id');
				
					
					$data["ques_dtl"] = $this->main_model->get_detail('manage_question_'.$year_id,'ques_id',$questionid);					
					
					$data["correct_ans"] = $this->main_model->get_detail('manage_answer_'.$year_id,'ans_id',$data["ques_dtl"]->ques_rightanswer);					
										
					if($data["ques_dtl"]->ques_rightanswer==$answerid)
					{
						
						$data['correct']=1;
						/*----insert user exam list---------*/
						$userid=$this->session->userdata('user_id');
						$createdate=date("Y-m-d H:i:s");
						$chkrow_exam=$this->questions_model->check_userexam($userid,$year_id,$term_id);	
						
						if($chkrow_exam->exam_id!="" )
						{
							$exam_id=$chkrow_exam->exam_id;
						}
						else
						{
							$user_exam=array(
									'user_id'=>$userid,
									'year_id'=>$year_id,
									'term_id'=>$term_id,													
									'exam_date'=>$createdate
									
									);
							$exam_id=$this->questions_model->Save_Userexam($user_exam);	
						}
						
						if($exam_id!="")
						{
							$uexam_history=array(
								'exam_id'=>$exam_id,
								'user_id'=>$userid,
								'year_id'=>$year_id,
								'term_id'=>$term_id,													
								'question_id'=>$questionid,
								'answer_id'=>$answerid,
								'answer_status'=>'false',
								
								);
							$historyexam_id=$this->questions_model->Save_Examhistory($uexam_history);		
						}
						
						/*----End of insert user exam list-------*/
						
										/*---check user not applied question list---*/
					$userexams=$this->questions_model->check_uexambyyear($userid,$year_id);
					if($userexams->exam_id!="" && $userexams->exam_status=='pending')
					{	
						$data['term_id']=$userexams->term_id;
					}
					else if($userexams->exam_id!="" && $userexams->exam_status=='pass')
					{	
						$data['term_id']=$userexams->term_id+1;
					}
					else
					{
						$data['term_id']=1;
					}
					
					/*----Get user exam question array------*/
					$exam_questermArr=array();
					$exam_questions=$this->questions_model->check_examhistory_question($userid,$year_id,$data['term_id']);
					if($exam_questions)
					{
						
						foreach($exam_questions as $examdata)
						{
							array_push($exam_questermArr,$examdata->question_id);
						}
					}
					
					
					/*----End of get user exam question array----*/
					$term_questermArr=array();
					$term_questions=$this->questions_model->term_exam($year_id,$data['term_id']);
					if($term_questions)
					{
						
						foreach($term_questions as $tquestion)
						{
							array_push($term_questermArr,$tquestion->question_id);
						}
						
					}
					$total_exam_question=count($exam_questermArr);
					$total_term_question=count($exam_questermArr);
					/*---update term by exam completed status----*/
					if($total_term_question==$total_exam_question)
					{
						$exam_status=array(
								'exam_status'=>'pass',							
								
								);
						
						$updateexam_status=$this->questions_model->Update_Examterm_status($exam_status,$exam_id);
					}
					/*---update term by exam completed status----*/
					$exam_output = array_merge(array_diff($term_questermArr, $exam_questermArr), array_diff($exam_questermArr, $term_questermArr));
					$exam_random=array_rand($exam_output);					
					$randquestion=$exam_output[$exam_random];
					/*---End of check user not applied question list---*/
					$data['Questionlist']=$this->questions_model->term_exam_question($year_id,$data['term_id'],$randquestion);
						//$data['Questionlist']=$this->questions_model->term_exam($year_id,1);
						$this->load->view('frontend/private/examplay',$data);

					}
					else
					{
			
						/*----insert user exam list---------*/
						$userid=$this->session->userdata('user_id');
						$createdate=date("Y-m-d H:i:s");
						$chkrow_exam=$this->questions_model->check_userexam($userid,$year_id,$term_id);	
						
						if($chkrow_exam->exam_id!="" )
						{
							$exam_id=$chkrow_exam->exam_id;
						}
						else
						{
							$user_exam=array(
									'user_id'=>$userid,
									'year_id'=>$year_id,
									'term_id'=>$term_id,													
									'exam_date'=>$createdate
									
									);
							$exam_id=$this->questions_model->Save_Userexam($user_exam);	
						}
						
						if($exam_id!="")
						{
							$uexam_history=array(
								'exam_id'=>$exam_id,
								'user_id'=>$userid,
								'year_id'=>$year_id,
								'term_id'=>$term_id,													
								'question_id'=>$questionid,
								'answer_id'=>$answerid,
								'answer_status'=>'true',
								
								);
							$hexam_id=$this->questions_model->Save_Examhistory($uexam_history);		
						}
						
								/*----Get user exam question array------*/
					$exam_questermArr=array();
					$exam_questions=$this->questions_model->check_examhistory_question($userid,$year_id,$term_id);
					if($exam_questions)
					{
						
						foreach($exam_questions as $examdata)
						{
							array_push($exam_questermArr,$examdata->question_id);
						}
					}
					
					
					/*----End of get user exam question array----*/
					$term_questermArr=array();
					$term_questions=$this->questions_model->term_exam($year_id,$term_id);
					if($term_questions)
					{
						
						foreach($term_questions as $tquestion)
						{
							array_push($term_questermArr,$tquestion->question_id);
						}
						
					}
					$total_exam_question=count($exam_questermArr);
					$total_term_question=count($exam_questermArr);
					/*---update term by exam completed status----*/
					if($total_term_question==$total_exam_question)
					{
						$exam_status=array(
								'exam_status'=>'pass',							
								
								);
						
						$updateexam_status=$this->questions_model->Update_Examterm_status($exam_status,$exam_id);
					}
					/*---update term by exam completed status----*/
						
						/*----End of insert user exam list-------*/
						$data["yourans"] = $this->main_model->get_detail('manage_answer_'.$year_id,'ans_id',$answerid);	
						$this->load->view('frontend/private/explanation',$data);
					}
					
								
					}
				else
				{
					$userid=$this->session->userdata('user_id');
					$this->session->set_userdata('ansattempt', '0');
					/*---check user not applied question list---*/
					$userexams=$this->questions_model->check_uexambyyear($userid,$year_id);
					$check_termexam_date=$this->questions_model->check_termexam_date($year_id);
					
					if($check_termexam_date->date!="0000-00-00 00:00:00")
					{	
						$cur_date=date("m/d/Y");
						$date=date("m/d/Y", strtotime($check_termexam_date->date));
						if($date==$cur_date){
						$data['term_id']=$check_termexam_date->term_id;
						
						}
						else{ $data['no_exam']=1;}
					}
					else
					{
						$data['no_exam']=1;
					}
					
					/*----Get user exam question array------*/
					$exam_questermArr=array();
					$exam_questions=$this->questions_model->check_examhistory_question($userid,$year_id,$data['term_id']);
					if($exam_questions)
					{
						
						foreach($exam_questions as $examdata)
						{
							array_push($exam_questermArr,$examdata->question_id);
						}
					}
					
					
					/*----End of get user exam question array----*/
					$term_questermArr=array();
					$term_questions=$this->questions_model->term_exam($year_id,$data['term_id']);
					if($term_questions)
					{
						
						foreach($term_questions as $tquestion)
						{
							array_push($term_questermArr,$tquestion->question_id);
						}
						
					}
					//var_dump($term_questermArr);
					
					$exam_output = array_merge(array_diff($term_questermArr, $exam_questermArr), array_diff($exam_questermArr, $term_questermArr));
					$exam_random=array_rand($exam_output);					
					$randquestion=$exam_output[$exam_random];
					/*---End of check user not applied question list---*/
					$data['Questionlist']=$this->questions_model->term_exam_question($year_id,$data['term_id'],$randquestion);
	
					$this->load->view('frontend/private/examplay',$data);
				}
			
			
			
			
			}
			/*---end final year exam-----*/
			else
			{	
				$this->session->unset_userdata('attempt');
				$this->session->unset_userdata('ansattempt');
			$data["skill_dtl"] =$this->main_model->get_skill('master_skill','skill_slug',$subskill,'skill_class',$year_id);		
			  $subskill_id=$data["skill_dtl"]->skill_id;
			$this->questions_model->CLASSID = $year_id;
				//$data["Questionlist"] = $this->questions_model->question_list_subskill($subskill_id);
		
				if($this->input->post('action')=='submitanswer')	
					{
					 $questionid=$this->input->post('questionid');
					 $answerid=$this->input->post('answerid');
				
					
					$data["ques_dtl"] = $this->main_model->get_detail('manage_question_'.$year_id,'ques_id',$questionid);
					//print_r($data["ques_dtl"]);
					
					$data["correct_ans"] = $this->main_model->get_detail('manage_answer_'.$year_id,'ans_id',$data["ques_dtl"]->ques_rightanswer);
					//print_r($data["correct_ans"]);
					//echo $data["correct_ans"]->ans_name;
										
					if($data["ques_dtl"]->ques_rightanswer==$answerid)
					{
						
					$data['correct']=1;
					$data["Questionlist"] = $this->questions_model->random_question($subskill_id);
					$this->load->view('frontend/private/play',$data);

					}
					else{
			
					$data["yourans"] = $this->main_model->get_detail('manage_answer_'.$year_id,'ans_id',$answerid);	
					$this->load->view('frontend/private/explanation',$data);
					}
					
								
					}
				else{
					$data["Questionlist"] = $this->questions_model->random_question($subskill_id);
					$this->load->view('frontend/private/play',$data);
					}
			
				}
			}
			else{
				
				if($this->session->userdata('user_id')!='' and $this->session->userdata('username')!='')
				{

				$data["SylList1"] = $this->syllabus_model->syllabus_list($year_id,1);
				$data["SylList2"] = $this->syllabus_model->syllabus_list($year_id,2);
				$data["SylList3"] = $this->syllabus_model->syllabus_list($year_id,3);
				$data["SylList4"] = $this->syllabus_model->syllabus_list($year_id,4);

				$this->load->view('frontend/private/kindergarten', $data);
				}
				else{
				$data["SylList1"] = $this->syllabus_model->syllabus_list($year_id,1);
				$data["SylList2"] = $this->syllabus_model->syllabus_list($year_id,2);
				$data["SylList3"] = $this->syllabus_model->syllabus_list($year_id,3);
				$data["SylList4"] = $this->syllabus_model->syllabus_list($year_id,4);

				$this->load->view('frontend/public/kg_wtht_login', $data);	
					
				}

			}
		
	}
	public function year8($subskill='') 
	{	
		$yearid=$this->session->userdata('loginyear');
			$yeardata=$this->classes_model->classes_details($yearid);
			if($yeardata)
			{
				$data['year_name']=$yeardata[0]->class_name;
				$data['year_slug']=$yeardata[0]->class_slug;
			}
		$year_id=9;
		$data['year_id']=$year_id;
		$userid2=$this->session->userdata('user_id');			
		$data['aatcount']=$this->exam_model->checkuser_aat_status($yearid,$userid2);
		$this->questions_model->CLASSID = $year_id;
		$data["year_dtl"] = $this->main_model->get_detail('master_class','class_id',$year_id);	
		$data['subskill']=$subskill;
		if($subskill!=""){
			/*---Start Assessment Test -----*/
				if($subskill=="assessment")
			{		
					 $this->session->set_userdata('attempt_ques', 0);
					 
					 //Page reload truncate table
					if($this->session->userdata('ass_attempt') > 0)
					{
					$checkasstest=$this->db->query("select exam_status from student_assessment_test  where year_id='".$year_id."' and user_id='".$this->session->userdata('user_id')."' 
							");
					$rowchecktest_status=$checkasstest->row();
					if($rowchecktest_status->exam_status=='pending')
					{						
					$del_asshistory=$this->db->query("delete  from sasstest_history  where year_id='".$year_id."' and user_id='".$this->session->userdata('user_id')."' 
							");
					$del_assmasterhistory=$this->db->query("delete  from student_assessment_test  where year_id='".$year_id."' and user_id='".$this->session->userdata('user_id')."' 
							");	
					$data['err_reload']=1;	
					$this->session->unset_userdata('ass_attempt');	
					}
					else
					{
						$data['err_reload']='';
					}						
					}
					else
					{
						$data['err_reload']='';	
					}
					
					/*---get all past year of assessment list----*/
					$pastyear=$this->questions_model->assessment_pastyear($year_id);
						/*echo '<pre>';
						var_dump($pastyear);
						echo '</pre>';
						*/
					$todaydate=date("Y-m-d H:i:s");	
					$userid=$this->session->userdata('user_id');
					$asstime_query=$this->questions_model->assessment_time($year_id,$userid);
					$yourstart=$asstime_query->start_time;
					if($yourstart!="" && $yourstart!=null)
					{
						$seconds = strtotime($todaydate) - strtotime($yourstart);
						$days    = floor($seconds / 86400);
						$hours   = floor(($seconds - ($days * 86400)) / 3600);
						$minutes = floor(($seconds - ($days * 86400) - ($hours * 3600))/60);
						
						if($minutes >30)
						{
							//echo $minutes;
							$exam_status=array(
								'exam_status'=>'pass',							
								'end_time'=>$todaydate,
								);
						
						$updateexam_status=$this->questions_model->Update_Asstterm_status($exam_status,$asstime_query->exam_id);
						$data['timeover']=1;
						}
						else
						{
							$totalminutes=30-$minutes;
							$data['showtimer']='Duration Left: '.$totalminutes;
						}
					}
					else
					{
						$data['showtimer']='Duration: 30';
					}
					
					/*---end of get all past year of assessment list----*/	
					if($this->input->post('action')=='submitanswer')	
					{
						//var_dump($this->input->post());
					$this->session->unset_userdata('ass_attempt');	
					 $questionid=$this->input->post('questionid');
					 $answerid=$this->input->post('answerid');
					 $year_id=$this->input->post('year_id');
					 $ass_year_id=$this->input->post('ass_year_id');
				
					
					$data["ques_dtl"] = $this->main_model->get_detail('manage_question_'.$ass_year_id,'ques_id',$questionid);					
					//var_dump($data["ques_dtl"]);
					$data["correct_ans"] = $this->main_model->get_detail('manage_answer_'.$ass_year_id,'ans_id',$data["ques_dtl"]->ques_rightanswer);					
										
					if($data["ques_dtl"]->ques_rightanswer==$answerid)
					{
						
						$data['correct']=1;
						/*----insert user exam list---------*/
						
						$createdate=date("Y-m-d H:i:s");
						$chkrow_exam=$this->questions_model->check_userassessment($userid,$year_id,1);	
						
						if($chkrow_exam->exam_id!="" )
						{
							$exam_id=$chkrow_exam->exam_id;
						}
						else
						{
							$user_exam=array(
									'user_id'=>$userid,
									'year_id'=>$year_id,
									'assyear_id'=>$ass_year_id,													
									'exam_date'=>$createdate,
									'start_time'=>$createdate
									
									);
							$exam_id=$this->questions_model->Save_Userassessment($user_exam);	
						}
						
						if($exam_id!="")
						{
							$uexam_history=array(
								'exam_id'=>$exam_id,
								'user_id'=>$userid,
								'year_id'=>$year_id,
								'assyear_id'=>$ass_year_id,													
								'question_id'=>$questionid,
								'answer_id'=>$answerid,
								'answer_status'=>'true',
								
								);
							$historyexam_id=$this->questions_model->Save_Assessmenthistory($uexam_history);		
						}
						
						/*----End of insert user exam list-------*/
										
					/*----Get user exam question array------*/
					$exam_questermArr=array();
					$exam_questions=$this->questions_model->check_asstesthistory_question($userid,$year_id,1);
					if($exam_questions)
					{
						
						foreach($exam_questions as $examdata)
						{
							array_push($exam_questermArr,$examdata->question_id);
						}
					}
					
					if($year_id ==1)
						{
							$firstyear=$year_id;
							$secondyear=$year_id;
						}
						else if($year_id ==2)
						{
							$firstyear=$year_id-1;
							$secondyear=$year_id-1;
						}
						else if($year_id >2)
						{
							$firstyear=$year_id-2;
							$secondyear=$year_id-1;
						}
						
					/*----End of get user exam question array----*/
					$term_questermArr=array();
					$term_questions=$this->questions_model->assessment_exam($year_id,1);
					if($term_questions)
					{
						
						foreach($term_questions as $tquestion)
						{
							array_push($term_questermArr,$tquestion->ass_question);
						}
						
					}
					$total_exam_question=count($exam_questermArr);
					$total_term_question=count($term_questermArr);
					/*---update term by exam completed status----*/
					if($total_term_question==$total_exam_question)
					{
						$exam_status=array(
								'exam_status'=>'pass',							
								'end_time'=>$createdate,
								);
						
						$updateexam_status=$this->questions_model->Update_Asstterm_status($exam_status,$exam_id);
						$data['completed']=1;
					}
					/*---update term by exam completed status----*/
					$exam_output = array_merge(array_diff($term_questermArr, $exam_questermArr), array_diff($exam_questermArr, $term_questermArr));
					$exam_random=array_rand($exam_output);
					$randquestion=$exam_output[$exam_random];
					/* $exam_random=array_shift($exam_output);		
					$randquestion=$exam_random; */
					/*---End of check user not applied question list---*/
					$data['Questionlist']=$this->questions_model->asstest_exam_question($year_id,1,$randquestion);
						//$data['Questionlist']=$this->questions_model->term_exam($year_id,1);
						$data['exam_id']=$exam_id;
						$this->load->view('frontend/private/assessmentplay',$data);

					}
					else
					{
			
						/*----insert user exam list---------*/
						$userid=$this->session->userdata('user_id');
						$createdate=date("Y-m-d H:i:s");
						$chkrow_exam=$this->questions_model->check_userassessment($userid,$year_id,1);	
						
						if($chkrow_exam->exam_id!="" )
						{
							$exam_id=$chkrow_exam->exam_id;
						}
						else
						{
							$user_exam=array(
									'user_id'=>$userid,
									'year_id'=>$year_id,
									'assyear_id'=>$ass_year_id,													
									'exam_date'=>$createdate,
									'start_time'=>$createdate
									
									);
							$exam_id=$this->questions_model->Save_Userassessment($user_exam);	
						}
						
						if($exam_id!="")
						{
							$uexam_history=array(
								'exam_id'=>$exam_id,
								'user_id'=>$userid,
								'year_id'=>$year_id,
								'assyear_id'=>$ass_year_id,													
								'question_id'=>$questionid,
								'answer_id'=>$answerid,
								'answer_status'=>'false',
								
								);
							$hexam_id=$this->questions_model->Save_Assessmenthistory($uexam_history);		
						}
						
								/*----Get user exam question array------*/
					$exam_questermArr=array();
					$exam_questions=$this->questions_model->check_asstesthistory_question($userid,$year_id,$term_id);
					if($exam_questions)
					{
						
						foreach($exam_questions as $examdata)
						{
							array_push($exam_questermArr,$examdata->question_id);
						}
					}
					
					
					/*----End of get user exam question array----*/
					$term_questermArr=array();
					$term_questions=$this->questions_model->assessment_exam($year_id,1);
					if($term_questions)
					{
						
						foreach($term_questions as $tquestion)
						{
							array_push($term_questermArr,$tquestion->ass_question);
						}
						
					}
					$total_exam_question=count($exam_questermArr);
					$total_term_question=count($term_questermArr);
					/*---update term by exam completed status----*/
					if(30==$total_exam_question)
					{
						$exam_status=array(
								'exam_status'=>'pass',
								'end_time'=>$createdate,	
								
								);
						
						$updateexam_status=$this->questions_model->Update_Asstterm_status($exam_status,$exam_id);
						$data['completed']=1;
					}
					/*---update term by exam completed status----*/
						
						/*----End of insert user exam list-------*/
					
						$data["yourans"] = $this->main_model->get_detail('manage_answer_'.$ass_year_id,'ans_id',$answerid);	
						$data['exam_id']=$exam_id;
						$this->load->view('frontend/private/asstestexplanation',$data);
					}
					
								
					}
				else
				{
					$userid=$this->session->userdata('user_id');
					/*---check user not applied question list---*/
					$userexams=$this->questions_model->check_uasstestbyyear($userid,$year_id);
					$data['exam_id']=$userexams->exam_id;
					if($userexams->exam_id!="" && $userexams->exam_status=='pending')
					{	
						$data['assyear_id']=$userexams->assyear_id;
					}
					
					else if($userexams->exam_id!="" && $userexams->exam_status=='pass')
					{	
						$data['assyear_id']=$userexams->assyear_id+1;
					}
				
					else
					{
						$data['assyear_id']=$pastyear[0]->ass_year_id;
						//echo $pastyear[0]->ass_year_id;
					}
					
					/*----Get user exam question array------*/
					$exam_questermArr=array();
					$exam_questions=$this->questions_model->check_asstesthistory_question($userid,$year_id,1);
					if($exam_questions)
					{
						
						foreach($exam_questions as $examdata)
						{
							array_push($exam_questermArr,$examdata->question_id);
						}
					}
					
					
					/*----End of get user exam question array----*/
					
					if($year_id ==1)
						{
							$firstyear=$year_id;
							$secondyear=$year_id;
						}
						else if($year_id ==2)
						{
							$firstyear=$year_id-1;
							$secondyear=$year_id-1;
						}
						else if($year_id >2)
						{
							$firstyear=$year_id-2;
							$secondyear=$year_id-1;
						}
						
					$term_questermArr=array();
					$term_questions=$this->questions_model->assessment_exam($year_id,1,$firstyear);
					
					if($term_questions)
					{
						
						foreach($term_questions as $tquestion)
						{
							array_push($term_questermArr,$tquestion->ass_question);
						}
						
					}
					//var_dump($term_questermArr);
					
					$exam_output = array_merge(array_diff($term_questermArr, $exam_questermArr), array_diff($exam_questermArr, $term_questermArr));
					$exam_random=array_rand($exam_output);
					$randquestion=$exam_output[$exam_random];
					/* $exam_random=array_shift($exam_output);
					$randquestion=$exam_random; */
					/*---End of check user not applied question list---*/
					if($userexams->exam_status!='pass')
					{
					$data['Questionlist']=$this->questions_model->asstest_exam_question($year_id,1,$randquestion);
					}
					else
					{
						$data['Questionlist']='';
						$data['completed']=1;
					}
					//var_dump($data['Questionlist']);
					$this->load->view('frontend/private/assessmentplay',$data);
				}
			
			}
		/*---End Assessment Test -----*/
			/*---final year exam-----*/
			else if($subskill=="exam")
			{
				$this->session->set_userdata('ansattempt', '0');
				
			if($this->input->post('action')=='submitanswer')	
					{
					 $questionid=$this->input->post('questionid');
					 $answerid=$this->input->post('answerid');
					 $year_id=$this->input->post('year_id');
					 
					 $term_id=$this->input->post('term_id');
				
					
					$data["ques_dtl"] = $this->main_model->get_detail('manage_question_'.$year_id,'ques_id',$questionid);					
					
					$data["correct_ans"] = $this->main_model->get_detail('manage_answer_'.$year_id,'ans_id',$data["ques_dtl"]->ques_rightanswer);					
										
					if($data["ques_dtl"]->ques_rightanswer==$answerid)
					{
						
						$data['correct']=1;
						/*----insert user exam list---------*/
						$userid=$this->session->userdata('user_id');
						$createdate=date("Y-m-d H:i:s");
						$chkrow_exam=$this->questions_model->check_userexam($userid,$year_id,$term_id);	
						
						if($chkrow_exam->exam_id!="" )
						{
							$exam_id=$chkrow_exam->exam_id;
						}
						else
						{
							$user_exam=array(
									'user_id'=>$userid,
									'year_id'=>$year_id,
									'term_id'=>$term_id,													
									'exam_date'=>$createdate
									
									);
							$exam_id=$this->questions_model->Save_Userexam($user_exam);	
						}
						
						if($exam_id!="")
						{
							$uexam_history=array(
								'exam_id'=>$exam_id,
								'user_id'=>$userid,
								'year_id'=>$year_id,
								'term_id'=>$term_id,													
								'question_id'=>$questionid,
								'answer_id'=>$answerid,
								'answer_status'=>'false',
								
								);
							$historyexam_id=$this->questions_model->Save_Examhistory($uexam_history);		
						}
						
						/*----End of insert user exam list-------*/
						
										/*---check user not applied question list---*/
					$userexams=$this->questions_model->check_uexambyyear($userid,$year_id);
					if($userexams->exam_id!="" && $userexams->exam_status=='pending')
					{	
						$data['term_id']=$userexams->term_id;
					}
					else if($userexams->exam_id!="" && $userexams->exam_status=='pass')
					{	
						$data['term_id']=$userexams->term_id+1;
					}
					else
					{
						$data['term_id']=1;
					}
					
					/*----Get user exam question array------*/
					$exam_questermArr=array();
					$exam_questions=$this->questions_model->check_examhistory_question($userid,$year_id,$data['term_id']);
					if($exam_questions)
					{
						
						foreach($exam_questions as $examdata)
						{
							array_push($exam_questermArr,$examdata->question_id);
						}
					}
					
					
					/*----End of get user exam question array----*/
					$term_questermArr=array();
					$term_questions=$this->questions_model->term_exam($year_id,$data['term_id']);
					if($term_questions)
					{
						
						foreach($term_questions as $tquestion)
						{
							array_push($term_questermArr,$tquestion->question_id);
						}
						
					}
					$total_exam_question=count($exam_questermArr);
					$total_term_question=count($exam_questermArr);
					/*---update term by exam completed status----*/
					if($total_term_question==$total_exam_question)
					{
						$exam_status=array(
								'exam_status'=>'pass',							
								
								);
						
						$updateexam_status=$this->questions_model->Update_Examterm_status($exam_status,$exam_id);
					}
					/*---update term by exam completed status----*/
					$exam_output = array_merge(array_diff($term_questermArr, $exam_questermArr), array_diff($exam_questermArr, $term_questermArr));
					$exam_random=array_rand($exam_output);					
					$randquestion=$exam_output[$exam_random];
					/*---End of check user not applied question list---*/
					$data['Questionlist']=$this->questions_model->term_exam_question($year_id,$data['term_id'],$randquestion);
						//$data['Questionlist']=$this->questions_model->term_exam($year_id,1);
						$this->load->view('frontend/private/examplay',$data);

					}
					else
					{
			
						/*----insert user exam list---------*/
						$userid=$this->session->userdata('user_id');
						$createdate=date("Y-m-d H:i:s");
						$chkrow_exam=$this->questions_model->check_userexam($userid,$year_id,$term_id);	
						
						if($chkrow_exam->exam_id!="" )
						{
							$exam_id=$chkrow_exam->exam_id;
						}
						else
						{
							$user_exam=array(
									'user_id'=>$userid,
									'year_id'=>$year_id,
									'term_id'=>$term_id,													
									'exam_date'=>$createdate
									
									);
							$exam_id=$this->questions_model->Save_Userexam($user_exam);	
						}
						
						if($exam_id!="")
						{
							$uexam_history=array(
								'exam_id'=>$exam_id,
								'user_id'=>$userid,
								'year_id'=>$year_id,
								'term_id'=>$term_id,													
								'question_id'=>$questionid,
								'answer_id'=>$answerid,
								'answer_status'=>'true',
								
								);
							$hexam_id=$this->questions_model->Save_Examhistory($uexam_history);		
						}
						
								/*----Get user exam question array------*/
					$exam_questermArr=array();
					$exam_questions=$this->questions_model->check_examhistory_question($userid,$year_id,$term_id);
					if($exam_questions)
					{
						
						foreach($exam_questions as $examdata)
						{
							array_push($exam_questermArr,$examdata->question_id);
						}
					}
					
					
					/*----End of get user exam question array----*/
					$term_questermArr=array();
					$term_questions=$this->questions_model->term_exam($year_id,$term_id);
					if($term_questions)
					{
						
						foreach($term_questions as $tquestion)
						{
							array_push($term_questermArr,$tquestion->question_id);
						}
						
					}
					$total_exam_question=count($exam_questermArr);
					$total_term_question=count($exam_questermArr);
					/*---update term by exam completed status----*/
					if($total_term_question==$total_exam_question)
					{
						$exam_status=array(
								'exam_status'=>'pass',							
								
								);
						
						$updateexam_status=$this->questions_model->Update_Examterm_status($exam_status,$exam_id);
					}
					/*---update term by exam completed status----*/
						
						/*----End of insert user exam list-------*/
						$data["yourans"] = $this->main_model->get_detail('manage_answer_'.$year_id,'ans_id',$answerid);	
						$this->load->view('frontend/private/explanation',$data);
					}
					
								
					}
				else
				{
					$userid=$this->session->userdata('user_id');
					$this->session->set_userdata('ansattempt', '0');
					/*---check user not applied question list---*/
					$userexams=$this->questions_model->check_uexambyyear($userid,$year_id);
					$check_termexam_date=$this->questions_model->check_termexam_date($year_id);
					
					if($check_termexam_date->date!="0000-00-00 00:00:00")
					{	
						$cur_date=date("m/d/Y");
						$date=date("m/d/Y", strtotime($check_termexam_date->date));
						if($date==$cur_date){
						$data['term_id']=$check_termexam_date->term_id;
						
						}
						else{ $data['no_exam']=1;}
					}
					else
					{
						$data['no_exam']=1;
					}
					
					/*----Get user exam question array------*/
					$exam_questermArr=array();
					$exam_questions=$this->questions_model->check_examhistory_question($userid,$year_id,$data['term_id']);
					if($exam_questions)
					{
						
						foreach($exam_questions as $examdata)
						{
							array_push($exam_questermArr,$examdata->question_id);
						}
					}
					
					
					/*----End of get user exam question array----*/
					$term_questermArr=array();
					$term_questions=$this->questions_model->term_exam($year_id,$data['term_id']);
					if($term_questions)
					{
						
						foreach($term_questions as $tquestion)
						{
							array_push($term_questermArr,$tquestion->question_id);
						}
						
					}
					//var_dump($term_questermArr);
					
					$exam_output = array_merge(array_diff($term_questermArr, $exam_questermArr), array_diff($exam_questermArr, $term_questermArr));
					$exam_random=array_rand($exam_output);					
					$randquestion=$exam_output[$exam_random];
					/*---End of check user not applied question list---*/
					$data['Questionlist']=$this->questions_model->term_exam_question($year_id,$data['term_id'],$randquestion);
	
					$this->load->view('frontend/private/examplay',$data);
				}
			
			
			
			
			}
				/*---end final year exam-----*/
			else
			{	
				$this->session->unset_userdata('attempt');
				$this->session->unset_userdata('ansattempt');
			$data["skill_dtl"] =$this->main_model->get_skill('master_skill','skill_slug',$subskill,'skill_class',$year_id);		
			  $subskill_id=$data["skill_dtl"]->skill_id;
			$this->questions_model->CLASSID = $year_id;
				//$data["Questionlist"] = $this->questions_model->question_list_subskill($subskill_id);
		
				if($this->input->post('action')=='submitanswer')	
					{
					 $questionid=$this->input->post('questionid');
					 $answerid=$this->input->post('answerid');
				
					
					$data["ques_dtl"] = $this->main_model->get_detail('manage_question_'.$year_id,'ques_id',$questionid);
					//print_r($data["ques_dtl"]);
					
					$data["correct_ans"] = $this->main_model->get_detail('manage_answer_'.$year_id,'ans_id',$data["ques_dtl"]->ques_rightanswer);
					//print_r($data["correct_ans"]);
					//echo $data["correct_ans"]->ans_name;
										
					if($data["ques_dtl"]->ques_rightanswer==$answerid)
					{
						
					$data['correct']=1;
					$data["Questionlist"] = $this->questions_model->random_question($subskill_id);
					$this->load->view('frontend/private/play',$data);

					}
					else{
			
					$data["yourans"] = $this->main_model->get_detail('manage_answer_'.$year_id,'ans_id',$answerid);	
					$this->load->view('frontend/private/explanation',$data);
					}
					
								
					}
				else{
					$data["Questionlist"] = $this->questions_model->random_question($subskill_id);
					$this->load->view('frontend/private/play',$data);
					}
			
				}
			}
			else{
				
				if($this->session->userdata('user_id')!='' and $this->session->userdata('username')!='')
				{

				$data["SylList1"] = $this->syllabus_model->syllabus_list($year_id,1);
				$data["SylList2"] = $this->syllabus_model->syllabus_list($year_id,2);
				$data["SylList3"] = $this->syllabus_model->syllabus_list($year_id,3);
				$data["SylList4"] = $this->syllabus_model->syllabus_list($year_id,4);

				$this->load->view('frontend/private/kindergarten', $data);
				}
				else{
				$data["SylList1"] = $this->syllabus_model->syllabus_list($year_id,1);
				$data["SylList2"] = $this->syllabus_model->syllabus_list($year_id,2);
				$data["SylList3"] = $this->syllabus_model->syllabus_list($year_id,3);
				$data["SylList4"] = $this->syllabus_model->syllabus_list($year_id,4);

				$this->load->view('frontend/public/kg_wtht_login', $data);	
					
				}

			}
	}
	public function year9($subskill='') 
	{	
		$yearid=$this->session->userdata('loginyear');
			$yeardata=$this->classes_model->classes_details($yearid);
			if($yeardata)
			{
				$data['year_name']=$yeardata[0]->class_name;
				$data['year_slug']=$yeardata[0]->class_slug;
			}
		$year_id=10;
		$data['year_id']=$year_id;
		$userid2=$this->session->userdata('user_id');			
		$data['aatcount']=$this->exam_model->checkuser_aat_status($yearid,$userid2);
		$this->questions_model->CLASSID = $year_id;
		$data["year_dtl"] = $this->main_model->get_detail('master_class','class_id',$year_id);	
		$data['subskill']=$subskill;
		if($subskill!=""){
			/*---Start Assessment Test -----*/
				if($subskill=="assessment")
			{		
					 $this->session->set_userdata('attempt_ques', 0);
					 
					 //Page reload truncate table
					if($this->session->userdata('ass_attempt') > 0)
					{
					$checkasstest=$this->db->query("select exam_status from student_assessment_test  where year_id='".$year_id."' and user_id='".$this->session->userdata('user_id')."' 
							");
					$rowchecktest_status=$checkasstest->row();
					if($rowchecktest_status->exam_status=='pending')
					{						
					$del_asshistory=$this->db->query("delete  from sasstest_history  where year_id='".$year_id."' and user_id='".$this->session->userdata('user_id')."' 
							");
					$del_assmasterhistory=$this->db->query("delete  from student_assessment_test  where year_id='".$year_id."' and user_id='".$this->session->userdata('user_id')."' 
							");	
					$data['err_reload']=1;	
					$this->session->unset_userdata('ass_attempt');	
					}
					else
					{
						$data['err_reload']='';
					}						
					}
					else
					{
						$data['err_reload']='';	
					}
					
					/*---get all past year of assessment list----*/
					$pastyear=$this->questions_model->assessment_pastyear($year_id);
						/*echo '<pre>';
						var_dump($pastyear);
						echo '</pre>';
						*/
					$todaydate=date("Y-m-d H:i:s");	
					$userid=$this->session->userdata('user_id');
					$asstime_query=$this->questions_model->assessment_time($year_id,$userid);
					$yourstart=$asstime_query->start_time;
					if($yourstart!="" && $yourstart!=null)
					{
						$seconds = strtotime($todaydate) - strtotime($yourstart);
						$days    = floor($seconds / 86400);
						$hours   = floor(($seconds - ($days * 86400)) / 3600);
						$minutes = floor(($seconds - ($days * 86400) - ($hours * 3600))/60);
						
						if($minutes >30)
						{
							//echo $minutes;
							$exam_status=array(
								'exam_status'=>'pass',							
								'end_time'=>$todaydate,
								);
						
						$updateexam_status=$this->questions_model->Update_Asstterm_status($exam_status,$asstime_query->exam_id);
						$data['timeover']=1;
						}
						else
						{
							$totalminutes=30-$minutes;
							$data['showtimer']='Duration Left: '.$totalminutes;
						}
					}
					else
					{
						$data['showtimer']='Duration: 30';
					}
					
					/*---end of get all past year of assessment list----*/	
					if($this->input->post('action')=='submitanswer')	
					{
						//var_dump($this->input->post());
					$this->session->unset_userdata('ass_attempt');	
					 $questionid=$this->input->post('questionid');
					 $answerid=$this->input->post('answerid');
					 $year_id=$this->input->post('year_id');
					 $ass_year_id=$this->input->post('ass_year_id');
				
					
					$data["ques_dtl"] = $this->main_model->get_detail('manage_question_'.$ass_year_id,'ques_id',$questionid);					
					//var_dump($data["ques_dtl"]);
					$data["correct_ans"] = $this->main_model->get_detail('manage_answer_'.$ass_year_id,'ans_id',$data["ques_dtl"]->ques_rightanswer);					
										
					if($data["ques_dtl"]->ques_rightanswer==$answerid)
					{
						
						$data['correct']=1;
						/*----insert user exam list---------*/
						
						$createdate=date("Y-m-d H:i:s");
						$chkrow_exam=$this->questions_model->check_userassessment($userid,$year_id,1);	
						
						if($chkrow_exam->exam_id!="" )
						{
							$exam_id=$chkrow_exam->exam_id;
						}
						else
						{
							$user_exam=array(
									'user_id'=>$userid,
									'year_id'=>$year_id,
									'assyear_id'=>$ass_year_id,													
									'exam_date'=>$createdate,
									'start_time'=>$createdate
									
									);
							$exam_id=$this->questions_model->Save_Userassessment($user_exam);	
						}
						
						if($exam_id!="")
						{
							$uexam_history=array(
								'exam_id'=>$exam_id,
								'user_id'=>$userid,
								'year_id'=>$year_id,
								'assyear_id'=>$ass_year_id,													
								'question_id'=>$questionid,
								'answer_id'=>$answerid,
								'answer_status'=>'true',
								
								);
							$historyexam_id=$this->questions_model->Save_Assessmenthistory($uexam_history);		
						}
						
						/*----End of insert user exam list-------*/
										
					/*----Get user exam question array------*/
					$exam_questermArr=array();
					$exam_questions=$this->questions_model->check_asstesthistory_question($userid,$year_id,1);
					if($exam_questions)
					{
						
						foreach($exam_questions as $examdata)
						{
							array_push($exam_questermArr,$examdata->question_id);
						}
					}
					
					if($year_id ==1)
						{
							$firstyear=$year_id;
							$secondyear=$year_id;
						}
						else if($year_id ==2)
						{
							$firstyear=$year_id-1;
							$secondyear=$year_id-1;
						}
						else if($year_id >2)
						{
							$firstyear=$year_id-2;
							$secondyear=$year_id-1;
						}
						
					/*----End of get user exam question array----*/
					$term_questermArr=array();
					$term_questions=$this->questions_model->assessment_exam($year_id,1);
					if($term_questions)
					{
						
						foreach($term_questions as $tquestion)
						{
							array_push($term_questermArr,$tquestion->ass_question);
						}
						
					}
					$total_exam_question=count($exam_questermArr);
					$total_term_question=count($term_questermArr);
					/*---update term by exam completed status----*/
					if($total_term_question==$total_exam_question)
					{
						$exam_status=array(
								'exam_status'=>'pass',							
								'end_time'=>$createdate,
								);
						
						$updateexam_status=$this->questions_model->Update_Asstterm_status($exam_status,$exam_id);
						$data['completed']=1;
					}
					/*---update term by exam completed status----*/
					$exam_output = array_merge(array_diff($term_questermArr, $exam_questermArr), array_diff($exam_questermArr, $term_questermArr));
					$exam_random=array_rand($exam_output);
					$randquestion=$exam_output[$exam_random];
					/* $exam_random=array_shift($exam_output);		
					$randquestion=$exam_random; */
					/*---End of check user not applied question list---*/
					$data['Questionlist']=$this->questions_model->asstest_exam_question($year_id,1,$randquestion);
						//$data['Questionlist']=$this->questions_model->term_exam($year_id,1);
						$data['exam_id']=$exam_id;
						$this->load->view('frontend/private/assessmentplay',$data);

					}
					else
					{
			
						/*----insert user exam list---------*/
						$userid=$this->session->userdata('user_id');
						$createdate=date("Y-m-d H:i:s");
						$chkrow_exam=$this->questions_model->check_userassessment($userid,$year_id,1);	
						
						if($chkrow_exam->exam_id!="" )
						{
							$exam_id=$chkrow_exam->exam_id;
						}
						else
						{
							$user_exam=array(
									'user_id'=>$userid,
									'year_id'=>$year_id,
									'assyear_id'=>$ass_year_id,													
									'exam_date'=>$createdate,
									'start_time'=>$createdate
									
									);
							$exam_id=$this->questions_model->Save_Userassessment($user_exam);	
						}
						
						if($exam_id!="")
						{
							$uexam_history=array(
								'exam_id'=>$exam_id,
								'user_id'=>$userid,
								'year_id'=>$year_id,
								'assyear_id'=>$ass_year_id,													
								'question_id'=>$questionid,
								'answer_id'=>$answerid,
								'answer_status'=>'false',
								
								);
							$hexam_id=$this->questions_model->Save_Assessmenthistory($uexam_history);		
						}
						
								/*----Get user exam question array------*/
					$exam_questermArr=array();
					$exam_questions=$this->questions_model->check_asstesthistory_question($userid,$year_id,$term_id);
					if($exam_questions)
					{
						
						foreach($exam_questions as $examdata)
						{
							array_push($exam_questermArr,$examdata->question_id);
						}
					}
					
					
					/*----End of get user exam question array----*/
					$term_questermArr=array();
					$term_questions=$this->questions_model->assessment_exam($year_id,1);
					if($term_questions)
					{
						
						foreach($term_questions as $tquestion)
						{
							array_push($term_questermArr,$tquestion->ass_question);
						}
						
					}
					$total_exam_question=count($exam_questermArr);
					$total_term_question=count($term_questermArr);
					/*---update term by exam completed status----*/
					if(30==$total_exam_question)
					{
						$exam_status=array(
								'exam_status'=>'pass',
								'end_time'=>$createdate,	
								
								);
						
						$updateexam_status=$this->questions_model->Update_Asstterm_status($exam_status,$exam_id);
						$data['completed']=1;
					}
					/*---update term by exam completed status----*/
						
						/*----End of insert user exam list-------*/
					
						$data["yourans"] = $this->main_model->get_detail('manage_answer_'.$ass_year_id,'ans_id',$answerid);	
						$data['exam_id']=$exam_id;
						$this->load->view('frontend/private/asstestexplanation',$data);
					}
					
								
					}
				else
				{
					$userid=$this->session->userdata('user_id');
					/*---check user not applied question list---*/
					$userexams=$this->questions_model->check_uasstestbyyear($userid,$year_id);
					$data['exam_id']=$userexams->exam_id;
					if($userexams->exam_id!="" && $userexams->exam_status=='pending')
					{	
						$data['assyear_id']=$userexams->assyear_id;
					}
					
					else if($userexams->exam_id!="" && $userexams->exam_status=='pass')
					{	
						$data['assyear_id']=$userexams->assyear_id+1;
					}
				
					else
					{
						$data['assyear_id']=$pastyear[0]->ass_year_id;
						//echo $pastyear[0]->ass_year_id;
					}
					
					/*----Get user exam question array------*/
					$exam_questermArr=array();
					$exam_questions=$this->questions_model->check_asstesthistory_question($userid,$year_id,1);
					if($exam_questions)
					{
						
						foreach($exam_questions as $examdata)
						{
							array_push($exam_questermArr,$examdata->question_id);
						}
					}
					
					
					/*----End of get user exam question array----*/
					
					if($year_id ==1)
						{
							$firstyear=$year_id;
							$secondyear=$year_id;
						}
						else if($year_id ==2)
						{
							$firstyear=$year_id-1;
							$secondyear=$year_id-1;
						}
						else if($year_id >2)
						{
							$firstyear=$year_id-2;
							$secondyear=$year_id-1;
						}
						
					$term_questermArr=array();
					$term_questions=$this->questions_model->assessment_exam($year_id,1,$firstyear);
					
					if($term_questions)
					{
						
						foreach($term_questions as $tquestion)
						{
							array_push($term_questermArr,$tquestion->ass_question);
						}
						
					}
					//var_dump($term_questermArr);
					
					$exam_output = array_merge(array_diff($term_questermArr, $exam_questermArr), array_diff($exam_questermArr, $term_questermArr));
					$exam_random=array_rand($exam_output);
					$randquestion=$exam_output[$exam_random];
					/* $exam_random=array_shift($exam_output);
					$randquestion=$exam_random; */
					/*---End of check user not applied question list---*/
					if($userexams->exam_status!='pass')
					{
					$data['Questionlist']=$this->questions_model->asstest_exam_question($year_id,1,$randquestion);
					}
					else
					{
						$data['Questionlist']='';
						$data['completed']=1;
					}
					//var_dump($data['Questionlist']);
					$this->load->view('frontend/private/assessmentplay',$data);
				}
			
			}
		/*---End Assessment Test -----*/
			/*---final year exam-----*/
			else if($subskill=="exam")
			{
				$this->session->set_userdata('ansattempt', '0');
				
			if($this->input->post('action')=='submitanswer')	
					{
					 $questionid=$this->input->post('questionid');
					 $answerid=$this->input->post('answerid');
					 $year_id=$this->input->post('year_id');
					 
					 $term_id=$this->input->post('term_id');
				
					
					$data["ques_dtl"] = $this->main_model->get_detail('manage_question_'.$year_id,'ques_id',$questionid);					
					
					$data["correct_ans"] = $this->main_model->get_detail('manage_answer_'.$year_id,'ans_id',$data["ques_dtl"]->ques_rightanswer);					
										
					if($data["ques_dtl"]->ques_rightanswer==$answerid)
					{
						
						$data['correct']=1;
						/*----insert user exam list---------*/
						$userid=$this->session->userdata('user_id');
						$createdate=date("Y-m-d H:i:s");
						$chkrow_exam=$this->questions_model->check_userexam($userid,$year_id,$term_id);	
						
						if($chkrow_exam->exam_id!="" )
						{
							$exam_id=$chkrow_exam->exam_id;
						}
						else
						{
							$user_exam=array(
									'user_id'=>$userid,
									'year_id'=>$year_id,
									'term_id'=>$term_id,													
									'exam_date'=>$createdate
									
									);
							$exam_id=$this->questions_model->Save_Userexam($user_exam);	
						}
						
						if($exam_id!="")
						{
							$uexam_history=array(
								'exam_id'=>$exam_id,
								'user_id'=>$userid,
								'year_id'=>$year_id,
								'term_id'=>$term_id,													
								'question_id'=>$questionid,
								'answer_id'=>$answerid,
								'answer_status'=>'false',
								
								);
							$historyexam_id=$this->questions_model->Save_Examhistory($uexam_history);		
						}
						
						/*----End of insert user exam list-------*/
						
										/*---check user not applied question list---*/
					$userexams=$this->questions_model->check_uexambyyear($userid,$year_id);
					if($userexams->exam_id!="" && $userexams->exam_status=='pending')
					{	
						$data['term_id']=$userexams->term_id;
					}
					else if($userexams->exam_id!="" && $userexams->exam_status=='pass')
					{	
						$data['term_id']=$userexams->term_id+1;
					}
					else
					{
						$data['term_id']=1;
					}
					
					/*----Get user exam question array------*/
					$exam_questermArr=array();
					$exam_questions=$this->questions_model->check_examhistory_question($userid,$year_id,$data['term_id']);
					if($exam_questions)
					{
						
						foreach($exam_questions as $examdata)
						{
							array_push($exam_questermArr,$examdata->question_id);
						}
					}
					
					
					/*----End of get user exam question array----*/
					$term_questermArr=array();
					$term_questions=$this->questions_model->term_exam($year_id,$data['term_id']);
					if($term_questions)
					{
						
						foreach($term_questions as $tquestion)
						{
							array_push($term_questermArr,$tquestion->question_id);
						}
						
					}
					$total_exam_question=count($exam_questermArr);
					$total_term_question=count($exam_questermArr);
					/*---update term by exam completed status----*/
					if($total_term_question==$total_exam_question)
					{
						$exam_status=array(
								'exam_status'=>'pass',							
								
								);
						
						$updateexam_status=$this->questions_model->Update_Examterm_status($exam_status,$exam_id);
					}
					/*---update term by exam completed status----*/
					$exam_output = array_merge(array_diff($term_questermArr, $exam_questermArr), array_diff($exam_questermArr, $term_questermArr));
					$exam_random=array_rand($exam_output);					
					$randquestion=$exam_output[$exam_random];
					/*---End of check user not applied question list---*/
					$data['Questionlist']=$this->questions_model->term_exam_question($year_id,$data['term_id'],$randquestion);
						//$data['Questionlist']=$this->questions_model->term_exam($year_id,1);
						$this->load->view('frontend/private/examplay',$data);

					}
					else
					{
			
						/*----insert user exam list---------*/
						$userid=$this->session->userdata('user_id');
						$createdate=date("Y-m-d H:i:s");
						$chkrow_exam=$this->questions_model->check_userexam($userid,$year_id,$term_id);	
						
						if($chkrow_exam->exam_id!="" )
						{
							$exam_id=$chkrow_exam->exam_id;
						}
						else
						{
							$user_exam=array(
									'user_id'=>$userid,
									'year_id'=>$year_id,
									'term_id'=>$term_id,													
									'exam_date'=>$createdate
									
									);
							$exam_id=$this->questions_model->Save_Userexam($user_exam);	
						}
						
						if($exam_id!="")
						{
							$uexam_history=array(
								'exam_id'=>$exam_id,
								'user_id'=>$userid,
								'year_id'=>$year_id,
								'term_id'=>$term_id,													
								'question_id'=>$questionid,
								'answer_id'=>$answerid,
								'answer_status'=>'true',
								
								);
							$hexam_id=$this->questions_model->Save_Examhistory($uexam_history);		
						}
						
								/*----Get user exam question array------*/
					$exam_questermArr=array();
					$exam_questions=$this->questions_model->check_examhistory_question($userid,$year_id,$term_id);
					if($exam_questions)
					{
						
						foreach($exam_questions as $examdata)
						{
							array_push($exam_questermArr,$examdata->question_id);
						}
					}
					
					
					/*----End of get user exam question array----*/
					$term_questermArr=array();
					$term_questions=$this->questions_model->term_exam($year_id,$term_id);
					if($term_questions)
					{
						
						foreach($term_questions as $tquestion)
						{
							array_push($term_questermArr,$tquestion->question_id);
						}
						
					}
					$total_exam_question=count($exam_questermArr);
					$total_term_question=count($exam_questermArr);
					/*---update term by exam completed status----*/
					if($total_term_question==$total_exam_question)
					{
						$exam_status=array(
								'exam_status'=>'pass',							
								
								);
						
						$updateexam_status=$this->questions_model->Update_Examterm_status($exam_status,$exam_id);
					}
					/*---update term by exam completed status----*/
						
						/*----End of insert user exam list-------*/
						$data["yourans"] = $this->main_model->get_detail('manage_answer_'.$year_id,'ans_id',$answerid);	
						$this->load->view('frontend/private/explanation',$data);
					}
					
								
					}
				else
				{
					$userid=$this->session->userdata('user_id');
					$this->session->set_userdata('ansattempt', '0');
					/*---check user not applied question list---*/
					$userexams=$this->questions_model->check_uexambyyear($userid,$year_id);
					$check_termexam_date=$this->questions_model->check_termexam_date($year_id);
					
					if($check_termexam_date->date!="0000-00-00 00:00:00")
					{	
						$cur_date=date("m/d/Y");
						$date=date("m/d/Y", strtotime($check_termexam_date->date));
						if($date==$cur_date){
						$data['term_id']=$check_termexam_date->term_id;
						
						}
						else{ $data['no_exam']=1;}
					}
					else
					{
						$data['no_exam']=1;
					}
					
					/*----Get user exam question array------*/
					$exam_questermArr=array();
					$exam_questions=$this->questions_model->check_examhistory_question($userid,$year_id,$data['term_id']);
					if($exam_questions)
					{
						
						foreach($exam_questions as $examdata)
						{
							array_push($exam_questermArr,$examdata->question_id);
						}
					}
					
					
					/*----End of get user exam question array----*/
					$term_questermArr=array();
					$term_questions=$this->questions_model->term_exam($year_id,$data['term_id']);
					if($term_questions)
					{
						
						foreach($term_questions as $tquestion)
						{
							array_push($term_questermArr,$tquestion->question_id);
						}
						
					}
					//var_dump($term_questermArr);
					
					$exam_output = array_merge(array_diff($term_questermArr, $exam_questermArr), array_diff($exam_questermArr, $term_questermArr));
					$exam_random=array_rand($exam_output);					
					$randquestion=$exam_output[$exam_random];
					/*---End of check user not applied question list---*/
					$data['Questionlist']=$this->questions_model->term_exam_question($year_id,$data['term_id'],$randquestion);
	
					$this->load->view('frontend/private/examplay',$data);
				}
			
			
			
			
			}
			/*---end final year exam-----*/
			else
			{	
				$this->session->unset_userdata('attempt');
				$this->session->unset_userdata('ansattempt');
			$data["skill_dtl"] =$this->main_model->get_skill('master_skill','skill_slug',$subskill,'skill_class',$year_id);		
			  $subskill_id=$data["skill_dtl"]->skill_id;
			$this->questions_model->CLASSID = $year_id;
				//$data["Questionlist"] = $this->questions_model->question_list_subskill($subskill_id);
		
				if($this->input->post('action')=='submitanswer')	
					{
					 $questionid=$this->input->post('questionid');
					 $answerid=$this->input->post('answerid');
				
					
					$data["ques_dtl"] = $this->main_model->get_detail('manage_question_'.$year_id,'ques_id',$questionid);
					//print_r($data["ques_dtl"]);
					
					$data["correct_ans"] = $this->main_model->get_detail('manage_answer_'.$year_id,'ans_id',$data["ques_dtl"]->ques_rightanswer);
					//print_r($data["correct_ans"]);
					//echo $data["correct_ans"]->ans_name;
										
					if($data["ques_dtl"]->ques_rightanswer==$answerid)
					{
						
					$data['correct']=1;
					$data["Questionlist"] = $this->questions_model->random_question($subskill_id);
					$this->load->view('frontend/private/play',$data);

					}
					else{
			
					$data["yourans"] = $this->main_model->get_detail('manage_answer_'.$year_id,'ans_id',$answerid);	
					$this->load->view('frontend/private/explanation',$data);
					}
					
								
					}
				else{
					$data["Questionlist"] = $this->questions_model->random_question($subskill_id);
					$this->load->view('frontend/private/play',$data);
					}
			
				}
			}
			else{
				
				if($this->session->userdata('user_id')!='' and $this->session->userdata('username')!='')
				{

				$data["SylList1"] = $this->syllabus_model->syllabus_list($year_id,1);
				$data["SylList2"] = $this->syllabus_model->syllabus_list($year_id,2);
				$data["SylList3"] = $this->syllabus_model->syllabus_list($year_id,3);
				$data["SylList4"] = $this->syllabus_model->syllabus_list($year_id,4);

				$this->load->view('frontend/private/kindergarten', $data);
				}
				else{
				$data["SylList1"] = $this->syllabus_model->syllabus_list($year_id,1);
				$data["SylList2"] = $this->syllabus_model->syllabus_list($year_id,2);
				$data["SylList3"] = $this->syllabus_model->syllabus_list($year_id,3);
				$data["SylList4"] = $this->syllabus_model->syllabus_list($year_id,4);

				$this->load->view('frontend/public/kg_wtht_login', $data);	
					
				}

			}
		
	}
	public function year10($subskill='') 
	{	
		$yearid=$this->session->userdata('loginyear');
			$yeardata=$this->classes_model->classes_details($yearid);
			if($yeardata)
			{
				$data['year_name']=$yeardata[0]->class_name;
				$data['year_slug']=$yeardata[0]->class_slug;
			}
		$year_id=11;
		$data['year_id']=$year_id;
		
		$userid2=$this->session->userdata('user_id');			
		$data['aatcount']=$this->exam_model->checkuser_aat_status($yearid,$userid2);
		$this->questions_model->CLASSID = $year_id;
		$data["year_dtl"] = $this->main_model->get_detail('master_class','class_id',$year_id);	
		$data['subskill']=$subskill;
		if($subskill!=""){
			/*---Start Assessment Test -----*/
				if($subskill=="assessment")
			{		
					 $this->session->set_userdata('attempt_ques', 0);
					 
					 //Page reload truncate table
					if($this->session->userdata('ass_attempt') > 0)
					{
					$checkasstest=$this->db->query("select exam_status from student_assessment_test  where year_id='".$year_id."' and user_id='".$this->session->userdata('user_id')."' 
							");
					$rowchecktest_status=$checkasstest->row();
					if($rowchecktest_status->exam_status=='pending')
					{						
					$del_asshistory=$this->db->query("delete  from sasstest_history  where year_id='".$year_id."' and user_id='".$this->session->userdata('user_id')."' 
							");
					$del_assmasterhistory=$this->db->query("delete  from student_assessment_test  where year_id='".$year_id."' and user_id='".$this->session->userdata('user_id')."' 
							");	
					$data['err_reload']=1;	
					$this->session->unset_userdata('ass_attempt');	
					}
					else
					{
						$data['err_reload']='';
					}						
					}
					else
					{
						$data['err_reload']='';	
					}
					
					/*---get all past year of assessment list----*/
					$pastyear=$this->questions_model->assessment_pastyear($year_id);
						/*echo '<pre>';
						var_dump($pastyear);
						echo '</pre>';
						*/
					$todaydate=date("Y-m-d H:i:s");	
					$userid=$this->session->userdata('user_id');
					$asstime_query=$this->questions_model->assessment_time($year_id,$userid);
					$yourstart=$asstime_query->start_time;
					if($yourstart!="" && $yourstart!=null)
					{
						$seconds = strtotime($todaydate) - strtotime($yourstart);
						$days    = floor($seconds / 86400);
						$hours   = floor(($seconds - ($days * 86400)) / 3600);
						$minutes = floor(($seconds - ($days * 86400) - ($hours * 3600))/60);
						
						if($minutes >30)
						{
							//echo $minutes;
							$exam_status=array(
								'exam_status'=>'pass',							
								'end_time'=>$todaydate,
								);
						
						$updateexam_status=$this->questions_model->Update_Asstterm_status($exam_status,$asstime_query->exam_id);
						$data['timeover']=1;
						}
						else
						{
							$totalminutes=30-$minutes;
							$data['showtimer']='Duration Left: '.$totalminutes;
						}
					}
					else
					{
						$data['showtimer']='Duration: 30';
					}
					
					/*---end of get all past year of assessment list----*/	
					if($this->input->post('action')=='submitanswer')	
					{
						//var_dump($this->input->post());
					$this->session->unset_userdata('ass_attempt');	
					 $questionid=$this->input->post('questionid');
					 $answerid=$this->input->post('answerid');
					 $year_id=$this->input->post('year_id');
					 $ass_year_id=$this->input->post('ass_year_id');
				
					
					$data["ques_dtl"] = $this->main_model->get_detail('manage_question_'.$ass_year_id,'ques_id',$questionid);					
					//var_dump($data["ques_dtl"]);
					$data["correct_ans"] = $this->main_model->get_detail('manage_answer_'.$ass_year_id,'ans_id',$data["ques_dtl"]->ques_rightanswer);					
										
					if($data["ques_dtl"]->ques_rightanswer==$answerid)
					{
						
						$data['correct']=1;
						/*----insert user exam list---------*/
						
						$createdate=date("Y-m-d H:i:s");
						$chkrow_exam=$this->questions_model->check_userassessment($userid,$year_id,1);	
						
						if($chkrow_exam->exam_id!="" )
						{
							$exam_id=$chkrow_exam->exam_id;
						}
						else
						{
							$user_exam=array(
									'user_id'=>$userid,
									'year_id'=>$year_id,
									'assyear_id'=>$ass_year_id,													
									'exam_date'=>$createdate,
									'start_time'=>$createdate
									
									);
							$exam_id=$this->questions_model->Save_Userassessment($user_exam);	
						}
						
						if($exam_id!="")
						{
							$uexam_history=array(
								'exam_id'=>$exam_id,
								'user_id'=>$userid,
								'year_id'=>$year_id,
								'assyear_id'=>$ass_year_id,													
								'question_id'=>$questionid,
								'answer_id'=>$answerid,
								'answer_status'=>'true',
								
								);
							$historyexam_id=$this->questions_model->Save_Assessmenthistory($uexam_history);		
						}
						
						/*----End of insert user exam list-------*/
										
					/*----Get user exam question array------*/
					$exam_questermArr=array();
					$exam_questions=$this->questions_model->check_asstesthistory_question($userid,$year_id,1);
					if($exam_questions)
					{
						
						foreach($exam_questions as $examdata)
						{
							array_push($exam_questermArr,$examdata->question_id);
						}
					}
					
					if($year_id ==1)
						{
							$firstyear=$year_id;
							$secondyear=$year_id;
						}
						else if($year_id ==2)
						{
							$firstyear=$year_id-1;
							$secondyear=$year_id-1;
						}
						else if($year_id >2)
						{
							$firstyear=$year_id-2;
							$secondyear=$year_id-1;
						}
						
					/*----End of get user exam question array----*/
					$term_questermArr=array();
					$term_questions=$this->questions_model->assessment_exam($year_id,1);
					if($term_questions)
					{
						
						foreach($term_questions as $tquestion)
						{
							array_push($term_questermArr,$tquestion->ass_question);
						}
						
					}
					$total_exam_question=count($exam_questermArr);
					$total_term_question=count($term_questermArr);
					/*---update term by exam completed status----*/
					if($total_term_question==$total_exam_question)
					{
						$exam_status=array(
								'exam_status'=>'pass',							
								'end_time'=>$createdate,
								);
						
						$updateexam_status=$this->questions_model->Update_Asstterm_status($exam_status,$exam_id);
						$data['completed']=1;
					}
					/*---update term by exam completed status----*/
					$exam_output = array_merge(array_diff($term_questermArr, $exam_questermArr), array_diff($exam_questermArr, $term_questermArr));
					$exam_random=array_rand($exam_output);
					$randquestion=$exam_output[$exam_random];
					/* $exam_random=array_shift($exam_output);		
					$randquestion=$exam_random; */
					/*---End of check user not applied question list---*/
					$data['Questionlist']=$this->questions_model->asstest_exam_question($year_id,1,$randquestion);
						//$data['Questionlist']=$this->questions_model->term_exam($year_id,1);
						$data['exam_id']=$exam_id;
						$this->load->view('frontend/private/assessmentplay',$data);

					}
					else
					{
			
						/*----insert user exam list---------*/
						$userid=$this->session->userdata('user_id');
						$createdate=date("Y-m-d H:i:s");
						$chkrow_exam=$this->questions_model->check_userassessment($userid,$year_id,1);	
						
						if($chkrow_exam->exam_id!="" )
						{
							$exam_id=$chkrow_exam->exam_id;
						}
						else
						{
							$user_exam=array(
									'user_id'=>$userid,
									'year_id'=>$year_id,
									'assyear_id'=>$ass_year_id,													
									'exam_date'=>$createdate,
									'start_time'=>$createdate
									
									);
							$exam_id=$this->questions_model->Save_Userassessment($user_exam);	
						}
						
						if($exam_id!="")
						{
							$uexam_history=array(
								'exam_id'=>$exam_id,
								'user_id'=>$userid,
								'year_id'=>$year_id,
								'assyear_id'=>$ass_year_id,													
								'question_id'=>$questionid,
								'answer_id'=>$answerid,
								'answer_status'=>'false',
								
								);
							$hexam_id=$this->questions_model->Save_Assessmenthistory($uexam_history);		
						}
						
								/*----Get user exam question array------*/
					$exam_questermArr=array();
					$exam_questions=$this->questions_model->check_asstesthistory_question($userid,$year_id,$term_id);
					if($exam_questions)
					{
						
						foreach($exam_questions as $examdata)
						{
							array_push($exam_questermArr,$examdata->question_id);
						}
					}
					
					
					/*----End of get user exam question array----*/
					$term_questermArr=array();
					$term_questions=$this->questions_model->assessment_exam($year_id,1);
					if($term_questions)
					{
						
						foreach($term_questions as $tquestion)
						{
							array_push($term_questermArr,$tquestion->ass_question);
						}
						
					}
					$total_exam_question=count($exam_questermArr);
					$total_term_question=count($term_questermArr);
					/*---update term by exam completed status----*/
					if(30==$total_exam_question)
					{
						$exam_status=array(
								'exam_status'=>'pass',
								'end_time'=>$createdate,	
								
								);
						
						$updateexam_status=$this->questions_model->Update_Asstterm_status($exam_status,$exam_id);
						$data['completed']=1;
					}
					/*---update term by exam completed status----*/
						
						/*----End of insert user exam list-------*/
					
						$data["yourans"] = $this->main_model->get_detail('manage_answer_'.$ass_year_id,'ans_id',$answerid);	
						$data['exam_id']=$exam_id;
						$this->load->view('frontend/private/asstestexplanation',$data);
					}
					
								
					}
				else
				{
					$userid=$this->session->userdata('user_id');
					/*---check user not applied question list---*/
					$userexams=$this->questions_model->check_uasstestbyyear($userid,$year_id);
					$data['exam_id']=$userexams->exam_id;
					if($userexams->exam_id!="" && $userexams->exam_status=='pending')
					{	
						$data['assyear_id']=$userexams->assyear_id;
					}
					
					else if($userexams->exam_id!="" && $userexams->exam_status=='pass')
					{	
						$data['assyear_id']=$userexams->assyear_id+1;
					}
				
					else
					{
						$data['assyear_id']=$pastyear[0]->ass_year_id;
						//echo $pastyear[0]->ass_year_id;
					}
					
					/*----Get user exam question array------*/
					$exam_questermArr=array();
					$exam_questions=$this->questions_model->check_asstesthistory_question($userid,$year_id,1);
					if($exam_questions)
					{
						
						foreach($exam_questions as $examdata)
						{
							array_push($exam_questermArr,$examdata->question_id);
						}
					}
					
					
					/*----End of get user exam question array----*/
					
					if($year_id ==1)
						{
							$firstyear=$year_id;
							$secondyear=$year_id;
						}
						else if($year_id ==2)
						{
							$firstyear=$year_id-1;
							$secondyear=$year_id-1;
						}
						else if($year_id >2)
						{
							$firstyear=$year_id-2;
							$secondyear=$year_id-1;
						}
						
					$term_questermArr=array();
					$term_questions=$this->questions_model->assessment_exam($year_id,1,$firstyear);
					
					if($term_questions)
					{
						
						foreach($term_questions as $tquestion)
						{
							array_push($term_questermArr,$tquestion->ass_question);
						}
						
					}
					//var_dump($term_questermArr);
					
					$exam_output = array_merge(array_diff($term_questermArr, $exam_questermArr), array_diff($exam_questermArr, $term_questermArr));
					$exam_random=array_rand($exam_output);
					$randquestion=$exam_output[$exam_random];
					/* $exam_random=array_shift($exam_output);
					$randquestion=$exam_random; */
					/*---End of check user not applied question list---*/
					if($userexams->exam_status!='pass')
					{
					$data['Questionlist']=$this->questions_model->asstest_exam_question($year_id,1,$randquestion);
					}
					else
					{
						$data['Questionlist']='';
						$data['completed']=1;
					}
					//var_dump($data['Questionlist']);
					$this->load->view('frontend/private/assessmentplay',$data);
				}
			
			}
		/*---End Assessment Test -----*/
			/*---final year exam-----*/
			else if($subskill=="exam")
			{
				$this->session->set_userdata('ansattempt', '0');
				
			if($this->input->post('action')=='submitanswer')	
					{
					 $questionid=$this->input->post('questionid');
					 $answerid=$this->input->post('answerid');
					 $year_id=$this->input->post('year_id');
					 
					 $term_id=$this->input->post('term_id');
				
					
					$data["ques_dtl"] = $this->main_model->get_detail('manage_question_'.$year_id,'ques_id',$questionid);					
					
					$data["correct_ans"] = $this->main_model->get_detail('manage_answer_'.$year_id,'ans_id',$data["ques_dtl"]->ques_rightanswer);					
										
					if($data["ques_dtl"]->ques_rightanswer==$answerid)
					{
						
						$data['correct']=1;
						/*----insert user exam list---------*/
						$userid=$this->session->userdata('user_id');
						$createdate=date("Y-m-d H:i:s");
						$chkrow_exam=$this->questions_model->check_userexam($userid,$year_id,$term_id);	
						
						if($chkrow_exam->exam_id!="" )
						{
							$exam_id=$chkrow_exam->exam_id;
						}
						else
						{
							$user_exam=array(
									'user_id'=>$userid,
									'year_id'=>$year_id,
									'term_id'=>$term_id,													
									'exam_date'=>$createdate
									
									);
							$exam_id=$this->questions_model->Save_Userexam($user_exam);	
						}
						
						if($exam_id!="")
						{
							$uexam_history=array(
								'exam_id'=>$exam_id,
								'user_id'=>$userid,
								'year_id'=>$year_id,
								'term_id'=>$term_id,													
								'question_id'=>$questionid,
								'answer_id'=>$answerid,
								'answer_status'=>'false',
								
								);
							$historyexam_id=$this->questions_model->Save_Examhistory($uexam_history);		
						}
						
						/*----End of insert user exam list-------*/
						
										/*---check user not applied question list---*/
					$userexams=$this->questions_model->check_uexambyyear($userid,$year_id);
					if($userexams->exam_id!="" && $userexams->exam_status=='pending')
					{	
						$data['term_id']=$userexams->term_id;
					}
					else if($userexams->exam_id!="" && $userexams->exam_status=='pass')
					{	
						$data['term_id']=$userexams->term_id+1;
					}
					else
					{
						$data['term_id']=1;
					}
					
					/*----Get user exam question array------*/
					$exam_questermArr=array();
					$exam_questions=$this->questions_model->check_examhistory_question($userid,$year_id,$data['term_id']);
					if($exam_questions)
					{
						
						foreach($exam_questions as $examdata)
						{
							array_push($exam_questermArr,$examdata->question_id);
						}
					}
					
					
					/*----End of get user exam question array----*/
					$term_questermArr=array();
					$term_questions=$this->questions_model->term_exam($year_id,$data['term_id']);
					if($term_questions)
					{
						
						foreach($term_questions as $tquestion)
						{
							array_push($term_questermArr,$tquestion->question_id);
						}
						
					}
					$total_exam_question=count($exam_questermArr);
					$total_term_question=count($exam_questermArr);
					/*---update term by exam completed status----*/
					if($total_term_question==$total_exam_question)
					{
						$exam_status=array(
								'exam_status'=>'pass',							
								
								);
						
						$updateexam_status=$this->questions_model->Update_Examterm_status($exam_status,$exam_id);
					}
					/*---update term by exam completed status----*/
					$exam_output = array_merge(array_diff($term_questermArr, $exam_questermArr), array_diff($exam_questermArr, $term_questermArr));
					$exam_random=array_rand($exam_output);					
					$randquestion=$exam_output[$exam_random];
					/*---End of check user not applied question list---*/
					$data['Questionlist']=$this->questions_model->term_exam_question($year_id,$data['term_id'],$randquestion);
						//$data['Questionlist']=$this->questions_model->term_exam($year_id,1);
						$this->load->view('frontend/private/examplay',$data);

					}
					else
					{
			
						/*----insert user exam list---------*/
						$userid=$this->session->userdata('user_id');
						$createdate=date("Y-m-d H:i:s");
						$chkrow_exam=$this->questions_model->check_userexam($userid,$year_id,$term_id);	
						
						if($chkrow_exam->exam_id!="" )
						{
							$exam_id=$chkrow_exam->exam_id;
						}
						else
						{
							$user_exam=array(
									'user_id'=>$userid,
									'year_id'=>$year_id,
									'term_id'=>$term_id,													
									'exam_date'=>$createdate
									
									);
							$exam_id=$this->questions_model->Save_Userexam($user_exam);	
						}
						
						if($exam_id!="")
						{
							$uexam_history=array(
								'exam_id'=>$exam_id,
								'user_id'=>$userid,
								'year_id'=>$year_id,
								'term_id'=>$term_id,													
								'question_id'=>$questionid,
								'answer_id'=>$answerid,
								'answer_status'=>'true',
								
								);
							$hexam_id=$this->questions_model->Save_Examhistory($uexam_history);		
						}
						
								/*----Get user exam question array------*/
					$exam_questermArr=array();
					$exam_questions=$this->questions_model->check_examhistory_question($userid,$year_id,$term_id);
					if($exam_questions)
					{
						
						foreach($exam_questions as $examdata)
						{
							array_push($exam_questermArr,$examdata->question_id);
						}
					}
					
					
					/*----End of get user exam question array----*/
					$term_questermArr=array();
					$term_questions=$this->questions_model->term_exam($year_id,$term_id);
					if($term_questions)
					{
						
						foreach($term_questions as $tquestion)
						{
							array_push($term_questermArr,$tquestion->question_id);
						}
						
					}
					$total_exam_question=count($exam_questermArr);
					$total_term_question=count($exam_questermArr);
					/*---update term by exam completed status----*/
					if($total_term_question==$total_exam_question)
					{
						$exam_status=array(
								'exam_status'=>'pass',							
								
								);
						
						$updateexam_status=$this->questions_model->Update_Examterm_status($exam_status,$exam_id);
					}
					/*---update term by exam completed status----*/
						
						/*----End of insert user exam list-------*/
						$data["yourans"] = $this->main_model->get_detail('manage_answer_'.$year_id,'ans_id',$answerid);	
						$this->load->view('frontend/private/explanation',$data);
					}
					
								
					}
				else
				{
					$userid=$this->session->userdata('user_id');
					$this->session->set_userdata('ansattempt', '0');
					/*---check user not applied question list---*/
					$userexams=$this->questions_model->check_uexambyyear($userid,$year_id);
					$check_termexam_date=$this->questions_model->check_termexam_date($year_id);
					
					if($check_termexam_date->date!="0000-00-00 00:00:00")
					{	
						$cur_date=date("m/d/Y");
						$date=date("m/d/Y", strtotime($check_termexam_date->date));
						if($date==$cur_date){
						$data['term_id']=$check_termexam_date->term_id;
						
						}
						else{ $data['no_exam']=1;}
					}
					else
					{
						$data['no_exam']=1;
					}
					
					/*----Get user exam question array------*/
					$exam_questermArr=array();
					$exam_questions=$this->questions_model->check_examhistory_question($userid,$year_id,$data['term_id']);
					if($exam_questions)
					{
						
						foreach($exam_questions as $examdata)
						{
							array_push($exam_questermArr,$examdata->question_id);
						}
					}
					
					
					/*----End of get user exam question array----*/
					$term_questermArr=array();
					$term_questions=$this->questions_model->term_exam($year_id,$data['term_id']);
					if($term_questions)
					{
						
						foreach($term_questions as $tquestion)
						{
							array_push($term_questermArr,$tquestion->question_id);
						}
						
					}
					//var_dump($term_questermArr);
					
					$exam_output = array_merge(array_diff($term_questermArr, $exam_questermArr), array_diff($exam_questermArr, $term_questermArr));
					$exam_random=array_rand($exam_output);					
					$randquestion=$exam_output[$exam_random];
					/*---End of check user not applied question list---*/
					$data['Questionlist']=$this->questions_model->term_exam_question($year_id,$data['term_id'],$randquestion);
	
					$this->load->view('frontend/private/examplay',$data);
				}
			
			
			
			
			}
			/*---end final year exam-----*/
			else
			{	
				$this->session->unset_userdata('attempt');
				$this->session->unset_userdata('ansattempt');
			$data["skill_dtl"] =$this->main_model->get_skill('master_skill','skill_slug',$subskill,'skill_class',$year_id);		
			  $subskill_id=$data["skill_dtl"]->skill_id;
			$this->questions_model->CLASSID = $year_id;
				//$data["Questionlist"] = $this->questions_model->question_list_subskill($subskill_id);
		
				if($this->input->post('action')=='submitanswer')	
					{
					 $questionid=$this->input->post('questionid');
					 $answerid=$this->input->post('answerid');
				
					
					$data["ques_dtl"] = $this->main_model->get_detail('manage_question_'.$year_id,'ques_id',$questionid);
					//print_r($data["ques_dtl"]);
					
					$data["correct_ans"] = $this->main_model->get_detail('manage_answer_'.$year_id,'ans_id',$data["ques_dtl"]->ques_rightanswer);
					//print_r($data["correct_ans"]);
					//echo $data["correct_ans"]->ans_name;
										
					if($data["ques_dtl"]->ques_rightanswer==$answerid)
					{
						
					$data['correct']=1;
					$data["Questionlist"] = $this->questions_model->random_question($subskill_id);
					$this->load->view('frontend/private/play',$data);

					}
					else{
			
					$data["yourans"] = $this->main_model->get_detail('manage_answer_'.$year_id,'ans_id',$answerid);	
					$this->load->view('frontend/private/explanation',$data);
					}
					
								
					}
				else{
					$data["Questionlist"] = $this->questions_model->random_question($subskill_id);
					$this->load->view('frontend/private/play',$data);
					}
			
				}
			}
			else{
				
				if($this->session->userdata('user_id')!='' and $this->session->userdata('username')!='')
				{

				$data["SylList1"] = $this->syllabus_model->syllabus_list($year_id,1);
				$data["SylList2"] = $this->syllabus_model->syllabus_list($year_id,2);
				$data["SylList3"] = $this->syllabus_model->syllabus_list($year_id,3);
				$data["SylList4"] = $this->syllabus_model->syllabus_list($year_id,4);

				$this->load->view('frontend/private/kindergarten', $data);
				}
				else{
				$data["SylList1"] = $this->syllabus_model->syllabus_list($year_id,1);
				$data["SylList2"] = $this->syllabus_model->syllabus_list($year_id,2);
				$data["SylList3"] = $this->syllabus_model->syllabus_list($year_id,3);
				$data["SylList4"] = $this->syllabus_model->syllabus_list($year_id,4);

				$this->load->view('frontend/public/kg_wtht_login', $data);	
					
				}

			}
	}
	public function year11($subskill='') 
	{	
		$yearid=$this->session->userdata('loginyear');
			$yeardata=$this->classes_model->classes_details($yearid);
			if($yeardata)
			{
				$data['year_name']=$yeardata[0]->class_name;
				$data['year_slug']=$yeardata[0]->class_slug;
			}
		$year_id=12;
		$data['year_id']=$year_id;
		
		$userid2=$this->session->userdata('user_id');			
		$data['aatcount']=$this->exam_model->checkuser_aat_status($yearid,$userid2);
		
		$this->questions_model->CLASSID = $year_id;
		$data["year_dtl"] = $this->main_model->get_detail('master_class','class_id',$year_id);	
		$data['subskill']=$subskill;
		if($subskill!=""){
			/*---Start Assessment Test -----*/
				if($subskill=="assessment")
			{		
					 $this->session->set_userdata('attempt_ques', 0);
					 
					 //Page reload truncate table
					if($this->session->userdata('ass_attempt') > 0)
					{
					$checkasstest=$this->db->query("select exam_status from student_assessment_test  where year_id='".$year_id."' and user_id='".$this->session->userdata('user_id')."' 
							");
					$rowchecktest_status=$checkasstest->row();
					if($rowchecktest_status->exam_status=='pending')
					{						
					$del_asshistory=$this->db->query("delete  from sasstest_history  where year_id='".$year_id."' and user_id='".$this->session->userdata('user_id')."' 
							");
					$del_assmasterhistory=$this->db->query("delete  from student_assessment_test  where year_id='".$year_id."' and user_id='".$this->session->userdata('user_id')."' 
							");	
					$data['err_reload']=1;	
					$this->session->unset_userdata('ass_attempt');	
					}
					else
					{
						$data['err_reload']='';
					}						
					}
					else
					{
						$data['err_reload']='';	
					}
					
					/*---get all past year of assessment list----*/
					$pastyear=$this->questions_model->assessment_pastyear($year_id);
						/*echo '<pre>';
						var_dump($pastyear);
						echo '</pre>';
						*/
					$todaydate=date("Y-m-d H:i:s");	
					$userid=$this->session->userdata('user_id');
					$asstime_query=$this->questions_model->assessment_time($year_id,$userid);
					$yourstart=$asstime_query->start_time;
					if($yourstart!="" && $yourstart!=null)
					{
						$seconds = strtotime($todaydate) - strtotime($yourstart);
						$days    = floor($seconds / 86400);
						$hours   = floor(($seconds - ($days * 86400)) / 3600);
						$minutes = floor(($seconds - ($days * 86400) - ($hours * 3600))/60);
						
						if($minutes >30)
						{
							//echo $minutes;
							$exam_status=array(
								'exam_status'=>'pass',							
								'end_time'=>$todaydate,
								);
						
						$updateexam_status=$this->questions_model->Update_Asstterm_status($exam_status,$asstime_query->exam_id);
						$data['timeover']=1;
						}
						else
						{
							$totalminutes=30-$minutes;
							$data['showtimer']='Duration Left: '.$totalminutes;
						}
					}
					else
					{
						$data['showtimer']='Duration: 30';
					}
					
					/*---end of get all past year of assessment list----*/	
					if($this->input->post('action')=='submitanswer')	
					{
						//var_dump($this->input->post());
					$this->session->unset_userdata('ass_attempt');	
					 $questionid=$this->input->post('questionid');
					 $answerid=$this->input->post('answerid');
					 $year_id=$this->input->post('year_id');
					 $ass_year_id=$this->input->post('ass_year_id');
				
					
					$data["ques_dtl"] = $this->main_model->get_detail('manage_question_'.$ass_year_id,'ques_id',$questionid);					
					//var_dump($data["ques_dtl"]);
					$data["correct_ans"] = $this->main_model->get_detail('manage_answer_'.$ass_year_id,'ans_id',$data["ques_dtl"]->ques_rightanswer);					
										
					if($data["ques_dtl"]->ques_rightanswer==$answerid)
					{
						
						$data['correct']=1;
						/*----insert user exam list---------*/
						
						$createdate=date("Y-m-d H:i:s");
						$chkrow_exam=$this->questions_model->check_userassessment($userid,$year_id,1);	
						
						if($chkrow_exam->exam_id!="" )
						{
							$exam_id=$chkrow_exam->exam_id;
						}
						else
						{
							$user_exam=array(
									'user_id'=>$userid,
									'year_id'=>$year_id,
									'assyear_id'=>$ass_year_id,													
									'exam_date'=>$createdate,
									'start_time'=>$createdate
									
									);
							$exam_id=$this->questions_model->Save_Userassessment($user_exam);	
						}
						
						if($exam_id!="")
						{
							$uexam_history=array(
								'exam_id'=>$exam_id,
								'user_id'=>$userid,
								'year_id'=>$year_id,
								'assyear_id'=>$ass_year_id,													
								'question_id'=>$questionid,
								'answer_id'=>$answerid,
								'answer_status'=>'true',
								
								);
							$historyexam_id=$this->questions_model->Save_Assessmenthistory($uexam_history);		
						}
						
						/*----End of insert user exam list-------*/
										
					/*----Get user exam question array------*/
					$exam_questermArr=array();
					$exam_questions=$this->questions_model->check_asstesthistory_question($userid,$year_id,1);
					if($exam_questions)
					{
						
						foreach($exam_questions as $examdata)
						{
							array_push($exam_questermArr,$examdata->question_id);
						}
					}
					
					if($year_id ==1)
						{
							$firstyear=$year_id;
							$secondyear=$year_id;
						}
						else if($year_id ==2)
						{
							$firstyear=$year_id-1;
							$secondyear=$year_id-1;
						}
						else if($year_id >2)
						{
							$firstyear=$year_id-2;
							$secondyear=$year_id-1;
						}
						
					/*----End of get user exam question array----*/
					$term_questermArr=array();
					$term_questions=$this->questions_model->assessment_exam($year_id,1);
					if($term_questions)
					{
						
						foreach($term_questions as $tquestion)
						{
							array_push($term_questermArr,$tquestion->ass_question);
						}
						
					}
					$total_exam_question=count($exam_questermArr);
					$total_term_question=count($term_questermArr);
					/*---update term by exam completed status----*/
					if($total_term_question==$total_exam_question)
					{
						$exam_status=array(
								'exam_status'=>'pass',							
								'end_time'=>$createdate,
								);
						
						$updateexam_status=$this->questions_model->Update_Asstterm_status($exam_status,$exam_id);
						$data['completed']=1;
					}
					/*---update term by exam completed status----*/
					$exam_output = array_merge(array_diff($term_questermArr, $exam_questermArr), array_diff($exam_questermArr, $term_questermArr));
					$exam_random=array_rand($exam_output);
					$randquestion=$exam_output[$exam_random];
					/* $exam_random=array_shift($exam_output);		
					$randquestion=$exam_random; */
					/*---End of check user not applied question list---*/
					$data['Questionlist']=$this->questions_model->asstest_exam_question($year_id,1,$randquestion);
						//$data['Questionlist']=$this->questions_model->term_exam($year_id,1);
						$data['exam_id']=$exam_id;
						$this->load->view('frontend/private/assessmentplay',$data);

					}
					else
					{
			
						/*----insert user exam list---------*/
						$userid=$this->session->userdata('user_id');
						$createdate=date("Y-m-d H:i:s");
						$chkrow_exam=$this->questions_model->check_userassessment($userid,$year_id,1);	
						
						if($chkrow_exam->exam_id!="" )
						{
							$exam_id=$chkrow_exam->exam_id;
						}
						else
						{
							$user_exam=array(
									'user_id'=>$userid,
									'year_id'=>$year_id,
									'assyear_id'=>$ass_year_id,													
									'exam_date'=>$createdate,
									'start_time'=>$createdate
									
									);
							$exam_id=$this->questions_model->Save_Userassessment($user_exam);	
						}
						
						if($exam_id!="")
						{
							$uexam_history=array(
								'exam_id'=>$exam_id,
								'user_id'=>$userid,
								'year_id'=>$year_id,
								'assyear_id'=>$ass_year_id,													
								'question_id'=>$questionid,
								'answer_id'=>$answerid,
								'answer_status'=>'false',
								
								);
							$hexam_id=$this->questions_model->Save_Assessmenthistory($uexam_history);		
						}
						
								/*----Get user exam question array------*/
					$exam_questermArr=array();
					$exam_questions=$this->questions_model->check_asstesthistory_question($userid,$year_id,$term_id);
					if($exam_questions)
					{
						
						foreach($exam_questions as $examdata)
						{
							array_push($exam_questermArr,$examdata->question_id);
						}
					}
					
					
					/*----End of get user exam question array----*/
					$term_questermArr=array();
					$term_questions=$this->questions_model->assessment_exam($year_id,1);
					if($term_questions)
					{
						
						foreach($term_questions as $tquestion)
						{
							array_push($term_questermArr,$tquestion->ass_question);
						}
						
					}
					$total_exam_question=count($exam_questermArr);
					$total_term_question=count($term_questermArr);
					/*---update term by exam completed status----*/
					if(30==$total_exam_question)
					{
						$exam_status=array(
								'exam_status'=>'pass',
								'end_time'=>$createdate,	
								
								);
						
						$updateexam_status=$this->questions_model->Update_Asstterm_status($exam_status,$exam_id);
						$data['completed']=1;
					}
					/*---update term by exam completed status----*/
						
						/*----End of insert user exam list-------*/
					
						$data["yourans"] = $this->main_model->get_detail('manage_answer_'.$ass_year_id,'ans_id',$answerid);	
						$data['exam_id']=$exam_id;
						$this->load->view('frontend/private/asstestexplanation',$data);
					}
					
								
					}
				else
				{
					$userid=$this->session->userdata('user_id');
					/*---check user not applied question list---*/
					$userexams=$this->questions_model->check_uasstestbyyear($userid,$year_id);
					$data['exam_id']=$userexams->exam_id;
					if($userexams->exam_id!="" && $userexams->exam_status=='pending')
					{	
						$data['assyear_id']=$userexams->assyear_id;
					}
					
					else if($userexams->exam_id!="" && $userexams->exam_status=='pass')
					{	
						$data['assyear_id']=$userexams->assyear_id+1;
					}
				
					else
					{
						$data['assyear_id']=$pastyear[0]->ass_year_id;
						//echo $pastyear[0]->ass_year_id;
					}
					
					/*----Get user exam question array------*/
					$exam_questermArr=array();
					$exam_questions=$this->questions_model->check_asstesthistory_question($userid,$year_id,1);
					if($exam_questions)
					{
						
						foreach($exam_questions as $examdata)
						{
							array_push($exam_questermArr,$examdata->question_id);
						}
					}
					
					
					/*----End of get user exam question array----*/
					
					if($year_id ==1)
						{
							$firstyear=$year_id;
							$secondyear=$year_id;
						}
						else if($year_id ==2)
						{
							$firstyear=$year_id-1;
							$secondyear=$year_id-1;
						}
						else if($year_id >2)
						{
							$firstyear=$year_id-2;
							$secondyear=$year_id-1;
						}
						
					$term_questermArr=array();
					$term_questions=$this->questions_model->assessment_exam($year_id,1,$firstyear);
					
					if($term_questions)
					{
						
						foreach($term_questions as $tquestion)
						{
							array_push($term_questermArr,$tquestion->ass_question);
						}
						
					}
					//var_dump($term_questermArr);
					
					$exam_output = array_merge(array_diff($term_questermArr, $exam_questermArr), array_diff($exam_questermArr, $term_questermArr));
					$exam_random=array_rand($exam_output);
					$randquestion=$exam_output[$exam_random];
					/* $exam_random=array_shift($exam_output);
					$randquestion=$exam_random; */
					/*---End of check user not applied question list---*/
					if($userexams->exam_status!='pass')
					{
					$data['Questionlist']=$this->questions_model->asstest_exam_question($year_id,1,$randquestion);
					}
					else
					{
						$data['Questionlist']='';
						$data['completed']=1;
					}
					//var_dump($data['Questionlist']);
					$this->load->view('frontend/private/assessmentplay',$data);
				}
			
			}
		/*---End Assessment Test -----*/
			/*---final year exam-----*/
			else if($subskill=="exam")
			{
				$this->session->set_userdata('ansattempt', '0');
				
			if($this->input->post('action')=='submitanswer')	
					{
					 $questionid=$this->input->post('questionid');
					 $answerid=$this->input->post('answerid');
					 $year_id=$this->input->post('year_id');
					 
					 $term_id=$this->input->post('term_id');
				
					
					$data["ques_dtl"] = $this->main_model->get_detail('manage_question_'.$year_id,'ques_id',$questionid);					
					
					$data["correct_ans"] = $this->main_model->get_detail('manage_answer_'.$year_id,'ans_id',$data["ques_dtl"]->ques_rightanswer);					
										
					if($data["ques_dtl"]->ques_rightanswer==$answerid)
					{
						
						$data['correct']=1;
						/*----insert user exam list---------*/
						$userid=$this->session->userdata('user_id');
						$createdate=date("Y-m-d H:i:s");
						$chkrow_exam=$this->questions_model->check_userexam($userid,$year_id,$term_id);	
						
						if($chkrow_exam->exam_id!="" )
						{
							$exam_id=$chkrow_exam->exam_id;
						}
						else
						{
							$user_exam=array(
									'user_id'=>$userid,
									'year_id'=>$year_id,
									'term_id'=>$term_id,													
									'exam_date'=>$createdate
									
									);
							$exam_id=$this->questions_model->Save_Userexam($user_exam);	
						}
						
						if($exam_id!="")
						{
							$uexam_history=array(
								'exam_id'=>$exam_id,
								'user_id'=>$userid,
								'year_id'=>$year_id,
								'term_id'=>$term_id,													
								'question_id'=>$questionid,
								'answer_id'=>$answerid,
								'answer_status'=>'false',
								
								);
							$historyexam_id=$this->questions_model->Save_Examhistory($uexam_history);		
						}
						
						/*----End of insert user exam list-------*/
						
										/*---check user not applied question list---*/
					$userexams=$this->questions_model->check_uexambyyear($userid,$year_id);
					if($userexams->exam_id!="" && $userexams->exam_status=='pending')
					{	
						$data['term_id']=$userexams->term_id;
					}
					else if($userexams->exam_id!="" && $userexams->exam_status=='pass')
					{	
						$data['term_id']=$userexams->term_id+1;
					}
					else
					{
						$data['term_id']=1;
					}
					
					/*----Get user exam question array------*/
					$exam_questermArr=array();
					$exam_questions=$this->questions_model->check_examhistory_question($userid,$year_id,$data['term_id']);
					if($exam_questions)
					{
						
						foreach($exam_questions as $examdata)
						{
							array_push($exam_questermArr,$examdata->question_id);
						}
					}
					
					
					/*----End of get user exam question array----*/
					$term_questermArr=array();
					$term_questions=$this->questions_model->term_exam($year_id,$data['term_id']);
					if($term_questions)
					{
						
						foreach($term_questions as $tquestion)
						{
							array_push($term_questermArr,$tquestion->question_id);
						}
						
					}
					$total_exam_question=count($exam_questermArr);
					$total_term_question=count($exam_questermArr);
					/*---update term by exam completed status----*/
					if($total_term_question==$total_exam_question)
					{
						$exam_status=array(
								'exam_status'=>'pass',							
								
								);
						
						$updateexam_status=$this->questions_model->Update_Examterm_status($exam_status,$exam_id);
					}
					/*---update term by exam completed status----*/
					$exam_output = array_merge(array_diff($term_questermArr, $exam_questermArr), array_diff($exam_questermArr, $term_questermArr));
					$exam_random=array_rand($exam_output);					
					$randquestion=$exam_output[$exam_random];
					/*---End of check user not applied question list---*/
					$data['Questionlist']=$this->questions_model->term_exam_question($year_id,$data['term_id'],$randquestion);
						//$data['Questionlist']=$this->questions_model->term_exam($year_id,1);
						$this->load->view('frontend/private/examplay',$data);

					}
					else
					{
			
						/*----insert user exam list---------*/
						$userid=$this->session->userdata('user_id');
						$createdate=date("Y-m-d H:i:s");
						$chkrow_exam=$this->questions_model->check_userexam($userid,$year_id,$term_id);	
						
						if($chkrow_exam->exam_id!="" )
						{
							$exam_id=$chkrow_exam->exam_id;
						}
						else
						{
							$user_exam=array(
									'user_id'=>$userid,
									'year_id'=>$year_id,
									'term_id'=>$term_id,													
									'exam_date'=>$createdate
									
									);
							$exam_id=$this->questions_model->Save_Userexam($user_exam);	
						}
						
						if($exam_id!="")
						{
							$uexam_history=array(
								'exam_id'=>$exam_id,
								'user_id'=>$userid,
								'year_id'=>$year_id,
								'term_id'=>$term_id,													
								'question_id'=>$questionid,
								'answer_id'=>$answerid,
								'answer_status'=>'true',
								
								);
							$hexam_id=$this->questions_model->Save_Examhistory($uexam_history);		
						}
						
								/*----Get user exam question array------*/
					$exam_questermArr=array();
					$exam_questions=$this->questions_model->check_examhistory_question($userid,$year_id,$term_id);
					if($exam_questions)
					{
						
						foreach($exam_questions as $examdata)
						{
							array_push($exam_questermArr,$examdata->question_id);
						}
					}
					
					
					/*----End of get user exam question array----*/
					$term_questermArr=array();
					$term_questions=$this->questions_model->term_exam($year_id,$term_id);
					if($term_questions)
					{
						
						foreach($term_questions as $tquestion)
						{
							array_push($term_questermArr,$tquestion->question_id);
						}
						
					}
					$total_exam_question=count($exam_questermArr);
					$total_term_question=count($exam_questermArr);
					/*---update term by exam completed status----*/
					if($total_term_question==$total_exam_question)
					{
						$exam_status=array(
								'exam_status'=>'pass',							
								
								);
						
						$updateexam_status=$this->questions_model->Update_Examterm_status($exam_status,$exam_id);
					}
					/*---update term by exam completed status----*/
						
						/*----End of insert user exam list-------*/
						$data["yourans"] = $this->main_model->get_detail('manage_answer_'.$year_id,'ans_id',$answerid);	
						$this->load->view('frontend/private/explanation',$data);
					}
					
								
					}
				else
				{
					$userid=$this->session->userdata('user_id');
					$this->session->set_userdata('ansattempt', '0');
					/*---check user not applied question list---*/
					$userexams=$this->questions_model->check_uexambyyear($userid,$year_id);
					$check_termexam_date=$this->questions_model->check_termexam_date($year_id);
					
					if($check_termexam_date->date!="0000-00-00 00:00:00")
					{	
						$cur_date=date("m/d/Y");
						$date=date("m/d/Y", strtotime($check_termexam_date->date));
						if($date==$cur_date){
						$data['term_id']=$check_termexam_date->term_id;
						
						}
						else{ $data['no_exam']=1;}
					}
					else
					{
						$data['no_exam']=1;
					}
					
					/*----Get user exam question array------*/
					$exam_questermArr=array();
					$exam_questions=$this->questions_model->check_examhistory_question($userid,$year_id,$data['term_id']);
					if($exam_questions)
					{
						
						foreach($exam_questions as $examdata)
						{
							array_push($exam_questermArr,$examdata->question_id);
						}
					}
					
					
					/*----End of get user exam question array----*/
					$term_questermArr=array();
					$term_questions=$this->questions_model->term_exam($year_id,$data['term_id']);
					if($term_questions)
					{
						
						foreach($term_questions as $tquestion)
						{
							array_push($term_questermArr,$tquestion->question_id);
						}
						
					}
					//var_dump($term_questermArr);
					
					$exam_output = array_merge(array_diff($term_questermArr, $exam_questermArr), array_diff($exam_questermArr, $term_questermArr));
					$exam_random=array_rand($exam_output);					
					$randquestion=$exam_output[$exam_random];
					/*---End of check user not applied question list---*/
					$data['Questionlist']=$this->questions_model->term_exam_question($year_id,$data['term_id'],$randquestion);
	
					$this->load->view('frontend/private/examplay',$data);
				}
			
			
			
			
			}
			/*---end final year exam-----*/
			else
			{	
				$this->session->unset_userdata('attempt');
				$this->session->unset_userdata('ansattempt');
			$data["skill_dtl"] =$this->main_model->get_skill('master_skill','skill_slug',$subskill,'skill_class',$year_id);		
			  $subskill_id=$data["skill_dtl"]->skill_id;
			 $this->questions_model->CLASSID = $year_id;
				//$data["Questionlist"] = $this->questions_model->question_list_subskill($subskill_id);
		
				if($this->input->post('action')=='submitanswer')	
					{
					 $questionid=$this->input->post('questionid');
					
					 
					$ques_detail= $this->questions_model->question_details($questionid);
					$ques_type=explode(',',$ques_detail->ques_type);
					if(in_array(1,$ques_type)){  
						
					 $answerid=$this->input->post('answerid');
					$answerid=$this->input->post('answerid');
				
					
					$data["ques_dtl"] = $this->main_model->get_detail('manage_question_'.$year_id,'ques_id',$questionid);
					//print_r($data["ques_dtl"]);
					
					$data["correct_ans"] = $this->main_model->get_detail('manage_answer_'.$year_id,'ans_id',$data["ques_dtl"]->ques_rightanswer);
					//print_r($data["correct_ans"]);
					//echo $data["correct_ans"]->ans_name;
										
					if($data["ques_dtl"]->ques_rightanswer==$answerid)
					{
						
					$data['correct']=1;
					$data["Questionlist"] = $this->questions_model->random_question($subskill_id);
					$this->load->view('frontend/private/play',$data);

					}
					else{
			
					$data["yourans"] = $this->main_model->get_detail('manage_answer_'.$year_id,'ans_id',$answerid);	
					$this->load->view('frontend/private/explanation',$data);
					}
					}
					elseif(in_array(26,$ques_type))
					{
						
					$all_answer = $this->main_model->getall('manage_answer_'.$year_id,'ans_quesid',$questionid);
					$correct=true;
					 for($i=0;$i<count($all_answer);$i++){
						 
						$incount=$i+1;
						if($all_answer[$i]->ans_name!=$this->input->post('input'.$incount))
						{ 
							$correct=false;
							
						}
						
					 	
					 }
					 
					 if($correct){
						$data['correct']=1;
						$data["Questionlist"] = $this->questions_model->random_question($subskill_id);
						$this->load->view('frontend/private/play',$data);
					 }
					 else{
						$data["yourans"] = $this->main_model->get_detail('manage_answer_'.$year_id,'ans_id',$answerid);	
						$this->load->view('frontend/private/explanation',$data);
					 }
					 
					}
					 
					
					else{
						$data["yourans"] = $this->main_model->get_detail('manage_answer_'.$year_id,'ans_id',$answerid);	
						$this->load->view('frontend/private/explanation',$data);
						}
						
					}
				else{
					$data["Questionlist"] = $this->questions_model->random_question($subskill_id);
					$this->load->view('frontend/private/play',$data);
					}
			
				}
			}
			else{
				
				if($this->session->userdata('user_id')!='' and $this->session->userdata('username')!='')
				{

				$data["SylList1"] = $this->syllabus_model->syllabus_list($year_id,1);
				$data["SylList2"] = $this->syllabus_model->syllabus_list($year_id,2);
				$data["SylList3"] = $this->syllabus_model->syllabus_list($year_id,3);
				$data["SylList4"] = $this->syllabus_model->syllabus_list($year_id,4);

				$this->load->view('frontend/private/kindergarten', $data);
				}
				else{
				$data["SylList1"] = $this->syllabus_model->syllabus_list($year_id,1);
				$data["SylList2"] = $this->syllabus_model->syllabus_list($year_id,2);
				$data["SylList3"] = $this->syllabus_model->syllabus_list($year_id,3);
				$data["SylList4"] = $this->syllabus_model->syllabus_list($year_id,4);

				$this->load->view('frontend/public/kg_wtht_login', $data);	
					
				}

			}
		
		
	}
	public function year12($subskill='') 
	{	
		$yearid=$this->session->userdata('loginyear');
			$yeardata=$this->classes_model->classes_details($yearid);
			if($yeardata)
			{
				$data['year_name']=$yeardata[0]->class_name;
				$data['year_slug']=$yeardata[0]->class_slug;
			}
		$year_id=13;
		$data['year_id']=$year_id;
		
		$userid2=$this->session->userdata('user_id');			
		$data['aatcount']=$this->exam_model->checkuser_aat_status($yearid,$userid2);
		
		$this->questions_model->CLASSID = $year_id;
		$data["year_dtl"] = $this->main_model->get_detail('master_class','class_id',$year_id);	
		$data['subskill']=$subskill;
		if($subskill!=""){
			/*---Start Assessment Test -----*/
				if($subskill=="assessment")
			{		
					 $this->session->set_userdata('attempt_ques', 0);
					 
					 //Page reload truncate table
					if($this->session->userdata('ass_attempt') > 0)
					{
					$checkasstest=$this->db->query("select exam_status from student_assessment_test  where year_id='".$year_id."' and user_id='".$this->session->userdata('user_id')."' 
							");
					$rowchecktest_status=$checkasstest->row();
					if($rowchecktest_status->exam_status=='pending')
					{						
					$del_asshistory=$this->db->query("delete  from sasstest_history  where year_id='".$year_id."' and user_id='".$this->session->userdata('user_id')."' 
							");
					$del_assmasterhistory=$this->db->query("delete  from student_assessment_test  where year_id='".$year_id."' and user_id='".$this->session->userdata('user_id')."' 
							");	
					$data['err_reload']=1;	
					$this->session->unset_userdata('ass_attempt');	
					}
					else
					{
						$data['err_reload']='';
					}						
					}
					else
					{
						$data['err_reload']='';	
					}
					
					/*---get all past year of assessment list----*/
					$pastyear=$this->questions_model->assessment_pastyear($year_id);
						/*echo '<pre>';
						var_dump($pastyear);
						echo '</pre>';
						*/
					$todaydate=date("Y-m-d H:i:s");	
					$userid=$this->session->userdata('user_id');
					$asstime_query=$this->questions_model->assessment_time($year_id,$userid);
					$yourstart=$asstime_query->start_time;
					if($yourstart!="" && $yourstart!=null)
					{
						$seconds = strtotime($todaydate) - strtotime($yourstart);
						$days    = floor($seconds / 86400);
						$hours   = floor(($seconds - ($days * 86400)) / 3600);
						$minutes = floor(($seconds - ($days * 86400) - ($hours * 3600))/60);
						
						if($minutes >30)
						{
							//echo $minutes;
							$exam_status=array(
								'exam_status'=>'pass',							
								'end_time'=>$todaydate,
								);
						
						$updateexam_status=$this->questions_model->Update_Asstterm_status($exam_status,$asstime_query->exam_id);
						$data['timeover']=1;
						}
						else
						{
							$totalminutes=30-$minutes;
							$data['showtimer']='Duration Left: '.$totalminutes;
						}
					}
					else
					{
						$data['showtimer']='Duration: 30';
					}
					
					/*---end of get all past year of assessment list----*/	
					if($this->input->post('action')=='submitanswer')	
					{
						//var_dump($this->input->post());
					$this->session->unset_userdata('ass_attempt');	
					 $questionid=$this->input->post('questionid');
					 $answerid=$this->input->post('answerid');
					 $year_id=$this->input->post('year_id');
					 $ass_year_id=$this->input->post('ass_year_id');
				
					
					$data["ques_dtl"] = $this->main_model->get_detail('manage_question_'.$ass_year_id,'ques_id',$questionid);					
					//var_dump($data["ques_dtl"]);
					$data["correct_ans"] = $this->main_model->get_detail('manage_answer_'.$ass_year_id,'ans_id',$data["ques_dtl"]->ques_rightanswer);					
										
					if($data["ques_dtl"]->ques_rightanswer==$answerid)
					{
						
						$data['correct']=1;
						/*----insert user exam list---------*/
						
						$createdate=date("Y-m-d H:i:s");
						$chkrow_exam=$this->questions_model->check_userassessment($userid,$year_id,1);	
						
						if($chkrow_exam->exam_id!="" )
						{
							$exam_id=$chkrow_exam->exam_id;
						}
						else
						{
							$user_exam=array(
									'user_id'=>$userid,
									'year_id'=>$year_id,
									'assyear_id'=>$ass_year_id,													
									'exam_date'=>$createdate,
									'start_time'=>$createdate
									
									);
							$exam_id=$this->questions_model->Save_Userassessment($user_exam);	
						}
						
						if($exam_id!="")
						{
							$uexam_history=array(
								'exam_id'=>$exam_id,
								'user_id'=>$userid,
								'year_id'=>$year_id,
								'assyear_id'=>$ass_year_id,													
								'question_id'=>$questionid,
								'answer_id'=>$answerid,
								'answer_status'=>'true',
								
								);
							$historyexam_id=$this->questions_model->Save_Assessmenthistory($uexam_history);		
						}
						
						/*----End of insert user exam list-------*/
										
					/*----Get user exam question array------*/
					$exam_questermArr=array();
					$exam_questions=$this->questions_model->check_asstesthistory_question($userid,$year_id,1);
					if($exam_questions)
					{
						
						foreach($exam_questions as $examdata)
						{
							array_push($exam_questermArr,$examdata->question_id);
						}
					}
					
					if($year_id ==1)
						{
							$firstyear=$year_id;
							$secondyear=$year_id;
						}
						else if($year_id ==2)
						{
							$firstyear=$year_id-1;
							$secondyear=$year_id-1;
						}
						else if($year_id >2)
						{
							$firstyear=$year_id-2;
							$secondyear=$year_id-1;
						}
						
					/*----End of get user exam question array----*/
					$term_questermArr=array();
					$term_questions=$this->questions_model->assessment_exam($year_id,1);
					if($term_questions)
					{
						
						foreach($term_questions as $tquestion)
						{
							array_push($term_questermArr,$tquestion->ass_question);
						}
						
					}
					$total_exam_question=count($exam_questermArr);
					$total_term_question=count($term_questermArr);
					/*---update term by exam completed status----*/
					if($total_term_question==$total_exam_question)
					{
						$exam_status=array(
								'exam_status'=>'pass',							
								'end_time'=>$createdate,
								);
						
						$updateexam_status=$this->questions_model->Update_Asstterm_status($exam_status,$exam_id);
						$data['completed']=1;
					}
					/*---update term by exam completed status----*/
					$exam_output = array_merge(array_diff($term_questermArr, $exam_questermArr), array_diff($exam_questermArr, $term_questermArr));
					$exam_random=array_rand($exam_output);
					$randquestion=$exam_output[$exam_random];
					/* $exam_random=array_shift($exam_output);		
					$randquestion=$exam_random; */
					/*---End of check user not applied question list---*/
					$data['Questionlist']=$this->questions_model->asstest_exam_question($year_id,1,$randquestion);
						//$data['Questionlist']=$this->questions_model->term_exam($year_id,1);
						$data['exam_id']=$exam_id;
						$this->load->view('frontend/private/assessmentplay',$data);

					}
					else
					{
			
						/*----insert user exam list---------*/
						$userid=$this->session->userdata('user_id');
						$createdate=date("Y-m-d H:i:s");
						$chkrow_exam=$this->questions_model->check_userassessment($userid,$year_id,1);	
						
						if($chkrow_exam->exam_id!="" )
						{
							$exam_id=$chkrow_exam->exam_id;
						}
						else
						{
							$user_exam=array(
									'user_id'=>$userid,
									'year_id'=>$year_id,
									'assyear_id'=>$ass_year_id,													
									'exam_date'=>$createdate,
									'start_time'=>$createdate
									
									);
							$exam_id=$this->questions_model->Save_Userassessment($user_exam);	
						}
						
						if($exam_id!="")
						{
							$uexam_history=array(
								'exam_id'=>$exam_id,
								'user_id'=>$userid,
								'year_id'=>$year_id,
								'assyear_id'=>$ass_year_id,													
								'question_id'=>$questionid,
								'answer_id'=>$answerid,
								'answer_status'=>'false',
								
								);
							$hexam_id=$this->questions_model->Save_Assessmenthistory($uexam_history);		
						}
						
								/*----Get user exam question array------*/
					$exam_questermArr=array();
					$exam_questions=$this->questions_model->check_asstesthistory_question($userid,$year_id,$term_id);
					if($exam_questions)
					{
						
						foreach($exam_questions as $examdata)
						{
							array_push($exam_questermArr,$examdata->question_id);
						}
					}
					
					
					/*----End of get user exam question array----*/
					$term_questermArr=array();
					$term_questions=$this->questions_model->assessment_exam($year_id,1);
					if($term_questions)
					{
						
						foreach($term_questions as $tquestion)
						{
							array_push($term_questermArr,$tquestion->ass_question);
						}
						
					}
					$total_exam_question=count($exam_questermArr);
					$total_term_question=count($term_questermArr);
					/*---update term by exam completed status----*/
					if(30==$total_exam_question)
					{
						$exam_status=array(
								'exam_status'=>'pass',
								'end_time'=>$createdate,	
								
								);
						
						$updateexam_status=$this->questions_model->Update_Asstterm_status($exam_status,$exam_id);
						$data['completed']=1;
					}
					/*---update term by exam completed status----*/
						
						/*----End of insert user exam list-------*/
					
						$data["yourans"] = $this->main_model->get_detail('manage_answer_'.$ass_year_id,'ans_id',$answerid);	
						$data['exam_id']=$exam_id;
						$this->load->view('frontend/private/asstestexplanation',$data);
					}
					
								
					}
				else
				{
					$userid=$this->session->userdata('user_id');
					/*---check user not applied question list---*/
					$userexams=$this->questions_model->check_uasstestbyyear($userid,$year_id);
					$data['exam_id']=$userexams->exam_id;
					if($userexams->exam_id!="" && $userexams->exam_status=='pending')
					{	
						$data['assyear_id']=$userexams->assyear_id;
					}
					
					else if($userexams->exam_id!="" && $userexams->exam_status=='pass')
					{	
						$data['assyear_id']=$userexams->assyear_id+1;
					}
				
					else
					{
						$data['assyear_id']=$pastyear[0]->ass_year_id;
						//echo $pastyear[0]->ass_year_id;
					}
					
					/*----Get user exam question array------*/
					$exam_questermArr=array();
					$exam_questions=$this->questions_model->check_asstesthistory_question($userid,$year_id,1);
					if($exam_questions)
					{
						
						foreach($exam_questions as $examdata)
						{
							array_push($exam_questermArr,$examdata->question_id);
						}
					}
					
					
					/*----End of get user exam question array----*/
					
					if($year_id ==1)
						{
							$firstyear=$year_id;
							$secondyear=$year_id;
						}
						else if($year_id ==2)
						{
							$firstyear=$year_id-1;
							$secondyear=$year_id-1;
						}
						else if($year_id >2)
						{
							$firstyear=$year_id-2;
							$secondyear=$year_id-1;
						}
						
					$term_questermArr=array();
					$term_questions=$this->questions_model->assessment_exam($year_id,1,$firstyear);
					
					if($term_questions)
					{
						
						foreach($term_questions as $tquestion)
						{
							array_push($term_questermArr,$tquestion->ass_question);
						}
						
					}
					//var_dump($term_questermArr);
					
					$exam_output = array_merge(array_diff($term_questermArr, $exam_questermArr), array_diff($exam_questermArr, $term_questermArr));
					$exam_random=array_rand($exam_output);
					$randquestion=$exam_output[$exam_random];
					/* $exam_random=array_shift($exam_output);
					$randquestion=$exam_random; */
					/*---End of check user not applied question list---*/
					if($userexams->exam_status!='pass')
					{
					$data['Questionlist']=$this->questions_model->asstest_exam_question($year_id,1,$randquestion);
					}
					else
					{
						$data['Questionlist']='';
						$data['completed']=1;
					}
					//var_dump($data['Questionlist']);
					$this->load->view('frontend/private/assessmentplay',$data);
				}
			
			}
		/*---End Assessment Test -----*/
			/*---final year exam-----*/
			else if($subskill=="exam")
			{
				$this->session->set_userdata('ansattempt', '0');
				
			if($this->input->post('action')=='submitanswer')	
					{
					 $questionid=$this->input->post('questionid');
					 $answerid=$this->input->post('answerid');
					 $year_id=$this->input->post('year_id');
					 
					 $term_id=$this->input->post('term_id');
				
					
					$data["ques_dtl"] = $this->main_model->get_detail('manage_question_'.$year_id,'ques_id',$questionid);					
					
					$data["correct_ans"] = $this->main_model->get_detail('manage_answer_'.$year_id,'ans_id',$data["ques_dtl"]->ques_rightanswer);					
										
					if($data["ques_dtl"]->ques_rightanswer==$answerid)
					{
						
						$data['correct']=1;
						/*----insert user exam list---------*/
						$userid=$this->session->userdata('user_id');
						$createdate=date("Y-m-d H:i:s");
						$chkrow_exam=$this->questions_model->check_userexam($userid,$year_id,$term_id);	
						
						if($chkrow_exam->exam_id!="" )
						{
							$exam_id=$chkrow_exam->exam_id;
						}
						else
						{
							$user_exam=array(
									'user_id'=>$userid,
									'year_id'=>$year_id,
									'term_id'=>$term_id,													
									'exam_date'=>$createdate
									
									);
							$exam_id=$this->questions_model->Save_Userexam($user_exam);	
						}
						
						if($exam_id!="")
						{
							$uexam_history=array(
								'exam_id'=>$exam_id,
								'user_id'=>$userid,
								'year_id'=>$year_id,
								'term_id'=>$term_id,													
								'question_id'=>$questionid,
								'answer_id'=>$answerid,
								'answer_status'=>'false',
								
								);
							$historyexam_id=$this->questions_model->Save_Examhistory($uexam_history);		
						}
						
						/*----End of insert user exam list-------*/
						
										/*---check user not applied question list---*/
					$userexams=$this->questions_model->check_uexambyyear($userid,$year_id);
					if($userexams->exam_id!="" && $userexams->exam_status=='pending')
					{	
						$data['term_id']=$userexams->term_id;
					}
					else if($userexams->exam_id!="" && $userexams->exam_status=='pass')
					{	
						$data['term_id']=$userexams->term_id+1;
					}
					else
					{
						$data['term_id']=1;
					}
					
					/*----Get user exam question array------*/
					$exam_questermArr=array();
					$exam_questions=$this->questions_model->check_examhistory_question($userid,$year_id,$data['term_id']);
					if($exam_questions)
					{
						
						foreach($exam_questions as $examdata)
						{
							array_push($exam_questermArr,$examdata->question_id);
						}
					}
					
					
					/*----End of get user exam question array----*/
					$term_questermArr=array();
					$term_questions=$this->questions_model->term_exam($year_id,$data['term_id']);
					if($term_questions)
					{
						
						foreach($term_questions as $tquestion)
						{
							array_push($term_questermArr,$tquestion->question_id);
						}
						
					}
					$total_exam_question=count($exam_questermArr);
					$total_term_question=count($exam_questermArr);
					/*---update term by exam completed status----*/
					if($total_term_question==$total_exam_question)
					{
						$exam_status=array(
								'exam_status'=>'pass',							
								
								);
						
						$updateexam_status=$this->questions_model->Update_Examterm_status($exam_status,$exam_id);
					}
					/*---update term by exam completed status----*/
					$exam_output = array_merge(array_diff($term_questermArr, $exam_questermArr), array_diff($exam_questermArr, $term_questermArr));
					$exam_random=array_rand($exam_output);					
					$randquestion=$exam_output[$exam_random];
					/*---End of check user not applied question list---*/
					$data['Questionlist']=$this->questions_model->term_exam_question($year_id,$data['term_id'],$randquestion);
						//$data['Questionlist']=$this->questions_model->term_exam($year_id,1);
						$this->load->view('frontend/private/examplay',$data);

					}
					else
					{
			
						/*----insert user exam list---------*/
						$userid=$this->session->userdata('user_id');
						$createdate=date("Y-m-d H:i:s");
						$chkrow_exam=$this->questions_model->check_userexam($userid,$year_id,$term_id);	
						
						if($chkrow_exam->exam_id!="" )
						{
							$exam_id=$chkrow_exam->exam_id;
						}
						else
						{
							$user_exam=array(
									'user_id'=>$userid,
									'year_id'=>$year_id,
									'term_id'=>$term_id,													
									'exam_date'=>$createdate
									
									);
							$exam_id=$this->questions_model->Save_Userexam($user_exam);	
						}
						
						if($exam_id!="")
						{
							$uexam_history=array(
								'exam_id'=>$exam_id,
								'user_id'=>$userid,
								'year_id'=>$year_id,
								'term_id'=>$term_id,													
								'question_id'=>$questionid,
								'answer_id'=>$answerid,
								'answer_status'=>'true',
								
								);
							$hexam_id=$this->questions_model->Save_Examhistory($uexam_history);		
						}
						
								/*----Get user exam question array------*/
					$exam_questermArr=array();
					$exam_questions=$this->questions_model->check_examhistory_question($userid,$year_id,$term_id);
					if($exam_questions)
					{
						
						foreach($exam_questions as $examdata)
						{
							array_push($exam_questermArr,$examdata->question_id);
						}
					}
					
					
					/*----End of get user exam question array----*/
					$term_questermArr=array();
					$term_questions=$this->questions_model->term_exam($year_id,$term_id);
					if($term_questions)
					{
						
						foreach($term_questions as $tquestion)
						{
							array_push($term_questermArr,$tquestion->question_id);
						}
						
					}
					$total_exam_question=count($exam_questermArr);
					$total_term_question=count($exam_questermArr);
					/*---update term by exam completed status----*/
					if($total_term_question==$total_exam_question)
					{
						$exam_status=array(
								'exam_status'=>'pass',							
								
								);
						
						$updateexam_status=$this->questions_model->Update_Examterm_status($exam_status,$exam_id);
					}
					/*---update term by exam completed status----*/
						
						/*----End of insert user exam list-------*/
						$data["yourans"] = $this->main_model->get_detail('manage_answer_'.$year_id,'ans_id',$answerid);	
						$this->load->view('frontend/private/explanation',$data);
					}
					
								
					}
				else
				{
					$userid=$this->session->userdata('user_id');
					$this->session->set_userdata('ansattempt', '0');
					/*---check user not applied question list---*/
					$userexams=$this->questions_model->check_uexambyyear($userid,$year_id);
					$check_termexam_date=$this->questions_model->check_termexam_date($year_id);
					
					if($check_termexam_date->date!="0000-00-00 00:00:00")
					{	
						$cur_date=date("m/d/Y");
						$date=date("m/d/Y", strtotime($check_termexam_date->date));
						if($date==$cur_date){
						$data['term_id']=$check_termexam_date->term_id;
						
						}
						else{ $data['no_exam']=1;}
					}
					else
					{
						$data['no_exam']=1;
					}
					
					/*----Get user exam question array------*/
					$exam_questermArr=array();
					$exam_questions=$this->questions_model->check_examhistory_question($userid,$year_id,$data['term_id']);
					if($exam_questions)
					{
						
						foreach($exam_questions as $examdata)
						{
							array_push($exam_questermArr,$examdata->question_id);
						}
					}
					
					
					/*----End of get user exam question array----*/
					$term_questermArr=array();
					$term_questions=$this->questions_model->term_exam($year_id,$data['term_id']);
					if($term_questions)
					{
						
						foreach($term_questions as $tquestion)
						{
							array_push($term_questermArr,$tquestion->question_id);
						}
						
					}
					//var_dump($term_questermArr);
					
					$exam_output = array_merge(array_diff($term_questermArr, $exam_questermArr), array_diff($exam_questermArr, $term_questermArr));
					$exam_random=array_rand($exam_output);					
					$randquestion=$exam_output[$exam_random];
					/*---End of check user not applied question list---*/
					$data['Questionlist']=$this->questions_model->term_exam_question($year_id,$data['term_id'],$randquestion);
	
					$this->load->view('frontend/private/examplay',$data);
				}
			
			
			
			
			}
				/*---end final year exam-----*/
			else
			{	
				$this->session->unset_userdata('attempt');
				$this->session->unset_userdata('ansattempt');
			$data["skill_dtl"] =$this->main_model->get_skill('master_skill','skill_slug',$subskill,'skill_class',$year_id);		
			  $subskill_id=$data["skill_dtl"]->skill_id;
			$this->questions_model->CLASSID = $year_id;
				//$data["Questionlist"] = $this->questions_model->question_list_subskill($subskill_id);
		
				if($this->input->post('action')=='submitanswer')	
					{
					 $questionid=$this->input->post('questionid');
					 $answerid=$this->input->post('answerid');
				
					
					$data["ques_dtl"] = $this->main_model->get_detail('manage_question_'.$year_id,'ques_id',$questionid);
					//print_r($data["ques_dtl"]);
					
					$data["correct_ans"] = $this->main_model->get_detail('manage_answer_'.$year_id,'ans_id',$data["ques_dtl"]->ques_rightanswer);
					//print_r($data["correct_ans"]);
					//echo $data["correct_ans"]->ans_name;
										
					if($data["ques_dtl"]->ques_rightanswer==$answerid)
					{
						
					$data['correct']=1;
					$data["Questionlist"] = $this->questions_model->random_question($subskill_id);
					$this->load->view('frontend/private/play',$data);

					}
					else{
			
					$data["yourans"] = $this->main_model->get_detail('manage_answer_'.$year_id,'ans_id',$answerid);	
					$this->load->view('frontend/private/explanation',$data);
					}
					
								
					}
				else{
					$data["Questionlist"] = $this->questions_model->random_question($subskill_id);
					$this->load->view('frontend/private/play',$data);
					}
			
				}
			}
			else{
				
				if($this->session->userdata('user_id')!='' and $this->session->userdata('username')!='')
				{

				$data["SylList1"] = $this->syllabus_model->syllabus_list($year_id,1);
				$data["SylList2"] = $this->syllabus_model->syllabus_list($year_id,2);
				$data["SylList3"] = $this->syllabus_model->syllabus_list($year_id,3);
				$data["SylList4"] = $this->syllabus_model->syllabus_list($year_id,4);

				$this->load->view('frontend/private/kindergarten', $data);
				}
				else{
				$data["SylList1"] = $this->syllabus_model->syllabus_list($year_id,1);
				$data["SylList2"] = $this->syllabus_model->syllabus_list($year_id,2);
				$data["SylList3"] = $this->syllabus_model->syllabus_list($year_id,3);
				$data["SylList4"] = $this->syllabus_model->syllabus_list($year_id,4);

				$this->load->view('frontend/public/kg_wtht_login', $data);	
					
				}

			}
		
		
	}
	public function year13($subskill='') 
	{
			
		$yearid=$this->session->userdata('loginyear');
			$yeardata=$this->classes_model->classes_details($yearid);
			if($yeardata)
			{
				$data['year_name']=$yeardata[0]->class_name;
				$data['year_slug']=$yeardata[0]->class_slug;
			}
		$year_id=14;
		$data['year_id']=$year_id;
		
		$userid2=$this->session->userdata('user_id');			
		$data['aatcount']=$this->exam_model->checkuser_aat_status($yearid,$userid2);
		
		$this->questions_model->CLASSID = $year_id;
		$data["year_dtl"] = $this->main_model->get_detail('master_class','class_id',$year_id);	
		$data['subskill']=$subskill;
		if($subskill!=""){
			/*---Start Assessment Test -----*/
				if($subskill=="assessment")
			{		
					 $this->session->set_userdata('attempt_ques', 0);
					 
					 //Page reload truncate table
					if($this->session->userdata('ass_attempt') > 0)
					{
					$checkasstest=$this->db->query("select exam_status from student_assessment_test  where year_id='".$year_id."' and user_id='".$this->session->userdata('user_id')."' 
							");
					$rowchecktest_status=$checkasstest->row();
					if($rowchecktest_status->exam_status=='pending')
					{						
					$del_asshistory=$this->db->query("delete  from sasstest_history  where year_id='".$year_id."' and user_id='".$this->session->userdata('user_id')."' 
							");
					$del_assmasterhistory=$this->db->query("delete  from student_assessment_test  where year_id='".$year_id."' and user_id='".$this->session->userdata('user_id')."' 
							");	
					$data['err_reload']=1;	
					$this->session->unset_userdata('ass_attempt');	
					}
					else
					{
						$data['err_reload']='';
					}						
					}
					else
					{
						$data['err_reload']='';	
					}
					
					/*---get all past year of assessment list----*/
					$pastyear=$this->questions_model->assessment_pastyear($year_id);
						/*echo '<pre>';
						var_dump($pastyear);
						echo '</pre>';
						*/
					$todaydate=date("Y-m-d H:i:s");	
					$userid=$this->session->userdata('user_id');
					$asstime_query=$this->questions_model->assessment_time($year_id,$userid);
					$yourstart=$asstime_query->start_time;
					if($yourstart!="" && $yourstart!=null)
					{
						$seconds = strtotime($todaydate) - strtotime($yourstart);
						$days    = floor($seconds / 86400);
						$hours   = floor(($seconds - ($days * 86400)) / 3600);
						$minutes = floor(($seconds - ($days * 86400) - ($hours * 3600))/60);
						
						if($minutes >30)
						{
							//echo $minutes;
							$exam_status=array(
								'exam_status'=>'pass',							
								'end_time'=>$todaydate,
								);
						
						$updateexam_status=$this->questions_model->Update_Asstterm_status($exam_status,$asstime_query->exam_id);
						$data['timeover']=1;
						}
						else
						{
							$totalminutes=30-$minutes;
							$data['showtimer']='Duration Left: '.$totalminutes;
						}
					}
					else
					{
						$data['showtimer']='Duration: 30';
					}
					
					/*---end of get all past year of assessment list----*/	
					if($this->input->post('action')=='submitanswer')	
					{
						//var_dump($this->input->post());
					$this->session->unset_userdata('ass_attempt');	
					 $questionid=$this->input->post('questionid');
					 $answerid=$this->input->post('answerid');
					 $year_id=$this->input->post('year_id');
					 $ass_year_id=$this->input->post('ass_year_id');
				
					
					$data["ques_dtl"] = $this->main_model->get_detail('manage_question_'.$ass_year_id,'ques_id',$questionid);					
					//var_dump($data["ques_dtl"]);
					$data["correct_ans"] = $this->main_model->get_detail('manage_answer_'.$ass_year_id,'ans_id',$data["ques_dtl"]->ques_rightanswer);					
										
					if($data["ques_dtl"]->ques_rightanswer==$answerid)
					{
						
						$data['correct']=1;
						/*----insert user exam list---------*/
						
						$createdate=date("Y-m-d H:i:s");
						$chkrow_exam=$this->questions_model->check_userassessment($userid,$year_id,1);	
						
						if($chkrow_exam->exam_id!="" )
						{
							$exam_id=$chkrow_exam->exam_id;
						}
						else
						{
							$user_exam=array(
									'user_id'=>$userid,
									'year_id'=>$year_id,
									'assyear_id'=>$ass_year_id,													
									'exam_date'=>$createdate,
									'start_time'=>$createdate
									
									);
							$exam_id=$this->questions_model->Save_Userassessment($user_exam);	
						}
						
						if($exam_id!="")
						{
							$uexam_history=array(
								'exam_id'=>$exam_id,
								'user_id'=>$userid,
								'year_id'=>$year_id,
								'assyear_id'=>$ass_year_id,													
								'question_id'=>$questionid,
								'answer_id'=>$answerid,
								'answer_status'=>'true',
								
								);
							$historyexam_id=$this->questions_model->Save_Assessmenthistory($uexam_history);		
						}
						
						/*----End of insert user exam list-------*/
										
					/*----Get user exam question array------*/
					$exam_questermArr=array();
					$exam_questions=$this->questions_model->check_asstesthistory_question($userid,$year_id,1);
					if($exam_questions)
					{
						
						foreach($exam_questions as $examdata)
						{
							array_push($exam_questermArr,$examdata->question_id);
						}
					}
					
					if($year_id ==1)
						{
							$firstyear=$year_id;
							$secondyear=$year_id;
						}
						else if($year_id ==2)
						{
							$firstyear=$year_id-1;
							$secondyear=$year_id-1;
						}
						else if($year_id >2)
						{
							$firstyear=$year_id-2;
							$secondyear=$year_id-1;
						}
						
					/*----End of get user exam question array----*/
					$term_questermArr=array();
					$term_questions=$this->questions_model->assessment_exam($year_id,1);
					if($term_questions)
					{
						
						foreach($term_questions as $tquestion)
						{
							array_push($term_questermArr,$tquestion->ass_question);
						}
						
					}
					$total_exam_question=count($exam_questermArr);
					$total_term_question=count($term_questermArr);
					/*---update term by exam completed status----*/
					if($total_term_question==$total_exam_question)
					{
						$exam_status=array(
								'exam_status'=>'pass',							
								'end_time'=>$createdate,
								);
						
						$updateexam_status=$this->questions_model->Update_Asstterm_status($exam_status,$exam_id);
						$data['completed']=1;
					}
					/*---update term by exam completed status----*/
					$exam_output = array_merge(array_diff($term_questermArr, $exam_questermArr), array_diff($exam_questermArr, $term_questermArr));
					$exam_random=array_rand($exam_output);
					$randquestion=$exam_output[$exam_random];
					/* $exam_random=array_shift($exam_output);		
					$randquestion=$exam_random; */
					/*---End of check user not applied question list---*/
					$data['Questionlist']=$this->questions_model->asstest_exam_question($year_id,1,$randquestion);
						//$data['Questionlist']=$this->questions_model->term_exam($year_id,1);
						$data['exam_id']=$exam_id;
						$this->load->view('frontend/private/assessmentplay',$data);

					}
					else
					{
			
						/*----insert user exam list---------*/
						$userid=$this->session->userdata('user_id');
						$createdate=date("Y-m-d H:i:s");
						$chkrow_exam=$this->questions_model->check_userassessment($userid,$year_id,1);	
						
						if($chkrow_exam->exam_id!="" )
						{
							$exam_id=$chkrow_exam->exam_id;
						}
						else
						{
							$user_exam=array(
									'user_id'=>$userid,
									'year_id'=>$year_id,
									'assyear_id'=>$ass_year_id,													
									'exam_date'=>$createdate,
									'start_time'=>$createdate
									
									);
							$exam_id=$this->questions_model->Save_Userassessment($user_exam);	
						}
						
						if($exam_id!="")
						{
							$uexam_history=array(
								'exam_id'=>$exam_id,
								'user_id'=>$userid,
								'year_id'=>$year_id,
								'assyear_id'=>$ass_year_id,													
								'question_id'=>$questionid,
								'answer_id'=>$answerid,
								'answer_status'=>'false',
								
								);
							$hexam_id=$this->questions_model->Save_Assessmenthistory($uexam_history);		
						}
						
								/*----Get user exam question array------*/
					$exam_questermArr=array();
					$exam_questions=$this->questions_model->check_asstesthistory_question($userid,$year_id,$term_id);
					if($exam_questions)
					{
						
						foreach($exam_questions as $examdata)
						{
							array_push($exam_questermArr,$examdata->question_id);
						}
					}
					
					
					/*----End of get user exam question array----*/
					$term_questermArr=array();
					$term_questions=$this->questions_model->assessment_exam($year_id,1);
					if($term_questions)
					{
						
						foreach($term_questions as $tquestion)
						{
							array_push($term_questermArr,$tquestion->ass_question);
						}
						
					}
					$total_exam_question=count($exam_questermArr);
					$total_term_question=count($term_questermArr);
					/*---update term by exam completed status----*/
					if(30==$total_exam_question)
					{
						$exam_status=array(
								'exam_status'=>'pass',
								'end_time'=>$createdate,	
								
								);
						
						$updateexam_status=$this->questions_model->Update_Asstterm_status($exam_status,$exam_id);
						$data['completed']=1;
					}
					/*---update term by exam completed status----*/
						
						/*----End of insert user exam list-------*/
					
						$data["yourans"] = $this->main_model->get_detail('manage_answer_'.$ass_year_id,'ans_id',$answerid);	
						$data['exam_id']=$exam_id;
						$this->load->view('frontend/private/asstestexplanation',$data);
					}
					
								
					}
				else
				{
					$userid=$this->session->userdata('user_id');
					/*---check user not applied question list---*/
					$userexams=$this->questions_model->check_uasstestbyyear($userid,$year_id);
					$data['exam_id']=$userexams->exam_id;
					if($userexams->exam_id!="" && $userexams->exam_status=='pending')
					{	
						$data['assyear_id']=$userexams->assyear_id;
					}
					
					else if($userexams->exam_id!="" && $userexams->exam_status=='pass')
					{	
						$data['assyear_id']=$userexams->assyear_id+1;
					}
				
					else
					{
						$data['assyear_id']=$pastyear[0]->ass_year_id;
						//echo $pastyear[0]->ass_year_id;
					}
					
					/*----Get user exam question array------*/
					$exam_questermArr=array();
					$exam_questions=$this->questions_model->check_asstesthistory_question($userid,$year_id,1);
					if($exam_questions)
					{
						
						foreach($exam_questions as $examdata)
						{
							array_push($exam_questermArr,$examdata->question_id);
						}
					}
					
					
					/*----End of get user exam question array----*/
					
					if($year_id ==1)
						{
							$firstyear=$year_id;
							$secondyear=$year_id;
						}
						else if($year_id ==2)
						{
							$firstyear=$year_id-1;
							$secondyear=$year_id-1;
						}
						else if($year_id >2)
						{
							$firstyear=$year_id-2;
							$secondyear=$year_id-1;
						}
						
					$term_questermArr=array();
					$term_questions=$this->questions_model->assessment_exam($year_id,1,$firstyear);
					
					if($term_questions)
					{
						
						foreach($term_questions as $tquestion)
						{
							array_push($term_questermArr,$tquestion->ass_question);
						}
						
					}
					//var_dump($term_questermArr);
					
					$exam_output = array_merge(array_diff($term_questermArr, $exam_questermArr), array_diff($exam_questermArr, $term_questermArr));
					$exam_random=array_rand($exam_output);
					$randquestion=$exam_output[$exam_random];
					/* $exam_random=array_shift($exam_output);
					$randquestion=$exam_random; */
					/*---End of check user not applied question list---*/
					if($userexams->exam_status!='pass')
					{
					$data['Questionlist']=$this->questions_model->asstest_exam_question($year_id,1,$randquestion);
					}
					else
					{
						$data['Questionlist']='';
						$data['completed']=1;
					}
					//var_dump($data['Questionlist']);
					$this->load->view('frontend/private/assessmentplay',$data);
				}
			
			}
		/*---End Assessment Test -----*/
			/*---final year exam-----*/
			else if($subskill=="exam")
			{
				$this->session->set_userdata('ansattempt', '0');
				
			if($this->input->post('action')=='submitanswer')	
					{
					 $questionid=$this->input->post('questionid');
					 $answerid=$this->input->post('answerid');
					 $year_id=$this->input->post('year_id');
					 
					 $term_id=$this->input->post('term_id');
				
					
					$data["ques_dtl"] = $this->main_model->get_detail('manage_question_'.$year_id,'ques_id',$questionid);					
					
					$data["correct_ans"] = $this->main_model->get_detail('manage_answer_'.$year_id,'ans_id',$data["ques_dtl"]->ques_rightanswer);					
										
					if($data["ques_dtl"]->ques_rightanswer==$answerid)
					{
						
						$data['correct']=1;
						/*----insert user exam list---------*/
						$userid=$this->session->userdata('user_id');
						$createdate=date("Y-m-d H:i:s");
						$chkrow_exam=$this->questions_model->check_userexam($userid,$year_id,$term_id);	
						
						if($chkrow_exam->exam_id!="" )
						{
							$exam_id=$chkrow_exam->exam_id;
						}
						else
						{
							$user_exam=array(
									'user_id'=>$userid,
									'year_id'=>$year_id,
									'term_id'=>$term_id,													
									'exam_date'=>$createdate
									
									);
							$exam_id=$this->questions_model->Save_Userexam($user_exam);	
						}
						
						if($exam_id!="")
						{
							$uexam_history=array(
								'exam_id'=>$exam_id,
								'user_id'=>$userid,
								'year_id'=>$year_id,
								'term_id'=>$term_id,													
								'question_id'=>$questionid,
								'answer_id'=>$answerid,
								'answer_status'=>'false',
								
								);
							$historyexam_id=$this->questions_model->Save_Examhistory($uexam_history);		
						}
						
						/*----End of insert user exam list-------*/
						
										/*---check user not applied question list---*/
					$userexams=$this->questions_model->check_uexambyyear($userid,$year_id);
					if($userexams->exam_id!="" && $userexams->exam_status=='pending')
					{	
						$data['term_id']=$userexams->term_id;
					}
					else if($userexams->exam_id!="" && $userexams->exam_status=='pass')
					{	
						$data['term_id']=$userexams->term_id+1;
					}
					else
					{
						$data['term_id']=1;
					}
					
					/*----Get user exam question array------*/
					$exam_questermArr=array();
					$exam_questions=$this->questions_model->check_examhistory_question($userid,$year_id,$data['term_id']);
					if($exam_questions)
					{
						
						foreach($exam_questions as $examdata)
						{
							array_push($exam_questermArr,$examdata->question_id);
						}
					}
					
					
					/*----End of get user exam question array----*/
					$term_questermArr=array();
					$term_questions=$this->questions_model->term_exam($year_id,$data['term_id']);
					if($term_questions)
					{
						
						foreach($term_questions as $tquestion)
						{
							array_push($term_questermArr,$tquestion->question_id);
						}
						
					}
					$total_exam_question=count($exam_questermArr);
					$total_term_question=count($exam_questermArr);
					/*---update term by exam completed status----*/
					if($total_term_question==$total_exam_question)
					{
						$exam_status=array(
								'exam_status'=>'pass',							
								
								);
						
						$updateexam_status=$this->questions_model->Update_Examterm_status($exam_status,$exam_id);
					}
					/*---update term by exam completed status----*/
					$exam_output = array_merge(array_diff($term_questermArr, $exam_questermArr), array_diff($exam_questermArr, $term_questermArr));
					$exam_random=array_rand($exam_output);					
					$randquestion=$exam_output[$exam_random];
					/*---End of check user not applied question list---*/
					$data['Questionlist']=$this->questions_model->term_exam_question($year_id,$data['term_id'],$randquestion);
						//$data['Questionlist']=$this->questions_model->term_exam($year_id,1);
						$this->load->view('frontend/private/examplay',$data);

					}
					else
					{
			
						/*----insert user exam list---------*/
						$userid=$this->session->userdata('user_id');
						$createdate=date("Y-m-d H:i:s");
						$chkrow_exam=$this->questions_model->check_userexam($userid,$year_id,$term_id);	
						
						if($chkrow_exam->exam_id!="" )
						{
							$exam_id=$chkrow_exam->exam_id;
						}
						else
						{
							$user_exam=array(
									'user_id'=>$userid,
									'year_id'=>$year_id,
									'term_id'=>$term_id,													
									'exam_date'=>$createdate
									
									);
							$exam_id=$this->questions_model->Save_Userexam($user_exam);	
						}
						
						if($exam_id!="")
						{
							$uexam_history=array(
								'exam_id'=>$exam_id,
								'user_id'=>$userid,
								'year_id'=>$year_id,
								'term_id'=>$term_id,													
								'question_id'=>$questionid,
								'answer_id'=>$answerid,
								'answer_status'=>'true',
								
								);
							$hexam_id=$this->questions_model->Save_Examhistory($uexam_history);		
						}
						
								/*----Get user exam question array------*/
					$exam_questermArr=array();
					$exam_questions=$this->questions_model->check_examhistory_question($userid,$year_id,$term_id);
					if($exam_questions)
					{
						
						foreach($exam_questions as $examdata)
						{
							array_push($exam_questermArr,$examdata->question_id);
						}
					}
					
					
					/*----End of get user exam question array----*/
					$term_questermArr=array();
					$term_questions=$this->questions_model->term_exam($year_id,$term_id);
					if($term_questions)
					{
						
						foreach($term_questions as $tquestion)
						{
							array_push($term_questermArr,$tquestion->question_id);
						}
						
					}
					$total_exam_question=count($exam_questermArr);
					$total_term_question=count($exam_questermArr);
					/*---update term by exam completed status----*/
					if($total_term_question==$total_exam_question)
					{
						$exam_status=array(
								'exam_status'=>'pass',							
								
								);
						
						$updateexam_status=$this->questions_model->Update_Examterm_status($exam_status,$exam_id);
					}
					/*---update term by exam completed status----*/
						
						/*----End of insert user exam list-------*/
						$data["yourans"] = $this->main_model->get_detail('manage_answer_'.$year_id,'ans_id',$answerid);	
						$this->load->view('frontend/private/explanation',$data);
					}
					
								
					}
				else
				{
					$userid=$this->session->userdata('user_id');
					$this->session->set_userdata('ansattempt', '0');
					/*---check user not applied question list---*/
					$userexams=$this->questions_model->check_uexambyyear($userid,$year_id);
					$check_termexam_date=$this->questions_model->check_termexam_date($year_id);
					
					if($check_termexam_date->date!="0000-00-00 00:00:00")
					{	
						$cur_date=date("m/d/Y");
						$date=date("m/d/Y", strtotime($check_termexam_date->date));
						if($date==$cur_date){
						$data['term_id']=$check_termexam_date->term_id;
						
						}
						else{ $data['no_exam']=1;}
					}
					else
					{
						$data['no_exam']=1;
					}
					
					/*----Get user exam question array------*/
					$exam_questermArr=array();
					$exam_questions=$this->questions_model->check_examhistory_question($userid,$year_id,$data['term_id']);
					if($exam_questions)
					{
						
						foreach($exam_questions as $examdata)
						{
							array_push($exam_questermArr,$examdata->question_id);
						}
					}
					
					
					/*----End of get user exam question array----*/
					$term_questermArr=array();
					$term_questions=$this->questions_model->term_exam($year_id,$data['term_id']);
					if($term_questions)
					{
						
						foreach($term_questions as $tquestion)
						{
							array_push($term_questermArr,$tquestion->question_id);
						}
						
					}
					//var_dump($term_questermArr);
					
					$exam_output = array_merge(array_diff($term_questermArr, $exam_questermArr), array_diff($exam_questermArr, $term_questermArr));
					$exam_random=array_rand($exam_output);					
					$randquestion=$exam_output[$exam_random];
					/*---End of check user not applied question list---*/
					$data['Questionlist']=$this->questions_model->term_exam_question($year_id,$data['term_id'],$randquestion);
	
					$this->load->view('frontend/private/examplay',$data);
				}
			
			
			
			
			}
			/*---end final year exam-----*/
			else
			{	
				$this->session->unset_userdata('attempt');
				$this->session->unset_userdata('ansattempt');
			$data["skill_dtl"] =$this->main_model->get_skill('master_skill','skill_slug',$subskill,'skill_class',$year_id);		
			  $subskill_id=$data["skill_dtl"]->skill_id;
			$this->questions_model->CLASSID = $year_id;
				//$data["Questionlist"] = $this->questions_model->question_list_subskill($subskill_id);
		
				if($this->input->post('action')=='submitanswer')	
					{
					 $questionid=$this->input->post('questionid');
					 $answerid=$this->input->post('answerid');
				
					
					$data["ques_dtl"] = $this->main_model->get_detail('manage_question_'.$year_id,'ques_id',$questionid);
					//print_r($data["ques_dtl"]);
					
					$data["correct_ans"] = $this->main_model->get_detail('manage_answer_'.$year_id,'ans_id',$data["ques_dtl"]->ques_rightanswer);
					//print_r($data["correct_ans"]);
					//echo $data["correct_ans"]->ans_name;
										
					if($data["ques_dtl"]->ques_rightanswer==$answerid)
					{
						
					$data['correct']=1;
					$data["Questionlist"] = $this->questions_model->random_question($subskill_id);
					$this->load->view('frontend/private/play',$data);

					}
					else{
			
					$data["yourans"] = $this->main_model->get_detail('manage_answer_'.$year_id,'ans_id',$answerid);	
					$this->load->view('frontend/private/explanation',$data);
					}
					
								
					}
				else{
					$data["Questionlist"] = $this->questions_model->random_question($subskill_id);
					$this->load->view('frontend/private/play',$data);
					}
			
				}
			}
			else{
				
				if($this->session->userdata('user_id')!='' and $this->session->userdata('username')!='')
				{

				$data["SylList1"] = $this->syllabus_model->syllabus_list($year_id,1);
				$data["SylList2"] = $this->syllabus_model->syllabus_list($year_id,2);
				$data["SylList3"] = $this->syllabus_model->syllabus_list($year_id,3);
				$data["SylList4"] = $this->syllabus_model->syllabus_list($year_id,4);

				$this->load->view('frontend/private/kindergarten', $data);
				}
				else{
				$data["SylList1"] = $this->syllabus_model->syllabus_list($year_id,1);
				$data["SylList2"] = $this->syllabus_model->syllabus_list($year_id,2);
				$data["SylList3"] = $this->syllabus_model->syllabus_list($year_id,3);
				$data["SylList4"] = $this->syllabus_model->syllabus_list($year_id,4);
				

				$this->load->view('frontend/public/kg_wtht_login', $data);	
					
				}

			}
		
	}
	public function auckland() 
	{		
		$this->load->view('frontend/public/auckland');
	
	}
	public function tauranga() 
	{		
		$this->load->view('frontend/public/tauranga');
	
	}
	public function ourteam() 
	{		
		$this->load->view('frontend/public/our-team');
	
	}

	public function contactus() 
	{	
		$this->load->model('Contact_model');

		$this->form_validation->set_rules('fname', 'Please fill detail in first name', 'trim|required');
		$this->form_validation->set_rules('lname', 'Please fill detail in Last name', 'trim|required');
		$this->form_validation->set_rules('email', 'Please fill detail in Email', 'trim|required|valid_email');
		$this->form_validation->set_rules('msg', 'Please fill detail in Message box', 'required');
		if($this->form_validation->run() == false)
		{
			$this->load->view('frontend/public/contact-us');
		}
		else
		{
			$insert=$this->Contact_model->insert_data();
			if($insert)
			{
				$this->session->set_flashdata('msg','Your requst submitted');
				$to=contact_toemail;
				$from=basic_from_email;
				$sub=contact_subject;
				$data=array('Name' => $this->input->post('fname').' '.$this->input->post('lname'),
							'Email'  => $this->input->post('email'),
							'Message'  => $this->input->post('msg'),
 							);
				$msg='';
				$msg.='<table>';
				
				foreach ($data as $key => $value) 
				{
					$msg.='<tr><td>'.$key.'</td><td>'.$value.'</td></tr>';

				}
				$msg.='</table>';
				
				$this->email($to,$from,$sub,$msg);
				redirect($_SERVER['http_FERERER']);

			}else{
				$this->session->set_flashdata('msg','Your requst not submitted');
				redirect($_SERVER['http_FERERER']);
			}

		}
	
	}
	public function noticeboard() 
	{		
		$this->load->view('frontend/private/notice-board');
	
	}
	public function helpcenter() 
	{		
		$this->load->view('frontend/public/help-center');
	
	}
	public function faqs() 
	{		
		$this->load->view('frontend/public/faqs');
	
	}
	public function termconditions() 
	{		
		$this->load->view('frontend/public/term-conditions');
	
	}
	public function privacypolicy() 
	{		
		$this->load->view('frontend/public/privacy-policy');
	
	}
	public function disclaimer() 
	{		
		$this->load->view('frontend/public/disclaimer');
	
	}
	public function testimonial() 
	{		
		$this->load->view('frontend/public/testimonial');
	
	}


	public function doupload($path,$type,$filename)
     {
         
        $config = array(
        'upload_path' => $path,
        'allowed_types' => $type,
        'overwrite' => TRUE,
        'max_size' => "2048000", 
        'max_height' => "768",
        'max_width' => "1024"
        );
        $this->load->library('upload', $config);
        if(!$this->upload->do_upload($filename))
        { 
            $data['imageError'] =  $this->upload->display_errors();
            $data=array('success'=>false,'$msg'=>$data['imageError']);

        }
        else
        {
            $imageDetailArray = $this->upload->data();
            $image =  $imageDetailArray['file_name'];
            $data=array('success'=>true,'$msg'=>'file upload successfully' ,'file_name'=>$image);
        }
        return $data;
     }	
	public function becomeaninstructor() 
	{

		$this->load->model('Contact_model');
		$this->form_validation->set_rules('fname', 'Please fill detail in first name', 'trim|required');
		$this->form_validation->set_rules('lname', 'Please fill detail in Last name', 'trim|required');
		$this->form_validation->set_rules('email', 'Please fill detail in Email', 'trim|required|valid_email');
		$this->form_validation->set_rules('exp_yr', 'Please select Total Work Experience year', 'required');
		$this->form_validation->set_rules('exp_mn', 'Please select Total Work Experience year', 'required');
		$this->form_validation->set_rules('job_title', 'Please select job title', 'required');
		$this->form_validation->set_rules('phone', 'Please fill detail in phone input box', 'required');
		$this->form_validation->set_rules('state', 'Please select job state', 'required');
		$this->form_validation->set_rules('city', 'Please select job state', 'required');
		if($this->form_validation->run() == false)
		{
			$this->load->view('frontend/public/become-an-instructor');
		}
		else
		{	
			$path="assets/uploads/resume/";
			$type='pdf|docs|docs';
		    $upload=$this->doupload($path,$type,'resume');
		    if($upload['success'])
		    {
		    	$insert=$this->Contact_model->becomeaninstructor_insert($upload['file_name']);
		    	if($insert)
		    	{
		    		$to=becomeinstruct_toemail;
					$from=basic_from_email;
					$sub=becomeinstruct_subject;
					$data=array('Name' 			=> 	$this->input->post('fname').' '.$this->input->post('lname'),
								'Email'  		=> 	$this->input->post('email'),
								'Experience'	=> 	$this->input->post('exp_yr').' Year and '. $this->input->post('exp_mn').' Month ',
								'Job title'		=> 	$this->input->post('job_title'),
								'Email'  		=> 	$this->input->post('email'),
								'Phone'  		=> 	$this->input->post('phone'),
								'State' 		=>	$this->input->post('state'),
								'city' 			=> 	$this->input->post('city'),
								'resume'  		=>	'<a href="'.base_url('/'.$path.$upload['file_name']).'">View Resume</a>',
	 							);
					$msg='';
					$msg.='<table>';
					foreach ($data as $key => $value) 
					{
						$msg.='<tr><td>'.$key.'</td><td>'.$value.'</td></tr>';
					}
					$msg.='</table>';
					$this->email($to,$from,$sub,$msg,$file=base_url('/'.$path.$upload['file_name']));
		    		$this->session->set_flashdata('msg','resume upload successfully');
					redirect($_SERVER['HTTP_REFERER']);
		    	}
		    	else
		    	{

			    	$this->session->set_flashdata('msg','Please Try after some time');
			    	redirect($_SERVER['HTTP_REFERER']);	
		    	}
		    }
		    else
		    {
		    	$this->session->set_flashdata('msg','Please Try after some time');
		    	redirect($_SERVER['HTTP_REFERER']);
		    }

		}
	
	}
	public function becomeanaffiliate() 
	{		
		$this->load->view('frontend/public/become-an-affiliate');
	
	}
	
	public function single_post($event) 
	{	
		$data['event']=$event;
		$this->load->view('frontend/public/single-post',$data);
	
	}
	
	public function random_password() 
	{
		$alphabet = 'abcdefghijkmnopqrstuvwxyzABCDEFGHJKLMNOPQRSTUVWXYZ1234567890';
		$password = array(); 
		$alpha_length = strlen($alphabet) - 1; 
		for ($i = 0; $i < 8; $i++) 
		{
			$n = rand(0, $alpha_length);
			$password[] = $alphabet[$n];
		}
		return implode($password); 
	}
	

	public function registered() 
	{	
		$data['regthank']='';
		$this->load->view('frontend/public/thanks-signup',$data);
	
	}		
	
	
	public function play($subskill_id) 
	{
		$year_id=1;
		$this->questions_model->CLASSID = $year_id;
		//$data["Questionlist"] = $this->questions_model->question_list_subskill($subskill_id);
		
		if($this->input->post('action')=='submitanswer')	
				{
					 $questionid=$this->input->post('questionid');
					 $answerid=$this->input->post('answerid');
				
					
					$data["ques_dtl"] = $this->main_model->get_detail('manage_question_'.$year_id,'ques_id',$questionid);
					//print_r($data["ques_dtl"]);
					
					$data["correct_ans"] = $this->main_model->get_detail('manage_answer_'.$year_id,'ans_id',$data["ques_dtl"]->ques_rightanswer);
					//print_r($data["correct_ans"]);
					//echo $data["correct_ans"]->ans_name;
										
					if($data["ques_dtl"]->ques_rightanswer==$answerid)
					{
						
					$data['correct']=1;
					$data["Questionlist"] = $this->questions_model->random_question($subskill_id);
					$this->load->view('frontend/private/play',$data);

					}
					else{
			
					$data["yourans"] = $this->main_model->get_detail('manage_answer_'.$year_id,'ans_id',$answerid);	
					$this->load->view('frontend/private/explanation',$data);
					}
					
								
				}
				else{
					$data["Questionlist"] = $this->questions_model->random_question($subskill_id);
					$this->load->view('frontend/private/play',$data);
				}
	
	}

	public function mynoticeboard() 
	{		
		if($this->session->userdata('username')!='')
		{	
			if($user_id=$this->session->userdata('user_type')=='1'){
			
				redirect(BASE_URL_ADMIN);
			};

			
			$user_id=$this->session->userdata('user_id');
			$yearid=$this->session->userdata('loginyear');
			$yeardata=$this->classes_model->classes_details($yearid);
			if($yeardata)
			{
				$data['year_name']=$yeardata[0]->class_name;
				$data['year_slug']=$yeardata[0]->class_slug;
			}
			$data['aatcount']=$this->exam_model->checkuser_aat_status($yearid,$user_id);
			
			$this->load->view('frontend/private/my-notice-board',$data);
		}
		else
		{
			redirect(base_url().'login');
		}
	
	}

	
	public function changepassword() 
	{		
		
		if(!$this->session->userdata('username'))
		{
			redirect(base_url().'login');
		}
		$this->form_validation->set_rules('currentpassword', 'Current Password', 'required');
		$this->form_validation->set_rules('password', 'New Password', 'required');
		$this->form_validation->set_rules('cpassword', 'Confirm Password', 'required');
		
		if($this->form_validation->run())
		{
			$currentpassword =$this->input->post('currentpassword');
			$password = $this->input->post('password');
			$cpassword = $this->input->post('cpassword');
			
			
				$data=array('val'=>'',
						'table'=>'user_details',
						'where'=>array('user_id'=>$this->session->userdata('user_id'),'password'=>md5($currentpassword))
						);
			$res=$this->Login_model->signin($data);			
			
			if ($res['res']) 
			{	
				if ($password==$cpassword) 
				{
				
				
					$user_data=array(							
								'password'=>md5($password)						
								
								);	
					$userid=$this->User_model->Save_Password($user_data,$this->session->userdata('user_id'));
					$data1['fullname']=$this->session->userdata('fullname');
				
					$data1['password']=$password;
					
					$this->load->library('email');
					$config = array (
					'mailtype' => 'html',
					'charset' => 'utf-8',
					'priority' => '1'
					);
					$this->email->initialize($config);
					
					$senderemail=$this->session->userdata('email');
				
					$body = $this->load->view('emails/changepassword',$data1,TRUE);
					$this->email->from(basic_from_email, basic_from_name);
					$this->email->to($senderemail);
					$this->email->subject(passwordreset_subject);
					$this->email->message($body);
					$this->email->send();				
					
					$data['success']='Your password has been changed successfully';
				
					
									
				} 
				else
				{
					$data['error']='Sorry your password did not match. <br/>Please try again.';
					
				}
			}
			else
			{
				$data['error']='Sorry your current password did not match. <br/>Please try again.';
			}
		}
		else
		{
			$data['error']='';
		}
		
		
		$this->load->view('frontend/private/changepassword',$data);
	
	}
		
	
	public function thisweekclassroomexercise($subskill='') 
	{		
		
				
		if($this->session->userdata('username')!='')
		{		
			$yearid=$this->session->userdata('loginyear');
			$user_id=$this->session->userdata('user_id');
			$data['year_id']=$yearid;
			$data['aatcount']=$this->exam_model->checkuser_aat_status($yearid,$user_id);
			/*---home play exercise-----*/
			
			
			
			if($subskill!="")
			{	
			
			
			
			$yearid=$this->session->userdata('loginyear');
			$user_id=$this->session->userdata('user_id');
			$data['year_id']=$yearid;
			$data["year_dtl"] = $this->main_model->get_detail('master_class','class_id',$yearid);	
			$data['subskill']=$subskill;
			
		
				
			$this->session->unset_userdata('attempt');
			$this->session->unset_userdata('ansattempt');
			$this->session->unset_userdata('testagain');
			$data["skill_dtl"] =$this->main_model->get_skill('master_skill','skill_slug',$subskill,'skill_class',$yearid);		
			$subskill_id=$data["skill_dtl"]->skill_id;
			$data['skill_id']=$subskill_id;
			$this->questions_model->CLASSID = $yearid;
				//$data["Questionlist"] = $this->questions_model->question_list_subskill($subskill_id);
				/*---reset home work score is less than 80%---*/
			
				/*-----reset home work score is less than 80%---*/
		
				   //$this->session->set_userdata('attempt_ques_offset', 0);
					$sqlchk_examlast=$this->db->query("select exam_id,exam_status from student_classexcerise  where user_id='".$this->session->userdata('user_id')."' and skill_id='".$subskill_id."' 
							and year_id='".$yearid."' and exam_status='pending'  order by exam_id desc");
					$row_chkexam_id=$sqlchk_examlast->row();
					$lastexam_id=$row_chkexam_id->exam_id;
					$data['lastexam']=$lastexam_id;
					$lastexam_status=$row_chkexam_id->exam_status;
					$data['lastexam_status']=$lastexam_status;
					if($_REQUEST['again']=='1')
					{
						$testagain = $this->session->userdata('testagain');
						$testagain++;
						$this->session->set_userdata('testagain', $testagain);
						$user_id1=$this->session->userdata('user_id');	
					$data["Questionlist"] = $this->recursive_randomclass($subskill_id,$user_id1,$year_id);
					$data['ctest_completed']=0;
					}
					else
					{
					
					
				if($lastexam_id!='')
				{					
					$sqlattques1=$this->db->query("select count(hid) as totalattentquestion from student_classexcerise_history  where user_id='".$this->session->userdata('user_id')."' and skill_id='".$subskill_id."' 
							and year_id='".$yearid."' and exam_id='".$lastexam_id."' ");
					$row_attendq1=$sqlattques1->row();
					$totalattent1=$row_attendq1->totalattentquestion;
					
					
					
					if($totalattent1 <= 19)
					{
					$user_id1=$this->session->userdata('user_id');	
					$data["Questionlist"] = $this->recursive_randomclass($subskill_id,$user_id1,$year_id);
					$data['ctest_completed']=0;
					}
					else
					{
						$data["Questionlist"] = '';
						$data['ctest_completed']=1;
					}
				}
				else
				{
					$user_id1=$this->session->userdata('user_id');	
					$data["Questionlist"] = $this->recursive_randomclass($subskill_id,$user_id1,$year_id);
					$data['ctest_completed']=0;
				}
					}
					
					$this->load->view('frontend/private/class_exercise',$data);
					
			
			
			
			}
			/*----end of home work play exercise----*/
			else
			{
			$yeardata=$this->classes_model->classes_details($yearid);
			if($yeardata)
			{
				$data['year_name']=$yeardata[0]->class_name;
				$data['year_slug']=$yeardata[0]->class_slug;
				$year_date=$yeardata[0]->year_date;
				
			}
			
			 /*----get current term of  user year----*/
			 $term_query=$this->db->query('select * from yearterm_date where year_id = "'.$yearid.'" and CURDATE() >=term_date order by term_date desc'); 
			 
			 $num_termdate=$term_query->num_rows();
		
			if($num_termdate > 0)
			{
			$row_termdate=$term_query->row();
			$term_id=$row_termdate->term_id;
			$data['term_id']=$term_id;
			/*----Check user current week status----*/
			 
			 	$current_term=$row_termdate->term_id;
				$termdate=date('m/d/Y',strtotime($row_termdate->term_date));
				$currentdate=date('m/d/Y');
				if($termdate==$currentdate)
				{
					$currentweek=1;
				}
				else
				{					
					$currentweek=$this->week_between_two_dates($termdate,$currentdate);
					$currentweek=$currentweek+1;
				
				}
				 $data['userweek']=$currentweek;
			
			 		/*----Student Current year Active Weeks with Order Paymemt-----*/
				$query_ord=$this->db->query("select plan_id,order_date,order_week,order_totalweek from orders where userid = '".$this->session->userdata('user_id')."' and year_id = '".$yearid."' and order_status='active' and pay_status='confirm' order by orderid desc"); 
				$num_ord= $query_ord->num_rows();
				if($num_ord > 0)
				{	
					$row_ord= $query_ord->row();
					//echo $row_ord->order_date;
					$order_week=$row_ord->order_totalweek;
					$userdays=$order_week*7;
					$order_date = strtotime($row_ord->order_date);
					$order_date1 = strtotime("+".$userdays." day", $order_date);
					$expiry_date= date('Y/m/d', $order_date1);
					$todate=date('Y/m/d');
					if(strtotime($expiry_date) >= strtotime($todate))
					{
						$data['planactive']='yes';
					}
					else
					{
						$data['planactive']='no';
					}	
				
					$data['nobuyplan']='0';
					
				}
				else
				{
					$order_week=0;
					$data['nobuyplan']='1';
				}
		
		/*----End of Student Current year Active Weeks with Order Paymemt-----*/
		
		
			
			
			}
			else
			{
			$current_term='0';	
			}
			/*----end of current term of user year----*/
			
			//$data["SylList1"] = $this->syllabus_model->syllabus_list($yearid,$current_term);

			 $data["SylList1"] = $this->main_model->get_selected_details('syllabus_week_subskill',$columns=array('skill_id','subskill_id','week_id','subskill_order','goal_id'),$where=array('year_id'=>$yearid,'week_id'=> $currentweek , 'term_id'=>$term_id),'multiple',$obj=true);
			$this->load->view('frontend/private/this-week-classroom-exercise',$data);
			}
		}
		else
		{
			redirect(base_url().'login');
		}
	}
	
	

	public function homeworkexercise($subskill='') 
	{
				
		if($this->session->userdata('username')!='')
		{		
			$yearid=$this->session->userdata('loginyear');
			$user_id=$this->session->userdata('user_id');
			$data['year_id']=$yearid;
			$data['aatcount']=$this->exam_model->checkuser_aat_status($yearid,$user_id);
			/*---home play exercise-----*/
			if($subskill!="")
			{	
			
			
			
			$yearid=$this->session->userdata('loginyear');
			$user_id=$this->session->userdata('user_id');
			$data['year_id']=$yearid;
			$data["year_dtl"] = $this->main_model->get_detail('master_class','class_id',$yearid);	
			$data['subskill']=$subskill;
			
		
				
			$this->session->unset_userdata('attempt');
			$this->session->unset_userdata('ansattempt');
			$this->session->unset_userdata('testagain');
			$data["skill_dtl"] =$this->main_model->get_skill('master_skill','skill_slug',$subskill,'skill_class',$yearid);		
			 $subskill_id=$data["skill_dtl"]->skill_id;
			 $data['skill_id']=$subskill_id;
			 $this->questions_model->CLASSID = $yearid;
				//$data["Questionlist"] = $this->questions_model->question_list_subskill($subskill_id);
				/*---reset home work score is less than 80%---*/
			if($_REQUEST['reh']=='1')
			{
			
				/*$del_hwhistory=$this->db->query("delete  from student_home_history  where year_id='".$yearid."' and user_id='".$this->session->userdata('user_id')."' 
							and skill_id='".$subskill_id."'");
				$del_hwmasterhistory=$this->db->query("delete  from student_homeworktest  where year_id='".$yearid."' and user_id='".$this->session->userdata('user_id')."' 
							 and skill_id='".$subskill_id."'");	
					$data['err_reload']=1;	
					$this->session->unset_userdata('attempt');
					$this->session->unset_userdata('ansattempt');
					redirect(base_url().'homework/'.$subskill);
					*/
					
			}
				/*-----reset home work score is less than 80%---*/
		           
				   //$this->session->set_userdata('attempt_ques_offset', 0);
					$sqlchk_examlast=$this->db->query("select exam_id,exam_status from student_homeworktest  where user_id='".$this->session->userdata('user_id')."' and skill_id='".$subskill_id."' 
							and year_id='".$yearid."'  order by exam_id desc ");
					$row_chkexam_id=$sqlchk_examlast->row();
					$lastexam_id=$row_chkexam_id->exam_id;
					$data['lastexam']=$lastexam_id;
					$lastexam_status=$row_chkexam_id->exam_status;
					$data['lastexam_status']=$lastexam_status;
					if($_REQUEST['again']=='1')
					{
						$testagain = $this->session->userdata('testagain');
						$testagain++;
						$this->session->set_userdata('testagain', $testagain);
						$user_id1=$this->session->userdata('user_id');	
					$data["Questionlist"] = $this->recursive_random1($subskill_id,$user_id1,$year_id);
					$data['ctest_completed']=0;
					}
					else
					{
					
					
				if($lastexam_id!='')
				{					
					$sqlattques1=$this->db->query("select count(hid) as totalattentquestion from student_home_history  where user_id='".$this->session->userdata('user_id')."' and skill_id='".$subskill_id."' 
							and year_id='".$yearid."' and exam_id='".$lastexam_id."' ");
					$row_attendq1=$sqlattques1->row();
					$totalattent1=$row_attendq1->totalattentquestion;
					
					
					
					if($totalattent1 <= 19)
					{
					$user_id1=$this->session->userdata('user_id');	
					$data["Questionlist"] = $this->recursive_random1($subskill_id,$user_id1,$year_id);
					$data['ctest_completed']=0;
					}
					else
					{
						$data["Questionlist"] = '';
						$data['ctest_completed']=1;
					}
				}
				else
				{
					$user_id1=$this->session->userdata('user_id');	
					$data["Questionlist"] = $this->recursive_random1($subskill_id,$user_id1,$year_id);
					$data['ctest_completed']=0;
				}
					}
					
					$this->load->view('frontend/private/play-homework',$data);
					
			
			
			
			}
			/*----end of home work play exercise----*/
			else
			{
			$yeardata=$this->classes_model->classes_details($yearid);
			if($yeardata)
			{
				$data['year_name']=$yeardata[0]->class_name;
				$data['year_slug']=$yeardata[0]->class_slug;
				$year_date=$yeardata[0]->year_date;
				
			}
			
			 /*----get current term of  user year----*/
			 $term_query=$this->db->query('select * from yearterm_date where year_id = "'.$yearid.'" and CURDATE() >= term_date order by term_date desc'); 
			
			$num_termdate=$term_query->num_rows();
			if($num_termdate > 0)
			{	
			$row_termdate=$term_query->row();
		
			/*----Check user current week status----*/
			 
			 	$current_term=$row_termdate->term_id;
				$data['term_id']=$current_term;
				
				$termdate=date('m/d/Y',strtotime($row_termdate->term_date));
				$currentdate=date('m/d/Y');
				if($termdate==$currentdate)
				{
					$currentweek=1;
				}
				else
				{					
					$currentweek=$this->week_between_two_dates($termdate, $currentdate);
					$currentweek=$currentweek+1;
				
				}
				$data['userweek']=$currentweek;
			
			 		/*----Student Current year Active Weeks with Order Paymemt-----*/
				$query_ord=$this->db->query("select plan_id,order_date,order_week from orders where userid = '".$this->session->userdata('user_id')."' and year_id = '".$yearid."' and order_status='active' and pay_status='confirm' order by orderid desc"); 
				$num_ord= $query_ord->num_rows();
				if($num_ord > 0)
				{	
					$row_ord= $query_ord->row();
					//echo $row_ord->order_date;
					$order_week=$row_ord->order_week;
					$userdays=$order_week*7;
					$order_date = strtotime($row_ord->order_date);
					$order_date1 = strtotime("+".$userdays." day", $order_date);
					$expiry_date= date('Y/m/d', $order_date1);
					$todate=date('Y/m/d');
					if(strtotime($expiry_date) >= strtotime($todate))
					{
						$data['planactive']='yes';
					}
					else
					{
						$data['planactive']='no';
					}	
				
					$data['nobuyplan']='0';
					
				}
				else
				{
					$order_week=0;
					$data['nobuyplan']='1';
				}
		
		/*----End of Student Current year Active Weeks with Order Paymemt-----*/
		
		
			
			
			}
			else
			{
			$current_term='0';	
			}
			/*----end of current term of user year----*/
			
			
			$ho_week_qry=$this->db->query("select * from student_classexcerise where user_id='".$user_id."' and year_id='".$yearid."' and term_id='".$row_termdate->term_id."' group by week_id order by exam_id desc LIMIT 2");
			$ho_week_res=$ho_week_qry->result();
			$ho_week_arr=array();
			foreach($ho_week_res as $ho_week_ress){
				$ho_week_arr[]=$ho_week_ress->week_id;
			}
			
			if(count($ho_week_arr)>0){
				$data['homework']=1;
			}
			else{
				$data['homework']=0;
			}
				
				
			$weeklist=implode(',',$ho_week_arr);
			$data['weeklist']=$weeklist;
			
				$preweek=$currentweek-1;
				$nextweek=$currentweek+1;
				//$data['weeklist']="'".$preweek."','".$currentweek."'";
				$sql_syllist=$this->db->query("select * from syllabus_week_subskill where week_id IN('".$weeklist."') and term_id='".$current_term."' and year_id='".$yearid."' GROUP BY skill_id");
				$data["SylList1"]=$sql_syllist->result();
			
			 
			
			
			$this->load->view('frontend/private/homework-exercise',$data);
			}
		}
		else
		{
			redirect(base_url().'login');
		}
	}
	
	
	public function recursive_random1($subskill_id='',$userid='',$year_id='')
	{
		$Questionlist = $this->questions_model->random_question($subskill_id);
		foreach($Questionlist as $hquestion)
		{
						$current_question=$hquestion->ques_id;
		}
						$exam_questermArr=array();
						$exam_questions=$this->questions_model->check_homehistory_question($userid,$year_id,$subskill_id);
						
							if($exam_questions)
							{
								
								foreach($exam_questions as $examdata)
								{
									array_push($exam_questermArr,$examdata->question_id);
								}
								
								if(in_array($current_question,$exam_questermArr))
								{
									return $this->recursive_random($subskill_id,$userid,$year_id);
								}
								else
								{
									return $Questionlist;
								}	
							}
							else
							{
								return $Questionlist;
							}
	}
	
	public function recursive_randomclass($subskill_id='',$userid='',$year_id='')
	{
		$Questionlist = $this->questions_model->random_question($subskill_id);
		foreach($Questionlist as $hquestion)
		{
						$current_question=$hquestion->ques_id;
		}
						$exam_questermArr=array();
						$exam_questions=$this->questions_model->check_classexchistory_question($userid,$year_id,$subskill_id);
						
							if($exam_questions)
							{
								
								foreach($exam_questions as $examdata)
								{
									array_push($exam_questermArr,$examdata->question_id);
								}
								
								if(in_array($current_question,$exam_questermArr))
								{
									return $this->recursive_randomclass($subskill_id,$userid,$year_id);
								}
								else
								{
									return $Questionlist;
								}	
							}
							else
							{
								return $Questionlist;
							}
	}
	public function studentexamgrade() 
	{		
		if($this->session->userdata('username')!='')
		{		
			$yearid=$this->session->userdata('loginyear');
			$user_id=$this->session->userdata('user_id');
			$data['year_id']=$yearid;
			$data['user_id']=$user_id;
			$data['aatcount']=$this->exam_model->checkuser_aat_status($yearid,$user_id);
			$yeardata=$this->classes_model->classes_details($yearid);
			if($yeardata)
			{
				$data['year_name']=$yeardata[0]->class_name;
				$data['year_slug']=$yeardata[0]->class_slug;
				
				$data['examterm_list']=$this->students_model->student_exambyterm($yearid);
				
			}
			$this->load->view('frontend/private/student-exam-grade',$data);
		}
		else
		{
			redirect(base_url().'login');
		}
	
	}

	public function studentexamsheet() 
	{		
		if($this->session->userdata('username')!='')
		{		
			$yearid=$this->session->userdata('loginyear');
			$user_id=$this->session->userdata('user_id');
			$data['year_id']=$yearid;
			$data['user_id']=$user_id;
			$data['aatcount']=$this->exam_model->checkuser_aat_status($yearid,$user_id);
			$data['exam_details']=$this->students_model->exam_details();
			$this->load->view('frontend/private/yearly-report',$data);
		}
		else
		{
			redirect(base_url().'login');
		}
	
	}
	public function membership_plans() 
	{		
		if($this->session->userdata('username')!='')
		{		
			
			$yearid=$this->session->userdata('loginyear');
			$data['year_id']=$yearid;
			$userid=$this->session->userdata('user_id');
			$data['user_id']=$userid;	
			$yeardata=$this->classes_model->classes_details($yearid);
			$payyear=$yearid;
				
			$query_chkord=$this->db->query("select * from orders  where userid='".$userid."' and pay_status='confirm' and order_status='active' and year_id='".$payyear."' order by  orderid desc");
			$num_chkord=$query_chkord->num_rows();
			$data['num_chkord']=$num_chkord;
			$data['payyear']=$payyear;
			 
			 
			 
			 
			$chk_sch=$this->main_model->getall('class_schedule','year_id',$payyear);
			if($chk_sch){
				$data['class_schedule']=1;
				$data['center_list']=$this->center_model->available_center_dropdown($payyear);
			}
			else{
				$data['class_schedule']=0;
			}
			 
			 
			if($yeardata)
			{
				$data['year_name']=$yeardata[0]->class_name;
				$data['year_slug']=$yeardata[0]->class_slug;
			}
			 
				
			$data['aatcount']=$this->exam_model->checkuser_aat_status($yearid,$userid);			
			$config["per_page"] = 100;	
			$page = ($_REQUEST['page']) ? $_REQUEST['page'] : 0;	
				
			$data["planlist"] = $this->plan_model->plan_list($config["per_page"],$page);
			
			// Check term date
			$whr='year_id="'.$payyear.'" and term_id=1';
			$row_termdate=$this->main_model->get_where_row_latest('yearterm_date',$whr);  

			
			/*----Check user current week status----*/
			if($row_termdate){
				$termdate=date('m/d/Y',strtotime($row_termdate->term_date));
				$currentdate=date('m/d/Y');
				if($termdate==$currentdate)
				{
					$currentweek=1;
				}
				else
				{					
					$currentweek=$this->week_between_two_dates($termdate,$currentdate);
					$currentweek=$currentweek+1;
				
				}
			}
			else{
				$currentweek=1;
			}
			$data['userweek']=$currentweek;  
						
			
			$this->load->view('frontend/private/membership-plan',$data);
		}
		else
		{
			redirect(base_url().'login');
		}
	
	}


	public function paynow_old($id="") 
	{		
		if($this->session->userdata('username')!='')
		{		
			
			/*-----send order to paypal-----*/
			if($id!="" && $id!=null)
			{
				$plandata=$this->plan_model->plan_details($id);
				if($plandata)
				{
						$userid=$this->session->userdata('user_id');
						$planinfo=$plandata[0];
						$data["plandetail"]=$plandata[0];
						$year=$this->uri->segment(3);
						$year=$this->session->userdata('loginyear');
					
						$query_chkpro=$this->db->query("select * from student_promoted  where user_id='".$userid."' and pay_status='pending' order by  pid desc ");
						$num_chkpro=$query_chkpro->num_rows();
						if($num_chkpro > 0)
						{
							$yearchk=$query_chkpro->row();
							$centerid=$yearchk->center_id;
						}
						else
						{
							$query_user=$this->db->query("select center_id from user_details  where user_id='".$userid."'  ");
							$yearchk=$query_user->row();
							$centerid=$yearchk->center_id;
						}
						$createdate=date("Y-m-d H:i:s");
						$ord_data=array(
							'userid'=>$userid,
							'year_id'=>$year,
							'center_id'=>$centerid,
							'plan_id'=>$id,
							'amount'=>$planinfo->plan_price,
							'order_status'=>'inactive',
							'pay_status'=>'pending',
							'order_week'=>$planinfo->plan_week,
							'order_date'=>$createdate,
							);
						$orderid=$this->order_model->Save_Order($ord_data);	
						$data["orderid"]=$orderid;	
					
					
				}
			}
			else
			{
				redirect(base_url().'membership-plan');
			}
			/*-----end of order send to paypal----*/
			
			
				
				
			//$data["planlist"] = $this->plan_model->plan_list($config["per_page"],$page);				
			
			$this->load->view('frontend/private/paynow',$data);
		}
		else
		{
			redirect(base_url().'login');
		}
	
	}
	
	public function paynow($id="") 
	{		
		if($this->session->userdata('username')!='')
		{		
			
			//var_dump($this->input->post());
			$id=$this->input->post('planid');
			 $pertermweek=$this->input->post('week_id');
			 $day=$this->input->post('sel_day');
			  $sel_time=$this->input->post('sel_time');
			 $center_id=$this->input->post('reg_center');
			$current_date_time=date('Y-m-d H:i:s');	
			
		
        //if($pertermweek!="" && $day!="" && $sel_time!="" && $center_id!="")
			if($pertermweek!="" )
			{
				
			/*-----send order to paypal-----*/
				
			if($pertermweek)
			{
				
				
				$plandata=$this->plan_model->plan_details($id);
				if($plandata)
				{
						$userid=$this->session->userdata('user_id');
						$planinfo=$plandata[0];
						$data["plandetail"]=$plandata[0];
						$year=$this->input->post('payyear');
						 
						//$year=$this->session->userdata('loginyear');
					
						$query_chkpro=$this->db->query("select * from student_promoted  where user_id='".$userid."' and pay_status='pending' order by  pid desc ");
						$num_chkpro=$query_chkpro->num_rows();
						if($num_chkpro > 0)
						{
							$yearchk=$query_chkpro->row();
							$centerid=$yearchk->center_id;
						}
						else
						{
							$query_user=$this->db->query("select center_id from user_details  where user_id='".$userid."'  ");
							$yearchk=$query_user->row();
							$centerid=$yearchk->center_id;
						}
						$createdate=date("Y-m-d H:i:s");
						$ord_data=array(
							'userid'=>$userid,
							'year_id'=>$year,
							//'center_id'=>$center_id,
                            'center_id'=>null,
							'plan_id'=>$id,							
							'order_status'=>'inactive',
							'pay_status'=>'pending',
							'order_week'=>$planinfo->plan_week,														
							'order_date'=>$createdate,
							);
						 $orderid=$this->order_model->Save_Order($ord_data);	
						/*-----insert per order weeks----*/
						
					
					foreach($pertermweek as $key=>$value)
					{
						
						//array_push($termArr,$key);
						$countweek=1;	
						foreach($value as $weekdata)
						{
							if($weekdata!='')
							{	
							$ord_weeks=array(
									'ordweek_orderid'=>$orderid,
									'ordweek_userid'=>$userid,
									'ordweek_yearid'=>$year,
									'ordweek_termid'=>$key,
									'ordweek_weekid'=>$weekdata,
									'ordweek_paystatus'=>'pending',
									'ordweek_date'=>$createdate
									);
								$orderweekid=$this->order_model->Save_OrderWeeks($ord_weeks);
								$countweek++;
								
							//Temperory book seat

							  $whr="where year_id='".$year."' and center_id='".$center_id."' and day='".$day."' and time='".$sel_time."'";
								$qry_room_lists=$this->db->query("select * from class_schedule ".$whr."");
								$row_room_listss=$qry_room_lists->result();

							/*if($row_room_listss){
								
								foreach($row_room_listss as $row_room_list){
														
								$whr="class_schdl_id='".$row_room_list->id."' and room_no='".$row_room_list->room_no."' and term_id='".$key."' and week_id='".$weekdata."'";
								$row_room_lists=$this->main_model->get_where_row("classroom_booking",$whr);
								if($row_room_lists){

								if(($row_room_lists->room_available>0) && (strtotime($row_room_lists->class_schdl_date)>strtotime($current_date_time)))
								{
									
								$tmpbookroominfo=array(
										'class_r_b_id'=>$row_room_lists->id,
										'order_id'=>$orderid,
										'date'=>date('Y-m-d'),
										'user_id'=>$userid
										);
								$updatebookroom=$this->main_model->Save('temp_class_booking',$tmpbookroominfo);
								}
								else{
								$this->session->set_flashdata('success_msg', 'No seat available or class of selected week has been over');
									redirect(base_url().'membership-plan');	
									
								}



								}
								else{
								$this->session->set_flashdata('success_msg', 'No seat available or class of selected week has been over');
									redirect(base_url().'membership-plan');	
									
								}
								
								
								
								}	
								
							}
							else{
								$this->session->set_flashdata('success_msg', 'No seat available or class of selected week has been over');
									redirect(base_url().'membership-plan');	
									
							}*/
							}
						}
						
					
				
						/*-----end of insert order per weeks---*/
						$queryweeks=$this->db->query('select count(*) as "totalweek" from order_weeks where ordweek_orderid="'.$orderid.'" ');
						$resweeks=$queryweeks->row();
						$totalweek= $resweeks->totalweek;
						if($totalweek!='')
						{	
						
						
						$amount_without_gst=$planinfo->plan_price*$totalweek;
						$gst=$amount_without_gst*15/100;
						$totalamount=$amount_without_gst+$gst;
						$totalamount=round($totalamount,2);
						
						$uord_data=array(						
						
							'amount_without_gst'=>$amount_without_gst,
							'amount_gst'=>$gst,
							'amount'=>$totalamount,
							'order_totalweek'=>$totalweek
							);
						$orderid2=$this->order_model->Update_Order($uord_data,$orderid);
						
						
						
						
						$data["totalamount"]=$totalamount;
                        //$data["totalamount"]=25;	
						}
						else
						{
							$del_oitem=$this->db->query("delete from order_weeks where ordweek_orderid='".$orderid."'" );
							$del_order=$this->db->query("delete from orders where orderid='".$orderid."'" );
							$this->session->set_flashdata('error','Select any one week of plan');
							redirect(base_url().'membership-plan');
						}
						
						$data["orderid"]=$orderid;	
					
					
				}
			}
			else
			{
				redirect(base_url().'membership-plan');
			}
			/*-----end of order send to paypal----*/
			
			
				
				
			//$data["planlist"] = $this->plan_model->plan_list($config["per_page"],$page);				
			
			$this->load->view('frontend/private/paynow',$data);
			}
			}
			else{
				$this->session->set_flashdata('success_msg', 'Please select all fields');
				redirect(base_url().'membership-plan');
			}
		
		
		
		
		}else
		{
			redirect(base_url().'login');
		}
	
	} 
	public function paythank() 
	{		
		if($this->session->userdata('username')!='')
		{		
			$user_id=$this->session->userdata('user_id');
			$yearid=$this->session->userdata('loginyear');
			$yeardata=$this->classes_model->classes_details($yearid);
			if($yeardata)
			{
				$data['year_name']=$yeardata[0]->class_name;
				$data['year_slug']=$yeardata[0]->class_slug;
			}
			$data['aatcount']=$this->exam_model->checkuser_aat_status($yearid,$user_id);
			
			$this->load->view('frontend/private/pay-thank',$data);
			/* $this->session->unset_userdata('username');
		$this->session->unset_userdata('user_id');
		$this->session->sess_destroy(); */
		}
		else
		{
			redirect(base_url().'login');
		}
	
	}
	public function paycancel() 
	{		
		if($this->session->userdata('username')!='')
		{		
			
			
			$this->load->view('frontend/private/pay-cancel',$data);
		}
		else
		{
			redirect(base_url().'login');
		}
	
	}
	
public function paynotified() 
	{		
		define("DEBUG", 1);
		// Set to 0 once you're ready to go live
		define("USE_SANDBOX", 1);
		define("LOG_FILE", "ipn.log");
		// Read POST data
		// reading posted data directly from $_POST causes serialization
		// issues with array data in POST. Reading raw POST data from input stream instead.
		$raw_post_data = file_get_contents('php://input');
		$raw_post_array = explode('&', $raw_post_data);
		$myPost = array();
		foreach ($raw_post_array as $keyval) {
			$keyval = explode ('=', $keyval);
			if (count($keyval) == 2)
				$myPost[$keyval[0]] = urldecode($keyval[1]);
		}
		// read the post from PayPal system and add 'cmd'
		$req = 'cmd=_notify-validate';
		if(function_exists('get_magic_quotes_gpc')) {
			$get_magic_quotes_exists = true;
		}
		foreach ($myPost as $key => $value) {
			if($get_magic_quotes_exists == true && get_magic_quotes_gpc() == 1) {
				$value = urlencode(stripslashes($value));
			} else {
				$value = urlencode($value);
			}
			$req .= "&$key=$value";
		}
		// Post IPN data back to PayPal to validate the IPN data is genuine
		// Without this step anyone can fake IPN data
		if(USE_SANDBOX == true) {
			$paypal_url = "https://www.sandbox.paypal.com/cgi-bin/webscr";
		} else {
			$paypal_url = "https://www.paypal.com/cgi-bin/webscr";
		}
		$ch = curl_init($paypal_url);
		if ($ch == FALSE) {
			return FALSE;
		}
		curl_setopt($ch, CURLOPT_HTTP_VERSION, CURL_HTTP_VERSION_1_1);
		curl_setopt($ch, CURLOPT_POST, 1);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER,1);
		curl_setopt($ch, CURLOPT_POSTFIELDS, $req);
		curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 1);
		curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 2);
		curl_setopt($ch, CURLOPT_FORBID_REUSE, 1);
		if(DEBUG == true) {
			curl_setopt($ch, CURLOPT_HEADER, 1);
			curl_setopt($ch, CURLINFO_HEADER_OUT, 1);
		}
		// CONFIG: Optional proxy configuration
		//curl_setopt($ch, CURLOPT_PROXY, $proxy);
		//curl_setopt($ch, CURLOPT_HTTPPROXYTUNNEL, 1);
		// Set TCP timeout to 30 seconds
		curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 30);
		curl_setopt($ch, CURLOPT_HTTPHEADER, array('Connection: Close'));
		// CONFIG: Please download 'cacert.pem' from "http://curl.haxx.se/docs/caextract.html" and set the directory path
		// of the certificate as shown below. Ensure the file is readable by the webserver.
		// This is mandatory for some environments.
		//$cert = __DIR__ . "./cacert.pem";
		//curl_setopt($ch, CURLOPT_CAINFO, $cert);
		$res = curl_exec($ch);
		if (curl_errno($ch) != 0) // cURL error
			{
			if(DEBUG == true) {	
				error_log(date('[Y-m-d H:i e] '). "Can't connect to PayPal to validate IPN message: " . curl_error($ch) . PHP_EOL, 3, LOG_FILE);
			}
			curl_close($ch);
			exit;
		} else {
				// Log the entire HTTP response if debug is switched on.
				if(DEBUG == true) {
					error_log(date('[Y-m-d H:i e] '). "HTTP request of validation request:". curl_getinfo($ch, CURLINFO_HEADER_OUT) ." for IPN payload: $req" . PHP_EOL, 3, LOG_FILE);
					error_log(date('[Y-m-d H:i e] '). "HTTP response of validation request: $res" . PHP_EOL, 3, LOG_FILE);
				}
				curl_close($ch);
		}
		// Inspect IPN validation result and act accordingly
		// Split response headers and payload, a better way for strcmp
		$tokens = explode("\r\n\r\n", trim($res));
		$res = trim(end($tokens));
		if (strcmp ($res, "VERIFIED") == 0) 
		{
			// assign posted variables to local variables
			$item_name = $this->input->post('item_name');
			$item_number = $this->input->post('item_number');
			$payment_status = $this->input->post('payment_status');
			$payment_amount = $this->input->post('mc_gross');
			$payment_currency = $this->input->post('mc_currency');
			$txn_id = $this->input->post('txn_id');
			$receiver_email = $this->input->post('receiver_email');
			$payer_email = $this->input->post('payer_email');
			
		
			// check whether the payment_status is Completed
			$isPaymentCompleted = false;
			if($payment_status == "Completed") {
				$isPaymentCompleted = true;
			}
			// check that txn_id has not been previously processed
			/*$isUniqueTxnId = false; 
			$result = $db->selectQuery("SELECT * FROM payments WHERE txn_id = '$txn_id'");
			if(empty($result)) {
				$isUniqueTxnId = true;
			}
*/			
			// check that receiver_email is your PayPal email
			// check that payment_amount/payment_currency are correct
			if($isPaymentCompleted && $payment_currency == "USD") {
				$createdate=date("Y-m-d H:i:s");
				$ord_data=array(
							
							'order_status'=>'active',
							'pay_status'=>'confirm',
							'trans_id'=>$txn_id,
							'pay_date'=>$createdate
							);
						$orderid=$this->order_model->Update_Order($ord_data,$item_number);
						
	/*----promoted user class status---*/	
	$query_ordinfo=$this->db->query("select * from orders  where orderid='".$item_number."' ");	
	$orderinfo=$query_ordinfo->row();
	if($orderinfo->userid !="")
	{	
		$query_chkpro=$this->db->query("select * from user_details  where user_id='".$orderinfo->userid."'");
		$num_chkpro=$query_chkpro->num_rows();
		if($num_chkpro > 0)
		{
					$user_row=$query_chkpro->row();

						$promotedyear=array(						
								'center_id'=>$orderinfo->center_id	
								);
						$updateuseryear=$this->exam_model->promoted_student_year($promotedyear,$orderinfo->userid);	
					
						

						/*----update order current year----*/
						$ord_data1=array(						
						
							'year_id'=>$user_row->year_id
							);
						$orderid2=$this->order_model->Update_Order($ord_data1,$item_number);
						/*----end of update order current year---*/
						
						/*----update order weeks current year----*/
						$ord_weeks=array(						
						
							'ordweek_yearid'=>$user_row->year_id,
							'ordweek_paystatus'=>'confirm'
							);
						$orderid2=$this->order_model->Update_OrderWeeks($ord_weeks,$item_number);
						/*----end of update order weeks current year---*/		
			
					
					 
					//Update user center
					$user_data=array(													
								'center_id'=>$orderinfo->center_id,							
								);
					$orderid=$this->main_model->Update('user_details',$user_data,'user_id',$orderinfo->userid);
					 
					 
					//Change(Reduce) room capacity
					$date=date('Y-m-d');
					$whr="user_id=".$orderinfo->userid."  and order_id=".$item_number."";
					
					$row_tmpbooks=$this->main_model->get_where_result('temp_class_booking',$whr);
					foreach($row_tmpbooks as $row_tmpbook){				
					$row_book=$this->main_model->get_detail('classroom_booking','id',$row_tmpbook->class_r_b_id);	
					$week_id=$row_book->week_id;

					
					$room_avail=$row_book->room_available-1;	
					$bookroominfo=array(
								'room_available'=>$room_avail
								);
					$this->main_model->Update('classroom_booking',$bookroominfo,'id',$row_tmpbook->class_r_b_id);
					
					
					
					//Get order week_id
					$whr="ordweek_weekid=".$week_id." and ordweek_orderid=".$item_number."";
					
					$row_orderweek=$this->main_model->get_where_row('order_weeks',$whr);
					//Save seat allotment info
					
					$bookseatinfo=array(
								'id'=>'',
								'user_id'=>$orderinfo->userid,
								'date'=>$date,
								'class_schdl_id'=>$row_book->class_schdl_id,
								'classroom_booking_id'=>$row_tmpbook->class_r_b_id,
								'order_id'=>$item_number,
								'order_week_id'=>$row_orderweek->ordweek_id
								);
					
					$this->main_model->Save('seat_allotment_info',$bookseatinfo);
					$this->db->reset_query();
					}
					/*-----end of update center stock---*/
					
				//Send order mail to user 	
				$result=$orderinfo;
				$this->load->library('email');
				$config = array (
					'mailtype' => 'html',
					'charset' => 'utf-8',
					'priority' => '1'
					);
					$this->email->initialize($config);
					
					$user_details=$this->main_model->get_detail('user_details','user_id',$orderinfo->userid);
					
					
					
					$senderemail=$user_details->email;
		
		
		$expirydate="";
		$orddb="";
		if($result!= null && $result!= ""){		
		 
		  
			$plan_name=$this->plan_model->GetPlanName($result->plan_id);
			/*----expired order plan------*/
			$expirydate=strtotime("+".$result->order_week." week", strtotime($result->order_date));
			if($today > $expirydate)
			{
				$orddb=array('order_status'=>'expired');				
				$this->order_model->Update_Order($orddb,$result->orderid);
			}
	$row_centerdetail= $this->main_model->get_detail('centerlocation','center_id',$result->center_id);
		$year_dtl=$this->main_model->get_detail('master_class','class_id',$user_details->year_id);
$mail_html='<!DOCTYPE HTML>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>My Uni Education Group Ltd</title>
<style>
* {
	margin:0px;
	padding:0px;
}
html, body {
	margin:0px;
	padding:0px;
	font-size:18px;
	line-height:20px;
	font-family:Arial, Helvetica, sans-serif; 
	color:#000;
}
img {
	max-width:100%;
}
h3 {
	font-size:24px;
	font-weight:normal;
}
.container {
	width:80%;
	margin:0 auto;
	max-width:600px;
	padding:0px;
}

.btn {
	background:#005e82;
	padding:5px;
	display: inline-block;
	color: #fff;
	text-decoration: none;
	width:120px;
}
.footer {
	text-align:left;
	font-size:12px;
	font-weight:bolder;
	line-height:18px;
	width:100%;
	float:left;
	background: #000;
	color: #fff;
	padding:15px;
	box-sizing: border-box;
}
.footer .detail strong {
	font-size:16px;
	font-weight:bolder;
	line-height:22px;
}
.footer .detail strong i {
	font-size:12px;
	text-transform:uppercase;
}

strong {
	font-weight:bold;
}
 .tableBox tr:nth-child(even) {
 background:#f2f2f2;
}
table {
	font-size:14px; 
}
table p {
	font-size:12pt;
	line-height:25px;
	padding-bottom:5px;
}
table h2 {
	padding: 0 0 12px 0;
	font-weight: 400;
	font-size:22px;
}
.footer .detail td p {
	padding-bottom:0px;
	font-size:14px; 
	line-height:20px;
}
table .tableBox {
	font-size:14px;
}
 
table .tableBox td {
	padding-left:8px;
	line-height:32px;
}

table .tableBox td  p{ padding-bottom:0px; font-size:14px;}

table h3 {
	font-size:24px;
	line-height: 32px;
	color:#FFF;
	font-weight:700;
}
.footer-text{ padding:0 10px;}
.footer-text p{color:#fff; padding-bottom:0px; font-size:10pt; line-height:17px;}
.footer-text p a{color:#fff;}
table p{ padding:0 15px;}
.footer-text p{ padding:0px;}
.left-padding-15{ padding-left:15px;}
 @media only screen and (max-width:400px) {
	 .btn{ margin-bottom:15px;}
	 .container {
	width:70%;
	margin:0 auto;
	max-width:320px;
	padding:0px;
}


}
</style>
</head>

<body style="background:#d0d0d0;">
<table width="100%" border="0" cellspacing="0" cellpadding="0" class="container" bgcolor="#ffffff">
  <tr bgcolor="#d0d0d0">
    <td height="15"></td>
  </tr>
  <tr>
    <td><table width="100%" border="0" cellspacing="15" cellpadding="0">
        <tr>
          <td align="center"><a href="'.base_url().'"><img src="'.base_url().'assets/images/logo.png'.'" alt="" width="156" height="134" /></a></td>
        </tr>
      </table></td>
  </tr>

  <tr>
    <td align="center" valign="top" bgcolor="#f4f4f4"><table width="85%" border="0" align="center" cellpadding="0" cellspacing="0">
      <tr>
        <td height="10"></td>
      </tr>
      <tr>
        <td>&nbsp;</td>
      </tr>
      <tr>
        <td><p>Dear  Parent/Guardian  and Student,</p></td>
      </tr>
      <tr>
        <td height="15"></td>
      </tr>
      <tr>
        <td><p>We  are very pleased to have '.$user_details->first_name.'  booked into the classes below:</p></td>
      </tr>
      <tr>
        <td height="15"></td>
      </tr>
      <tr>
        <td class="left-padding-15"><table width="500" border="0" cellspacing="0" cellpadding="0">
          <tr>
            <td width="175" valign="top"><strong>Reference Number : </strong></td>
            <td width="275" valign="top">'.$result->orderid.'</td>
            </tr>
          <tr>
            <td height="8" valign="top"></td>
            <td height="8" valign="top"></td>
          </tr>
		  <tr>
            <td width="175" valign="top"><strong>Transaction Id : </strong></td>
            <td width="275" valign="top">'.$txn_id.'</td>
            </tr>
          <tr>
            <td height="8" valign="top"></td>
            <td height="8" valign="top"></td>
          </tr>
          <tr>
            <td valign="top"><strong>Student&rsquo;s Name : </strong></td>
            <td valign="top">'.$user_details->first_name.' '.$user_details->last_name.'</td>
          </tr>
          <tr>
            <td height="8" valign="top"></td>
            <td height="8" valign="top"></td>
          </tr>
          <tr>
            <td valign="top"><strong>Student&rsquo;s ID : </strong></td>
            <td valign="top"><strong></strong>'.$user_details->user_id.'</td>
          </tr>
          <tr>
            <td height="8" valign="top"></td>
            <td height="8" valign="top"></td>
          </tr>
          <tr>
            <td valign="top"><strong>Registered Subject : </strong></td>
            <td valign="top">The University of English</td>
          </tr>
          <tr>
            <td height="8" valign="top"></td>
            <td height="8" valign="top"></td>
          </tr>
          <tr>
            <td valign="top"><strong>MY UNIYear :</strong></td>
			
            <td valign="top"><strong>'.$year_dtl->class_name.'</strong></td>
          </tr>
          <tr>
            <td height="8" valign="top"></td>
            <td height="8" valign="top"></td>
          </tr>
          <tr>
            <td valign="top"><strong>ClassesEnrolled :</strong></td>
            <td valign="top"><strong></strong>For class enrolled please see invoice</td>
          </tr>
          <tr>
            <td height="8" valign="top"></td>
            <td height="8" valign="top"></td>
          </tr>
          <tr>
            <td valign="top"><strong>Tution Fee:</strong></td>
            <td valign="top">'.$result->amount.'</td>
          </tr>
          <tr>
            <td height="8" valign="top"></td>
            <td height="8" valign="top"></td>
          </tr>
          <tr>
            <td valign="top"><strong>Centre :</strong></td>
            <td valign="top"><p>'.$row_centerdetail->center_address.', '.$row_centerdetail->center_city.', '.$row_centerdetail->center_zip.'</p></td>
          </tr>
          </table></td>
      </tr>
      <tr class="container">
        <td height="15" align="center"></td>
      </tr>
      <tr>
        <td><p>For more information, please visit our subject website <a href="'.base_url().'">'.base_url().'</a></p></td>
      </tr>
      <tr>
        <td height="15"></td>
      </tr>
      <tr>
        <td><p>If you have any questions please contact us on 022 645  8491 or email us at <a href="mailto:ask@myunieducation.com">ask@myunieducation.com</a>.  Please DO NOT reply to this email as it is an  auto-generated message.</p></td>
      </tr>
      <tr>
        <td>&nbsp;</td>
      </tr>
      <tr>
        <td height="10"></td>
      </tr>
    </table></td>
  </tr>
  
  <tr bgcolor="#69c4a9">
    <td height="15" align="center" bgcolor="#485052"></td>
  </tr>
  <tr bgcolor="#69c4a9">
    <td height="15" align="left" bgcolor="#485052"  style="padding:10px;"><img src="https://www.myunieducation.com/wp-content/themes/myunieducation/images/logo.png" alt="" width="111" height="111" /></td>
  </tr>
  <tr bgcolor="#69c4a9">
    <td align="left" bgcolor="#485052" style="padding:10px;"><h3>MY UNI EDUCATION GROUP LIMITED</h3></td>
  </tr>
  <tr bgcolor="#485052">
    <td align="center" style="padding:0px;"><table width="100%" border="0" align="center" cellpadding="0" cellspacing="0">
      <tr>
        <td align="left" bgcolor="#485052" class="footer-text"><p><strong>Tel:</strong> (+64) 022 645 8491</p>
          <p><strong>Email:</strong> <a href="mailto:ask@myunieducation.com">ask@myunieducation.com</a></p>
          <p><strong>Headquarters  Address:</strong> 2A Wagener Place, Mt Albert, Auckland, 1025, New Zealand</p>
          <p><strong>Website:</strong> <a href="http://www.myunieducation.com">www.myunieducation.com</a></p></td>
      </tr>
      <tr>
        <td align="left" bgcolor="#485052" class="footer-text">&nbsp;</td>
      </tr>
    </table></td>
  </tr>
 
</table>
</body>
</html>';		
					$body = $mail_html;
					$this->email->from(basic_from_email, basic_from_name);
					$this->email->to($senderemail);
					$this->email->subject(order_subject);
					$this->email->message($body);
					$this->email->send();				
					
					 
					
					/*-----end of update center stock---*/
			
		}
			
	}
	/*----promoted user class status---*/						
			}
			// process payment and mark item as paid.
			
			
			if(DEBUG == true) {
				error_log(date('[Y-m-d H:i e] '). "Verified IPN: $req ". PHP_EOL, 3, LOG_FILE);
			}
			
		} else if (strcmp ($res, "INVALID") == 0) {
			// log for manual investigation
			// Add business logic here which deals with invalid IPN messages
			if(DEBUG == true) {
				error_log(date('[Y-m-d H:i e] '). "Invalid IPN: $req" . PHP_EOL, 3, LOG_FILE);
			}
		}
	}
	}
	
	public function orderhistory() 
	{		
		if($this->session->userdata('username')!='')
		{		
			
			$userid=$this->session->userdata('user_id');
			$yearid=$this->session->userdata('loginyear');
			$user_year=$this->User_model->user_year($userid);
			$year_id=$user_year->year_id;			
			$yeardata=$this->classes_model->classes_details($year_id);
			if($yeardata)
			{
				$data['year_name']=$yeardata[0]->class_name;
				$data['year_slug']=$yeardata[0]->class_slug;
			}
			$config["base_url"] =  BASE_URL_ADMIN. "order-history";
			$config["total_rows"] = $this->order_model->orderlist_currentyear_count($year_id,$userid);
			$config["per_page"] = 20;
			
			$this->pagination->initialize($config);

			$page = ($_REQUEST['page']) ? $_REQUEST['page'] : 0;
			$data["orderlist"] = $this->order_model->orderlist_currentyear($config["per_page"], $page,$year_id,$userid);
			$data["links"] = $this->pagination->create_links();
			$data['aatcount']=$this->exam_model->checkuser_aat_status($yearid,$userid);
			$this->load->view('frontend/private/order-history',$data);
		}
		else
		{
			redirect(base_url().'login');
		}
	
	}
	public function pay_load() 
	{		
		if($this->session->userdata('username')!='')
		{		
			
			$userid=$this->session->userdata('user_id');
			$yearid=$this->session->userdata('loginyear');
			$user_year=$this->User_model->user_year($userid);
			$year_id=$user_year->year_id;			
			$yeardata=$this->classes_model->classes_details($year_id);
			if($yeardata)
			{
				$data['year_name']=$yeardata[0]->class_name;
				$data['year_slug']=$yeardata[0]->class_slug;
			}
			$config["base_url"] =  BASE_URL_ADMIN. "order-history";
			$config["total_rows"] = $this->order_model->orderlist_currentyear_count($year_id,$userid);
			$config["per_page"] = 20;
			
			$this->pagination->initialize($config);
			$data['userid']=$this->session->userdata('user_id');
			$this->load->view('frontend/private/pay_load',$data);
		}
		else
		{
			redirect(base_url().'login');
		}
	
	}
	
	public function assessment_report() 
	{		
		if($this->session->userdata('username')!='')
		{		
			
		    $userid=$this->session->userdata('user_id');
			$user_year=$this->User_model->user_year($userid);
			$query_chkpro=$this->db->query("select * from student_promoted  where user_id='".$userid."' and pay_status='confirm' order by  pid desc ");
			$year_chkpro=$query_chkpro->row();	
			$yearid=$this->session->userdata('loginyear');			
			//$yeardata=$this->classes_model->classes_details($year_chkpro->reg_year);
			$yeardata=$this->classes_model->classes_details($yearid);
			if($yeardata)
			{
				$data['year_name']=$yeardata[0]->class_name;
				$data['year_slug']=$yeardata[0]->class_slug;
			}
			
			$data["asstestlist"] = $this->exam_model->asstest_by_user($userid, $year_chkpro->reg_year);
			
			
			$this->load->view('frontend/private/assessment-report',$data);
		}
		else
		{
			redirect(base_url().'login');
		}
	
	}
/*-----Book Center class----*/
	public function bookcenterclass($id="") 
	{		
		if($this->session->userdata('username')!='')
		{		
			
			/*-----send order to paypal-----*/
			$userid=$this->session->userdata('user_id');
			$yearid=$this->session->userdata('loginyear');	
			if($id!="" && $id!=null)
			{
				
				
				$userarray=$this->User_model->user_details($userid);
				$data['userinfo']=$userarray[0];
				$data['elg_yearname']=$this->classes_model->GetClassName($id);
				$data['center_list']=$this->center_model->center_dropdown();
				$data['elg_yearid']=$id;
				
				$this->form_validation->set_rules('first_name', 'First Name', 'required');
				$this->form_validation->set_rules('last_name', 'Last Name', 'required');
				$this->form_validation->set_rules('email', 'Email', 'required|valid_email');
				$this->form_validation->set_rules('phone', 'Phone', 'required|callback_chk_phone');
				$this->form_validation->set_rules('dob', 'DOB', 'required');
			
		if($this->form_validation->run())
		{
					$first_name=$this->input->post('first_name');
					$last_name=$this->input->post('last_name');
					$email=$this->input->post('email');
					$phone=$this->input->post('phone');
					$dob=$this->input->post('dob');
					$elg_yearid=$this->input->post('elg_yearid');
					
					if($dob!="")
					{
						$dobarray=explode('/',$dob);
						$dob=$dobarray[2].'-'.$dobarray[1].'-'.$dobarray[0];
					}						
					$address=$this->input->post('address');
					$city=$this->input->post('city');
					$state=$this->input->post('state');
					$zipcode=$this->input->post('zipcode');
					
					
					$studentinfo=array(
								'first_name'=>$first_name,
								'last_name'=>$last_name,
								'email'=>$email,
								'phone'=>$phone,
								'dob'=>$dob,
								'address'=>$address,
								'city'=>$city,
								'state'=>$state,
								'zipcode'=>$zipcode
								
								);
					$updateusers=$this->User_model->update_staff($userid,$studentinfo);	
					
					
					//redirect(base_url().'membership-plan');
					redirect(base_url().'booking-parents/'.$id);
			



			}
			
			}
			
			else
			{
				redirect(base_url().'assessment');
			}
			/*-----end of order send to paypal----*/
			
			$query_chkord=$this->db->query("select * from orders  where userid='".$userid."' and pay_status='confirm' and order_status='active' and year_id='".$yearid."' order by  orderid desc ");
			$num_chkord=$query_chkord->num_rows();
			$data['checkord']=$num_chkord;
			
			$this->load->view('frontend/private/book-center-class',$data);
		}
		else
		{
			redirect(base_url().'login');
		}
	
	}
/*----End of booking center class-----*/
	public function our_centers() 
	{		
		
			
		
		if($this->session->userdata('username')!='')
		{		
			$user_id=$this->session->userdata('user_id');
			$yearid=$this->session->userdata('loginyear');
			$yeardata=$this->classes_model->classes_details($yearid);
			if($yeardata)
			{
				$data['year_name']=$yeardata[0]->class_name;
				$data['year_slug']=$yeardata[0]->class_slug;
			}
			$data['aatcount']=$this->exam_model->checkuser_aat_status($yearid,$user_id);
			$data['center_list'] = $this->main_model->get_selected_details('centerlocation',$columns = array('center_name','center_city','center_state','center_address','center_phone'),$where = array('status'=>1),'multiple',$obj_form=true);
		$this->load->view('frontend/private/our-centers',$data);
		}
		else
		{
			redirect(base_url().'login');
		}
		
	
	}
	public function certificate_award() 
	{	
		$data = array();
		
		if($this->session->userdata('username')!='')
		{		
			$user_id=$this->session->userdata('user_id');
			$yearid=$this->session->userdata('loginyear');
			$yeardata=$this->classes_model->classes_details($yearid);
			if($yeardata)
			{
				$data['year_name']=$yeardata[0]->class_name;
				$data['year_slug']=$yeardata[0]->class_slug;
			}
			$data['aatcount']=$this->exam_model->checkuser_aat_status($yearid,$user_id);
			$this->load->view('frontend/private/certificate_award',$data);
		}
		else
		{
			redirect(base_url().'login');
		}
	}
	
/*-----Book Center class----*/
//Booking parent
public function bookingparents($id="") 
	{		
		if($this->session->userdata('username')!='')
		{		
			
			/*-----send order to paypal-----*/
		$userid=$this->session->userdata('user_id');
		$yearid=$this->session->userdata('loginyear');
			if($id!="" && $id!=null)
			{
				
				
				$userarray=$this->User_model->user_details($userid);
				$data['userinfo']=$userarray[0];
				$data['elg_yearname']=$this->classes_model->GetClassName($id);
				$data['center_list']=$this->center_model->center_dropdown();
				$data['elg_yearid']=$id;
				
				$this->form_validation->set_rules('mother_name', 'Name', 'required');
				/*$this->form_validation->set_rules('father_name', 'Father Name', 'required'); */
				$this->form_validation->set_rules('email', 'Email', 'required|valid_email');
				$this->form_validation->set_rules('phone', 'Phone', 'required|callback_chk_phone');
								
		if($this->form_validation->run())
		{
					$mother_name=$this->input->post('mother_name');
					$father_name='';
					$email=$this->input->post('email');
					$phone=$this->input->post('phone');											
					$occupation=$this->input->post('occupation');
					
					
					$parentinfo=array(
								'student_id'=>$userid,
								'mother_name'=>$mother_name,
								'father_name'=>$father_name,
								'email'=>$email,
								'phone'=>$phone,								
								'occupation'=>$occupation
								
								);
					$updateusers=$this->exam_model->Save_Parents($parentinfo,$userid);
					
					
					redirect(base_url().'membership-plan');
				}
			}
			
			else
			{
				//redirect(base_url().'assessment');
			}
			/*-----end of order send to paypal----*/
			$data['parentinfo']=$this->exam_model->getparent($userid);
			
			$query_chkord=$this->db->query("select * from orders  where userid='".$userid."' and pay_status='confirm' and order_status='active' and year_id='".$yearid."' order by  orderid desc ");
			$num_chkord=$query_chkord->num_rows();
			$data['checkord']=$num_chkord;
			
			$this->load->view('frontend/private/booking-parents',$data);
		}
		else
		{
			redirect(base_url().'login');
		}
	
	}

public function pre_view($year='',$queId='')
	{
		


		$yearid=$this->session->userdata('loginyear');
			$yeardata=$this->classes_model->classes_details($yearid);
			if($yeardata)
			{
				$data['year_name']=$yeardata[0]->class_name;
				$data['year_slug']=$yeardata[0]->class_slug;
			}
		$year_id=$year;
		$data['year_id']=$year_id;
		$this->questions_model->CLASSID = $year_id;
		$data["year_dtl"] = $this->main_model->get_detail('master_class','class_id',$year_id);	
		if($queId!=""){
			/*---Start Assessment Test -----*/
			
	
			$this->questions_model->CLASSID = $year_id;
				//$data["Questionlist"] = $this->questions_model->question_list_subskill($subskill_id);
		
				if($this->input->post('action')=='submitanswer')	
					{
					 $questionid=$this->input->post('questionid');
					
					
					$ques_detail= $this->questions_model->question_details($questionid);
					$ques_type=explode(',',$ques_detail->ques_type);
					if(in_array(1,$ques_type)){  
						
					
					$answerid=$this->input->post('answerid');
				
					
					$data["ques_dtl"] = $this->main_model->get_detail('manage_question_'.$year_id,'ques_id',$questionid);
					//print_r($data["ques_dtl"]);
					
					$data["correct_ans"] = $this->main_model->get_detail('manage_answer_'.$year_id,'ans_id',$data["ques_dtl"]->ques_rightanswer);
					//print_r($data["correct_ans"]);
					//echo $data["correct_ans"]->ans_name;
										
					if($data["ques_dtl"]->ques_rightanswer==$answerid)
					{
						
					$data['correct']=1;
					$data["Questionlist"] = $this->questions_model->random_question($subskill_id);
					$this->load->view('frontend/private/play',$data);

					}
					else{
			
					$data["yourans"] = $this->main_model->get_detail('manage_answer_'.$year_id,'ans_id',$answerid);	
					$this->load->view('frontend/private/explanation',$data);
					}
					}
					elseif(in_array(22,$ques_type))
					{
						
					$answerid=$this->input->post('answerid');
					 $answerid=implode(',',$answerid);
					//exit;
					
					$data["ques_dtl"] = $this->main_model->get_detail('manage_question_'.$year_id,'ques_id',$questionid);
					//print_r($data["ques_dtl"]);
					
					$data["correct_ans"] = $this->main_model->get_detail('manage_answer_'.$year_id,'ans_id',$data["ques_dtl"]->ques_rightanswer);
					//print_r($data["correct_ans"]);
					//echo $data["correct_ans"]->ans_name;
										
					if($data["ques_dtl"]->ques_rightanswer==$answerid)
					{
						
					$data['correct']=1;
					$data["Questionlist"] = $this->questions_model->random_question($subskill_id);
					$this->load->view('frontend/private/play',$data);

					}
					else{
			
					$data["yourans"] = $this->main_model->get_detail('manage_answer_'.$year_id,'ans_id',$answerid);	
					$this->load->view('frontend/private/explanation',$data);
					}
					}
					elseif(in_array(26,$ques_type))
					{
						
					$all_answer = $this->main_model->getall('manage_answer_'.$year_id,'ans_quesid',$questionid);
					$correct=true;
					 for($i=0;$i<count($all_answer);$i++){
						 
						$incount=$i+1;
						if($all_answer[$i]->ans_name!=$this->input->post('input'.$incount))
						{ 
							$correct=false;
							
						}
						
					 	
					 }
					 
					 if($correct){
						$data['correct']=1;
						$data["Questionlist"] = $this->questions_model->random_question($subskill_id);
						$this->load->view('frontend/private/play',$data);
					 }
					 else{
						$data["yourans"] = $this->main_model->get_detail('manage_answer_'.$year_id,'ans_id',$answerid);	
						$this->load->view('frontend/private/explanation',$data);
					 }
					 
					}
					 
					
					else{
						$data["yourans"] = $this->main_model->get_detail('manage_answer_'.$year_id,'ans_id',$answerid);	
						$this->load->view('frontend/private/explanation',$data);
						}
						
					}
				else{
					$data["Questionlist"] = $this->main_model->preview('manage_question_'.$year_id,'ques_id',$queId);
					
					$this->load->view('frontend/public/preview',$data);
					}
			
				
			}
			else{
				
				if($this->session->userdata('user_id')!='' and $this->session->userdata('username')!='')
				{

				$data["SylList1"] = $this->syllabus_model->syllabus_list($year_id,1);
				$data["SylList2"] = $this->syllabus_model->syllabus_list($year_id,2);
				$data["SylList3"] = $this->syllabus_model->syllabus_list($year_id,3);
				$data["SylList4"] = $this->syllabus_model->syllabus_list($year_id,4);

				$this->load->view('frontend/private/kindergarten', $data);
				}
				else{
				$data["SylList1"] = $this->syllabus_model->syllabus_list($year_id,1);
				$data["SylList2"] = $this->syllabus_model->syllabus_list($year_id,2);
				$data["SylList3"] = $this->syllabus_model->syllabus_list($year_id,3);
				$data["SylList4"] = $this->syllabus_model->syllabus_list($year_id,4);

				$this->load->view('frontend/public/preview', $data);	
					
				

			}
		

	}
}


/*----End of booking center class-----*/

	/*--Order invoice PDF---*/
	public function orderinvoice($orderid="")
	{
			
						
		if($this->session->userdata('username')!='')
		{		
			
			/*-----send order to paypal-----*/
			$userid=$this->session->userdata('user_id');	
			$orderinfo = $this->order_model->order_invoice($orderid,$userid);
			$plan_name=$this->plan_model->GetPlanName($orderinfo->plan_id);
			$user_name=$this->User_model->user_fullname($orderinfo->userid);
			$year_name=$this->classes_model->GetClassName($orderinfo->year_id);
			$center_name=$this->center_model->GetDepartmeantName($orderinfo->center_id);
			$parentinfo=$this->students_model->parent_details($orderinfo->userid);
			

/*-------- create pdf file----*/
$pdf = new TCPDF(PDF_PAGE_ORIENTATION, PDF_UNIT, PDF_PAGE_FORMAT, true, 'UTF-8', false);    
// set document information
$pdf->SetCreator(PDF_CREATOR);
// $pdf->SetMargins(PDF_MARGIN_LEFT, PDF_MARGIN_TOP, PDF_MARGIN_RIGHT);
// set auto page breaks
$pdf->SetAutoPageBreak(TRUE, PDF_MARGIN_BOTTOM); 
// set some language-dependent strings (optional)
if (@file_exists(dirname(__FILE__).'/lang/eng.php')) {
	require_once(dirname(__FILE__).'/lang/eng.php');
	$pdf->setLanguageArray($l);
}  
// set default font subsetting mode
$pdf->SetFont('helvetica', 'B', 20);
$pdf->SetPrintHeader(false);
$pdf->SetPrintFooter(false);
// add a page
$pdf->AddPage();
$pdf->SetFont('helvetica', '', 10);
// Set some content to print
$masterdata='<table cellpadding="0" cellspacing="0" border="0" style="width:100%;"  >
												 
<tr>
<tr><td  colspan="2" style="text-align:center;"><center><img src="'.base_url('assets/images/logo.png').'" style="width:100px;height:100px;"  /><br><br></td></tr>	
<tr><td  colspan="2" style="text-align:center;"><center><h2>Invoice</h2><br><br></td></tr>
								
</table>
<table cellpadding="0" cellspacing="0" border="0" style="width:100%;"  >
<tr>
<td style="width:50%;" valign="top">
<table cellpadding="0" cellspacing="0" border="0" style="width:100%;"  >
<tr><td><strong>Student Name:</strong> </td> <td>'.$user_name.' </td></tr>
<tr><td><strong>Parent Name:</strong> </td> <td>'.$parentinfo->mother_name.'</td></tr>

</table>
</td>
<td style="width:50%;" valign="top">
<table cellpadding="0" cellspacing="0" border="0" style="width:100%;"  >
<tr><td><strong>Order-ID:</strong> </td> <td>'.$orderinfo->orderid.' </td></tr>
<tr><td><strong>Transation-ID:</strong> </td> <td> '.$orderinfo->trans_id.'</td></tr>
<tr><td><strong>Payment Status:</strong> </td> <td>'.$orderinfo->pay_status.'</td></tr>
<tr><td><strong>Date:</strong> </td> <td> '.date('F d, Y',strtotime($orderinfo->order_date)).'</td></tr>


</table>
</td>

</tr>
</table><br><br>
';
$masterdata .='<table border="1"  class="viewtable" width="100%" style="padding:4px;" >
<thead>
<tr>
	<td width="20%"><strong>Plan Name</strong></td>
	<td width="10%"><strong>Year</strong></td>
	<td width="10%"><strong>Center</strong></td>
	<td width="10%"><strong>Weeks</strong></td>
	<td width="20%"><strong>Per Weeks</strong></td>
	<td width="10%"><strong>GST</strong></td>
	<td width="20%"><strong>Amount</strong></td>
</tr>	
</thead>
<tbody>';


		
	$masterdata .='<tr>
		<td width="20%" >'.$plan_name.'</td>
		<td width="10%" >'.$year_name.'</td>
		<td width="10%" >'.$center_name.'</td>
		<td width="10%" >'.$orderinfo->order_totalweek.' Weeks</td>
		<td width="20%" >$25</td>
		<td width="10%" >$'.$orderinfo->amount_gst.'</td>
		<td width="20%" >$'.$orderinfo->amount_without_gst.'</td>
		</tr>
		<tr><td colspan="6" style="text-align:right;"><b>Total Amount</b></td>
		<td>$'.$orderinfo->amount.'</td></tr>
		</tbody>
		</table>
		';
$sqlweeks=$this->db->query('select * from order_weeks where ordweek_orderid="'.$orderinfo->orderid.'"');
$numweeks=$sqlweeks->num_rows();	
$rowweeks=$sqlweeks->result();		
if($numweeks > 0)
{	
$masterdata .='<br><br><strong>Your Paid Weeks Details</strong><br><br><table border="1"  class="viewtable" width="100%" style="padding:4px;" >
<thead>
<tr>
	<td width="20%"><strong>Year </strong></td>
	<td width="20%"><strong>Term </strong></td>
	<td width="20%"><strong>Weeks</strong></td>
	<td width="40%"><strong>Class DateTime</strong></td>
	
</tr>	
</thead>
<tbody>';


	foreach($rowweeks as $weeks)
	{	
	$seetbook_row=$this->main_model->get_detail('seat_allotment_info','order_week_id',$weeks->ordweek_id);
	$classroombook_row=$this->main_model->get_detail('classroom_booking','id',$seetbook_row->classroom_booking_id);
	if(date('Y-m-d',strtotime($classroombook_row->class_schdl_date))!='1970-01-01'){
	$masterdata .='<tr>
		<td width="20%" >'.$year_name.'</td>
		<td width="20%" >Term '.$weeks->ordweek_termid.'</td>		
		<td width="20%" >Week '.$weeks->ordweek_weekid.'</td>
		<td width="40%" >'.date('Y-m-d H:i:A',strtotime($classroombook_row->class_schdl_date)).'</td>
		
		</tr>';
	}	
	}	
	
	
	$masterdata .='</tbody>	</table>';

}	

	$html = <<<EOD
     $masterdata	    
EOD;
// echo $masterdata;
// Print text using writeHTMLCell()
$pdf->writeHTMLCell(0, 0, '', '', $html, 0, 0, 0, true, '', true);   

$pdf->Output('Order-Invoice-'.$orderid.'.pdf', 'D');  
/*-------end of created pdf file---*/
		}
		else
		{
			redirect(base_url().'login');
		}
	}
/*--end of order invoice pdf----*/

/*----renew plan payment again----*/
	public function renewpayment($id="") 
	{		
		$current_date_time=date('Y-m-d H:i:s');	
		if($this->session->userdata('username')!='')
		{		
			
			$yearid=$this->session->userdata('loginyear');
			$user_id=$this->session->userdata('user_id');

			$data['year_id']=$yearid;
			$data['aatcount']=$this->exam_model->checkuser_aat_status($yearid,$user_id);
			$day=$this->input->post('sel_day');
			$sel_time=$this->input->post('sel_time');
			$center_id=$this->input->post('reg_center');
			/*-----send order to paypal-----*/
			$pertermweek=$this->input->post('week_id');
			$id=$this->input->post('planid');
			if($pertermweek!="" && $day!="" && $sel_time!="" && $center_id!="")
			{
			
			if($pertermweek)
			{
				
				$plandata=$this->plan_model->plan_details($id);
				if($plandata)
				{
						$userid=$this->session->userdata('user_id');
						$planinfo=$plandata[0];
						$data["plandetail"]=$plandata[0];
						$year=$this->uri->segment(3);
					
						$query_user=$this->db->query("select center_id from user_details  where user_id='".$userid."'  ");
						$yearchk=$query_user->row();
						$centerid=$yearchk->center_id;
						
						$createdate=date("Y-m-d H:i:s");
						$ord_data=array(
							'userid'=>$userid,
							'year_id'=>$yearid,
							'center_id'=>$centerid,
							'plan_id'=>$id,
							'amount'=>$planinfo->plan_price,
							'order_status'=>'inactive',
							'pay_status'=>'pending',
							'order_week'=>$planinfo->plan_week,
							'order_date'=>$createdate,
							);
						$orderid=$this->order_model->Save_Order($ord_data);	
						/*----insert specify order week----*/
						foreach($pertermweek as $key=>$value)
					{
						
						//array_push($termArr,$key);
						$countweek=1;	
						foreach($value as $weekdata)
						{
							if($weekdata!='')
							{	
							$ord_weeks=array(
									'ordweek_orderid'=>$orderid,
									'ordweek_userid'=>$userid,
									'ordweek_yearid'=>$yearid,
									'ordweek_termid'=>$key,
									'ordweek_weekid'=>$weekdata,
									'ordweek_paystatus'=>'pending',
									'ordweek_date'=>$createdate
									);
								$orderweekid=$this->order_model->Save_OrderWeeks($ord_weeks);
								$countweek++;
								
								
					//Temperory book seat

							   $whr="where year_id='".$yearid."' and center_id='".$center_id."' and day='".$day."' and time='".$sel_time."'";
								$qry_room_lists=$this->db->query("select * from class_schedule ".$whr."");
								$row_room_listss=$qry_room_lists->result();
							if($row_room_listss){
								
								foreach($row_room_listss as $row_room_list){
														
								$whr="class_schdl_id='".$row_room_list->id."' and room_no='".$row_room_list->room_no."' and term_id='".$key."' and week_id='".$weekdata."'";
								$row_room_lists=$this->main_model->get_where_row("classroom_booking",$whr);
								if($row_room_lists){

								if(($row_room_lists->room_available>0) && (strtotime($row_room_lists->class_schdl_date)>strtotime($current_date_time)))
								{
									
								$tmpbookroominfo=array(
										'class_r_b_id'=>$row_room_lists->id,
										'order_id'=>$orderid,
										'date'=>date('Y-m-d'),
										'user_id'=>$userid
										);
								$updatebookroom=$this->main_model->Save('temp_class_booking',$tmpbookroominfo);
								}
								else{
								$this->session->set_flashdata('success_msg', 'No seat available or class of selected week has been over');
									redirect(base_url().'membership-plan');	
									
								}



								}
								else{
								$this->session->set_flashdata('success_msg', 'No seat available or class of selected week has been over');
									redirect(base_url().'membership-plan');	
									
								}
								
								
								
								}	
								
							}
							else{
								$this->session->set_flashdata('success_msg', 'No class schedule');
									redirect(base_url().'membership-plan');	
									
							}
								

								
								
							}
						}
					}
				
						/*-----end of insert order per weeks---*/
						$queryweeks=$this->db->query('select count(*) as "totalweek" from order_weeks where ordweek_orderid="'.$orderid.'" ');
						$resweeks=$queryweeks->row();
						$totalweek= $resweeks->totalweek;
						if($totalweek!='')
						{	
						
						
						$amount_without_gst=$planinfo->plan_price*$totalweek;
						$gst=$amount_without_gst*15/100;
						$totalamount=$amount_without_gst+$gst;
						$totalamount=round($totalamount,2);
						
						$uord_data=array(						
						
							'amount_without_gst'=>$amount_without_gst,
							'amount_gst'=>$gst,
							'amount'=>$totalamount,
							'order_totalweek'=>$totalweek
							);
						$orderid2=$this->order_model->Update_Order($uord_data,$orderid);
						$data["totalamount"]=$totalamount;	
						}
						else
						{
							$del_oitem=$this->db->query("delete from order_weeks where ordweek_orderid='".$orderid."'" );
							$del_order=$this->db->query("delete from orders where orderid='".$orderid."'" );
							$this->session->set_flashdata('error','Select any one week of plan');
							redirect(base_url().'membership-plan');
						}
						
						/*----end of insert specify order week---*/
						
						$data["orderid"]=$orderid;	
					
					
				}
				else
				{
					redirect(base_url().'membership-plan');
				}
			
			$this->load->view('frontend/private/renew-plan',$data);
			}
			
			
			}
			else{
				$this->session->set_flashdata('success_msg', 'Please select all fields');
				redirect(base_url().'membership-plan');
			}
			}
			
			/*-----end of order send to paypal----*/
			
				
			//$data["planlist"] = $this->plan_model->plan_list($config["per_page"],$page);				
		else
		{
			redirect(base_url().'login');
		}
	
	}
	
	public function renewnotified() 
	{		
		define("DEBUG", 1);
		// Set to 0 once you're ready to go live
		define("USE_SANDBOX", 1);
		define("LOG_FILE", "ipn.log");
		// Read POST data
		// reading posted data directly from $_POST causes serialization
		// issues with array data in POST. Reading raw POST data from input stream instead.
		$raw_post_data = file_get_contents('php://input');
		$raw_post_array = explode('&', $raw_post_data);
		$myPost = array();
		foreach ($raw_post_array as $keyval) {
			$keyval = explode ('=', $keyval);
			if (count($keyval) == 2)
				$myPost[$keyval[0]] = urldecode($keyval[1]);
		}
		// read the post from PayPal system and add 'cmd'
		$req = 'cmd=_notify-validate';
		if(function_exists('get_magic_quotes_gpc')) {
			$get_magic_quotes_exists = true;
		}
		foreach ($myPost as $key => $value) {
			if($get_magic_quotes_exists == true && get_magic_quotes_gpc() == 1) {
				$value = urlencode(stripslashes($value));
			} else {
				$value = urlencode($value);
			}
			$req .= "&$key=$value";
		}
		// Post IPN data back to PayPal to validate the IPN data is genuine
		// Without this step anyone can fake IPN data
		if(USE_SANDBOX == true) {
			$paypal_url = "https://www.sandbox.paypal.com/cgi-bin/webscr";
		} else {
			$paypal_url = "https://www.paypal.com/cgi-bin/webscr";
		}
		$ch = curl_init($paypal_url);
		if ($ch == FALSE) {
			return FALSE;
		}
		curl_setopt($ch, CURLOPT_HTTP_VERSION, CURL_HTTP_VERSION_1_1);
		curl_setopt($ch, CURLOPT_POST, 1);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER,1);
		curl_setopt($ch, CURLOPT_POSTFIELDS, $req);
		curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 1);
		curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 2);
		curl_setopt($ch, CURLOPT_FORBID_REUSE, 1);
		if(DEBUG == true) {
			curl_setopt($ch, CURLOPT_HEADER, 1);
			curl_setopt($ch, CURLINFO_HEADER_OUT, 1);
		}
		// CONFIG: Optional proxy configuration
		//curl_setopt($ch, CURLOPT_PROXY, $proxy);
		//curl_setopt($ch, CURLOPT_HTTPPROXYTUNNEL, 1);
		// Set TCP timeout to 30 seconds
		curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 30);
		curl_setopt($ch, CURLOPT_HTTPHEADER, array('Connection: Close'));
		// CONFIG: Please download 'cacert.pem' from "http://curl.haxx.se/docs/caextract.html" and set the directory path
		// of the certificate as shown below. Ensure the file is readable by the webserver.
		// This is mandatory for some environments.
		//$cert = __DIR__ . "./cacert.pem";
		//curl_setopt($ch, CURLOPT_CAINFO, $cert);
		$res = curl_exec($ch);
		if (curl_errno($ch) != 0) // cURL error
			{
			if(DEBUG == true) {	
				error_log(date('[Y-m-d H:i e] '). "Can't connect to PayPal to validate IPN message: " . curl_error($ch) . PHP_EOL, 3, LOG_FILE);
			}
			curl_close($ch);
			exit;
		} else {
				// Log the entire HTTP response if debug is switched on.
				if(DEBUG == true) {
					error_log(date('[Y-m-d H:i e] '). "HTTP request of validation request:". curl_getinfo($ch, CURLINFO_HEADER_OUT) ." for IPN payload: $req" . PHP_EOL, 3, LOG_FILE);
					error_log(date('[Y-m-d H:i e] '). "HTTP response of validation request: $res" . PHP_EOL, 3, LOG_FILE);
				}
				curl_close($ch);
		}
		// Inspect IPN validation result and act accordingly
		// Split response headers and payload, a better way for strcmp
		$tokens = explode("\r\n\r\n", trim($res));
		$res = trim(end($tokens));
		if (strcmp ($res, "VERIFIED") == 0) 
		{
			// assign posted variables to local variables
			$item_name = $this->input->post('item_name');
			$item_number = $this->input->post('item_number');
			$payment_status = $this->input->post('payment_status');
			$payment_amount = $this->input->post('mc_gross');
			$payment_currency = $this->input->post('mc_currency');
			$txn_id = $this->input->post('txn_id');
			$receiver_email = $this->input->post('receiver_email');
			$payer_email = $this->input->post('payer_email');
			
		
			// check whether the payment_status is Completed
			$isPaymentCompleted = false;
			if($payment_status == "Completed") {
				$isPaymentCompleted = true;
			}
			// check that txn_id has not been previously processed
			/*$isUniqueTxnId = false; 
			$result = $db->selectQuery("SELECT * FROM payments WHERE txn_id = '$txn_id'");
			if(empty($result)) {
				$isUniqueTxnId = true;
			}
*/			
			// check that receiver_email is your PayPal email
			// check that payment_amount/payment_currency are correct
			if($isPaymentCompleted && $payment_currency == "USD") {
				$createdate=date("Y-m-d H:i:s");
				$ord_data=array(
							
							'order_status'=>'active',
							'pay_status'=>'confirm',
							'trans_id'=>$txn_id,
							'pay_date'=>$createdate
							);
						$orderid=$this->order_model->Update_Order($ord_data,$item_number);
						
						$query_ordinfo=$this->db->query("select * from orders  where orderid='".$item_number."' ");	
						$orderinfo=$query_ordinfo->row();
						if($orderinfo->userid !="")
						{
					   /*----update order weeks current year----*/
						$ord_weeks=array(			
						
							
							'ordweek_paystatus'=>'confirm'
							);
						$orderid2=$this->order_model->Update_OrderWeeks($ord_weeks,$item_number);
						/*----end of update order weeks current year---*/	
						
				//Change(Reduce) room capacity
					$date=date('Y-m-d');
					$whr="user_id=".$orderinfo->userid."  and order_id=".$item_number."";
					
					$row_tmpbooks=$this->main_model->get_where_result('temp_class_booking',$whr);
					foreach($row_tmpbooks as $row_tmpbook){				
					$row_book=$this->main_model->get_detail('classroom_booking','id',$row_tmpbook->class_r_b_id);	
					$week_id=$row_book->week_id;

					
					$room_avail=$row_book->room_available-1;	
					$bookroominfo=array(
								'room_available'=>$room_avail
								);
					$this->main_model->Update('classroom_booking',$bookroominfo,'id',$row_tmpbook->class_r_b_id);
					
					
					
					//Get order week_id
					$whr="ordweek_weekid=".$week_id." and ordweek_orderid=".$item_number."";
					
					$row_orderweek=$this->main_model->get_where_row('order_weeks',$whr);
					//Save seat allotment info
					
					$bookseatinfo=array(
								'id'=>'',
								'user_id'=>$orderinfo->userid,
								'date'=>$date,
								'class_schdl_id'=>$row_book->class_schdl_id,
								'classroom_booking_id'=>$row_tmpbook->class_r_b_id,
								'order_id'=>$item_number,
								'order_week_id'=>$row_orderweek->ordweek_id
								);
					
					$this->main_model->Save('seat_allotment_info',$bookseatinfo);
					$this->db->reset_query();
					}
					/*-----end of update center stock---*/
					
				//Send order mail to user 	
				$result=$orderinfo;
				$this->load->library('email');
				$config = array (
					'mailtype' => 'html',
					'charset' => 'utf-8',
					'priority' => '1'
					);
					$this->email->initialize($config);
					
					$user_details=$this->main_model->get_detail('user_details','user_id',$orderinfo->userid);
					
					
					
					$senderemail=$user_details->email;
		
		
		$expirydate="";
		$orddb="";
		if($result!= null && $result!= ""){		
		 
		  
			$plan_name=$this->plan_model->GetPlanName($result->plan_id);
			/*----expired order plan------*/
			$expirydate=strtotime("+".$result->order_week." week", strtotime($result->order_date));
			if($today > $expirydate)
			{
				$orddb=array('order_status'=>'expired');				
				$this->order_model->Update_Order($orddb,$result->orderid);
			}
		
	$row_centerdetail= $this->main_model->get_detail('centerlocation','center_id',$result->center_id);
		$year_dtl=$this->main_model->get_detail('master_class','class_id',$user_details->year_id);
$mail_html='<!DOCTYPE HTML>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>My Uni Education Group Ltd</title>
<style>
* {
	margin:0px;
	padding:0px;
}
html, body {
	margin:0px;
	padding:0px;
	font-size:18px;
	line-height:20px;
	font-family:Arial, Helvetica, sans-serif; 
	color:#000;
}
img {
	max-width:100%;
}
h3 {
	font-size:24px;
	font-weight:normal;
}
.container {
	width:80%;
	margin:0 auto;
	max-width:600px;
	padding:0px;
}

.btn {
	background:#005e82;
	padding:5px;
	display: inline-block;
	color: #fff;
	text-decoration: none;
	width:120px;
}
.footer {
	text-align:left;
	font-size:12px;
	font-weight:bolder;
	line-height:18px;
	width:100%;
	float:left;
	background: #000;
	color: #fff;
	padding:15px;
	box-sizing: border-box;
}
.footer .detail strong {
	font-size:16px;
	font-weight:bolder;
	line-height:22px;
}
.footer .detail strong i {
	font-size:12px;
	text-transform:uppercase;
}

strong {
	font-weight:bold;
}
 .tableBox tr:nth-child(even) {
 background:#f2f2f2;
}
table {
	font-size:14px; 
}
table p {
	font-size:12pt;
	line-height:25px;
	padding-bottom:5px;
}
table h2 {
	padding: 0 0 12px 0;
	font-weight: 400;
	font-size:22px;
}
.footer .detail td p {
	padding-bottom:0px;
	font-size:14px; 
	line-height:20px;
}
table .tableBox {
	font-size:14px;
}
 
table .tableBox td {
	padding-left:8px;
	line-height:32px;
}

table .tableBox td  p{ padding-bottom:0px; font-size:14px;}

table h3 {
	font-size:24px;
	line-height: 32px;
	color:#FFF;
	font-weight:700;
}
.footer-text{ padding:0 10px;}
.footer-text p{color:#fff; padding-bottom:0px; font-size:10pt; line-height:17px;}
.footer-text p a{color:#fff;}
table p{ padding:0 15px;}
.footer-text p{ padding:0px;}
.left-padding-15{ padding-left:15px;}
 @media only screen and (max-width:400px) {
	 .btn{ margin-bottom:15px;}
	 .container {
	width:70%;
	margin:0 auto;
	max-width:320px;
	padding:0px;
}


}
</style>
</head>

<body style="background:#d0d0d0;">
<table width="100%" border="0" cellspacing="0" cellpadding="0" class="container" bgcolor="#ffffff">
  <tr bgcolor="#d0d0d0">
    <td height="15"></td>
  </tr>
  <tr>
    <td><table width="100%" border="0" cellspacing="15" cellpadding="0">
        <tr>
          <td align="center"><a href="'.base_url().'"><img src="'.base_url().'assets/images/logo.png'.'" alt="" width="156" height="134" /></a></td>
        </tr>
      </table></td>
  </tr>

  <tr>
    <td align="center" valign="top" bgcolor="#f4f4f4"><table width="85%" border="0" align="center" cellpadding="0" cellspacing="0">
      <tr>
        <td height="10"></td>
      </tr>
      <tr>
        <td>&nbsp;</td>
      </tr>
      <tr>
        <td><p>Dear  Parent/Guardian  and Student,</p></td>
      </tr>
      <tr>
        <td height="15"></td>
      </tr>
      <tr>
        <td><p>We  are very pleased to have '.$user_details->first_name.'  booked into the classes below:</p></td>
      </tr>
      <tr>
        <td height="15"></td>
      </tr>
      <tr>
        <td class="left-padding-15"><table width="500" border="0" cellspacing="0" cellpadding="0">
          <tr>
            <td width="175" valign="top"><strong>Reference Number : </strong></td>
            <td width="275" valign="top">'.$result->orderid.'</td>
            </tr>
          <tr>
            <td height="8" valign="top"></td>
            <td height="8" valign="top"></td>
          </tr>
		  <tr>
            <td width="175" valign="top"><strong>Transaction Id : </strong></td>
            <td width="275" valign="top">'.$txn_id.'</td>
            </tr>
          <tr>
            <td height="8" valign="top"></td>
            <td height="8" valign="top"></td>
          </tr>
          <tr>
            <td valign="top"><strong>Student&rsquo;s Name : </strong></td>
            <td valign="top">'.$user_details->first_name.' '.$user_details->last_name.'</td>
          </tr>
          <tr>
            <td height="8" valign="top"></td>
            <td height="8" valign="top"></td>
          </tr>
          <tr>
            <td valign="top"><strong>Student&rsquo;s ID : </strong></td>
            <td valign="top"><strong></strong>'.$user_details->user_id.'</td>
          </tr>
          <tr>
            <td height="8" valign="top"></td>
            <td height="8" valign="top"></td>
          </tr>
          <tr>
            <td valign="top"><strong>Registered Subject : </strong></td>
            <td valign="top">The University of English</td>
          </tr>
          <tr>
            <td height="8" valign="top"></td>
            <td height="8" valign="top"></td>
          </tr>
          <tr>
            <td valign="top"><strong>MY UNIYear :</strong></td>
			
            <td valign="top"><strong>'.$year_dtl->class_name.'</strong></td>
          </tr>
          <tr>
            <td height="8" valign="top"></td>
            <td height="8" valign="top"></td>
          </tr>
          <tr>
            <td valign="top"><strong>ClassesEnrolled :</strong></td>
            <td valign="top"><strong></strong>For class enrolled please see invoice</td>
          </tr>
          <tr>
            <td height="8" valign="top"></td>
            <td height="8" valign="top"></td>
          </tr>
          <tr>
            <td valign="top"><strong>Tution Fee:</strong></td>
            <td valign="top">'.$result->amount.'</td>
          </tr>
          <tr>
            <td height="8" valign="top"></td>
            <td height="8" valign="top"></td>
          </tr>
          <tr>
            <td valign="top"><strong>Centre :</strong></td>
            <td valign="top"><p>'.$row_centerdetail->center_address.', '.$row_centerdetail->center_city.', '.$row_centerdetail->center_zip.'</p></td>
          </tr>
          </table></td>
      </tr>
      <tr class="container">
        <td height="15" align="center"></td>
      </tr>
      <tr>
        <td><p>For more information, please visit our subject website <a href="'.base_url().'">'.base_url().'</a></p></td>
      </tr>
      <tr>
        <td height="15"></td>
      </tr>
      <tr>
        <td><p>If you have any questions please contact us on 022 645  8491 or email us at <a href="mailto:ask@myunieducation.com">ask@myunieducation.com</a>.  Please DO NOT reply to this email as it is an  auto-generated message.</p></td>
      </tr>
      <tr>
        <td>&nbsp;</td>
      </tr>
      <tr>
        <td height="10"></td>
      </tr>
    </table></td>
  </tr>
  
  <tr bgcolor="#69c4a9">
    <td height="15" align="center" bgcolor="#485052"></td>
  </tr>
  <tr bgcolor="#69c4a9">
    <td height="15" align="left" bgcolor="#485052"  style="padding:10px;"><img src="https://www.myunieducation.com/wp-content/themes/myunieducation/images/logo.png" alt="" width="111" height="111" /></td>
  </tr>
  <tr bgcolor="#69c4a9">
    <td align="left" bgcolor="#485052" style="padding:10px;"><h3>MY UNI EDUCATION GROUP LIMITED</h3></td>
  </tr>
  <tr bgcolor="#485052">
    <td align="center" style="padding:0px;"><table width="100%" border="0" align="center" cellpadding="0" cellspacing="0">
      <tr>
        <td align="left" bgcolor="#485052" class="footer-text"><p><strong>Tel:</strong> (+64) 022 645 8491</p>
          <p><strong>Email:</strong> <a href="mailto:ask@myunieducation.com">ask@myunieducation.com</a></p>
          <p><strong>Headquarters  Address:</strong> 2A Wagener Place, Mt Albert, Auckland, 1025, New Zealand</p>
          <p><strong>Website:</strong> <a href="http://www.myunieducation.com">www.myunieducation.com</a></p></td>
      </tr>
      <tr>
        <td align="left" bgcolor="#485052" class="footer-text">&nbsp;</td>
      </tr>
    </table></td>
  </tr>
 
</table>
</body>
</html>';		
					$body = $mail_html;
					$this->email->from(basic_from_email, basic_from_name);
					$this->email->to($senderemail);
					$this->email->subject(order_subject);
					$this->email->message($body);
					$this->email->send();				
					
					 
					
					/*-----end of update center stock---*/
			
		}	
			
			
			
			
			}
			
			}
			// process payment and mark item as paid.
			
			
			if(DEBUG == true) {
				error_log(date('[Y-m-d H:i e] '). "Verified IPN: $req ". PHP_EOL, 3, LOG_FILE);
			}
			
		} else if (strcmp ($res, "INVALID") == 0) {
			// log for manual investigation
			// Add business logic here which deals with invalid IPN messages
			if(DEBUG == true) {
				error_log(date('[Y-m-d H:i e] '). "Invalid IPN: $req" . PHP_EOL, 3, LOG_FILE);
			}
		}
	}
		
	public function renewthank() 
	{		
		if($this->session->userdata('username')!='')
		{		
			
			$yearid=$this->session->userdata('loginyear');
			$user_id=$this->session->userdata('user_id');
			$data['year_id']=$yearid;
			$data['aatcount']=$this->exam_model->checkuser_aat_status($yearid,$user_id);
			$this->load->view('frontend/private/renew-thank',$data);
			//$this->session->unset_userdata('username');
		//$this->session->unset_userdata('user_id');
		//$this->session->sess_destroy();
		}
		else
		{
			redirect(base_url().'login');
		}
	
	}
/*-----end of renew plan payment again-----*/
	
	
	
/* ---------------- function exam 	 --------------------*/
	public function exam() 
	{
		
		
		$yearid=$this->session->userdata('loginyear');
		
		$yeardata=$this->classes_model->classes_details($yearid);
		if($yeardata)
		{
			$data['year_name']=$yeardata[0]->class_name;
			$data['year_slug']=$yeardata[0]->class_slug;
			$year_id=$yeardata[0]->class_id;
		}

		$data['year_id']=$year_id;
		$userid2=$this->session->userdata('user_id');			
		$data['aatcount']=$this->exam_model->checkuser_aat_status($yearid,$userid2);
		$this->questions_model->CLASSID = $year_id;
		$data["year_dtl"] = $this->main_model->get_detail('master_class','class_id',$year_id);	
		$data['subskill']=$subskill;
		
		$userid=$this->session->userdata('user_id');
		$this->session->set_userdata('ansattempt', '0');
		
		/*---check user not applied question list---*/
		$userexams=$this->questions_model->check_uexambyyear($userid,$year_id);
		if($userexams->exam_id!="" && $userexams->exam_status=='pending')
		{	
			$this->db->query('delete from sexam_history where user_id="'.$userid.'" and year_id="'.$year_id.'" and term_id="'.$userexams->term_id.'" and attempt="'.$userexams->attempt.'"');
			$this->db->query('delete from student_exam where exam_id="'.$userexams->exam_id.'"');			
			$data['attempt']=$userexams->attempt;
			$exam_attampt=$userexams->attempt;
		}
		elseif($userexams->exam_id!="" && $userexams->exam_status=='done')
		{
			$exam_attampt=$userexams->attempt+1;
			$data['attempt']=$exam_attampt;
		}
		else{
			$data['attempt']=1;
			$exam_attampt=1;
		}
		
		//maximum attempt is 5
		if($exam_attampt>5)
		{
			$data['no_exam']=2;
		}
		
		
		$check_termexam_date=$this->questions_model->check_termexam_date($year_id);

		if(isset($check_termexam_date) && $check_termexam_date->date!="0000-00-00 00:00:00")
		{	
			$cur_date=date("m/d/Y");
			$date=date("m/d/Y", strtotime($check_termexam_date->date));
			if($date<=$cur_date){
			$data['term_id']=$check_termexam_date->term_id;
			
			}
			else{ $data['no_exam']=1;}
		}
		else
		{
			$data['no_exam']=1;
		}

		/*----Get user exam question array------*/
		if($data['no_exam']!="1" && $data['no_exam']!="2"){
		$exam_questermArr=array(0);
		$randquestion=$this->questions_model->get_exam_question($year_id,$check_termexam_date->term_id,$exam_questermArr);
		/*---End of check user not applied question list---*/
		$data['FirstQuestion']=$randquestion->question_id;
		}
		$this->load->view('frontend/private/examplay',$data);
		
		
	}

	//Attempt exam
	public	function attemp_exam($id="")
	{
		if($exam_id)
				{
					
					
					$data['exam_details']=$this->students_model->exam_details($exam_id);
					
				}
		$this->load->view('frontend/private/attemp_history',$data);
	}

	
	
	//Analysys report
	public	function analysis_report($id="")
	{
		
		
			
		if($this->session->userdata('username')!='')
		{		
			$user_id=$this->session->userdata('user_id');
			$yearid=$this->session->userdata('loginyear');
					
			 $data['year_id']=$yearid;			
			 $data['user_id']=$user_id;			 
		
			$data['aatcount']=$this->exam_model->checkuser_aat_status($yearid,$user_id);
			
			$yeardata=$this->classes_model->classes_details($yearid);
			if($yeardata)
			{
				$data['year_name']=$yeardata[0]->class_name;
				$data['year_slug']=$yeardata[0]->class_slug;
			}
			$data['aatcount']=$this->exam_model->checkuser_aat_status($yearid,$user_id);
			$this->load->view('frontend/private/analysis-report',$data);
		}
		else
		{
			redirect(base_url().'login');
		}
	
	}

/*-----Birthday Reminder------*/
	public function birthday() 
	{
		$sqlbirth="SELECT `user_id`, `email`,`first_name`,`last_name`, `dob`,
    DATE_ADD(
        dob, 
        INTERVAL IF(DAYOFYEAR(dob) >= DAYOFYEAR(CURDATE()),
            YEAR(CURDATE())-YEAR(dob),
            YEAR(CURDATE())-YEAR(dob)+1
        ) YEAR
    ) AS `next_birthday`
FROM `user_details` 
WHERE 
    `dob` IS NOT NULL
HAVING 
    `next_birthday` BETWEEN CURDATE() AND DATE_ADD(CURDATE(), INTERVAL 0 DAY)
ORDER BY `next_birthday`
";
$birth_query=$this->db->query($sqlbirth);
$num_birth=$birth_query->num_rows();
if($num_birth > 0)
{	
	
	$this->load->library('email');
				$config = array (
				'mailtype' => 'html',
				'charset' => 'utf-8',
				'priority' => '1'
				);
	$this->email->initialize($config);
	$row_birth=$birth_query->result();
	foreach($row_birth as $rowbirth)
	{
		
		
				
				$senderemail=$rowbirth->email;
				$data1['first_name']=$rowbirth->first_name;
				$data1['last_name']=$rowbirth->last_name;
				$data1['fullname']=$rowbirth->first_name.' '.$rowbirth->last_name;
				$body = $this->load->view('emails/birthday-wishes',$data1,TRUE);
				$this->email->from(basic_from_email, basic_from_name);
				$this->email->to($senderemail);
				$this->email->subject(birthday_subject);
				$this->email->message($body);
				$this->email->send();
		
	}
}

	}
	/*-----End of birthday Reminder-----*/
	public function studentmonthlyexamsheet($month) 
	{
		
		
		$data = array();
		if($this->session->userdata('username')!='')
		{		
			 
			$data['month']=$month;
			$data['mymonth']=date('m',strtotime($month));
			 $yearid=$this->session->userdata('loginyear');
			 $data['year_id']=$yearid;
			 	$yeardata=$this->classes_model->classes_details($yearid);
			if($yeardata)
			{
				$data['year_name']=$yeardata[0]->class_name;
				$data['year_slug']=$yeardata[0]->class_slug;
			}
			 
			 $user_id=$this->session->userdata('user_id');
			 $data['user_id']=$user_id;			 
		
			$data['aatcount']=$this->exam_model->checkuser_aat_status($yearid,$user_id);
			$term_query=$this->db->query('select * from yearterm_date where year_id = "'.$yearid.'" and year(term_date) = year(curdate())
			and month(term_date) = month(curdate())
			'); 
			$num_termdate=$term_query->num_rows();
			if($num_termdate > 0)
			{	
			$row_termdate=$term_query->row();
			$current_term=$row_termdate->term_id;
			}
			 $data['student_details']=$this->main_model->get_selected_details('user_details',$columns=array('user_id','first_name','last_name','year_id','center_id','dob'),$where=array('user_id'=>$this->session->userdata('user_id')),'single',$obj=true);
			
			 $data["SylList1"] = $this->main_model->get_selected_details('syllabus_week_subskill',$columns=array('skill_id','subskill_id','week_id','subskill_order','goal_id'),$where=array('year_id'=>$yearid,'week_id <'=> 5, 'term_id'=>$current_term),'multiple',$obj=true);
			$this->load->view('frontend/private/monthly-report',$data);
		}
		else
		{
			redirect(base_url().'login');
		}
	
	}
	
/*----All month report----*/
	public function allmonthreport() 
	{
		//$data = array();
		if($this->session->userdata('username')!='')
		{		
			 $yearid=$this->session->userdata('loginyear');
			 $data['year_id']=$yearid;
			 $userid=$this->session->userdata('user_id');
			 $data['user_id']=$userid;	
			 $yeardata=$this->classes_model->classes_details($yearid);
			if($yeardata)
			{
				$data['year_name']=$yeardata[0]->class_name;
				$data['year_slug']=$yeardata[0]->class_slug;
			}
			 
				
			$data['aatcount']=$this->exam_model->checkuser_aat_status($yearid,$userid);
				 $term_query=$this->db->query('select * from yearterm_date where year_id = "'.$yearid.'" and year(term_date) = year(curdate())
			and month(term_date) = month(curdate())
			'); 
			$num_termdate=$term_query->num_rows();
			if($num_termdate > 0)
			{	
			$row_termdate=$term_query->row();
			
			/*----Check user current week status----*/
			 
			 	$current_term=$row_termdate->term_id;
				$data['term_id']=$current_term;
			}
			$this->load->view('frontend/private/all-month-report',$data);
		}
		else
		{
			redirect(base_url().'login');
		}
	
	}
/*-----All month report-----*/		
	public function show_pdf($year,$pdf_name){
		
		$data["year_dtl"] = $this->main_model->get_detail('master_class','class_slug',$year);	
		$year_id=$data["year_dtl"]->class_id;
		$data['file_name']=trim($pdf_name);
		if($this->session->userdata('loginyear')!="" || ($this->session->userdata('user_type')=='1'))
		{
			$years=explode(',',$this->session->userdata('loginyear'));
			if(in_array($year_id,$years))
			{
				
				$data['pdf_path'] = 'assets/uploads/notes/'.$pdf_name;
				$this->load->view('frontend/private/pdf_viewer',$data);
				
			}
			elseif($this->session->userdata('user_type')=='1'){
				$data['pdf_path'] = 'assets/uploads/notes/'.$pdf_name;
				$this->load->view('frontend/private/pdf_viewer',$data);
			}
			else{
				redirect(base_url());
			}
		}
	}
/*----All weeks report----*/
	public function allweeksreport() 
	{
		//$data = array();
		if($this->session->userdata('username')!='')
		{		
			 $yearid=$this->session->userdata('loginyear');
			 $data['year_id']=$yearid;
			 $userid=$this->session->userdata('user_id');
			 $data['user_id']=$userid;	
			 $yeardata=$this->classes_model->classes_details($yearid);
			if($yeardata)
			{
				$data['year_name']=$yeardata[0]->class_name;
				$data['year_slug']=$yeardata[0]->class_slug;
			}
			 
				
			$data['aatcount']=$this->exam_model->checkuser_aat_status($yearid,$userid);
				 $term_query=$this->db->query('select * from yearterm_date where year_id = "'.$yearid.'" and year(term_date) = year(curdate())
			and month(term_date) = month(curdate())
			'); 
			$num_termdate=$term_query->num_rows();
			if($num_termdate > 0)
			{	
			$row_termdate=$term_query->row();
			
			/*----Check user current week status----*/
			 
			 	$current_term=$row_termdate->term_id;
				$data['term_id']=$current_term;
				$termdate=date('m/d/Y',strtotime($row_termdate->term_date));
				$data['dbdate']=$row_termdate->term_date;
				$data['termdate']=$termdate;
				$currentdate=date('m/d/Y');
				if($termdate==$currentdate)
				{
					$currentweek=1;
				}
				else
				{					
					$currentweek=$this->week_between_two_dates($termdate, $currentdate);
					$currentweek=$currentweek+1;
				
				}
				$data['userweek']=$currentweek;
				
			}
			$this->load->view('frontend/private/all-weeks-report',$data);
		}
		else
		{
			redirect(base_url().'login');
		}
	
	}
	public function studentweeklyexamsheet($week) 
	{
		
		
		$data = array();
		if($this->session->userdata('username')!='')
		{		
			 
			$data['week']=$week;
			//$data['mymonth']=date('m',strtotime($month));
			 $yearid=$this->session->userdata('loginyear');
			 $data['year_id']=$yearid;
			 	$yeardata=$this->classes_model->classes_details($yearid);
			if($yeardata)
			{
				$data['year_name']=$yeardata[0]->class_name;
				$data['year_slug']=$yeardata[0]->class_slug;
			}
			 
			 $user_id=$this->session->userdata('user_id');
			 $data['user_id']=$user_id;			 
		
			$data['aatcount']=$this->exam_model->checkuser_aat_status($yearid,$user_id);
			 $data['student_details']=$this->main_model->get_selected_details('user_details',$columns=array('user_id','first_name','last_name','year_id','center_id','dob'),$where=array('user_id'=>$this->session->userdata('user_id')),'single',$obj=true);
			
			$term_query=$this->db->query('select * from yearterm_date where year_id = "'.$yearid.'" and year(term_date) = year(curdate())
			and month(term_date) = month(curdate())
			'); 
			$num_termdate=$term_query->num_rows();
			if($num_termdate > 0)
			{	
			$row_termdate=$term_query->row();
			
			/*----Check user current week status----*/
			 
			 	$current_term=$row_termdate->term_id;
				$data['term_id']=$current_term;
				$termdate=date('m/d/Y',strtotime($row_termdate->term_date));
				$data['term_id']=$current_term;				
				$data['dbdate']=$row_termdate->term_date;
				$data['termdate']=$termdate;
			 
			 $data["SylList1"] = $this->main_model->get_selected_details('syllabus_week_subskill',$columns=array('skill_id','subskill_id','week_id','subskill_order','goal_id'),$where=array('year_id'=>$yearid,'week_id '=> $week, 'term_id'=>$current_term),'multiple',$obj=true);
			}
			else
			{
				$data["SylList1"]="";
			}
			$this->load->view('frontend/private/weekly-report',$data);
		}
		else
		{
			redirect(base_url().'login');
		}
	
	}	
/*-----All weeks report-----*/
public function chk_phone($phone) 
{		
	$re = '/^(?:(?:\(?(?:00|\+)([1-4]\d\d|[1-9]\d?)\)?)?[\-\.\ \\\\\/]?)?((?:\(?\d{1,}\)?[\-\.\ \\\\\/]?){0,})(?:[\-\.\ \\\\\/]?(?:#|ext\.?|extension|x)[\-\.\ \\\\\/]?(\d+))?$/';
if(preg_match($re, $phone, $matches, PREG_OFFSET_CAPTURE,0))
{return true;}
else{
 $this->form_validation->set_message('chk_phone', 'The Phone field is not in the correct format.');
 return false;
};
	
}	
public function week_between_two_dates($date1, $date2)
	{
		
		
		$first = DateTime::createFromFormat('m/d/Y', $date1);
		$second = DateTime::createFromFormat('m/d/Y', $date2);
		if($date1 > $date2) return $this->week_between_two_dates($date2, $date1);
		return floor($first->diff($second)->days/7);
	}
	
}
