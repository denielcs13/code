<?php
defined('BASEPATH') OR exit('No direct script access allowed');
error_reporting(E_ALL);
ini_set('display_errors',1);
header('Content-type: text/html; charset=utf-8');
class Unieducation extends MY_Controller {

	public function __construct()
    {
		parent::__construct();
			$this->load->library(array('session'));
			
			$this->load->helper('form');
            $this->load->helper('question');
            $this->load->helper('question_helper');
			$this->load->helper('get_counter_helper');
			$this->load->helper(array('url','form'));
			$this->load->model('Login_model');	
			date_default_timezone_set('Pacific/Auckland');
			$this->load->library("pagination");			
			$this->load->library('form_validation');
			if($this->uri->segment(1)=='order-history')
			{
				
				if($this->session->userdata('user_id')!="")
				{
					$sqlchkuyear=$this->db->query("select year_id from user_details where user_id='".$this->session->userdata('user_id')."'");
					$row_chkuyear=$sqlchkuyear->row();					
					$this->session->set_userdata('loginyear', $row_chkuyear->year_id);			
					
					
				}
			}
			/*---end of after ats payment update user current year---*/
			
    }
	public function index($sub="",$year='')
	{	
	
		
        if($this->uri->segment(1)=='math')
        {
        $obj=$this->math;
        $data["obj"]= $obj;  
        }elseif($this->uri->segment(1)=='english'){
         $obj=$this->english;
         $objdata["obj"]= $obj;     
        }	
		
        if($year!="")
        {
			$data["year"]=$year;
			$data["year_dtl"] = $this->main_model->get_detail('master_class','class_slug',$year);	
			$year_id=$data["year_dtl"]->class_id;
			$this->questions_model->CLASSID = $year_id;
			$data["year"]=$year;
		}
		
		
		  
		$data['error']='';
		$this->load->view('frontend/public/index',$data);
		
	}
    public function _404(){
		$this->load->view("frontend/public/404");
	}
public function math($year="",$slug=""){
		if($this->session->userdata('profile_update')=='no')
        {
            redirect(base_url('profile-update')); 
        }
        if($this->uri->segment(1)=='math')
                {
                $obj=$this->math;
                $objdata["obj"]= $obj;  
                }elseif($this->uri->segment(1)=='english'){
                 $obj=$this->english;
                 $objdata['obj'];   
                }
                $year=$this->uri->segment(2);
                $data['class_slug']=$year;
                $data['year']=$this->uri->segment(2);
                
                $year_id=$this->main_model->getsid(TBL_CLASS,$objdata['obj'],$year); 
                $data['year_id']=$year_id;
                $data['year_dtl']=$this->main_model->get_detail($obj,TBL_CLASS,array('class_id'=>$year_id),"single");
                $data['SylList']=$this->main_model->get_detail($obj,'master_skill',array('skill_class'=>$year_id,'skill_parent'=>'0'),$insgle=null,'skill_order','asc');
                if($slug)
                {
                    
                    $subskill=$this->uri->segment(3);
                    $data['subskill']=$subskill;
                    $skill=$this->main_model->get_detail($obj,'master_skill',array('skill_class'=>$year_id,'skill_slug'=>$subskill),"single");
                    $data['skill']=$skill;
                    //$this->main_model->getall($obj,'manage_question','*',$col=null,$data['paging']["limit"], $data['paging']['offset']);
                    //unset value
                    $this->session->set_userdata('attempt', '0');
                    $ansattempt = $this->session->set_userdata('ansattempt','0');
                    //unset value
                    $data["Questionlist"] = $this->main_model->random_question($obj,$year_id,$skill->skill_id);
					$this->load->view('frontend/public/header',$objdata);
                    $this->load->view('frontend/private/play',$data);
                    $this->load->view('frontend/public/footer');
                    
                }else{
                   $this->load->view('frontend/public/header',$objdata);
                   $this->load->view('frontend/public/syllabus_list',$data);
                   $this->load->view('frontend/public/footer',$data);
                }
	}
public function english($year="",$slug=""){
		
        if($this->session->userdata('profile_update')=='no')
        {
            redirect(base_url('profile-update')); 
        }
        if($this->uri->segment(1)=='math')
                {
                $obj=$this->math;
                $objdata["obj"]= $obj;  
                }elseif($this->uri->segment(1)=='english'){
                 $obj=$this->english;
                 $objdata["obj"]= $obj;  
                }
                $year=$this->uri->segment(2);
                $data['year']=$this->uri->segment(2);
                
                $year_id=$this->main_model->getsid(TBL_CLASS,$objdata['obj'],$year); 
                $data['year_id']=$year_id;
                $data['year_dtl']=$this->main_model->get_detail($obj,TBL_CLASS,array('class_id'=>$year_id),"single");
                $data['SylList']=$this->main_model->get_detail($obj,'master_skill',array('skill_class'=>$year_id,'skill_parent'=>'0'),$insgle=null,'skill_order','asc');
                
                if($slug)
                {
                    
                    $subskill=$this->uri->segment(3);
                    $data['subskill']=$subskill;
                    $skill=$this->main_model->get_detail($obj,'master_skill',array('skill_class'=>$year_id,'skill_slug'=>$subskill),"single");
                    $data['skill']=$skill;
                    //$this->main_model->getall($obj,'manage_question','*',$col=null,$data['paging']["limit"], $data['paging']['offset']);
                    //unset value
                    $this->session->set_userdata('attempt', '0');
                    $ansattempt = $this->session->set_userdata('ansattempt','0');
                    //unset value
                    $data["Questionlist"] = $this->main_model->random_question($obj,$year_id,$skill->skill_id);
					$this->load->view('frontend/public/header',$objdata);
                    $this->load->view('frontend/private/play',$data);
                    $this->load->view('frontend/public/footer');
                    
                }else{
                   $this->load->view('frontend/public/header',$objdata);
                   $this->load->view('frontend/public/syllabus_list',$data);
                   $this->load->view('frontend/public/footer',$data);
                }
	}
public function random_password() 
	{
		$alphabet = 'abcdefghijkmnopqrstuvwxyzABCDEFGHJKLMNOPQRSTUVWXYZ1234567890';
		$password = array(); 
		$alpha_length = strlen($alphabet) - 1; 
		for ($i = 0; $i < 8; $i++) 
		{
			$n = rand(0, $alpha_length);
			$password[] = $alphabet[$n];
		}
		return implode($password); 
	}
    

public function register() 
	{		
		$this->form_validation->set_rules('reg_email', 'Student�s Email', 'required|valid_email|is_unique[main_user.email]|callback_checkEmail');	
		$this->form_validation->set_rules('reg_fname', 'Student�s First Name', 'required');
		$this->form_validation->set_rules('reg_lname', 'Student�s Last Name', 'required');
		if($this->form_validation->run())
		{	
			//Check mail existence
			/* $row_user=$this->main_model->get_detail('user_details','email',$this->input->post('reg_email'));
			if($row_user->user_id!=""){
				$this->session->set_flashdata('msg','This email id already exist');
			} */
			
			$createdate=date("Y-m-d H:i:s");
			$password=$this->random_password();
			
			$user_data=array(
							'email'=>$this->input->post('reg_email'),
							'user_type'=>'6',
							'first_name'=>$this->input->post('reg_fname'),							
							'last_name'=>$this->input->post('reg_lname'),							
							'edate'=>$createdate,
							'status'=>'1',
							'password'=>md5($password),
							);
            
            $last_insert_is=$this->main_model->save($this->db,'temp_main_user',$user_data);
            if($last_insert_is)
            {
                $senderemail=$this->input->post('reg_email');
				$emailarr=explode('@',$senderemail);
				global $class_arr;
				$username=$emailarr[0].'M'.$class_arr[date('Y')].rand(10,99);
				/*----update user id----*/
				$r=false;
				while($r==false){
					$row_uname=$this->main_model->get_detail($this->db,'temp_main_user',array('user_name'=>$username),'single');
					if($row_uname==""){
						$r=true;
					}
					else{
						$username=$emailarr[0].'M'.$class_arr[date('Y')].rand(10,99);
					}
				} 
				$username_data=array(
				'user_name'=>$username							
				);
               $this->main_model->update($this->db,'temp_main_user',$username_data,array('user_id'=>$last_insert_is)); 	
	        } 
			$data['firstname']=$this->input->post('reg_fname');
			$data['fullname']=$this->input->post('reg_fname').' '.$this->input->post('reg_lname');
			$data['username']=$username;
			$data['password']=$password;
			$body = $this->load->view('emails/signup-to-student',$data,TRUE);
			$this->e_mail($senderemail,basic_from_email,basic_from_name,register_subject,$body);
			redirect(base_url('registered'));
    }
        $this->load->view('frontend/public/header');
		$this->load->view('frontend/public/register');
        $this->load->view('frontend/public/footer');
		
  }
 public function checkEmail($email)
		{
			
			
			if($email !="")
			{	
			
			 $pricedata=$this->main_model->student_emailcheck($email);	
			//var_dump($pricedata);
			 if($pricedata > 0)
			 {
				 
				  $this->form_validation->set_message('checkEmail', 'Email already registered with us');
                 return false;
			 }
			 else
			 {
				 
                 return true;
			 }
			}
			else
			{
				
                $this->form_validation->set_message('checkEmail', 'Enter valid email id');
                 return false;
			}	
			
		}
public function login()
	{
		
		$this->form_validation->set_rules('username', 'login ID', 'required');
		$this->form_validation->set_rules('password', 'Password', 'required');		
		if($this->form_validation->run())
		{
			
			$username = $this->input->post('username');
			$password = $this->input->post('password');
			$res=$res=$this->main_model->signin($username,$password);			
			
			if ($res) 
			{	
                if ($res->login_status=='no')
                {
				if($res->lastlogin!='' && $res->lastlogin!=null)
				{	
					$lastlogintime = strtotime($res->lastlogin);				
					$mylastlogin = date("m/d/y g:i A", $lastlogintime);
				}
				else
				{
					$mylastlogin='';
				}
                
				if($res->profile_update=='no')
                {
                    $updateLoginStatus=$this->main_model->Update($this->db,'temp_main_user',array('login_status'=>'yes','last_login_deviceid'=>$_SERVER['REMOTE_ADDR']),array('user_id'=>$res->user_id));
                }else{
                    
                  $updateLoginStatus=$this->main_model->Update($this->db,'main_user',array('login_status'=>'yes','last_login_deviceid'=>$_SERVER['REMOTE_ADDR']),array('user_id'=>$res->user_id));  
                }
				$userlogindata = array( 
									'username' => $res->user_name,
									'logged_in' => true,
									'user_id' => $res->user_id,
									'email' => $res->email,
									'user_type'=>$res->user_type,
									'fullname'=>$res->first_name.' '.$res->last_name,
									//'lastlogedin'=>$mylastlogin,
									'profile_update'=>$res->profile_update,
                                    'login_status'=>'yes',
                                    'login_deviceid'=>$res->last_login_deviceid,
                                    'last_active_time'=>$res->last_active_time,
									);						
				$this->session->set_userdata($userlogindata);
				/*$logindate=date("Y-m-d H:i:s");
				$lastlogin_data=array(					
							'lastlogin'=>$logindate	
							
							);	
				
				$lastlogin=$this->Login_model->lastlogin($lastlogin_data);*/
			if($res->profile_update=='no')
            {
                redirect(base_url('profile-update'));  
            }else{
              redirect(base_url().'dashboard');   
            }
			
				
			}else{
			 $data['error']='Sorry You are Login Another Device .<br/> Please Logout that device then try to login.';
			 $this->load->view('frontend/public/login',$data);
			}					
			} 
			else
			{
				$data['error']='Sorry your login ID and password did not match.<br/> <br/>Please try again.';
				$this->load->view('frontend/public/login',$data);
			}	
			
		}		
		else
		{
		$data['error']='';
		$this->load->view('frontend/public/login',$data);

		}	
		
	}
public function registered() 
    {	
    	$data['regthank']='';
    	$this->load->view('frontend/public/thanks-signup',$data);
    }
public function mynoticeboard() 
	{	
	   if($this->session->userdata('profile_update')=='no')
        {
            redirect(base_url('profile-update')); 
        }
		if($this->session->userdata('username')!='')
		{	
			$user_id=$this->session->userdata('user_id');
			
			Redirect(base_url());
		}
		else
		{
			redirect(base_url().'login');
		}
	
	}
public function logout() 
    {	
    	if($this->session->userdata('profile_update')=='no')
                {
                    $updateLoginStatus=$this->main_model->Update($this->db,'temp_main_user',array('login_status'=>'no','last_login_deviceid'=>$_SERVER['REMOTE_ADDR']),array('user_id'=>$this->session->userdata('user_id')));
                }else{
                    
                  $updateLoginStatus=$this->main_model->Update($this->db,'main_user',array('login_status'=>'no','last_login_deviceid'=>$_SERVER['REMOTE_ADDR']),array('user_id'=>$this->session->userdata('user_id')));  
                }
        $this->session->sess_destroy();
        Redirect(base_url());
    }
public function useremailcheck1()
		{
			
			$email=$this->input->post('email');
          	if(filter_var($email, FILTER_VALIDATE_EMAIL))
			{	
			
			 $pricedata=$this->main_model->student_emailcheck($email);	
			//var_dump($pricedata);
			 if($pricedata > 0)
			 {
				 
				 $msg="<span style='color:red'>Email already registered with us.</span>";
			 }
			 else
			 {
				 $msg="<span style='color:green'>You can register with us.</span>";
			 }
			}
			else
			{
				$msg="<span style='color:red'>Enter valid email id.</span>";
			}	
			echo $msg;
		}
public function profile_update() 
	{	
	    if($this->session->userdata('profile_update')=='yes')
        {
            redirect(base_url());
        }
	    $this->form_validation->set_rules('f_name', 'First Name', 'required');
		$this->form_validation->set_rules('last_name', 'Last Name', 'required');
        $this->form_validation->set_rules('dob', 'Date of Birth', 'required');
		$this->form_validation->set_rules('phone', 'phone', 'required');
        $this->form_validation->set_rules('address', 'address', 'required');
		$this->form_validation->set_rules('Country', 'Country', 'required');
		$this->form_validation->set_rules('city', 'City', 'required');
        $this->form_validation->set_rules('state', 'State', 'required');
		$this->form_validation->set_rules('zip', 'Zip Code', 'required');
        if($this->form_validation->run())
		{
		 if($_FILES['file']['name']!="")
         {
         $user=array(
                    'first_name'=>$this->input->post('f_name'),
                    'last_name'=>$this->input->post('last_name'),
                    'dob'=>$this->input->post('dob'),
                    'phone'=>$this->input->post('phone'),
                    'address'=>$this->input->post('address'),
                    'country'=>$this->input->post('Country'),
                    'city'=>$this->input->post('city'),
                    'state'=>$this->input->post('state'),
                    'zipcode'=>$this->input->post('zip'),
                    'profile_update'=>'yes',
                   );
         $path="./assets/images/userprofile/";
         $inputname="file";
         $type='gif|jpg|png|jpeg|bmp';
         $file_upload=$this->upload_file($path,$inputname,$type);
         $user['upload_path']=$file_upload['file_name'];
         
         if($file_upload['error'])
         {
           $updete_temp=$this->main_model->update($this->db,'temp_main_user',$user,array('user_id'=>$this->session->userdata('user_id'))); 
           if($updete_temp)
           {
            $update=$this->main_model->copy_user_row();
            redirect(base_url());
           } 
         }else{
            //upload not 
            redirect($_SERVER['HTTP_REFERER']);
         }
         
         }
         else{
           return; 
         }
         
        }
        else
        {
          
        }
        $data['user']=$this->main_model->get_login_user_from_temp(); 
        $this->load->view('frontend/public/header');
		$this->load->view('frontend/public/profile_update',$data);
        $this->load->view('frontend/public/footer');
	}
 public function testimonial() 
	{	
	   $this->load->view('frontend/public/header');
	   $this->load->view('frontend/public/testimonial');
	   $this->load->view('frontend/public/footer');
	}
public function contactus() 
	{	
		$this->form_validation->set_rules('fname', 'Please fill detail in first name', 'trim|required');
		$this->form_validation->set_rules('lname', 'Please fill detail in Last name', 'trim|required');
		$this->form_validation->set_rules('email', 'Please fill detail in Email', 'trim|required|valid_email');
		$this->form_validation->set_rules('msg', 'Please fill detail in Message box', 'required');
		if($this->form_validation->run() == false)
		{
	  
           $this->load->view('frontend/public/header');
    	   $this->load->view('frontend/public/contact-us');
    	   $this->load->view('frontend/public/footer');
		}
		else
		{
			
            $insert=$this->main_model->save($this->db,'contctus',$this->input->post());
			if($insert)
			{
				$this->session->set_flashdata('msg','Your requst submitted');
				$to=contact_toemail;
				$from=basic_from_email;
				$sub=contact_subject;
				$data=array('Name' => $this->input->post('fname').' '.$this->input->post('lname'),
							'Email'  => $this->input->post('email'),
							'Message'  => $this->input->post('msg'),
 							);
				$msg='';
				$msg.='<table>';
				
				foreach ($data as $key => $value) 
				{
					$msg.='<tr><td>'.$key.'</td><td>'.$value.'</td></tr>';

				}
				$msg.='</table>';
				
				$this->e_mail($to,$from,'CONTACT US',$sub,$msg);
				redirect($_SERVER['HTTP_REFERER']);

			}else{
				$this->session->set_flashdata('msg','Your requst not submitted');
				redirect($_SERVER['HTTP_REFERER']);
			}

		}
	
	}
public function our_centers() 
	{		
		$this->load->view('frontend/public/header');
        $this->load->view('frontend/public/our-centers');
        $this->load->view('frontend/public/footer');
	} 
 	public function forgotpassword() 
	{		
		$this->form_validation->set_rules('emailid', 'Login ID', 'required');
		
		if($this->form_validation->run())
		{
			$emailid = $this->input->post('emailid');
			
            $usertable=$this->main_model->get_detail($this->db,'temp_main_user',array('email'=>$emailid,'user_type'=>'6'),'single');			
			if($usertable)
            {
             $res=$usertable;
             
                
            }else{
             $usertable=$this->main_model->get_detail($this->db,'main_user',array('email'=>$emailid,'user_type'=>'6'),'single');   
             $res=$usertable;
             
            }
            
            if ($res) 
			{	 
				
				
				
				$password=$this->random_password();
			
				$user_data=array(							
							'password'=>md5($password)						
							
							);	
	            $userid=$this->main_model->update($this->db,'main_user',$user_data,array('user_id'=>$res->user_id));
				$data1['fullname']=$res->first_name;
				$data1['username']=$res->user_name;
				$data1['password']=$password;
				
				$senderemail=$res->email;
			
				$body = $this->load->view('emails/forgotpassword',$data1,TRUE);
				$this->e_mail($senderemail,basic_from_email, basic_from_name,forgotpassword_subject.' '.$res->user_name.' '.site_name,$body);
				$data['error']='Password sent to your email. Please check your inbox.';
			     
				
								
			} 
			else
			{
				$data['error']='Login ID not found.';
				
			}
		}
		else
		{
			$data['error']='';
		}
		$this->load->view('frontend/public/header');
		$this->load->view('frontend/public/forget-password',$data);
        $this->load->view('frontend/public/footer');
		
	} 
public function disclaimer() 
	{		
		
        $this->load->view('frontend/public/header');
		$this->load->view('frontend/public/disclaimer');
        $this->load->view('frontend/public/footer');
	
	} 
 public function helpcenter() 
	{		
		
        $this->load->view('frontend/public/header');
		$this->load->view('frontend/public/help-center');
        $this->load->view('frontend/public/footer');
	
	}
 public function faqs() 
	{		
		
        $this->load->view('frontend/public/header');
		$this->load->view('frontend/public/faqs');
        $this->load->view('frontend/public/footer');
	
	}
public function termconditions() 
	{		
		$this->load->view('frontend/public/header');
		$this->load->view('frontend/public/term-conditions');
        $this->load->view('frontend/public/footer');
	
	}
public function privacypolicy() 
	{		
		$this->load->view('frontend/public/header');
		$this->load->view('frontend/public/privacy-policy');
        $this->load->view('frontend/public/footer-test');
	
	}	
public function logout1() 
    {	
    	if($this->session->userdata('profile_update')=='no')
                {
                    $updateLoginStatus=$this->main_model->Update($this->db,'temp_main_user',array('login_status'=>'no','last_login_deviceid'=>$_SERVER['REMOTE_ADDR']),array('user_id'=>$this->session->userdata('user_id')));
                }else{
                    
                  $updateLoginStatus=$this->main_model->Update($this->db,'main_user',array('login_status'=>'no','last_login_deviceid'=>$_SERVER['REMOTE_ADDR']),array('user_id'=>$this->session->userdata('user_id')));  
                }
        $this->session->sess_destroy();
        $this->session->set_flashdata('error','We Found you are Inactive from 10 second <br> Session expired !!!');
        echo true;
    }	
public function test()
{
   date_default_timezone_set('Asia/Kolkata');
   $all=$this->db->select('last_active_time,user_id')->get('main_user')->result();
   foreach($all as $row)
   {
    
    if($row->last_active_time)
    {
      $last=strtotime($row->last_active_time);
      $current=strtotime(date('y-m-d h:i:s'));
      $diff1=($current-$last)/60;
      $diff=round($diff1,0);
      if($diff>59)
      {
        $update=$this->db->where(array('login_status'=>'yes','user_id'=>$row->user_id))->update('main_user',array('login_status'=>'no'));
      }
       
    }
   }
       
}




























}
