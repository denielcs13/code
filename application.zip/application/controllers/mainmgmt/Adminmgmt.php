<?php defined('BASEPATH') OR exit('No direct script access allowed');
class Adminmgmt extends MY_Controller {

     
    public function __construct()
    {
            parent::__construct();          
                        
            $this->load->model('Login_model','Login_model');            
            $this->load->helper(array('url','form'));
            $this->load->library(array('form_validation','session'));
            $this->load->library("pagination");
     }  

          /*pagination new*/
    public function pagination1($basepath,$total_row,$no_of_page,$uri_setment)
    {
        $config['base_url'] = base_url($basepath);
        //$basepath =admin/plan/
        $config['total_rows'] = $total_row;
        $config['per_page'] =$no_of_page;
        $config['use_page_numbers'] = TRUE;
        //no_of_page=10
        $config['uri_segment'] = $uri_setment;
        //$uri_setment=3
        $data['total_rows'] = $config['total_rows'];
        if (isset($_GET)) {
           $config['enable_query_string'] = TRUE;
           $config['suffix'] =  '?' .http_build_query($_GET, '', "&");
           $config['first_url'] = $config["base_url"] . $config['suffix'];
       }
       $this->pagination->initialize($config);
        $page = ($this->uri->segment($config["uri_segment"])) ? $this->uri->segment($config["uri_segment"]) : 0;
       $data['page_no'] = $page;
       $last_record_per_page = $config["per_page"] + ($data['page_no']);
       if ($data['total_rows'] < $last_record_per_page) {
           $last_record_per_page = $data['total_rows'];
       }
       $data["last_record_per_page"] = $last_record_per_page;
       $data["links"] = $this->pagination->create_links();
       $data['limit']=$config["per_page"];
       if (isset($page) && is_numeric($page))
                    {
                      if($page >1)
                      {
                      $data['offset'] = ($page-1) * $config['per_page'];
                      }
                      else
                      {
                          $data['offset']=0;
                      }
                    }
                    else
                    {
                      $data['offset'] = 0;
                    }
       return $data;
    }
    
    /*pagination ends  */
    
    public function index()
    {

     //var_dump($this->uri->segment(1));exit;
        if($this->uri->segment(1)==MAIN_ADMIN_SEG)
            {
                $obj=$this->math;
                $data["obj"]= $obj;  
            }
            if( $this->session->userdata('user_id')=='' and $this->session->userdata('username')=='')
                {
                    $data['error']='';
                    $this->load->view('backend/main/login',$data);
                }
            else
                {
                    $this->load->view('backend/main/common/header',$data);      
                    $this->load->view('backend/main/dashboard');
                    $this->load->view('backend/main/common/footer');    
                }
        
    }
    public function dashboard()
    {
        $data = new stdClass();
        if($this->uri->segment(1)==MAIN_ADMIN_SEG)
        {
        $obj=$this->math;
        $data["obj"]= $obj;  
        }  
        if ($this->session->userdata['user_id']== NULL && $this->session->userdata['user_id'] == "") {
            redirect( BASE_URL_MAIN_ADMIN. 'login','refresh');
        }
        $this->load->view('backend/main/common/header',$data);      
        $this->load->view('backend/main/dashboard');
        $this->load->view('backend/main/common/footer');    
    }
    public function _404(){
        $this->load->view("backend/404");
    }
    
    
    public function login()
    {
        
        
        $this->form_validation->set_rules('username', 'Username', 'required');
        $this->form_validation->set_rules('password', 'Password', 'required');      
        if($this->form_validation->run())
        {
            
            $username = $this->input->post('username');
            $password = $this->input->post('password');
            $user_type = $this->input->post('user_type');
            $data=array('val'=>'',
                        'table'=>'main_user',
                        'where'=>array('user_name'=>$username,'password'=>md5($password),'status'=>'1')
                        );
            $res=$this->Login_model->signin($data);
            if ($res['res']) 
            {   
                $userlogindata = array( 
                                    'username' => $res['rows']->user_name,
                                    'logged_in' => true,
                                    'user_id' => $res['rows']->user_id,
                                    'email' => $res['rows']->email,
                                    'user_type'=>$res['rows']->user_type,
                                    
                                    );
                
                $this->session->set_userdata($userlogindata);                                   
                if($res['rows']->role_type=="math_admin"):
                $this->session->set_userdata('role_type','math');
                redirect(BASE_URL_MATH_ADMIN);
                elseif($res['rows']->role_type=="english_admin"):
                $this->session->set_userdata('role_type','english');
                redirect(BASE_URL_ENGLISH_ADMIN);
                elseif($res['rows']->role_type=="chinees_admin"):
                $this->session->set_userdata('role_type','chinees');
                redirect(BASE_URL_CHINEES_ADMIN);
				elseif($res['rows']->role_type=="physics_admin"):
                $this->session->set_userdata('role_type','physics');
                redirect(BASE_URL_PHYSICS_ADMIN);
                elseif($res['rows']->role_type=="super_admin"):
                $this->session->set_userdata('role_type','super_admin');
                redirect(BASE_URL_MAIN_ADMIN);
                endif;
            } 
            else
            {
                $data['error']='Sorry your username and password did not match.<br/> <br/>Please try again.';
                $this->load->view('backend/main/login',$data);
            }   
            
        }       
        else
        {
        $data['error']='';
        $this->load->view('backend/main/login',$data);

        }       
        
    }
    public function logout() 
    {       
        $data = new stdClass();         
        session_destroy();
        redirect(BASE_URL_LOGOUT,'redirect');
        
    }
    
    public function get_class($subject="") 
    {       
        if($subject=="math")
        {
          $obj=$this->math;
        }
        elseif($subject=="english")
        {
          $obj=$this->english;
        }
        $year=$this->main_model->getall($obj,'classes','*');
        if($year)
        {
            $html='<option style="display: none;" value="">Select Subject</option>';
            foreach($year as $row)
            {
              $html.='<option value="'.$row->slug.'">'.$row->name.'</option>';   
            }
            echo $html;  
        }else{
            
            
        }
        
        
        
    }
    
public function skill($year="",$slug="")    
 {
    if($this->uri->segment(1)=='math-admin')
    {
    $obj=$this->math;
    $objdata["obj"]= $obj;  
    }elseif($this->uri->segment(1)=='english-admin'){
     $obj=$this->english;     
    }
    $data['year']=$year;
    $year_id=$this->main_model->getsid(TBL_CLASS,$objdata['obj'],$year); 
    $data['year_id']=$year_id;
    $data['year_dtl']=$this->main_model->get_detail($obj,TBL_CLASS,array('class_id'=>$year_id),"single");
    $data['SylList']=$this->main_model->get_detail($obj,'master_skill',array('skill_class'=>$year_id,'skill_parent'=>'0'),$insgle=null,'skill_order','asc');
    if($slug)
    {
        
        $subskill=$this->uri->segment(5);
        $skill=$this->main_model->get_detail($obj,'master_skill',array('skill_class'=>$year_id,'skill_slug'=>$subskill),"single");
        $data['skill']=$skill;
        $data['DepList']=$this->main_model->get_detail($obj,TBL_QUESTION.$year_id,array('ques_skillid'=>$skill->skill_parent,'ques_subskillid'=>$skill->skill_id));
        //$this->main_model->getall($obj,'manage_question','*',$col=null,$data['paging']["limit"], $data['paging']['offset']);
        
        $this->load->view('backend/math/common/header',$objdata);       
        $this->load->view('backend/math/skill-que-list',$data);
        $this->load->view('backend/math/common/footer'); 
    }else{
        $this->load->view('backend/math/common/header',$objdata);       
        $this->load->view('backend/math/skill-list',$data);
        $this->load->view('backend/math/common/footer');
    }   
 }
public function questions_list($year="")    
 {
    if($this->uri->segment(1)=='math-admin')
    {
    $obj=$this->math;
    $objdata["obj"]= $obj;  
    }elseif($this->uri->segment(1)=='english-admin'){
     $obj=$this->english;     
    }
    $data['year']=$year;
    $year_id=$this->main_model->getsid(TBL_CLASS,$objdata['obj'],$year); 
    $data['year_id']=$year_id;
    $current='math/adminmgmt/questions/'.$year;
    $totalRow=$this->main_model->numrows_total($obj,TBL_QUESTION.$year_id);
    $data=$this->create_pagination($current,$totalRow,20,5);
    $data['year_dtl']=$this->main_model->get_detail($obj,TBL_CLASS,array('class_id'=>$year_id),"single");
    $data['DepList']=$this->main_model->getall($obj,TBL_QUESTION.$year_id,'*',$col=null,$data["limit"], $data['offset'],"ques_id","desc");
    $this->load->view('backend/math/common/header',$objdata);       
    $this->load->view('backend/math/questions-list',$data);
    $this->load->view('backend/math/common/footer');
        
 }  
public function skill_order($year="")    
 {
    if($this->uri->segment(1)=='math-admin')
    {
    $obj=$this->math;
    $objdata["obj"]= $obj;  
    }elseif($this->uri->segment(1)=='english-admin'){
     $obj=$this->english;     
    }
    $data['year']=$year;
    $year_id=$this->main_model->getsid(TBL_CLASS,$objdata['obj'],$year); 
    $data['year_id']=$year_id;
    $data['year_dtl']=$this->main_model->get_detail($obj,TBL_CLASS,array('class_id'=>$year_id),"single");
    $data['SylList']=$this->main_model->get_detail($obj,'master_skill',array('skill_class'=>$year_id,'skill_parent'=>'0'),$insgle=null,'skill_order','asc');
    if($this->input->post('1'))
    {
      //echo '<pre>';
     $post=array_flip($this->input->post());
     foreach($post as $key=>$value)
     {
        $setorder=$this->main_model->Update($obj,'master_skill',array('skill_order'=>$value),array('skill_id'=>$key));
     }
     if($setorder)
     {
        $this->session->set_flashdata('success_msg','Skill ordererd succussfully');
        redirect(base_url('math-admin/adminmgmt/syllabus/'.$data['year_dtl']->class_slug));
     }else{
        $this->session->set_flashdata('success_msg','Skill not ordererd');
        $this->load->view('backend/math/common/header',$objdata);       
        $this->load->view('backend/math/skill-order',$data);
        $this->load->view('backend/math/common/footer');
     }
    }else{
        
        $this->load->view('backend/math/common/header',$objdata);       
        $this->load->view('backend/math/skill-order',$data);
        $this->load->view('backend/math/common/footer');  
    }
    
        
 }  
public function subskill_order($year="",$slug)    
 {
    if($this->uri->segment(1)=='math-admin')
    {
    $obj=$this->math;
    $objdata["obj"]= $obj;  
    }elseif($this->uri->segment(1)=='english-admin'){
     $obj=$this->english;     
    }
    $data['year']=$year;
    $year_id=$this->main_model->getsid(TBL_CLASS,$objdata['obj'],$year); 
    $data['year_id']=$year_id;
    $data['year_dtl']=$this->main_model->get_detail($obj,TBL_CLASS,array('class_id'=>$year_id),"single");
    $data['skillslug']=$this->main_model->get_detail($obj,'master_skill',array('skill_class'=>$year_id,"skill_slug"=>$slug),"single");
    $data['SylList']=$this->main_model->get_detail($obj,'master_skill',array('skill_class'=>$year_id,'skill_parent'=>$data['skillslug']->skill_id),$insgle=null,'skill_order','asc');
    if($this->input->post('1'))
    {
     $post=array_flip($this->input->post());
     foreach($post as $key=>$value)
     {
        $setorder=$this->main_model->Update($obj,'master_skill',array('skill_order'=>$value),array('skill_id'=>$key));
     }
     if($setorder)
     {
        $this->session->set_flashdata('success_msg','Skill ordererd succussfully');
        redirect(base_url('math-admin/adminmgmt/syllabus/'.$data['year_dtl']->class_slug));
     }else{
        $this->session->set_flashdata('success_msg','Skill not ordererd');
        $this->load->view('backend/math/common/header',$objdata);       
        $this->load->view('backend/math/subskill-order',$data);
        $this->load->view('backend/math/common/footer');
     }
    }else{
        
        $this->load->view('backend/math/common/header',$objdata);       
        $this->load->view('backend/math/subskill-order',$data);
        $this->load->view('backend/math/common/footer');  
    }
    
        
 }  

public function add_question($year="")    
 {
    if($this->uri->segment(1)=='math-admin')
    {
    $obj=$this->math;
    $objdata["obj"]= $obj;  
    }elseif($this->uri->segment(1)=='english-admin'){
     $obj=$this->english;     
    }
    $data['year']=$year;
    $year_id=$this->main_model->getsid(TBL_CLASS,$objdata['obj'],$year); 
    $data['year_id']=$year_id;
    $data['year_dtl']=$this->main_model->get_detail($obj,TBL_CLASS,array('class_id'=>$year_id),"single");
    $data['SylList']=$this->main_model->get_detail($obj,'master_skill',array('skill_class'=>$year_id,'skill_parent'=>'0'),$insgle=null,'skill_order','asc');
    if($this->input->post('quetype')=="html")
        {
          
          $insert_que=array('ques_type'         =>  26,
                            'ques_class'        =>  $year_id,
                            'ques_skillid'      =>  $this->input->post('ques_skillid'),
                            'ques_subskillid'   =>  $this->input->post('subskill'),
                            'ques_name'         =>  base64_encode($this->input->post('question_name')),
                            );
          
          
          $insert_que_id=$this->main_model->save($obj,'manage_question_'.$year_id,$insert_que);
          if($insert_que_id)
          {
            $i=0;
            $insertansid=array();
            foreach($this->input->post('answersr') as $row)
                {
                    if($this->input->post('answers')[$i])
                    {
                      $ans='1';  
                    }else{
                      $ans='0';  
                    }
                    $insert_ans=array('ans_quesid'  =>  $insert_que_id,
                                      'ans_name'    =>  $this->input->post('answersr')[$i],
                                      'ans_correct' =>  $ans,
                                      'has_image'   =>  '0' 
                                    );
                    $insert_ansID=$this->main_model->save($obj,'manage_answer_'.$year_id,$insert_ans);
                    array_push($insertansid,$insert_ansID);
                  $i++;  
                }
            $insert_expla=array( 'que_id'       =>  $insert_que_id,
                                  'get_explain' =>  base64_encode($this->input->post('explanation')),
                                  'class_id'    =>  $year_id,
                                );
            $insert_explaID=$this->main_model->save($obj,'manage_explain_'.$year_id,$insert_expla);
            $this->session->set_flashdata('success_msg','Question added successsfully!!');
            redirect('math-admin/adminmgmt/questions/'.$data['year_dtl']->class_slug);
          }else{
            $this->session->set_flashdata('success_msg','Question not added');
            $this->load->view('backend/math/common/header',$objdata);       
            $this->load->view('backend/math/add-question',$data);
            $this->load->view('backend/math/common/footer');
          }  
        }
    else
        {
            $this->load->view('backend/math/common/header',$objdata);       
            $this->load->view('backend/math/add-question',$data);
            $this->load->view('backend/math/common/footer');   
        }
      
 
 
 }
public function get_subskill($skillid="",$year_id="") 
    {       
        if($this->uri->segment(1)=='math-admin')
        {
        $obj=$this->math;
        $objdata["obj"]= $obj;  
        }elseif($this->uri->segment(1)=='english-admin'){
         $obj=$this->english; 
         $objdata["obj"]= $obj;     
        }
        
        $subskill=$this->main_model->get_detail($obj,'master_skill',array('skill_class'=>$year_id,'skill_parent'=>$skillid));
        if($subskill)
        {
            $html='<option style="display: none;" value="">Select Subject</option>';
            foreach($subskill as $subskillrow)
            {
              $html.='<option value="'.$subskillrow->skill_id.'">'.$subskillrow->skill_name.'</option>';   
            }
            echo $html;  
        }
        
        
        
    }
 public function EDIT_question($year="",$que_id)    
 {
    if($this->uri->segment(1)=='math-admin')
    {
    $obj=$this->math;
    $objdata["obj"]= $obj;  
    }elseif($this->uri->segment(1)=='english-admin'){
     $obj=$this->english;     
    }
    $data['year']=$year;
    $year_id=$this->main_model->getsid(TBL_CLASS,$objdata['obj'],$year); 
    $data['year_id']=$year_id;
    $data['year_dtl']=$this->main_model->get_detail($obj,TBL_CLASS,array('class_id'=>$year_id),"single");
    $data['que_list']=$this->main_model->get_detail($obj,TBL_QUESTION.$year_id,array('ques_id'=>$que_id),"single");
    $data['explantion']=$this->main_model->get_detail($obj,TBL_EXPLAN.$year_id,array('que_id'=>$que_id),"single");
    $data['subskilldefault']=$this->main_model->get_detail($obj,TBL_SKILL,array('skill_id'=>$data['que_list']->ques_subskillid),"single");
    $data['SylList']=$this->main_model->get_detail($obj,'master_skill',array('skill_class'=>$year_id,'skill_parent'=>'0'),$insgle=null,'skill_order','asc');
    $data['answer']=$this->main_model->get_detail($obj,TBL_ANSWER.$year_id,array('ans_quesid'=>$que_id),$insgle=null);
    
    
    if($this->input->post('quetype')=="html")
        {
          
          $insert_que=array('ques_type'         =>  26,
                            'ques_class'        =>  $year_id,
                            'ques_skillid'      =>  $this->input->post('ques_skillid'),
                            'ques_subskillid'   =>  $this->input->post('subskill'),
                            'ques_name'         =>  base64_encode($this->input->post('question_name')),
                            );
          
          
          $update_que_id=$this->main_model->update($obj,'manage_question_'.$year_id,$insert_que,array('ques_id'=>$que_id));
          if($update_que_id)
          {
            $i=0;
            $update_ansid=array();
            foreach($this->input->post('answersr') as $row)
                {
                    if($this->input->post('answers')[$i])
                    {
                      $ans='1';  
                    }else{
                      $ans='0';  
                    }
                    $insert_ans=array('ans_quesid'  =>  $que_id,
                                      'ans_name'    =>  $this->input->post('answersr')[$i],
                                      'ans_correct' =>  $ans,
                                      'has_image'   =>  '0' 
                                    );
                    $update_ansID=$this->main_model->update($obj,'manage_answer_'.$year_id,$insert_ans,array('ans_id'=>$this->input->post('answersid')[$i]));
                    array_push($update_ansid,$update_ansID);
                  $i++;  
                }
            $insert_expla=array( 'que_id'       =>  $que_id,
                                  'get_explain' =>  base64_encode($this->input->post('explanation')),
                                  'class_id'    =>  $year_id,
                                );
            $insert_explaID=$this->main_model->update($obj,'manage_explain_'.$year_id,$insert_expla,array('id'=>$this->input->post('explanation_id')));
            $this->session->set_flashdata('success_msg','Question added successsfully!!');
            redirect('math-admin/adminmgmt/questions/'.$data['year_dtl']->class_slug);
          }else{
            $this->session->set_flashdata('success_msg','Question not added');
            $this->load->view('backend/math/common/header',$objdata);       
            $this->load->view('backend/math/edit-question',$data);
            $this->load->view('backend/math/common/footer');
          }  
        }
    else
        {
            $this->load->view('backend/math/common/header',$objdata);       
            $this->load->view('backend/math/edit-question',$data);
            $this->load->view('backend/math/common/footer');   
        }
      
 
 
 }
 
public function delete_question($year="",$que_id)    
 {
    if($this->uri->segment(1)=='math-admin')
    {
    $obj=$this->math;
    $objdata["obj"]= $obj;  
    }elseif($this->uri->segment(1)=='english-admin'){
     $obj=$this->english;     
    }
    $data['year']=$year;
    $year_id=$this->main_model->getsid(TBL_CLASS,$objdata['obj'],$year); 
    $data['year_id']=$year_id;
    $data['year_dtl']=$this->main_model->get_detail($obj,TBL_CLASS,array('class_id'=>$year_id),"single");
    $deletequestion=$this->main_model->delete($obj,TBL_QUESTION.$year_id,array('ques_id'=>$que_id));
    if($deletequestion)
    {
      $delete_exp=$this->main_model->delete($obj,TBL_ANSWER.$year_id,array('ans_quesid'=>$que_id));
      $delete_ans=$this->main_model->delete($obj,TBL_EXPLAN.$year_id,array('que_id'=>$que_id));
      redirect('math-admin/adminmgmt/questions/'.$year);  
    }
    //dfgfjh,g
 }
public function add_skill($year="")    
 {
    if($this->uri->segment(1)=='math-admin')
    {
    $obj=$this->math;
    $objdata["obj"]= $obj;  
    }elseif($this->uri->segment(1)=='english-admin'){
     $obj=$this->english;     
    }
    $data['year']=$year;
    $year_id=$this->main_model->getsid(TBL_CLASS,$objdata['obj'],$year); 
    $data['year_id']=$year_id;
    $data['year_dtl']=$this->main_model->get_detail($obj,TBL_CLASS,array('class_id'=>$year_id),"single");
    $data['SylList']=$this->main_model->get_detail($obj,'master_skill',array('skill_class'=>$year_id,'skill_parent'=>'0'),$insgle=null,'skill_order','asc');
    if($this->input->post('skill-submit')=="Save")
        {
           
            $skill=array(
                            'skill_name'    =>  $this->input->post('skill_name'),
                            'skill_parent'  =>  '0',
                            'skill_slug'    =>  preg_replace('/[^A-Za-z0-9\-]/','-',$this->input->post('skill_name')),
                            'skill_descri'  =>  $this->input->post('skill_dec'),
                            'skill_class'   =>  $year_id,
                        );
            $insertskill=$this->main_model->Save($obj,TBL_SKILL,$skill);
            if($insertskill)
                {
                 $subskill=$this->input->post('subskill_name');
                 $skill_dec=$this->input->post('subskill_dec');
                 for($i=0;$i<count($skill_dec);$i++)
                     {
                         $sub_skill=array(
                                        'skill_name'    =>  $subskill[$i],
                                        'skill_parent'  =>  $insertskill,
                                        'skill_slug'    =>  preg_replace('/[^A-Za-z0-9\-]/','-',$subskill[$i]),
                                        'skill_descri'  =>  $skill_dec[$i],
                                        'skill_class'   =>  $year_id,
                                    );
                          $insertsubskill=$this->main_model->Save($obj,TBL_SKILL,$sub_skill);
                     }
                 $this->session->set_flashdata('success_msg','skill added successsfully!!');
                 redirect(base_url('math-admin/adminmgmt/syllabus/'.$year));   
                }
            else
                {
                  $this->session->set_flashdata('success_msg','skill NOT added!!'); 
                  redirect(base_url('math-admin/adminmgmt/syllabus/'.$year));
                }
            
        }
    elseif($this->input->post('subskill-submit')=="Save")
        {
         $insertskill=$this->input->post('skill_name');
         $subskill=$this->input->post('subskill_name');
         $skill_dec=$this->input->post('subskill_dec');
         for($i=0;$i<count($skill_dec);$i++)
             {
                 $sub_skill=array(
                                'skill_name'    =>  $subskill[$i],
                                'skill_parent'  =>  $insertskill,
                                'skill_slug'    =>  preg_replace('/[^A-Za-z0-9\-]/','-',$subskill[$i]),
                                'skill_descri'  =>  $skill_dec[$i],
                                'skill_class'   =>  $year_id,
                            );
                  $insertsubskill=$this->main_model->Save($obj,TBL_SKILL,$sub_skill);
             
             
             }
                     
            if($insertsubskill)
                {  
                 $this->session->set_flashdata('success_msg','sub skill added successsfully!!');
                 redirect(base_url('math-admin/adminmgmt/syllabus/'.$year));   
                }
            else
                {
                  $this->session->set_flashdata('success_msg','sub skill NOT added!!'); 
                  redirect(base_url('math-admin/adminmgmt/syllabus/'.$year));
                }   
        }
    else
        {
            
            $this->load->view('backend/math/common/header',$objdata);       
            $this->load->view('backend/math/addskill',$data);
            $this->load->view('backend/math/common/footer'); 
        
        }
    
    
      
 }
public function edit_skill($year="",$skillid="")    
 {
    if($this->uri->segment(1)=='math-admin')
    {
    $obj=$this->math;
    $objdata["obj"]= $obj;  
    }elseif($this->uri->segment(1)=='english-admin'){
     $obj=$this->english;     
    }
    $data['year']=$year;
    $data['skillid']=$skillid;
    $year_id=$this->main_model->getsid(TBL_CLASS,$objdata['obj'],$year); 
    $data['year_id']=$year_id;
    $data['year_dtl']=$this->main_model->get_detail($obj,TBL_CLASS,array('class_id'=>$year_id),"single");
    $data['SylList']=$this->main_model->get_detail($obj,'master_skill',array('skill_class'=>$year_id,'skill_parent'=>'0'),$insgle=null,'skill_order','asc');
    $data['subskilldefault']=$this->main_model->get_detail($obj,TBL_SKILL,array('skill_slug'=>$skillid,'skill_class'=>$year_id),"single");
    if($this->input->post('skill-upadte')=='Update')
    {
        $update=array(
                        'skill_name'=>$this->input->post('skill_name'),
                        'skill_descri'=>($this->input->post('skill_dec'))?$this->input->post('skill_dec'):null,
                        );
     $update1= $this->main_model->update($obj,TBL_SKILL,$update,array('skill_id'=>$data['subskilldefault']->skill_id));
    if($update1)
            {  
             $this->session->set_flashdata('success_msg','sub skill update successsfully!!');
             redirect(base_url('math-admin/adminmgmt/syllabus/'.$year));   
            }
        else
            {
              $this->session->set_flashdata('success_msg','sub skill NOT update!!'); 
              redirect(base_url('math-admin/adminmgmt/syllabus/'.$year));
            } 
    
    }
    else
    {
       $this->load->view('backend/math/common/header',$objdata);        
       $this->load->view('backend/math/edit-skill',$data);
       $this->load->view('backend/math/common/footer');    
    }
    
    
 }
 
 //user list
 public function student() 
    {   
     
   //echo 'hello';   
        if($this->uri->segment(1)==MAIN_ADMIN_SEG)
        {
        $obj=$this->math;
        $objdata["obj"]= $obj;  
        }

        if(isset($_REQUEST['sval']) && $_REQUEST['sval']!="")
        {
            $srch_dt=$_REQUEST['sval'];
                            //echo $srch_dt;die;
            //echo $srch_dt=$_REQUEST['sval'];exit;
        $countrow=$this->main_model->num_student_search($srch_dt);
        //var_dump($countrow);exit;
        $data=$this->pagination1(MAIN_ADMIN.'/student/',$countrow,1,4);
        $data['userlists'] = $this->main_model->get_users_search_list($data["limit"], $data['offset'],$_REQUEST['sval']);
        $data['page']="Student";
        $data['role_lst']='user';
        $data['error']=''; 
        }else{

            $countrow=$this->main_model->num_userlist('main_user');
        //var_dump($countrow);die;
        $data=$this->pagination1(MAIN_ADMIN.'/student/',$countrow,10,4);
        $data['userlists']=$this->main_model->get_userlist_d($data["limit"], $data['offset']);
        //var_dump($data['userlists']);die; 

        $data['page']="Student";
        $data['role_lst']='user';
        $data['error']=''; 

        }
         
        
        
        //var_dump($data['userlist']);die;
        /* if($subskill)
        {
            $html='<option style="display: none;" value="">Select Subject</option>';
            foreach($subskill as $subskillrow)
            {
              $html.='<option value="'.$subskillrow->skill_id.'">'.$subskillrow->skill_name.'</option>';   
            }
            echo $html;  
        } */
       $this->load->view('backend/main/common/header',$objdata);        
       $this->load->view('backend/main/users',$data);
       $this->load->view('backend/main/common/footer');  
        
        
    }
    public function parent() 
    {   
     
   //echo 'hello';   
        if($this->uri->segment(1)==MAIN_ADMIN_SEG)
        {
        $obj=$this->math;
        $objdata["obj"]= $obj;  
        }
        if(isset($_REQUEST['sval']) && $_REQUEST['sval']!="")
        {
            $srch_dt=$_REQUEST['sval'];
                            //echo $srch_dt;die;
            //echo $srch_dt=$_REQUEST['sval'];exit;
        $countrow=$this->main_model->num_student_search($srch_dt);
        //var_dump($countrow);exit;
        $data=$this->pagination1(MAIN_ADMIN.'/parent/',$countrow,1,4);
        $data['userlists'] = $this->main_model->get_users_search_list($data["limit"], $data['offset'],$_REQUEST['sval']);
        $data['page']="Parent";
        $data['role_lst']='parent';
        $data['error']='';
        }else{
            $countrow=$this->main_model->num_userlist_p('main_user');
        //var_dump($countrow);die;
        $data=$this->pagination1(MAIN_ADMIN.'/parent/',$countrow,10,4);
        $data['userlists']=$this->main_model->get_userlist_d_p($data["limit"], $data['offset']);
        //var_dump($data['userlists']);die;      
        $data['page']="Parent";
        $data['role_lst']='parent';
        $data['error']='';
        }

          
        
        
        //var_dump($data['userlist']);die;
        /* if($subskill)
        {
            $html='<option style="display: none;" value="">Select Subject</option>';
            foreach($subskill as $subskillrow)
            {
              $html.='<option value="'.$subskillrow->skill_id.'">'.$subskillrow->skill_name.'</option>';   
            }
            echo $html;  
        } */
       $this->load->view('backend/main/common/header',$objdata);        
       $this->load->view('backend/main/users',$data);
       $this->load->view('backend/main/common/footer');  
        
        
    }
    public function institute() 
    {   
     
   //echo 'hello';   
        if($this->uri->segment(1)==MAIN_ADMIN_SEG)
        {
        $obj=$this->math;
        $objdata["obj"]= $obj;  
        }
        if(isset($_REQUEST['sval']) && $_REQUEST['sval']!="")
        {
            $srch_dt=$_REQUEST['sval'];
                            //echo $srch_dt;die;
            //echo $srch_dt=$_REQUEST['sval'];exit;
        $countrow=$this->main_model->num_student_search($srch_dt);
        //var_dump($countrow);exit;
        $data=$this->pagination1(MAIN_ADMIN.'/parent/',$countrow,1,4);
        $data['userlists'] = $this->main_model->get_users_search_list($data["limit"], $data['offset'],$_REQUEST['sval']);
        $data['page']="Institute";
        $data['role_lst']='institute';
        $data['error']='';
        }else{
            $countrow=$this->main_model->num_userlist_i('main_user');
        //var_dump($countrow);die;
        $data=$this->pagination1(MAIN_ADMIN.'/institute/',$countrow,10,4);
        $data['userlists']=$this->main_model->get_userlist_d_i($data["limit"], $data['offset']);
        //var_dump($data['userlists']);die;      
        $data['page']="Institute";
        $data['role_lst']='institute';
        $data['error']='';

        }
          
        
        
        //var_dump($data['userlist']);die;
        /* if($subskill)
        {
            $html='<option style="display: none;" value="">Select Subject</option>';
            foreach($subskill as $subskillrow)
            {
              $html.='<option value="'.$subskillrow->skill_id.'">'.$subskillrow->skill_name.'</option>';   
            }
            echo $html;  
        } */
       $this->load->view('backend/main/common/header',$objdata);        
       $this->load->view('backend/main/users',$data);
       $this->load->view('backend/main/common/footer');  
        
        
    }
    
    public function delete_user($id)
    {
        
        if($this->uri->segment(1)==MAIN_ADMIN_SEG)
        {
        $obj=$this->math;
        $objdata["obj"]= $obj;  
        }
        
        $data['userlists']=$this->main_model->get_userlist_d('main_user');
        $stud_detail=$this->main_model->get_stud_detail('main_user','user_id',$id);
        if($this->main_model->delete_usrs('main_user','user_id',$id)){
        $this->session->set_flashdata('msgdel','User deleted successfully');
        }
		
		if($stud_detail->role_type=='user'){ 
            redirect(base_url(MAIN_ADMIN.'/student')); 
            }else if($stud_detail->role_type=='parents'){ 
            redirect(base_url(MAIN_ADMIN.'/parent')); 
            }else if($stud_detail->role_type=='institute'){ 
            redirect(base_url(MAIN_ADMIN.'/institute')); 
            }
        
       /* $this->load->view('backend/main/common/header',$objdata);        
       $this->load->view('backend/main/users',$data);
       $this->load->view('backend/main/common/footer');  */ 
    }

    public function active_user($id)
    {
        //var_dump($this->uri->segment(5));exit;
        if($this->uri->segment(1)==MAIN_ADMIN_SEG)
        {
        $obj=$this->math;
        $objdata["obj"]= $obj;  
        }
        
        if($id!='')
             {
                if($this->uri->segment(5) == 1){
                  $user=array(
                    
                    'status' =>  0,
                   );  
                }else{
                    $user=array(
                    
                    'status' =>  1,
                   );
                }
         
             }
        $stud_detail=$this->main_model->get_stud_detail('main_user','user_id',$this->uri->segment(4));
        //var_dump($data['stud_detail']);die;    
        $updete_temp=$this->main_model->update($this->db,'main_user',$user,array('user_id'=>$this->uri->segment(4))); 
           if($updete_temp)
           {

             $this->session->set_flashdata('stsup','Status updated successfully!');  
            }
            /* $update=$this->main_model->copy_user_row();*/
            if($stud_detail->role_type=='user'){ 
            redirect(base_url(MAIN_ADMIN.'/student')); 
            }else if($stud_detail->role_type=='parents'){ 
            redirect(base_url(MAIN_ADMIN.'/parent')); 
            }else if($stud_detail->role_type=='institute'){ 
            redirect(base_url(MAIN_ADMIN.'/institute')); 
            }
            
                  
          
    }

    
    
    public function edit_user($id)
    {
        
        if($this->uri->segment(1)==MAIN_ADMIN_SEG)
        {
        $obj=$this->math;
        $objdata["obj"]= $obj;  
        }
        if($this->input->post('skillupadte')=='Update'){
            
            $country_id = $this->input->post('country');
            $state_id = $this->input->post('state');
            //$data['const']=$this->main_model->country_by_id($country_id,'countries');
            //$data['consts']=$this->main_model->state_by_id($state_id,'states');
			
        
            
            if($this->input->post('user_type')=='6')
             {
         $user=array(
                    'first_name'=>$this->input->post('first_name'),                  
                    'phone'=>$this->input->post('phone'),
                    'country'=>$country_id,
                    'city'=>$this->input->post('city'),
                    'state'=>$state_id,
                    'zipcode'=>$this->input->post('zipcode'),
                    'profile_update'=>'yes',
                    'class_name'=>$this->input->post('class_name'),
                   );
             }else if($this->input->post('user_type')=='8')
             {
         $user=array(
                    'first_name'=>$this->input->post('first_name'),                    
                    'phone'=>$this->input->post('phone'),
                    'address'=>$this->input->post('address'),
                    'country'=>$country_id,
                    'city'=>$this->input->post('city'),
                    'state'=>$state_id,
                    'zipcode'=>$this->input->post('zipcode'),
                    'profile_update'=>'yes',
                    'inst_name'=>$this->input->post('inst_name'),
                    'inst_type'=>$this->input->post('inst_type'),
                    'dsgn_name'=>$this->input->post('dsgn_name'),
                   );
             }else{
                 $user=array(
                    'first_name'=>$this->input->post('first_name'),                    
                    'phone'=>$this->input->post('phone'),
                    'country'=>$country_id,
                    'city'=>$this->input->post('city'),
                    'state'=>$state_id,
                    'zipcode'=>$this->input->post('zipcode'),
                    'profile_update'=>'yes',
                    'chldr_num'=>$this->input->post('chldr_num')
                   );
             }
             //var_dump($user);die;
              $updete_temp=$this->main_model->update($this->db,'main_user',$user,array('user_id'=>$this->input->post('user_id'))); 
           if($updete_temp)
           {
             $this->session->set_flashdata('pflupd','Profile details updated successfully!');  
            /* $update=$this->main_model->copy_user_row();
            redirect(base_url()); */
           }    
            
        
        }
        
        
        $data['userdetails']=$this->main_model->get_user_by_id('main_user',$id);
       /* echo '<pre>';        
        print_r($data['userdetails']->country);die;
		echo '</pre>'; */ 
		//$data['userdetails']->country
        
            $userinfo=$this->main_model->get_login_user_from_main(); 
			$data['user']=$userinfo;
			$data['country_list']=$this->main_model->get_countries($obj);
			$data['state_list']=$this->main_model->get_states($obj,$data['userdetails']->country);
        
       $this->load->view('backend/main/common/header',$objdata);        
       $this->load->view('backend/main/edit-user',$data);
       $this->load->view('backend/main/common/footer');  
    }
	
	public function student_list($id) 
    {   
     
   //echo 'hello';   
        if($this->uri->segment(1)==MAIN_ADMIN_SEG)
        {
        $obj=$this->math;
        $objdata["obj"]= $obj;  
        }
        if(isset($_REQUEST['sval']) && $_REQUEST['sval']!="")
        {  
            $srch_dt=$_REQUEST['sval'];
                            //echo $srch_dt;die;
            //echo $srch_dt=$_REQUEST['sval'];exit;
        $countrow=$this->main_model->num_student_search($srch_dt);
		$stud_detail=$this->main_model->get_stud_detail('main_user','user_id',$id);
        //var_dump($countrow);exit;
        $data=$this->pagination1(MAIN_ADMIN.'/student_list/',$countrow,1,3);
        $data['userlists'] = $this->main_model->get_users_search_list($data["limit"], $data['offset'],$_REQUEST['sval']);
        $data['page']="Student";
        $data['role_lst']='user';
		$data['p_name']=$stud_detail->first_name;
        }else{
        $stud_detail=$this->main_model->get_stud_detail('main_user','user_id',$id);			
			
        $countrow=$this->main_model->num_student('main_user',$id);
        //var_dump($countrow);die;
        /* $data=$this->pagination1(MAIN_ADMIN.'/student_list/',$countrow,10,4); */
        $data['userlists']=$this->main_model->get_userlist_by_parent_id($id);
        //var_dump($data['userlists']);die;      
        $data['page']="Student";
        $data['role_lst']='user';
		$data['p_name']=$stud_detail->first_name;
        $data['error']='';

        }
          
        
        
        //var_dump($data['userlist']);die;
        /* if($subskill)
        {
            $html='<option style="display: none;" value="">Select Subject</option>';
            foreach($subskill as $subskillrow)
            {
              $html.='<option value="'.$subskillrow->skill_id.'">'.$subskillrow->skill_name.'</option>';   
            }657677
            echo $html;  
        } */
       $this->load->view('backend/main/common/header',$objdata);        
       $this->load->view('backend/main/student',$data);
       $this->load->view('backend/main/common/footer');
	}
 
 
    
}
