<?php defined('BASEPATH') OR exit('No direct script access allowed');
class Adminmgmt extends MY_Controller {

	 
	public function __construct()
    {
            parent::__construct();			
						
			$this->load->model('Login_model','Login_model');			
			$this->load->helper(array('url','form'));
			$this->load->library(array('form_validation','session'));
            
     }	
	      
	public function index()
	{
	 
        if($this->uri->segment(1)==MATH_ADMIN_SEG)
            {
                $obj=$this->math;
                $data["obj"]= $obj;  
            }elseif($this->uri->segment(1)==ENGLISH_ADMIN_SEG){
                $obj=$this->english; 
                $data["obj"]= $obj;     
            }
            if( $this->session->userdata('user_id')=='' and $this->session->userdata('username')=='')
                {
                    $data['error']='';
                    $this->load->view('backend/english/login',$data);
                }
            else
                {
                    $this->load->view('backend/english/common/header',$data);		
                    $this->load->view('backend/english/dashboard');
                    $this->load->view('backend/english/common/footer');	
                }
		
	}
	public function dashboard()
	{
		$data = new stdClass();
        if($this->uri->segment(1)==MATH_ADMIN_SEG)
        {
        $obj=$this->math;
        $data["obj"]= $obj;  
        }elseif($this->uri->segment(1)==ENGLISH_ADMIN_SEG){
         $obj=$this->english;
         $objdata["obj"]= $obj;     
        }	
		if ($this->session->userdata['user_id']== NULL && $this->session->userdata['user_id'] == "") {
			redirect( BASE_URL_MATH_ADMIN. 'login','refresh');
		}
		$this->load->view('backend/english/common/header',$data);		
		$this->load->view('backend/english/dashboard');
		$this->load->view('backend/english/common/footer');	
	}
	public function _404(){
		$this->load->view("backend/404");
	}
	
    
    public function login()
	{
		
		
		$this->form_validation->set_rules('username', 'Username', 'required');
		$this->form_validation->set_rules('password', 'Password', 'required');		
		if($this->form_validation->run())
		{
			
			$username = $this->input->post('username');
			$password = $this->input->post('password');
			$user_type = $this->input->post('user_type');
			$data=array('val'=>'',
						'table'=>'main_user',
						'where'=>array('user_name'=>$username,'password'=>md5($password),'status'=>'1')
						);
			$res=$this->Login_model->signin($data);
			if ($res['res']) 
			{	
				$userlogindata = array( 
									'username' => $res['rows']->user_name,
									'logged_in' => true,
									'user_id' => $res['rows']->user_id,
									'email' => $res['rows']->email,
									'user_type'=>$res['rows']->user_type,
                                    
									);
                
                $this->session->set_userdata($userlogindata);            						
				if($res['rows']->role_type=="math_admin"):
                $this->session->set_userdata('role_type','math');
                redirect(BASE_URL_MATH_ADMIN);
                elseif($res['rows']->role_type=="english_admin"):
                $this->session->set_userdata('role_type','english');
                redirect(BASE_URL_ENGLISH_ADMIN);
                elseif($res['rows']->role_type=="chines_admin"):
                $this->session->set_userdata('role_type','chinese');
                redirect(BASE_URL_CHINESE_ADMIN);
                endif;
            } 
			else
			{
				$data['error']='Sorry your username and password did not match.<br/> <br/>Please try again.';
				$this->load->view('backend/english/login',$data);
			}	
			
		}		
		else
		{
		$data['error']='';
		$this->load->view('backend/english/login',$data);

		}		
		
	}
    public function logout() 
	{		
		$data = new stdClass();			
		session_destroy();
		redirect(BASE_URL_LOGOUT,'redirect');
		
	}
    
    public function get_class($subject="") 
	{		
		if($subject=="math")
        {
          $obj=$this->math;
        }
        elseif($subject=="english")
        {
          $obj=$this->english;
        }
        $objdata["obj"]= $obj;
		$year=$this->main_model->getall($obj,'classes','*');
        if($year)
        {
            $html='<option style="display: none;" value="">Select Subject</option>';
            foreach($year as $row)
            {
              $html.='<option value="'.$row->slug.'">'.$row->name.'</option>';   
            }
            echo $html;  
        }else{
            
            
        }
        
        
        
	}
    
public function skill($year="",$slug="")    
 {
    if($this->uri->segment(1)==MATH_ADMIN_SEG)
    {
    $obj=$this->math;
    $objdata["obj"]= $obj;  
    }elseif($this->uri->segment(1)==ENGLISH_ADMIN_SEG){
     $obj=$this->english;
     $objdata["obj"]= $obj;     
    }
    
    $data['year']=$year;
    $year_id=$this->main_model->getsid(TBL_CLASS,$objdata['obj'],$year); 
    $data['year_id']=$year_id;
    $data['year_dtl']=$this->main_model->get_detail($obj,TBL_CLASS,array('class_id'=>$year_id),"single");
    $data['SylList']=$this->main_model->get_detail($obj,'master_skill',array('skill_class'=>$year_id,'skill_parent'=>'0'),$insgle=null,'skill_order','asc');
    if($slug)
    {
        
        $subskill=$this->uri->segment(5);
        $skill=$this->main_model->get_detail($obj,'master_skill',array('skill_class'=>$year_id,'skill_slug'=>$subskill),"single");
        $data['skill']=$skill;
        $data['DepList']=$this->main_model->get_detail($obj,TBL_QUESTION.$year_id,array('ques_skillid'=>$skill->skill_parent,'ques_subskillid'=>$skill->skill_id));
        //$this->main_model->getall($obj,'manage_question','*',$col=null,$data['paging']["limit"], $data['paging']['offset']);
        
        $this->load->view('backend/english/common/header',$objdata);		
    	$this->load->view('backend/english/skill-que-list',$data);
    	$this->load->view('backend/english/common/footer'); 
    }else{
        $this->load->view('backend/english/common/header',$objdata);		
    	$this->load->view('backend/english/skill-list',$data);
    	$this->load->view('backend/english/common/footer');
    }	
 }
public function questions_list($year="")    
 {
    if($this->uri->segment(1)==MATH_ADMIN_SEG)
    {
    $obj=$this->math;
    $objdata["obj"]= $obj;  
    }elseif($this->uri->segment(1)==ENGLISH_ADMIN_SEG){
     $obj=$this->english;   
     $objdata["obj"]= $obj;  
    }
    $data['year']=$year;
    $year_id=$this->main_model->getsid(TBL_CLASS,$objdata['obj'],$year); 
    $data['year_id']=$year_id;
    $current='math/adminmgmt/questions/'.$year;
    $totalRow=$this->main_model->numrows_total($obj,TBL_QUESTION.$year_id);
    $data=$this->create_pagination($current,$totalRow,20,5);
    $data['year_dtl']=$this->main_model->get_detail($obj,TBL_CLASS,array('class_id'=>$year_id),"single");
    $data['DepList']=$this->main_model->getall($obj,TBL_QUESTION.$year_id,'*',$col=null,$data["limit"], $data['offset'],"ques_id","desc");
    $this->load->view('backend/english/common/header',$objdata);		
	$this->load->view('backend/english/questions-list',$data);
	$this->load->view('backend/english/common/footer');
    	
 } 	
public function skill_order($year="")    
 {
    if($this->uri->segment(1)==MATH_ADMIN_SEG)
    {
    $obj=$this->math;
    $objdata["obj"]= $obj;  
    }elseif($this->uri->segment(1)==ENGLISH_ADMIN_SEG){
     $obj=$this->english;  
     $objdata["obj"]= $obj;   
    }
    $data['year']=$year;
    $year_id=$this->main_model->getsid(TBL_CLASS,$objdata['obj'],$year); 
    $data['year_id']=$year_id;
    $data['year_dtl']=$this->main_model->get_detail($obj,TBL_CLASS,array('class_id'=>$year_id),"single");
    $data['SylList']=$this->main_model->get_detail($obj,'master_skill',array('skill_class'=>$year_id,'skill_parent'=>'0'),$insgle=null,'skill_order','asc');
    if($this->input->post('1'))
    {
      //echo '<pre>';
     $post=array_flip($this->input->post());
     foreach($post as $key=>$value)
     {
        $setorder=$this->main_model->Update($obj,'master_skill',array('skill_order'=>$value),array('skill_id'=>$key));
     }
     if($setorder)
     {
        $this->session->set_flashdata('success_msg','Skill ordererd succussfully');
        redirect(base_url(ENGLISH_ADMIN.'/syllabus/'.$data['year_dtl']->class_slug));
     }else{
        $this->session->set_flashdata('success_msg','Skill not ordererd');
        $this->load->view('backend/english/common/header',$objdata);		
    	$this->load->view('backend/english/skill-order',$data);
    	$this->load->view('backend/english/common/footer');
     }
    }else{
        
        $this->load->view('backend/english/common/header',$objdata);		
    	$this->load->view('backend/english/skill-order',$data);
    	$this->load->view('backend/english/common/footer');  
    }
    
    	
 }	
public function subskill_order($year="",$slug)    
 {
    if($this->uri->segment(1)==MATH_ADMIN_SEG)
    {
    $obj=$this->math;
    $objdata["obj"]= $obj;  
    }elseif($this->uri->segment(1)==ENGLISH_ADMIN_SEG){
     $obj=$this->english;
     $objdata["obj"]= $obj;     
    }
    $data['year']=$year;
    $year_id=$this->main_model->getsid(TBL_CLASS,$objdata['obj'],$year); 
    $data['year_id']=$year_id;
    $data['year_dtl']=$this->main_model->get_detail($obj,TBL_CLASS,array('class_id'=>$year_id),"single");
    $data['skillslug']=$this->main_model->get_detail($obj,'master_skill',array('skill_class'=>$year_id,"skill_slug"=>$slug),"single");
    $data['SylList']=$this->main_model->get_detail($obj,'master_skill',array('skill_class'=>$year_id,'skill_parent'=>$data['skillslug']->skill_id),$insgle=null,'skill_order','asc');
    if($this->input->post('1'))
    {
     $post=array_flip($this->input->post());
     foreach($post as $key=>$value)
     {
        $setorder=$this->main_model->Update($obj,'master_skill',array('skill_order'=>$value),array('skill_id'=>$key));
     }
     if($setorder)
     {
        $this->session->set_flashdata('success_msg','Skill ordererd succussfully');
        redirect(base_url(ENGLISH_ADMIN.'/syllabus/'.$data['year_dtl']->class_slug));
     }else{
        $this->session->set_flashdata('success_msg','Skill not ordererd');
        $this->load->view('backend/english/common/header',$objdata);		
    	$this->load->view('backend/english/subskill-order',$data);
    	$this->load->view('backend/english/common/footer');
     }
    }else{
        
        $this->load->view('backend/english/common/header',$objdata);		
    	$this->load->view('backend/english/subskill-order',$data);
    	$this->load->view('backend/english/common/footer');  
    }
    
    	
 }	

public function add_question($year="")    
 {
    if($this->uri->segment(1)==MATH_ADMIN_SEG)
    {
    $obj=$this->math;
    $objdata["obj"]= $obj;  
    }elseif($this->uri->segment(1)==ENGLISH_ADMIN_SEG){
     $obj=$this->english;
     $objdata["obj"]= $obj;     
    }
    $data['year']=$year;
    $year_id=$this->main_model->getsid(TBL_CLASS,$objdata['obj'],$year); 
    $data['year_id']=$year_id;
    $data['year_dtl']=$this->main_model->get_detail($obj,TBL_CLASS,array('class_id'=>$year_id),"single");
    $data['SylList']=$this->main_model->get_detail($obj,'master_skill',array('skill_class'=>$year_id,'skill_parent'=>'0'),$insgle=null,'skill_order','asc');
    if($this->input->post('quetype')=="html")
        {
          
          $insert_que=array('ques_type'         =>  26,
                            'ques_class'        =>  $year_id,
                            'ques_skillid'      =>  $this->input->post('ques_skillid'),
                            'ques_subskillid'   =>  $this->input->post('subskill'),
                            'ques_name'         =>  base64_encode($this->input->post('question_name')),
                            );
          
          
          $insert_que_id=$this->main_model->save($obj,'manage_question_'.$year_id,$insert_que);
          if($insert_que_id)
          {
            $i=0;
            $insertansid=array();
            foreach($this->input->post('answersr') as $row)
                {
                    if($this->input->post('answers')[$i])
                    {
                      $ans='1';  
                    }else{
                      $ans='0';  
                    }
                    $insert_ans=array('ans_quesid'  =>  $insert_que_id,
                                      'ans_name'    =>  $this->input->post('answersr')[$i],
                                      'ans_correct' =>  $ans,
                                      'has_image'   =>  '0' 
                                    );
                    $insert_ansID=$this->main_model->save($obj,'manage_answer_'.$year_id,$insert_ans);
                    array_push($insertansid,$insert_ansID);
                  $i++;  
                }
            $insert_expla=array( 'que_id'       =>  $insert_que_id,
                                  'get_explain' =>  base64_encode($this->input->post('explanation')),
                                  'class_id'    =>  $year_id,
                                );
            $insert_explaID=$this->main_model->save($obj,'manage_explain_'.$year_id,$insert_expla);
            $this->session->set_flashdata('success_msg','Question added successsfully!!');
            redirect(ENGLISH_ADMIN.'/questions/'.$data['year_dtl']->class_slug);
          }else{
            $this->session->set_flashdata('success_msg','Question not added');
            $this->load->view('backend/english/common/header',$objdata);		
        	$this->load->view('backend/english/add-question',$data);
        	$this->load->view('backend/english/common/footer');
          }  
        }
    else
        {
            $this->load->view('backend/english/common/header',$objdata);		
        	$this->load->view('backend/english/add-question',$data);
        	$this->load->view('backend/english/common/footer');   
        }
      
 
 
 }
public function get_subskill($skillid="",$year_id="") 
	{		
		if($this->uri->segment(1)==MATH_ADMIN_SEG)
        {
        $obj=$this->math;
        $objdata["obj"]= $obj;  
        }elseif($this->uri->segment(1)==ENGLISH_ADMIN_SEG){
         $obj=$this->english; 
         $objdata["obj"]= $obj;     
        }
        
		$subskill=$this->main_model->get_detail($obj,'master_skill',array('skill_class'=>$year_id,'skill_parent'=>$skillid));
        if($subskill)
        {
            $html='<option style="display: none;" value="">Select Subject</option>';
            foreach($subskill as $subskillrow)
            {
              $html.='<option value="'.$subskillrow->skill_id.'">'.$subskillrow->skill_name.'</option>';   
            }
            echo $html;  
        }
        
        
        
	}
 public function EDIT_question($year="",$que_id)    
 {
    if($this->uri->segment(1)==MATH_ADMIN_SEG)
    {
    $obj=$this->math;
    $objdata["obj"]= $obj;  
    }elseif($this->uri->segment(1)==ENGLISH_ADMIN_SEG){
     $obj=$this->english; 
     $objdata["obj"]= $obj;    
    }
    $data['year']=$year;
    $year_id=$this->main_model->getsid(TBL_CLASS,$objdata['obj'],$year); 
    $data['year_id']=$year_id;
    $data['year_dtl']=$this->main_model->get_detail($obj,TBL_CLASS,array('class_id'=>$year_id),"single");
    $data['que_list']=$this->main_model->get_detail($obj,TBL_QUESTION.$year_id,array('ques_id'=>$que_id),"single");
    $data['explantion']=$this->main_model->get_detail($obj,TBL_EXPLAN.$year_id,array('que_id'=>$que_id),"single");
    $data['subskilldefault']=$this->main_model->get_detail($obj,TBL_SKILL,array('skill_id'=>$data['que_list']->ques_subskillid),"single");
    $data['SylList']=$this->main_model->get_detail($obj,'master_skill',array('skill_class'=>$year_id,'skill_parent'=>'0'),$insgle=null,'skill_order','asc');
    $data['answer']=$this->main_model->get_detail($obj,TBL_ANSWER.$year_id,array('ans_quesid'=>$que_id),$insgle=null);
    
    
    if($this->input->post('quetype')=="html")
        {
          
          $insert_que=array('ques_type'         =>  26,
                            'ques_class'        =>  $year_id,
                            'ques_skillid'      =>  $this->input->post('ques_skillid'),
                            'ques_subskillid'   =>  $this->input->post('subskill'),
                            'ques_name'         =>  base64_encode($this->input->post('question_name')),
                            );
          
          
          $update_que_id=$this->main_model->update($obj,'manage_question_'.$year_id,$insert_que,array('ques_id'=>$que_id));
          if($update_que_id)
          {
            $i=0;
            $update_ansid=array();
            foreach($this->input->post('answersr') as $row)
                {
                    if($this->input->post('answers')[$i])
                    {
                      $ans='1';  
                    }else{
                      $ans='0';  
                    }
                    $insert_ans=array('ans_quesid'  =>  $que_id,
                                      'ans_name'    =>  $this->input->post('answersr')[$i],
                                      'ans_correct' =>  $ans,
                                      'has_image'   =>  '0' 
                                    );
                    $update_ansID=$this->main_model->update($obj,'manage_answer_'.$year_id,$insert_ans,array('ans_id'=>$this->input->post('answersid')[$i]));
                    array_push($update_ansid,$update_ansID);
                  $i++;  
                }
            $insert_expla=array( 'que_id'       =>  $que_id,
                                  'get_explain' =>  base64_encode($this->input->post('explanation')),
                                  'class_id'    =>  $year_id,
                                );
            $insert_explaID=$this->main_model->update($obj,'manage_explain_'.$year_id,$insert_expla,array('id'=>$this->input->post('explanation_id')));
            $this->session->set_flashdata('success_msg','Question added successsfully!!');
            redirect(ENGLISH_ADMIN.'/questions/'.$data['year_dtl']->class_slug);
          }else{
            $this->session->set_flashdata('success_msg','Question not added');
            $this->load->view('backend/english/common/header',$objdata);		
        	$this->load->view('backend/english/edit-question',$data);
        	$this->load->view('backend/english/common/footer');
          }  
        }
    else
        {
            $this->load->view('backend/english/common/header',$objdata);		
        	$this->load->view('backend/english/edit-question',$data);
        	$this->load->view('backend/english/common/footer');   
        }
      
 
 
 }
 
public function delete_question($year="",$que_id)    
 {
    if($this->uri->segment(1)==MATH_ADMIN_SEG)
    {
    $obj=$this->math;
    $objdata["obj"]= $obj;  
    }elseif($this->uri->segment(1)==ENGLISH_ADMIN_SEG){
     $obj=$this->english; 
     $objdata["obj"]= $obj;    
    }
    $data['year']=$year;
    $year_id=$this->main_model->getsid(TBL_CLASS,$objdata['obj'],$year); 
    $data['year_id']=$year_id;
    $data['year_dtl']=$this->main_model->get_detail($obj,TBL_CLASS,array('class_id'=>$year_id),"single");
    $deletequestion=$this->main_model->delete($obj,TBL_QUESTION.$year_id,array('ques_id'=>$que_id));
    if($deletequestion)
    {
      $delete_exp=$this->main_model->delete($obj,TBL_ANSWER.$year_id,array('ans_quesid'=>$que_id));
      $delete_ans=$this->main_model->delete($obj,TBL_EXPLAN.$year_id,array('que_id'=>$que_id));
      redirect(base_url(ENGLISH_ADMIN.'/questions/'.$year));  
    }
    //dfgfjh,g
 }

public function add_skill($year="")    
 {
    if($this->uri->segment(1)==MATH_ADMIN_SEG)
    {
    $obj=$this->math;
    $objdata["obj"]= $obj;  
    }elseif($this->uri->segment(1)==ENGLISH_ADMIN_SEG){
     $obj=$this->english; 
     $objdata["obj"]= $obj;     
    }
    $data['year']=$year;
    $year_id=$this->main_model->getsid(TBL_CLASS,$objdata['obj'],$year); 
    $data['year_id']=$year_id;
    $data['year_dtl']=$this->main_model->get_detail($obj,TBL_CLASS,array('class_id'=>$year_id),"single");
    $data['SylList']=$this->main_model->get_detail($obj,'master_skill',array('skill_class'=>$year_id,'skill_parent'=>'0'),$insgle=null,'skill_order','asc');
    if($this->input->post('skill-submit')=="Save")
        {
           
            $skill=array(
                            'skill_name'    =>  $this->input->post('skill_name'),
                            'skill_parent'  =>  '0',
                            'skill_slug'    =>  preg_replace('/[^A-Za-z0-9\-]/','-',$this->input->post('skill_name')),
                            'skill_descri'  =>  $this->input->post('skill_dec'),
                            'skill_class'   =>  $year_id,
                        );
            $insertskill=$this->main_model->Save($obj,TBL_SKILL,$skill);
            if($insertskill)
                {
                 $subskill=$this->input->post('subskill_name');
                 $skill_dec=$this->input->post('subskill_dec');
                 for($i=0;$i<count($skill_dec);$i++)
                     {
                         $sub_skill=array(
                                        'skill_name'    =>  $subskill[$i],
                                        'skill_parent'  =>  $insertskill,
                                        'skill_slug'    =>  preg_replace('/[^A-Za-z0-9\-]/','-',$subskill[$i]),
                                        'skill_descri'  =>  $skill_dec[$i],
                                        'skill_class'   =>  $year_id,
                                    );
                          $insertsubskill=$this->main_model->Save($obj,TBL_SKILL,$sub_skill);
                     }
                 $this->session->set_flashdata('success_msg','skill added successsfully!!');
                 redirect(base_url(ENGLISH_ADMIN.'/syllabus/'.$year));   
                }
            else
                {
                  $this->session->set_flashdata('success_msg','skill NOT added!!'); 
                  redirect(base_url(ENGLISH_ADMIN.'/syllabus/'.$year));
                }
            
        }
    elseif($this->input->post('subskill-submit')=="Save")
        {
         $insertskill=$this->input->post('skill_name');
         $subskill=$this->input->post('subskill_name');
         $skill_dec=$this->input->post('subskill_dec');
         for($i=0;$i<count($skill_dec);$i++)
             {
                 $sub_skill=array(
                                'skill_name'    =>  $subskill[$i],
                                'skill_parent'  =>  $insertskill,
                                'skill_slug'    =>  preg_replace('/[^A-Za-z0-9\-]/','-',$subskill[$i]),
                                'skill_descri'  =>  $skill_dec[$i],
                                'skill_class'   =>  $year_id,
                            );
                  $insertsubskill=$this->main_model->Save($obj,TBL_SKILL,$sub_skill);
             
             
             }
                     
            if($insertsubskill)
                {  
                 $this->session->set_flashdata('success_msg','sub skill added successsfully!!');
                 redirect(base_url(ENGLISH_ADMIN.'/syllabus/'.$year));   
                }
            else
                {
                  $this->session->set_flashdata('success_msg','sub skill NOT added!!'); 
                  redirect(base_url(ENGLISH_ADMIN.'/syllabus/'.$year));
                }   
        }
    else
        {
            
            $this->load->view('backend/english/common/header',$objdata);		
        	$this->load->view('backend/english/addskill',$data);
        	$this->load->view('backend/english/common/footer'); 
        
        }
    
    
      
 }
public function edit_skill($year="",$skillid="")    
 {
    if($this->uri->segment(1)==MATH_ADMIN_SEG)
    {
    $obj=$this->math;
    $objdata["obj"]= $obj;  
    }elseif($this->uri->segment(1)==ENGLISH_ADMIN_SEG){
     $obj=$this->english;
     $objdata["obj"]= $obj;     
    }
    $data['year']=$year;
    $data['skillid']=$skillid;
    $year_id=$this->main_model->getsid(TBL_CLASS,$objdata['obj'],$year); 
    $data['year_id']=$year_id;
    $data['year_dtl']=$this->main_model->get_detail($obj,TBL_CLASS,array('class_id'=>$year_id),"single");
    $data['SylList']=$this->main_model->get_detail($obj,'master_skill',array('skill_class'=>$year_id,'skill_parent'=>'0'),$insgle=null,'skill_order','asc');
    $data['subskilldefault']=$this->main_model->get_detail($obj,TBL_SKILL,array('skill_slug'=>$skillid,'skill_class'=>$year_id),"single");
    if($this->input->post('skill-upadte')=='Update')
    {
        $update=array(
                        'skill_name'=>$this->input->post('skill_name'),
                        'skill_descri'=>($this->input->post('skill_dec'))?$this->input->post('skill_dec'):null,
                        );
     $update1= $this->main_model->update($obj,TBL_SKILL,$update,array('skill_id'=>$data['subskilldefault']->skill_id));
    if($update1)
            {  
             $this->session->set_flashdata('success_msg','sub skill update successsfully!!');
             redirect(base_url(ENGLISH_ADMIN.'/syllabus/'.$year));   
            }
        else
            {
              $this->session->set_flashdata('success_msg','sub skill NOT update!!'); 
              redirect(base_url(ENGLISH_ADMIN.'/syllabus/'.$year));
            } 
    
    }
    else
    {
       $this->load->view('backend/english/common/header',$objdata);		
	   $this->load->view('backend/english/edit-skill',$data);
	   $this->load->view('backend/english/common/footer');    
    }
    
    
 }
	
}
