<?php
defined('BASEPATH') OR exit('No direct script access allowed');
error_reporting(E_ALL);
ini_set('display_errors',0); 
class Ajaxcall extends My_Controller {
	public function __construct()
    {
            parent::__construct();
			$this->load->library(array('session'));
			$this->load->helper(array('url'));
			$this->load->helper('form');
			$this->load->helper('question_helper');
			$this->load->helper('check_answer_helper');
			date_default_timezone_set('Pacific/Auckland');	
			$this->load->library("pagination");
    }


public function ajax_testexam($subject="")
	{ 
		
        if($subject=='math')
        {
        $obj=$this->math;
        $objdata["obj"]= $obj;  
        }elseif($this->uri->segment(1)=='english'){
         $obj=$this->english;
         $objdata['obj'];   
        }
       
        
       
        $htmdata='';
		$this->session->set_userdata('totalquestion', '0');
		$userid=$this->session->userdata('user_id');
		$year_id=$this->input->post('year_id');
		$subskill=$this->input->post('subskill');
        	
		$skill_dtl =$this->main_model->get_detail($obj,'master_skill',array('skill_slug'=>$subskill,'skill_class'=>$year_id),'single');
        
        $subskill_id=$skill_dtl->skill_id;
		$this->questions_model->CLASSID = $year_id;
		
	if($this->input->post('action')=='submitanswer')	
					{				
						$attempt = $this->session->userdata('attempt');
						$attempt++;
						$this->session->set_userdata('attempt', $attempt);
						$questionid=$this->input->post('questionid');
						$answerid=$this->input->post('answerid');
						$ques_year_id=$this->input->post('ques_class');
						$page=$this->input->post('page');
						
						//$data["ques_dtl"] = $this->main_model->get_detail('manage_question_'.$ques_year_id,'ques_id',$questionid);
						$data["ques_dtl"] = $this->main_model->get_detail($obj,'manage_question_'.$ques_year_id,array('ques_id'=>$questionid),'single');
                        //print_r($data["ques_dtl"]);

						//$data["correct_ans"] = $this->main_model->get_detail('manage_answer_'.$ques_year_id,'ans_id',$data["ques_dtl"]->ques_rightanswer);
						$data["correct_ans"] = $this->main_model->get_detail($obj,'manage_answer_'.$ques_year_id,array('ans_id'=>$data["ques_dtl"]->ques_rightanswer),'single');
                        //print_r($data["correct_ans"]);
						//echo $data["correct_ans"]->ans_name;
						
						//04-29-19 starts
						$your_ans1 = $this->main_model->get_detail($obj,'manage_answer_'.$ques_year_id,array('ans_id'=>$answerid),'single');
						if($your_ans1->ans_name==$data["correct_ans"]->ans_name){
							
						$dt=array(
						'user_id'=>$userid,
						'ques_id'=>$questionid,
						'ans_id'=>$answerid,						
						'ques_class'=>$ques_year_id,						
						'crt_ans'=>$data["correct_ans"]->ans_name,						
						'createdOn'=>date('Y-m-d H:i:s')
						);
							
						}else{
							
						$dt=array(
						'user_id'=>$userid,
						'ques_id'=>$questionid,
						'ans_id'=>$answerid,						
						'ques_class'=>$ques_year_id,
						'crt_ans'=>$data["correct_ans"]->ans_name,				
						'wrg_ans'=>$your_ans1->ans_name,
						'createdOn'=>date('Y-m-d H:i:s')			

						);
							
						}
						//var_dump($dt);die;
						$this->main_model->Save_Quiz('quiz_user',$dt);
						//04-09-19 ends
						
						
						$ques_type=explode(',',$data["ques_dtl"]->ques_type);
						
						//Check answer
						$answer_truthness=check_answer($_POST,$obj);
						
                        
                        
						
		if($answer_truthness)
		{

		$correct=1;
		$ansattempt = $this->session->userdata('ansattempt');
		$ansattempt++;
		$this->session->set_userdata('ansattempt', $ansattempt);

		if(isset($correct) && $correct==1){	
				$htmdata .='<div id="infor"><h3>Fantastic</h3></div>';
			}
			
			
		if($page!='preview'){
			$Questionlist = $this->main_model->random_question($obj,$year_id,$subskill_id);
			
			//$this->load->view('frontend/private/play',$data);
			//------question & answer Pay--------
			$calper=($this->session->userdata('ansattempt')/$this->session->userdata('attempt'))*100;
			$textper_marks=number_format($calper);
			$htmdata .='<script type="text/javascript">					
				$("#textexamtotal").text( "'.$this->session->userdata('attempt').'/'.$this->session->userdata('ansattempt').'" );
				$("#testexampersent").text( "'.$textper_marks.'%" );
				</script>';
			foreach($Questionlist as $result){

			$htmdata1 =	get_question($obj,$year_id,$result->ques_id);
			$htmdata.=	$htmdata1; 
			}
		}
	
		}
	
		else
		{
		/*-----display wrong Explation-----*/
		$htmdata1 =	$this->get_explanation($obj,$year_id,$questionid,$answerid,$_POST);
		$htmdata.=	$htmdata1;
		$calper=($this->session->userdata('ansattempt')/$this->session->userdata('attempt'))*100;
		$textper_marks=number_format($calper);
		$htmdata .='<script type="text/javascript">					
		$("#textexamtotal").text( "'.$this->session->userdata('attempt').'/'.$this->session->userdata('ansattempt').'" );
		$("#testexampersent").text( "'.$textper_marks.'%" );
		</script>';
		
		if($page=='preview'){
			$htmdata .='<input type="hidden" name="page" value="preview"/>';
		}
			
		$htmdata .='<input type="hidden" name="year_id" value="'.$year_id.'"/>
					<input type="hidden" name="subskill" value="'.$subskill.'"/><input type="hidden" name="class_exercise" value="'.$class_exercise.'"/>';
					/*-----end of display wrong anser-----*/
		}
				
		/*------end of Explanation file----*/

		}
		else
		{
		$page=$this->input->post('page');				
		$calper=($this->session->userdata('ansattempt')/$this->session->userdata('attempt'))*100;
		$textper_marks=number_format($calper);
		$htmdata .='<script type="text/javascript">					
		$("#textexamtotal").text( "'.$this->session->userdata('attempt').'/'.$this->session->userdata('ansattempt').'" );
		$("#testexampersent").text( "'.$textper_marks.'%" );
		</script>';
				$class_exercise=$this->input->post('class_exercise');
				if($page!='preview'){
				$Questionlist = $this->main_model->random_question($obj,$year_id,$subskill_id);
				/*------question & answer display--------*/
				foreach($Questionlist as $result)
				{
		
					$htmdata1 =	get_question($obj,$year_id,$result->ques_id);
					$htmdata.=	$htmdata1; 
				}
				$htmdata .='<script type="text/javascript">					
				$("#btntestexam").prop("value", "Submit");
					</script>';	
				}
			}
				$htmdata .='<script type="text/javascript">					
                    				setInterval(function(){
                                        $("#infor").hide("slow","linear");
                                    },1000);
					       </script>';		
				echo $htmdata;
			
    }
public function get_explanation($obj,$year_id,$ques_id,$ans_id,$posted_ans){
	
	
	$this->questions_model->CLASSID = $year_id;
	$result = $this->main_model->get_detail($obj,'manage_question_'.$year_id,array('ques_id'=>$ques_id),'single');
	$ques_type=explode(',',$result->ques_type);
	$year_dtl=$this->main_model->get_detail($obj,'master_class',array('class_id'=>$result->ques_class));
	$skill_dtl=$this->main_model->get_detail($obj,'master_skill',array('skill_id'=>$result->ques_subskillid),'single');
	
	$html.= '<form method="post" action="">			
		<h1>Sorry, incorrect... </h1>';
		if(in_array(1,$ques_type)){ 
			$correct_ans = $this->main_model->get_detail($obj,'manage_answer_'.$year_id,array('ans_id'=>$result->ques_rightanswer),'single');
			
			if($correct_ans->has_image==1){
						$html.= '<h3>The correct answer is:<label><img src="'.$correct_ans->ans_name.'" /></label></h3>';	
						
						}
			else{
					 
				if($correct_ans->ans_type=='2')
					{
						$correct_ans->ans_name=base64_decode(trim($correct_ans->ans_name));
						 
					}
					
				
			$html.= '<h3>The correct answer is:&nbsp;<strong style="font-size: 34px; color:#ed9c0f">'.$correct_ans->ans_name.'</strong> </h3>';
			
			}
		}
		elseif(in_array(22,$ques_type))
					{
					$html.= '<h3>The correct answer is:';
					$answerid=explode(',',$result->ques_rightanswer);
					$ans=array();
					for($i=0;$i<count($answerid);$i++)
					{
					$correct_ans = $this->main_model->get_detail($obj,'manage_answer_'.$year_id,array('ans_id'=>$answerid[$i]),'single');
					if($correct_ans->has_image==1){
						$ans[]='<label><img src="'.$correct_ans->ans_name.'" /></label>';	
						
						}
						else{
								 
						if($correct_ans->ans_type=='2')
							{
								$correct_ans->ans_name=base64_decode(trim($correct_ans->ans_name));
								 
							}
						$ans[]=$correct_ans->ans_name;
						}	
					}
			$ans=implode(', ',$ans);		
			$html.='  <strong style="font-size: 34px; color:#ed9c0f">';		
			$html.=$ans;		
			$html.='</strong> </h3>';		
		}	
elseif(in_array(32,$ques_type))
		{
			$all_answer = $this->main_model->getall($obj,'manage_answer_'.$year_id,array('ans_quesid'=>$ques_id));
			$correct_ansname=array();
				for($i=0;$i<count($all_answer);$i++){
							
							
								if($all_answer[$i]->ans_name!="" && $all_answer[$i]->ans_correct==1)
								{ 
							if($all_answer[$i]->ans_type=='2')
								{
									 $correct_ansname[]=base64_decode(trim($all_answer[$i]->ans_name));
									 
								}
								else{
									$correct_ansname[]=$all_answer[$i]->ans_name;
								}
								
									
								}
							}
						$correct_ansname=implode(', ',$correct_ansname)	;
		$html.= '<h3>The correct answer is:<strong style="font-size: 34px; color:#ed9c0f">&nbsp;'.$correct_ansname.'</strong> </h3>';				
							
		}		
		elseif(in_array(26,$ques_type))
		{		
			$all_answer = $this->main_model->getall($obj,'manage_answer_'.$year_id,array('ans_quesid'=>$ques_id),'single');
			$correct_ansname=array();
				for($i=0;$i<count($all_answer);$i++){
							
								if($all_answer[$i]->ans_name!="" && $all_answer[$i]->ans_correct==1)
								{ 
							
								 
								if($all_answer[$i]->ans_type=='2')
									{
										$all_answer[$i]->ans_name=base64_decode(trim($all_answer[$i]->ans_name));
										 
									}
							
								$correct_ansname[]=$all_answer[$i]->ans_name;
									
								}
							}
				$correct_ansname=implode(', ',$correct_ansname)	;				
		$html.= '<h3>The correct answer is:<strong style="font-size: 34px; color:#ed9c0f">&nbsp;'.$correct_ansname.'</strong> </h3>';				
							
		}	
		
		$html.='<div style="border:1px solid #ccc; padding:30px;">';
		
			$html.='<div class="'.$year_dtl->class_slug.'-'.$skill_dtl->skill_slug.'  cls-'.$year_dtl->class_id.'-'.$result->ques_id.'">'; 
		
				$ques_type=explode(',',$result->ques_type);
				
				if(in_array(1,$ques_type)){  
					if(in_array(26,$ques_type))
					{
					$QuesDecoded = base64_decode($result->ques_name); 
					$html.= $QuesDecoded;
					}else{
					$html.= '<p>'.$result->ques_name.'</p>';
					}
					$html.= '<br>';
					
				
					$answers=$this->main_model->get_answers($obj,$result->ques_id,$year_id);
					foreach($answers as $answer){
					
					if($answer->has_image==1){
					$html.= '<a id ="a1" class="quiz-btn" href="#!"><input name="answerid" value="'.$answer->ans_id.'" name="rb" type="radio" id="rb1"><label><img src="'.$answer->ans_name.'" /></label></a>&nbsp;&nbsp;&nbsp;';	
					
					}
					else{
						if($answer->ans_type=='2')
						{
						$answer->ans_name=base64_decode(trim($answer->ans_name));
						 
						}
					$html.=  '<a id ="a1" class="quiz-btn" href="#!"><input name="answerid" value="'.$answer->ans_id.'" name="rb" type="radio" id="rb1"><label>'.$answer->ans_name.'</label></a>&nbsp;&nbsp;&nbsp;';
					}
					
					}
					
				
				}
					
				
				elseif(in_array(22,$ques_type))
				{ 
					if(in_array(26,$ques_type)){
					$QuesDecoded = base64_decode($result->ques_name); 
					}
					else{$QuesDecoded =$result->ques_name; }
					$html.= $QuesDecoded;
					$html.= '<br>';
					$answers=$this->main_model->get_answers($obj,$result->ques_id,$year_id);
					foreach($answers as $answer){
							
					if($answer->has_image==1){
					$html.= '<a id ="a1" class="quiz-btn" href="#!"><input name="answerid" value="'.$answer->ans_id.'" name="rb" type="checkbox" id="rb1"><label><img src="'.$answer->ans_name.'" /></label></a>&nbsp;&nbsp;&nbsp;';	
					
					}
					else{
						if($answer->ans_type=='2')
						{
						$answer->ans_name=base64_decode(trim($answer->ans_name));
						 
						}
					$html.=  '<a id ="a1" class="quiz-btn" href="#!"><input name="answerid" value="'.$answer->ans_id.'" name="rb" type="checkbox" id="rb1"><label>'.$answer->ans_name.'</label></a>&nbsp;&nbsp;&nbsp;';
					}
					
					}
					
					
				
				}
				elseif(in_array(26,$ques_type))
				{
					$QuesDecoded = base64_decode($result->ques_name); 
					$html.= $QuesDecoded;
					$html.= '<br>';
					
				
				}
				else{ 
				$html.= '<p>'.$result->ques_name.'</p>';
				$html.= '<br>';
					
				}
			
$html.= '</div>'; 
			$html.='<h4 class="space10">You answered: </h4>'; 
			
			if(in_array(1,$ques_type) || in_array(4,$ques_type) || in_array(6,$ques_type)){ 
				$your_ans1 = $this->main_model->get_detail($obj,'manage_answer_'.$year_id,array('ans_id'=>$ans_id),'single');
				if($your_ans1->has_image==1){
							$html.= '<h3><label><img src="'.$your_ans1->ans_name.'" /></label></h3>';	
							
							}
				else{
					if($your_ans1->ans_type=='2')
						{
						$your_ans1->ans_name=base64_decode(trim($your_ans1->ans_name));
						 
						}
				$html.='<h3>'.$your_ans1->ans_name.'</h3>';
				}
			}
			elseif(in_array(22,$ques_type))
			{	$ans=array();
				$html.='<h3>';
				$ans_id=explode(',',$ans_id);
				
				for($i=0;$i<count($ans_id);$i++){
					$your_ans1 = $this->main_model->get_detail($obj,'manage_answer_'.$year_id,array('ans_id'=>$ans_id[$i]),'single');
					if($your_ans1->has_image==1){
						$ans[]= '<label><img src="'.$your_ans1->ans_name.'" /></label>';	
								
						}
					else{
						if($your_ans1->ans_type=='2')
						{
							$ans[]=base64_decode(trim($your_ans1->ans_name));
						 
						}
						else{
							$ans[]= $your_ans1->ans_name;
						}
					}	
				}
				
				$ans=implode(' ',$ans);
				$html.=$ans.'</h3>';
			}
			elseif(in_array(26,$ques_type))
					    {
							
						if($posted_ans!=""){
						for($i=1;$i<=count($all_answer);$i++){
							
							
							if($posted_ans['input'.$i]!="")
							{ 
								$yourans.=$posted_ans['input'.$i];
								
							}
						
									
						}
			
			
				$html.='<h3>'.$yourans.'</h3>';
				}
				}
			$html.='</form>
			</div>';
			$html .='<script type="text/javascript">					
		$("#btntestexam").prop("value", "Next");
		</script>
		<script>window.MathJax = { MathML: { extensions: ["mml3.js", "content-mathml.js"]}};</script>
<script type="text/javascript" async src="https://cdnjs.cloudflare.com/ajax/libs/mathjax/2.7.0/MathJax.js?config=MML_HTMLorMML"></script>
';
		
    
			

return  $html;





}















/*end*/
}