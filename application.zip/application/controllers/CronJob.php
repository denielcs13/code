<?php
class CronJob extends CI_Controller
{
    public $math;
    public $main;
    public $english;
    public function __construct()
        {
            parent::__construct();
            date_default_timezone_set('Asia/Kolkata'); 			
    		$this->main=$this->load->database('default',true);
            $this->english=$this->load->database('uni_english',true);
            $this->math=$this->load->database('uni_math',true);
        }
public function cron_update_logout() 
	{		
		
       $all=$this->db->select('last_active_time,user_id,login_status')->get('main_user')->result();
       foreach($all as $row)
       {
        
        if($row->last_active_time!="" && $row->login_status=="yes")
        {
          
          $last=strtotime($row->last_active_time);
          $current=strtotime(date('y-m-d h:i:s'));
          $diff1=($current-$last)/60;
          $diff=round($diff1,0);
          if($diff>59)
          {
            $update=$this->db->where(array('login_status'=>'yes','user_id'=>$row->user_id))->update('main_user',array('login_status'=>'no'));
          }
           
        }
       }
	
	}
}



?>