<?php defined('BASEPATH') OR exit('No direct script access allowed');
class Adminmgmt extends MY_Controller {

	 
	public function __construct()
    {
            parent::__construct();			
						
			$this->load->model('Login_model','Login_model');			
			$this->load->helper(array('url','form'));
			$this->load->library(array('form_validation','session'));
    }	
	public function login()
	{
		
		
		$this->form_validation->set_rules('username', 'Username', 'required');
		$this->form_validation->set_rules('password', 'Password', 'required');		
		if($this->form_validation->run())
		{
			
			$username = $this->input->post('username');
			$password = $this->input->post('password');
			$user_type = $this->input->post('user_type');
			$data=array('val'=>'',
						'table'=>'main_user',
						'where'=>array('user_name'=>$username,'password'=>md5($password),'status'=>'1')
						);
			$res=$this->Login_model->signin($data);
			if ($res['res']) 
			{	
				$userlogindata = array( 
									'username' => $res['rows']->user_name,
									'logged_in' => true,
									'user_id' => $res['rows']->user_id,
									'email' => $res['rows']->email,
									'user_type'=>$res['rows']->user_type,
                                    );
									//var_dump($userlogindata);exit;
                
                $this->session->set_userdata($userlogindata);            						
				if($res['rows']->role_type=="math_admin"):
                $this->session->set_userdata('role_type','math');
                redirect(BASE_URL_MATH_ADMIN);
                elseif($res['rows']->role_type=="english_admin"):
                $this->session->set_userdata('role_type','english');
                redirect(BASE_URL_ENGLISH_ADMIN);
                elseif($res['rows']->role_type=="chinees_admin"):
                $this->session->set_userdata('role_type','chinees');
                redirect(BASE_URL_CHINEES_ADMIN);
                elseif($res['rows']->role_type=="physics_admin"):
                $this->session->set_userdata('role_type','physics');
                redirect(BASE_URL_PHYSICS_ADMIN);
				elseif($res['rows']->role_type=="super_admin"):
                $this->session->set_userdata('role_type','super_admin');
                redirect(BASE_URL_MAIN_ADMIN);
                endif;
            } 
			else
			{
				$data['error']='Sorry your username and password did not match.<br/> <br/>Please try again.';
				$this->load->view('backend/math/login',$data);
			}	
			
		}		
		else
		{
		$data['error']='';
		$this->load->view('backend/math/login',$data);

		}		
		
	}	
	
public function upload($year=''){
	      $year=strtolower($year);
		
		if(isset($_FILES['upload'])){
			// ------ Process your file upload code -------
			$filen = $_FILES['upload']['tmp_name']; 
			$temp = explode(".", $_FILES["upload"]["name"]);
			
			$newfilename = round(microtime(true)) . '.' . end($temp);
			//$con_images = "assets/uploads/ans/$year/".$newfilename;
			$uploaddir = 'assets/uploads/ans/'.$year.'/';
			if (!is_dir($uploaddir) && !mkdir($uploaddir)){
			  die("Error creating folder $uploaddir");
			}			
			$con_images=$uploaddir.$newfilename;
			move_uploaded_file($filen, $con_images );
			
		   //$url =	base_url()."assets/uploads/ans/$year/".$newfilename;
           $url =	base_url().$con_images;
		   $funcNum = $_GET['CKEditorFuncNum'] ;
		   // Optional: instance name (might be used to load a specific configuration file or anything else).
		   $CKEditor = $_GET['CKEditor'] ;
		   // Optional: might be used to provide localized messages.
		   $langCode = $_GET['langCode'] ;
			
		   // Usually you will only assign something here if the file could not be uploaded.
		   $message = '';
		   echo "<script type='text/javascript'>window.parent.CKEDITOR.tools.callFunction($funcNum, '$url', '$message');</script>";
		}	
	
}	
	
}
