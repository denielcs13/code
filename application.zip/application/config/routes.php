<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/*
| -------------------------------------------------------------------------
| URI ROUTING
| -------------------------------------------------------------------------
| This file lets you re-map URI requests to specific controller functions.
|
| Typically there is a one-to-one relationship between a URL string
| and its corresponding controller class/method. The segments in a
| URL normally follow this pattern:
|
|	example.com/class/method/id/
|
| In some instances, however, you may want to remap this relationship
| so that a different class/function is called than the one
| corresponding to the URL.
|
| Please see the user guide for complete details:
|
|	https://codeigniter.com/user_guide/general/routing.html
|
| -------------------------------------------------------------------------
| RESERVED ROUTES
| -------------------------------------------------------------------------
|
| There are three reserved routes:
|
|	$route['default_controller'] = 'welcome';
|
| This route indicates which controller class should be loaded if the
| URI contains no data. In the above example, the "welcome" class
| would be loaded.
|
|	$route['404_override'] = 'errors/page_missing';
|
| This route will tell the Router which controller/method to use if those
| provided in the URL cannot be matched to a valid route.
|
|	$route['translate_uri_dashes'] = FALSE;
|
| This is not exactly a route, but allows you to automatically route
| controller and method names that contain dashes. '-' isn't a valid
| class or method name character, so it requires translation.
| When you set this option to TRUE, it will replace ALL dashes in the
| controller and method URI segments.
|
| Examples:	my-controller/index	-> my_controller/index
|		my-controller/my-method	-> my_controller/my_method
*/
//math
$route['default_controller'] = 'unieducation';
$route['dummy'] = 'unieducation/subkilll';
// common
$route['register'] = 'unieducation/register';
//04-26-19
$route['add-user'] = 'unieducation/add_user';
$route['student-list'] = 'unieducation/student_list';
$route['delete-student/(:num)'] = 'unieducation/delete_student/$1';
$route['edit-student/(:num)'] = 'unieducation/edit_student/$1';
$route['math'] = 'unieducation/user_math';
$route['english'] = 'unieducation/user_english';
// 04-29-19 
$route['score'] = 'unieducation/user_score';
//04-30-19
$route['send-add-request'] = 'unieducation/send_add_request';
$route['mail-sent-institute'] = 'unieducation/send_email_inst';
//05-01-19
$route['approve-student'] = 'unieducation/approve_add_request'; 
$route['studentemailcheck'] = 'unieducation/studentemailcheck';
//05-02-19
$route['add-syllabus'] = 'unieducation/add_syllabus';
$route['classnamecheck'] = 'unieducation/classnamecheck/$1'; 
//05-03-19
$route['institute-syllabus-list'] = 'unieducation/institute_syllabus_list'; 
$route['delete-inst-syllabus/(:num)'] = 'unieducation/delete_inst_syllabus/$1';
//05-06-19 
$route['student-question-list'] = 'unieducation/student_question_list';
//05-07-19

/*statelist*/
$route['state_list/(:any)'] = 'unieducation/all_states_list/$1';
$route['country_list'] = 'unieducation/all_country_list';

$route['math_inst/(:any)'] = 'unieducation/math_inst/$1'; 
$route['math_inst/(:any)/(:any)'] = 'unieducation/math_inst/$1/$2';

$route['english_inst/(:any)'] = 'unieducation/english_inst/$1'; 
$route['english_inst/(:any)/(:any)'] = 'unieducation/english_inst/$1/$2';  


$route['useremailcheck1'] = 'unieducation/useremailcheck1';
$route['registered'] = 'unieducation/registered';
$route['login'] = 'unieducation/login';
$route['logout'] = 'unieducation/logout';
$route['logout1'] = 'unieducation/logout1';
$route['profile-update'] = 'unieducation/profile_update';
$route['dashboard-user'] = 'unieducation/user_dashboard';
$route['dashboard'] = 'unieducation/mynoticeboard';
$route['testimonials'] = 'unieducation/testimonial';
$route['contact-us'] = 'unieducation/contactus';
$route['our-centers'] = 'unieducation/our_centers';
$route['forgot-password'] = 'unieducation/forgotpassword';
$route['disclaimer'] = 'unieducation/disclaimer';
$route['help-center'] = 'unieducation/helpcenter';
$route['faqs'] = 'unieducation/faqs';
$route['term-conditions'] = 'unieducation/termconditions';
$route['privacy-policy'] = 'unieducation/privacypolicy';
$route['cronJob/device'] = 'CronJob/cron_update_logout'; 
// common



$route['math/(:any)'] = 'unieducation/math/$1';
$route['math/(:any)/(:any)'] = 'unieducation/math/$1/$2';



//english


$route['english/(:any)'] = 'unieducation/english/$1';
$route['english/(:any)/(:any)'] = 'unieducation/english/$1/$2';






// ADMIN PENAL
//$route['adminmgmt'] = 'adminmgmt/adminmgmt';
$route['adminmgmt/questions/upload/(:any)'] = 'adminmgmt/adminmgmt/upload/$1';

$route['adm-AjNoX9'] = 'adminmgmt/adminmgmt/login';
$route['math-MRGy2Cn/adm'] = 'mathmgmt/adminmgmt';
$route['math-MRGy2Cn/adm/login'] = 'mathmgmt/adminmgmt/login';
$route['math-MRGy2Cn/adm/logout'] = 'mathmgmt/adminmgmt/logout';
$route['math-MRGy2Cn/adm/subject/(:any)'] = 'mathmgmt/adminmgmt/select_subject/$1';
$route['math-MRGy2Cn/adm/get-class/(:any)'] = 'mathmgmt/adminmgmt/get_class/$1';
$route['math-MRGy2Cn/adm/add-sklill/(:any)/(:any)'] = 'mathmgmt/adminmgmt/add_skill/$1/$2';
$route['math-MRGy2Cn/adm/syllabus/(:any)'] = 'mathmgmt/adminmgmt/skill/$1';
$route['math-MRGy2Cn/adm/syllabus/(:any)/(:any)'] = 'mathmgmt/adminmgmt/skill/$1/$2';
$route['math-MRGy2Cn/adm/questions/(:any)'] = 'mathmgmt/adminmgmt/questions_list/$1';
$route['math-MRGy2Cn/adm/questions/(:any)/(:any)'] = 'mathmgmt/adminmgmt/questions_list/$1/$2';
$route['math-MRGy2Cn/adm/syllabus-order/(:any)'] = 'mathmgmt/adminmgmt/skill_order/$1';
$route['math-MRGy2Cn/adm/syllabus-order/(:any)/(:any)'] = 'mathmgmt/adminmgmt/subskill_order/$1/$2';
$route['math-MRGy2Cn/adm/add-question/(:any)'] = 'mathmgmt/adminmgmt/add_question/$1';
$route['math-MRGy2Cn/adm/edit-question/(:any)/(:any)'] = 'mathmgmt/adminmgmt/edit_question/$1/$2';
$route['math-MRGy2Cn/adm/get-subskill/(:any)/(:any)'] = 'mathmgmt/adminmgmt/get_subskill/$1/$2';
$route['math-MRGy2Cn/adm/delete-question/(:any)/(:any)'] = 'mathmgmt/adminmgmt/delete_question/$1/$2';
//done
$route['math-MRGy2Cn/adm/add-skill/(:any)'] = 'mathmgmt/adminmgmt/add_skill/$1';
$route['math-MRGy2Cn/adm/add-subskill/(:any)'] = 'mathmgmt/adminmgmt/add_skill/$1';
$route['math-MRGy2Cn/adm/edit-skill/(:any)/(:any)'] = 'mathmgmt/adminmgmt/edit_skill/$1/$2';


//super admin mgmt
$route['AjNoX9/adm'] = 'mainmgmt/adminmgmt';
$route['AjNoX9/adm/student'] = 'mainmgmt/adminmgmt/student';
$route['AjNoX9/adm/parent'] = 'mainmgmt/adminmgmt/parent';
$route['AjNoX9/adm/institute'] = 'mainmgmt/adminmgmt/institute';
$route['AjNoX9/adm/student/(:any)'] = 'mainmgmt/adminmgmt/student/$1';
$route['AjNoX9/adm/student-list/(:any)'] = 'mainmgmt/adminmgmt/student_list/$1';
$route['AjNoX9/adm/parent/(:any)'] = 'mainmgmt/adminmgmt/parent/$1';
$route['AjNoX9/adm/institute/(:any)'] = 'mainmgmt/adminmgmt/institute/$1';

$route['AjNoX9/adm/delete-user/(:any)'] = 'mainmgmt/adminmgmt/delete_user/$1';
$route['AjNoX9/adm/edit-user/(:any)'] = 'mainmgmt/adminmgmt/edit_user/$1';
$route['AjNoX9/adm/active-user/(:any)/(:any)'] = 'mainmgmt/adminmgmt/active_user/$1/$2';



$route['eng-ECD8nq/adm'] = 'englishmgmt/adminmgmt';
$route['eng-ECD8nq/adm/login'] = 'englishmgmt/adminmgmt/login';
$route['eng-ECD8nq/adm/logout'] = 'englishmgmt/adminmgmt/logout';
$route['eng-ECD8nq/adm/subject/(:any)'] = 'englishmgmt/adminmgmt/select_subject/$1';
$route['eng-ECD8nq/adm/get-class/(:any)'] = 'englishmgmt/adminmgmt/get_class/$1';
$route['eng-ECD8nq/adm/add-sklill/(:any)/(:any)'] = 'englishmgmt/adminmgmt/add_skill/$1/$2';
$route['eng-ECD8nq/adm/syllabus/(:any)'] = 'englishmgmt/adminmgmt/skill/$1';
$route['eng-ECD8nq/adm/syllabus/(:any)/(:any)'] = 'englishmgmt/adminmgmt/skill/$1/$2';
$route['eng-ECD8nq/adm/questions/(:any)'] = 'englishmgmt/adminmgmt/questions_list/$1';
$route['eng-ECD8nq/adm/questions/(:any)/(:any)'] = 'englishmgmt/adminmgmt/questions_list/$1/$2';
$route['eng-ECD8nq/adm/add-sklill/(:any)/(:any)'] = 'englishmgmt/adminmgmt/add_skill/$1/$2';
$route['eng-ECD8nq/adm/syllabus/(:any)'] = 'englishmgmt/adminmgmt/skill/$1';
$route['eng-ECD8nq/adm/syllabus/(:any)/(:any)'] = 'englishmgmt/adminmgmt/skill/$1/$2';
$route['eng-ECD8nq/adm/syllabus-order/(:any)'] = 'englishmgmt/adminmgmt/skill_order/$1';
$route['eng-ECD8nq/adm/syllabus-order/(:any)/(:any)'] = 'englishmgmt/adminmgmt/subskill_order/$1/$2';
$route['eng-ECD8nq/adm/add-question/(:any)'] = 'englishmgmt/adminmgmt/add_question/$1';
$route['eng-ECD8nq/adm/edit-question/(:any)/(:any)'] = 'englishmgmt/adminmgmt/edit_question/$1/$2';
$route['eng-ECD8nq/adm/get-subskill/(:any)/(:any)'] = 'englishmgmt/adminmgmt/get_subskill/$1/$2';
$route['eng-ECD8nq/adm/delete-question/(:any)/(:any)'] = 'englishmgmt/adminmgmt/delete_question/$1/$2';
$route['eng-ECD8nq/adm/add-skill/(:any)'] = 'englishmgmt/adminmgmt/add_skill/$1';
$route['eng-ECD8nq/adm/add-subskill/(:any)'] = 'englishmgmt/adminmgmt/add_skill/$1';
$route['eng-ECD8nq/adm/edit-skill/(:any)/(:any)'] = 'englishmgmt/adminmgmt/edit_skill/$1/$2';


$route['eng-ECD8nq/adm/import/(:any)'] = 'englishmgmt/adminmgmt/import/$1';

/* --chinees-- */
$route['chi-CHI7zx/adm'] = 'chineesmgmt/adminmgmt';
$route['chi-CHI7zx/adm/login'] = 'chineesmgmt/adminmgmt/login';
$route['chi-CHI7zx/adm/logout'] = 'chineesmgmt/adminmgmt/logout';
$route['chi-CHI7zx/adm/subject/(:any)'] = 'chineesmgmt/adminmgmt/select_subject/$1';
$route['chi-CHI7zx/adm/get-class/(:any)'] = 'chineesmgmt/adminmgmt/get_class/$1';
$route['chi-CHI7zx/adm/add-sklill/(:any)/(:any)'] = 'chineesmgmt/adminmgmt/add_skill/$1/$2';
$route['chi-CHI7zx/adm/syllabus/(:any)'] = 'chineesmgmt/adminmgmt/skill/$1';
$route['chi-CHI7zx/adm/syllabus/(:any)/(:any)'] = 'chineesmgmt/adminmgmt/skill/$1/$2';
$route['chi-CHI7zx/adm/questions/(:any)'] = 'chineesmgmt/adminmgmt/questions_list/$1';
$route['chi-CHI7zx/adm/questions/(:any)/(:any)'] = 'chineesmgmt/adminmgmt/questions_list/$1/$2';
$route['chi-CHI7zx/adm/add-sklill/(:any)/(:any)'] = 'chineesmgmt/adminmgmt/add_skill/$1/$2';
$route['chi-CHI7zx/adm/syllabus/(:any)'] = 'chineesmgmt/adminmgmt/skill/$1';
$route['chi-CHI7zx/adm/syllabus/(:any)/(:any)'] = 'chineesmgmt/adminmgmt/skill/$1/$2';
$route['chi-CHI7zx/adm/syllabus-order/(:any)'] = 'chineesmgmt/adminmgmt/skill_order/$1';
$route['chi-CHI7zx/adm/syllabus-order/(:any)/(:any)'] = 'chineesmgmt/adminmgmt/subskill_order/$1/$2';
$route['chi-CHI7zx/adm/add-question/(:any)'] = 'chineesmgmt/adminmgmt/add_question/$1';
$route['chi-CHI7zx/adm/edit-question/(:any)/(:any)'] = 'chineesmgmt/adminmgmt/edit_question/$1/$2';
$route['chi-CHI7zx/adm/get-subskill/(:any)/(:any)'] = 'chineesmgmt/adminmgmt/get_subskill/$1/$2';
$route['chi-CHI7zx/adm/delete-question/(:any)/(:any)'] = 'chineesmgmt/adminmgmt/delete_question/$1/$2';
$route['chi-CHI7zx/adm/add-skill/(:any)'] = 'chineesmgmt/adminmgmt/add_skill/$1';
$route['chi-CHI7zx/adm/add-subskill/(:any)'] = 'chineesmgmt/adminmgmt/add_skill/$1';
$route['chi-CHI7zx/adm/edit-skill/(:any)/(:any)'] = 'chineesmgmt/adminmgmt/edit_skill/$1/$2';





$route['adm-AjNoX9/login'] = 'adminmgmt/adminmgmt/login';
$route['adm-AjNoX9/logout'] = 'adminmgmt/adminmgmt/logout';
$route['AjNoX9/adm/logout'] = 'mainmgmt/adminmgmt/logout';
$route['adm-AjNoX9/subject/(:any)'] = 'adminmgmt/adminmgmt/select_subject/$1';
$route['adm-AjNoX9/get-class/(:any)'] = 'adminmgmt/adminmgmt/get_class/$1';
//math
$route['adm-AjNoX9/add-sklill/(:any)/(:any)'] = 'adminmgmt/adminmgmt/add_skill/$1/$2';
$route['adm-AjNoX9/skill/(:any)/(:any)'] = 'adminmgmt/adminmgmt/skill/$1/$2';







$route['chinese/adminmgmt'] = 'chinesemgmt/adminmgmt';



//english




$route['404_override'] = 'adminmgmt/_404';
$route['404_override'] = 'unieducation/_404';
//$route['translate_uri_dashes'] = FALSE;

$route['chinese'] = 'unieducation/user_chinese';
$route['chemistry'] = 'unieducation/user_chemistry';
$route['physics'] = 'unieducation/user_physics';
$route['biology'] = 'unieducation/user_biology';
$route['spanish'] = 'unieducation/user_spanish';

$route['test'] = 'unieducation/user_test';

$route['add-syllabus-skills/(:any)'] = 'unieducation/add_syllabus_skills/$1';
$route['inst-syllabus-skills/(:any)'] = 'unieducation/inst_syllabus_skills/$1'; 

$route['change-password'] = 'unieducation/changepassword';




