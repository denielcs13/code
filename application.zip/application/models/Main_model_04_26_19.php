<?php defined('BASEPATH') OR exit('No direct script access allowed');

class Main_model extends CI_Model {

	
	public function __construct() {
		parent::__construct();
		
	}
	
	public function get_detail($obj,$tbl_name,$where="",$single="",$order="",$ordertype="")
    {  
		$obj->select('*'); 
		$obj->from($tbl_name);
        if($where)
            {
              $obj->where($where);
            }
        if($order)
            {
              $obj->order_by($order,$ordertype);
            }
        if($single)
        {
        return $obj->get()->row();
        }else{
          return $obj->get()->result();  
        }
    }
    public function getall($obj,$tbl_name,$col_name='',$col_val='',$limit="",$offset="",$ordercol="",$order="")
    {
		$obj->select('*'); 
		$obj->from($tbl_name);
		if($col_name!="" && $col_val!="")
        {
		  $obj->where($col_name,$col_val);
		}
        if($limit)
		{
		  $obj->limit($limit, $offset);
		}
        if($order)
        {
          $obj->order_by($ordercol,$order);  
        }
		//$this->main->limit(0, 50);
		return $obj->get()->result();

	}
    public function getsid($table,$obj,$slug)
    {
       
       $id=$obj->select('class_id')->where('class_slug',$slug)->get($table)->row()->class_id;
       return $id; 
    }
    public function Save($obj,$tbl_name,$data)
	{
	
	  $obj->insert($tbl_name,$data);
	  return $obj->insert_id();
	}	
	
	public function Update($obj,$tbl_name,$data,$where)
	{
	  $obj->where($where);
	  return $obj->update($tbl_name,$data);
	}
	
	public function Delete($obj,$tbl_name,$where)
	{
	 if($where){
	  $obj->where($where); 
	  return $obj->delete($tbl_name);
	 }
	 else{
		 return flase;
	 }
	}
	public function numrows_total($obj,$tbl_name)
	{
		
		$numrows_total=$obj->get($tbl_name)->num_rows();
		return $numrows_total;
	}
    public function get_selected_details($table,$columns = array(),$where = array(),$records="single",$obj=false)
	{
        if(count($where) > 0){
			$this->main->where($where);
        }
		if(!empty($columns)){
			$this->main->select(implode(',', $columns));
		}
        $query = $this->main->get($table);
		
        if($records == "single"){
			if($obj){
				$result = $query->row();
			}else{
				$result = $query->row_array();
			}
            
        } else {
			if($obj){
				$result = $query->result();
			}else{
				$result = $query->result_array();
			}
        }	
        return $result;
   }
   public function student_emailcheck($email)
	{
        $temp=$this->db->where('email',$email)->get('temp_main_user')->num_rows();
        if($temp)
        {
          return $temp;  
        }else{
         $org=$this->db->where('email',$email)->get('main_user')->num_rows(); 
         return $org;   
        }	
        
   }
 public function signin($username,$password)
	{
	  
       $this -> db -> where(array('user_name'=>$username,'password'=>md5($password),'status'=>'1'));
	   $this -> db -> limit(1);	
	   $query = $this -> db -> get('main_user');	
		//echo $this->db->last_query();
		if($query -> num_rows() > 0)
		{
			$result=$query->row();
			return $result;
		}
		else
		{
		   $this -> db -> where(array('user_name'=>$username,'password'=>md5($password),'status'=>'1'));
    	   $this -> db -> limit(1);	
    	   $query = $this -> db -> get('temp_main_user');
           if($query -> num_rows() > 0)
    		{
    			$result=$query->row();
    			return $result;
    		}else{
    		  $result=false;
    		 return $result;
    		}
           
		   
		}	
   }
   public function lastlogin($data){
		$this->db->where('user_id', $this->session->userdata('user_id'));
		return $this->db->update('user_details',$data);	
	}
public function get_login_user_from_temp(){
   $this -> db -> where(array('user_id'=>$this->session->userdata('user_id')));
   
   $query = $this -> db -> get('temp_main_user');	
	if($query -> num_rows() > 0)
	{
		$result=$query->row();
		return $result;
	}
	else
	{
	  $result=false;
	  return $result;
	}	
}
public function get_login_user_from_main(){
   $this -> db -> where(array('user_id'=>$this->session->userdata('user_id')));
   
   $query = $this -> db -> get('main_user');	
	
	//echo $this->db->last_query();
	if($query -> num_rows() > 0)
	{
		$result=$query->row();
		return $result;
	}
	else
	{
	  $result=false;
	  return $result;
	}	
}
public function copy_user_row()
{
   $this->db->where('user_id',$this->session->userdata('user_id'));
   $temp_user=$this->db->get('temp_main_user')->row();
   $tempUserId=$this->session->userdata('user_id');
   $user=array(
                'first_name'=>$temp_user->first_name,
                'last_name'=>$temp_user->last_name,
                'dob'=>$temp_user->dob,
                'user_type'=>$temp_user->user_type,
                'edate'=>$temp_user->edate,
                'password'=>$temp_user->password,
                'user_name'=>$temp_user->user_name,
                'upload_path'=>$temp_user->upload_path,
                'email'=>$temp_user->email,
                'phone'=>$temp_user->phone,
                'address'=>$temp_user->address,
                'country'=>$temp_user->country,
                'city'=>$temp_user->city,
                'state'=>$temp_user->state,
                'zipcode'=>$temp_user->zipcode,
                'profile_update'=>'yes',
                'status'=>1
               );
   $res1=$this->db->where('user_id',$this->session->userdata('user_id'))->get('main_user');
  
   if($res1 -> num_rows()==0)
	{
	 $this->db->insert('main_user',$user);
     
    
       if($this->db->insert_id())
       {
        $orgUserId=$this->db->insert_id();
        $res=$this->db->where('user_id',$orgUserId)->get('main_user')->row();
        $userlogindata = array( 
    						'username' => $res->user_name,
    						'logged_in' => true,
    						'user_id' => $res->user_id,
    						'email' => $res->email,
    						'user_type'=>$res->user_type,
    						'fullname'=>$res->first_name.' '.$temp_user->last_name,
    						//'lastlogedin'=>$mylastlogin,
    						'profile_update'=>$res->profile_update
    						);
          $this->session->set_userdata($userlogindata);
          $delete=$this->db->where('user_id',$tempUserId)->delete('temp_main_user');
        	
    	}else{
    	   return $this->session->userdata('user_id');
    		   
    	}                  
     return $orgUserId;
   }
    
}

public function random_question($obj,$clssid,$subskill){
	
		$obj->select('*'); 
		$obj->from('manage_question_'.$clssid);
		$obj->where('ques_class',$clssid);	
		$obj->where('ques_subskillid',$subskill);
		$obj->order_by('ques_id','RANDOM');

		$obj->limit(1);		
		return $obj->get()->result();	
	}
public function get_answers($obj,$ques_id,$yearid)
    {
	    $obj->select('*'); 
		$obj->from('manage_answer_'.$yearid);
		$obj->where('ans_quesid',$ques_id);
		$obj->order_by('ans_id');
		return $obj->get()->result();	
	}


/*last */
}
?>