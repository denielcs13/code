<?php defined('BASEPATH') OR exit('No direct script access allowed');


class Login_model extends CI_Model {


	public function __construct() {
		parent::__construct();
		$this->load->database();
	}
	
	function signin($data)
	   {
		   $this -> db -> select($data['val']);
		   $this -> db -> from($data['table']);
		   $this -> db -> where($data['where']);
		   $this -> db -> limit(1);	
		   $query = $this -> db -> get();	
			
			//echo $this->db->last_query();
			if($query -> num_rows() > 0)
			{
				$result=array('res'=>true,'rows'=>$query->row_object());
				return $result;
			}
			else
			{
				$result=array('res'=>false);
				return $result;
			}
		}
	
	
	
	//////////////////////////////////////////////////////////////////////////////
	public function visitor_list(){
		$this->db->select('*'); 
		$this->db->from('visitor_details');
		$this->db->order_by('user_name', 'ASC');
		//$this->db->limit(0, 50);
		return $this->db->get()->result();

	
	}
	
	public function activity_status($id,$data)
	{
		$this->db->where('activity_type_id', $id);
		return $this->db->update('activity_type',$data);	
			
	}
	
	
	public function visitor_details($visitor_id='')
	{
		$this->db->select('*'); 
		$this->db->from('visitor_details');
		$this->db->where('visitor_id', $visitor_id);
		return $this->db->get()->result();	

	}
	
	public function Save_Update($data)
	{
	
	if($this->input->post('visitor_id')!='')
	{	
		$this->db->where('visitor_id', $this->input->post('visitor_id'));
		return $this->db->update('visitor_details',$data);
	}	
	else
	{
		return	$this->db->insert('visitor_details',$data);
	}	

	
	}
	
	
	
	
	
	public function delete_visitor($visitor_id){
			$this->db->where('visitor_id', $visitor_id);
			$this->db->delete('visitor_details');	
		}
	
	public function lastlogin($data){
		$this->db->where('user_id', $this->session->userdata('user_id'));
		return $this->db->update('user_details',$data);	
	}
	
	///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	
		
		
}
?>