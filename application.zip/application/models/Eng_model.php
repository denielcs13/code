<?php defined('BASEPATH') OR exit('No direct script access allowed');

class Eng_mode extends CI_Model {

	
	public function __construct() {
		parent::__construct();
	
	}
	
	public function get_detail($tbl_name,$col_name,$col_val)
    {  
		$this->main->select('*'); 
		$this->main->from($tbl_name);
        if($col_name)
            {
                $this->main->where($col_name,$col_val);
            }
        
        return $this->main->get()->row();
    }
    public function getall($tbl_name,$col_name='',$col_val='')
    {
		$this->main->select('*'); 
		$this->main->from($tbl_name);
		if($col_name!="" && $col_val!=""){
		$this->main->where($col_name,$col_val);
		}
		//$this->main->limit(0, 50);
		return $this->main->get()->result();

	}
    public function Save($tbl_name,$data)
	{
	
	  $this->main->insert($tbl_name,$data);
	  return $this->main->insert_id();
	}	
	
	public function Update($tbl_name,$data,$col_name='',$col_val='')
	{
	  $this->main->where($col_name,$col_val);
	  return $this->main->update($tbl_name,$data);
	}
	
	public function Delete($tbl_name,$col_name='',$col_val='')
	{
	 if($col_val!="" && $col_name!=""){
	  $this->main->where($col_name,$col_val);
	  return $this->main->delete($tbl_name);
	 }
	 else{
		 return flase;
	 }
	}
	
    public function get_selected_details($table,$columns = array(),$where = array(),$records="single",$obj=false)
	{
        if(count($where) > 0){
			$this->main->where($where);
        }
		if(!empty($columns)){
			$this->main->select(implode(',', $columns));
		}
        $query = $this->main->get($table);
		
        if($records == "single"){
			if($obj){
				$result = $query->row();
			}else{
				$result = $query->row_array();
			}
            
        } else {
			if($obj){
				$result = $query->result();
			}else{
				$result = $query->result_array();
			}
        }	
        return $result;
   }

}
?>