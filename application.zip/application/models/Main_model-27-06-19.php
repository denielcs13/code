<?php defined('BASEPATH') OR exit('No direct script access allowed');

class Main_model extends CI_Model {

	
	public function __construct() {
		parent::__construct();
		
	}
	
	public function get_detail($obj,$tbl_name,$where="",$single="",$order="",$ordertype="")
    {  
		$obj->select('*'); 
		$obj->from($tbl_name);
        if($where)
            {
              $obj->where($where);
            }
        if($order)
            {
              $obj->order_by($order,$ordertype);
            }
        if($single)
        {
        return $obj->get()->row();
        }else{
          return $obj->get()->result();  
        }
    }
    public function getall($obj,$tbl_name,$col_name='',$col_val='',$limit="",$offset="",$ordercol="",$order="")
    {
		$obj->select('*'); 
		$obj->from($tbl_name);
		if($col_name!="" && $col_val!="")
        {
		  $obj->where($col_name,$col_val);
		}
        if($limit)
		{
		  $obj->limit($limit, $offset);
		}
        if($order)
        {
          $obj->order_by($ordercol,$order);  
        }
		//$this->main->limit(0, 50);
		return $obj->get()->result();

	}
    public function getsid($table,$obj,$slug)
    {
       
       $id=$obj->select('class_id')->where('class_slug',$slug)->get($table)->row()->class_id;
       return $id; 
    }
    public function Save($obj,$tbl_name,$data)
	{
	
	  $obj->insert($tbl_name,$data);
	  return $obj->insert_id();
	}	
	
	public function Update($obj,$tbl_name,$data,$where)
	{
	  $obj->where($where);
	  return $obj->update($tbl_name,$data);
	}
	
	public function Delete($obj,$tbl_name,$where)
	{
	 if($where){
	  $obj->where($where); 
	  return $obj->delete($tbl_name);
	 }
	 else{
		 return flase;
	 }
	}
	public function numrows_total($obj,$tbl_name)
	{
		
		$numrows_total=$obj->get($tbl_name)->num_rows();
		return $numrows_total;
	}
    public function get_selected_details($table,$columns = array(),$where = array(),$records="single",$obj=false)
	{
        if(count($where) > 0){
			$this->main->where($where);
        }
		if(!empty($columns)){
			$this->main->select(implode(',', $columns));
		}
        $query = $this->main->get($table);
		
        if($records == "single"){
			if($obj){
				$result = $query->row();
			}else{
				$result = $query->row_array();
			}
            
        } else {
			if($obj){
				$result = $query->result();
			}else{
				$result = $query->result_array();
			}
        }	
        return $result;
   }
   public function student_emailcheck($email)
	{
        $temp=$this->db->where('email',$email)->get('temp_main_user')->num_rows();
        if($temp)
        {
          return $temp;  
        }else{
         $org=$this->db->where('email',$email)->get('main_user')->num_rows(); 
         return $org;   
        }	
        
   }
 public function signin($username,$password)
	{
	  
       $this -> db -> where(array('user_name'=>$username,'password'=>md5($password),'status'=>'1'));
	   $this -> db -> limit(1);	
	   $query = $this -> db -> get('main_user');	
		//echo $this->db->last_query();
		if($query -> num_rows() > 0)
		{
			$result=$query->row();
			return $result;
		}
		else
		{
		   $this -> db -> where(array('user_name'=>$username,'password'=>md5($password),'status'=>'1'));
    	   $this -> db -> limit(1);	
    	   $query = $this -> db -> get('temp_main_user');
           if($query -> num_rows() > 0)
    		{
    			$result=$query->row();
    			return $result;
    		}else{
    		  $result=false;
    		 return $result;
    		}
           
		   
		}	
   }
   public function lastlogin($data){
		$this->db->where('user_id', $this->session->userdata('user_id'));
		return $this->db->update('user_details',$data);	
	}
public function get_login_user_from_temp(){
   $this -> db -> where(array('user_id'=>$this->session->userdata('user_id')));
   
   $query = $this -> db -> get('temp_main_user');	
	if($query -> num_rows() > 0)
	{
		$result=$query->row();
		return $result;
	}
	else
	{
	  $result=false;
	  return $result;
	}	
}
public function get_login_user_from_main(){
   $this -> db -> where(array('user_id'=>$this->session->userdata('user_id')));
   
   $query = $this -> db -> get('main_user');	
	
	//echo $this->db->last_query();
	if($query -> num_rows() > 0)
	{
		$result=$query->row();
		return $result;
	}
	else
	{
	  $result=false;
	  return $result;
	}	
}
public function copy_user_row()
{
   $this->db->where('user_id',$this->session->userdata('user_id'));
   $temp_user=$this->db->get('temp_main_user')->row();
   $tempUserId=$this->session->userdata('user_id');
   $user=array(
                'first_name'=>$temp_user->first_name,
                'last_name'=>$temp_user->last_name,
                'dob'=>$temp_user->dob,
                'user_type'=>$temp_user->user_type,
                'edate'=>$temp_user->edate,
                'password'=>$temp_user->password,
                'user_name'=>$temp_user->user_name,
                'upload_path'=>$temp_user->upload_path,
                'email'=>$temp_user->email,
                'phone'=>$temp_user->phone,
                'address'=>$temp_user->address,
                'country'=>$temp_user->country,
                'city'=>$temp_user->city,
                'state'=>$temp_user->state,
                'zipcode'=>$temp_user->zipcode,
                'profile_update'=>'yes',
                'status'=>1
               );
   $res1=$this->db->where('user_id',$this->session->userdata('user_id'))->get('main_user');
  
   if($res1 -> num_rows()==0)
	{
	 $this->db->insert('main_user',$user);
     
    
       if($this->db->insert_id())
       {
        $orgUserId=$this->db->insert_id();
        $res=$this->db->where('user_id',$orgUserId)->get('main_user')->row();
        $userlogindata = array( 
    						'username' => $res->user_name,
    						'logged_in' => true,
    						'user_id' => $res->user_id,
    						'email' => $res->email,
    						'user_type'=>$res->user_type,
    						'fullname'=>$res->first_name.' '.$temp_user->last_name,
    						//'lastlogedin'=>$mylastlogin,
    						'profile_update'=>$res->profile_update
    						);
          $this->session->set_userdata($userlogindata);
          $delete=$this->db->where('user_id',$tempUserId)->delete('temp_main_user');
        	
    	}else{
    	   return $this->session->userdata('user_id');
    		   
    	}                  
     return $orgUserId;
   }
    
}

public function random_question($obj,$clssid,$subskill){
	
		$obj->select('*'); 
		$obj->from('manage_question_'.$clssid);
		$obj->where('ques_class',$clssid);	
		$obj->where('ques_subskillid',$subskill);
		$obj->order_by('ques_id','RANDOM');

		$obj->limit(1);		
		return $obj->get()->result();	
	}
public function get_answers($obj,$ques_id,$yearid)
    {
	    $obj->select('*'); 
		$obj->from('manage_answer_'.$yearid);
		$obj->where('ans_quesid',$ques_id);
		$obj->order_by('ans_id');
		return $obj->get()->result();	
	}


/*last */

//04/26/2019
public function all_student_list($prnt_id)
{	
	$this->db->select('*');
	$this->db->where('parent_id',$prnt_id);
	$this->db->from('main_user');
    $this->db->order_by('user_id','DESC');
    $qry =$this->db->get()->result();
    return $qry;
}
public function student_class($obj,$tbl_name)
{
	$obj->select('*'); 
    $obj->from($tbl_name);
    $obj->order_by('class_id','ASC');
	return $obj->get()->result();

 
}

//04-27-19
public function Delete_s($tbl_name,$col_name='',$col_val='')
	{
	 if($col_val!="" && $col_name!=""){
	  $this->db->where($col_name,$col_val);
	  return $this->db->delete($tbl_name);
	 }
	 else{
		 return false;
	 }
	}
	
	public function get_stud_detail($tbl_name,$col_name,$col_val){  
		$this->db->select('*'); 
		$this->db->from($tbl_name);
        $this->db->where($col_name,$col_val);	
		return $this->db->get()->row(); 

	}
	
	public function Update_stud($tbl_name,$data,$col_name='',$col_val='')
	{
		
	  $this->db->where($col_name,$col_val);
	  return $this->db->update($tbl_name,$data);
		
		
	}
	//04-29-19
	public function Save_Quiz($tbl_name,$data)
	{
	
	   $this->db->insert($tbl_name,$data);
	  return $this->db->insert_id();
		
		
	}

	public function student_score($usrid,$tbl_name)
	{        
    $this->db->select('*');
	$this->db->where('user_id',$usrid);
	$this->db->from('quiz_user');
    $this->db->order_by('qz_id','ASC');
    $qry =$this->db->get()->result();
    return $qry;

	}
	
	//04-30-19
	public function institute_details($tbl_name)
	{        
    $this->db->select('*');
	$this->db->where('user_type',8);
	$this->db->from($tbl_name);
    $this->db->order_by('user_id','ASC');
    $qry =$this->db->get()->result();
    return $qry;

	}

	public function getUserDetail_by_id($usrid,$tbl_name)
	{        
    $this->db->select('*');
	$this->db->where('user_id',$usrid);
	$this->db->from($tbl_name);
    $this->db->order_by('user_id','ASC');
    $qry =$this->db->get()->row();
    return $qry;

	}
	
	//05-01-19
	public function approve_emailcheck($email)
	{
        $temp=$this->db->where('email',$email)->where('parent_id',0)->get('temp_main_user')->num_rows();
        if($temp)
        {
          return $temp;  
        }else{
         $org=$this->db->where('email',$email)->where('parent_id',0)->get('main_user')->num_rows(); 
         return $org;   
        }	
        
   }
   
  public function Update_approve($tbl_name,$data,$col_name='',$col_val='')
	{
		
	  $this->db->where($col_name,$col_val);
	  return $this->db->update($tbl_name,$data);
		
		
	}
	
	public function getUserDetail_by_email($email,$tbl_name)
	{        
    $this->db->select('*');
	$this->db->where('email',$email);
	$this->db->from($tbl_name);
    $this->db->order_by('user_id','ASC');
    $qry =$this->db->get()->row();
    return $qry;

	}
	
	public function get_detail_topic($obj,$tbl_name,$like,$where="",$single="",$order="",$ordertype="")
    {  
		$obj->select('*'); 
		$obj->from($tbl_name);
        if($where)
            {
              $obj->where($where);
			  $obj->like('skill_name', $like);
			  
            }
        if($order)
            {
              $obj->order_by($order,$ordertype);
            }
        if($single)
        {
        return $obj->get()->row();
        }else{
          return $obj->get()->result();  
        }
    }
	
	public function save_syllabus_institute($userid){
		
		            $i=1;
					$syllbname = $_POST['syllb_name'];
					$clsname = $_POST['class_name'];
					$class_type = $_POST['class_type'];		
				
					$dt=date('y-m-d h:i:s');
		
						$data=array(
						            'year_id'     =>  $clsname,									
									'user_id'     =>  $userid,
                                    'createdon'   =>  $dt,
                                    'subject'  =>  $class_type,
                                    'syllb_name'  =>  $syllbname								
  									); 
									
						
						$qry=$this->db->insert('inst_syllabus',$data);		
												
						
					  
					   if ($qry)
						{   
							return true;
						}
					   
	}
	
	//05-03-19
	
	public function institute_syllabus_details($tbl_name,$usrid)
	{        
    $this->db->select('*');
	$this->db->where('user_id',$usrid);
	$this->db->from($tbl_name);
    $this->db->order_by('sid','desc');
    $qry =$this->db->get()->result();
    return $qry;

	}
	
	public function delete_syl_inst($tbl_name,$col_name='',$col_val='')
	{
	 if($col_val!="" && $col_name!=""){
	  $this->db->where($col_name,$col_val);
	  return $this->db->delete($tbl_name);
	 }
	 else{
		 return false;
	 }
	}
	
	//05-06-19
	
	public function user_class_name($userid,$tbl_name)
	{        
    $this->db->select('*');
	$this->db->where('user_id',$userid);
	$this->db->from($tbl_name);
    $this->db->order_by('user_id','ASC');
    $qry =$this->db->get()->row();
    return $qry;

	}
	
	public function student_question_details($tbl_name,$where="")
	{        
    $this->db->select('*');
	$this->db->where($where);
	$this->db->from($tbl_name);
    $this->db->order_by('sid','desc');
    $qry =$this->db->get()->result();
    return $qry;

	}
	
	public function county_all($tbl_name)
	{        
    $this->db->select('*');	
	$this->db->from($tbl_name);
    $this->db->order_by('id','asc');
    $qry =$this->db->get()->result();
    return $qry;

	}
	public function country_by_id($contryid,$tbl_name)
	{        
    $this->db->select('*');	
	$this->db->where('id',$contryid);
	$this->db->from($tbl_name);
    $this->db->order_by('id','asc');
    $qry =$this->db->get()->result();
    return $qry;

	}
	
	/*get state list*/
	public function country_state_name($country_id,$tbl_name)
	{        
    $this->db->select('*');
	$this->db->where('country_id',$country_id);
	$this->db->from($tbl_name);
    $this->db->order_by('id','ASC');
    $qry =$this->db->get()->result();
    return $qry;

	}
	
	public function state_by_id($state_id,$tbl_name)
	{        
    $this->db->select('*');	
	$this->db->where('id',$state_id);
	$this->db->from($tbl_name);
    $this->db->order_by('id','asc');
    $qry =$this->db->get()->result();
    return $qry;

	}
	
	//get all registered user list
	// public function get_userlist_d($tbl_name)
	// {
 //    $data=array(6,7,8);        
 //    $this->db->select('*');
	// $this->db->where_in('user_type',$data);	
	// $this->db->from($tbl_name);
 //    $this->db->order_by('user_id','ASC');
 //    $qry =$this->db->get()->result();
 //    return $qry;

	// }

	public function get_userlist_d($limit="",$offset="")
    {
        $data=array(6);        
	    $this->db->select('*');
		$this->db->where_in('user_type',$data);		
        $this->db->from('main_user');        
        $this->db->order_by('user_id','DESC');
        if($limit)
        {
        $this->db->limit($limit, $offset);
        }
        $data=$this->db->get()->result();
        return $data;
    }
    public function get_userlist_d_p($limit="",$offset="")
    {
        $data=array(7);        
	    $this->db->select('*');
		$this->db->where_in('user_type',$data);		
        $this->db->from('main_user');        
        $this->db->order_by('user_id','DESC');
        if($limit)
        {
        $this->db->limit($limit, $offset);
        }
        $data=$this->db->get()->result();
        return $data;
    }
    public function get_userlist_d_i($limit="",$offset="")
    {
        $data=array(8);        
	    $this->db->select('*');
		$this->db->where_in('user_type',$data);		
        $this->db->from('main_user');        
        $this->db->order_by('user_id','DESC');
        if($limit)
        {
        $this->db->limit($limit, $offset);
        }
        $data=$this->db->get()->result();
        return $data;
    }

	//
	public function num_userlist($tbl_name){
	$data=array(6);        
    $this->db->select('*');
    if(isset($_REQUEST['sval']) || isset($_GET['join_dt'])){
			if($_REQUEST['sval']!=""){
			$this->db->like('email', $_REQUEST['sval']);
		}
			
				
		}
	$this->db->where_in('user_type',$data);
		$qry = $this->db->get($tbl_name);
		return $qry->num_rows();
	}
	public function num_userlist_p($tbl_name){
	$data=array(7);        
    $this->db->select('*');

	$this->db->where_in('user_type',$data);
		$qry = $this->db->get($tbl_name);
		return $qry->num_rows();
	}
	public function num_userlist_i($tbl_name){
	$data=array(8);        
    $this->db->select('*');
	$this->db->where_in('user_type',$data);
		$qry = $this->db->get($tbl_name);
		return $qry->num_rows();
	}
	
	public function delete_usrs($tbl_name,$col_name='',$col_val='')
	{
	 if($col_val!="" && $col_name!=""){
	  $this->db->where($col_name,$col_val);
	  return $this->db->delete($tbl_name);
	 }
	 else{
		 return false;
	 }
	}
	
	public function get_user_by_id($tbl_name,$userid)
	{        
    $this->db->select('*');
	$this->db->where('user_id',$userid);
	$this->db->from($tbl_name);
    $this->db->order_by('user_id','ASC');
    $qry =$this->db->get()->row();
    return $qry;

	}

	public function num_student($tbl_name,$id){
	//$data=array(6);        
    $this->db->select('*');
	$this->db->where('parent_id',$id);
		$qry = $this->db->get($tbl_name);
		return $qry->num_rows();
	}

	public function num_student_search($srch_dt=""){
		//var_dump($_GET['sval']);exit
		if($_REQUEST['sval']!=""){
				$srch_dt=urldecode($_REQUEST['sval']);
				
				$this->db->like('email', $srch_dt);
			}
		//$this->db->join('tbl_roles as tr','tr.id = te.role_id','left');
		$qry = $this->db->get('main_user');
		return $qry->num_rows();
	}

	public function get_users_search_list($limit,$offset,$keyword=''){
		
		$this->db->order_by('te.first_name','ASC');
		$this->db->select('te.user_id,te.first_name,te.email,te.status,te.class_name');
		if(!empty($keyword)) {
        $this->db->group_start();
        $this->db->like('te.first_name', $keyword);
        $this->db->or_like('te.email', $keyword);
		// $this->db->or_like('te.first_name', $keyword);
        $this->db->group_end();
    }		
		// $this->db->join('tbl_roles as tr','tr.id = te.role_id','left');
		$qry = $this->db->get('main_user as te',$limit,$offset);
		return $qry->result();
	}
	
	 public function get_userlist_by_parent_id($id="")
    {
        //$data=array(8);         
	    $this->db->select('*');
		$this->db->where('parent_id',$id);		
        $this->db->from('main_user');        
        $this->db->order_by('user_id','DESC');
        /* if($limit)
        {
        $this->db->limit($limit, $offset);
        } */
        $data=$this->db->get()->result();
        return $data;
    } 
	
	/* public function get_userlist_by_parent_id($limit,$offset,$id=''){
		
		$this->db->order_by('te.first_name','ASC');
		$this->db->select('te.user_id1,te.first_name,te.email,te.status,te.parent_id');
		if(!empty($id)) {
        $this->db->group_start();
        $this->db->like('te.parent_id', $id);
        //$this->db->or_like('te.email', $keyword);
		// $this->db->or_like('te.first_name', $keyword);
        $this->db->group_end();
    }		
		// $this->db->join('tbl_roles as tr','tr.id = te.role_id','left');
		$qry = $this->db->get('main_user as te',$limit,$offset);
		return $qry->result();
	} */
	
	
	public function get_countries($obj)
		{
			$obj->select('*'); 
			 $this->db->from('countries');        
				$this->db->order_by('name','ASC');
			 $data=$this->db->get()->result();
				return $data;

		 
		}
		
		public function get_states($obj,$id)
		{
			$obj->select('*'); 
			$this->db->where('country_id',$id);		
			 $this->db->from('states');        
				$this->db->order_by('name','ASC');
			 $data=$this->db->get()->result();
				return $data;

		 
		}
		
	public function delete_sylskill_inst($tbl_name,$col_name='',$col_val='')
	{
	 if($col_val!="" && $col_name!=""){
	  $this->db->where($col_name,$col_val);
	  return $this->db->delete($tbl_name);
	 }
	 else{
		 return false;
	 }
	}


	public function get_syllabusinfo($obj,$id='',$userid='')
	{
		$obj->select('*'); 
		$this->db->where('sid',$id);
		$this->db->where('user_id',$userid);		
		$this->db->from('inst_syllabus');		
		$qry =$this->db->get()->row();
		return $qry;

	 
	}	

	
	
	public function save_syskill_institute($userid){
		
		            $i=1;
					$syllbname = $_POST['syllb_name'];
					$clsname = $_POST['class_name'];
					$class_type = $_POST['class_type'];
					$skillid = $_POST['skill_id'];
					$skillname = $_POST['skill_name'];
					$skillslug =$_POST['skill_slug'];
					$dt=date('y-m-d h:i:s');
					//foreach($skillid as $k=>$v){
						/* $data=array(
						            'year_id'     =>  $yrname,
									'skill_id'    =>  $skillid[$k],
                                    'skill_name'  =>  $skillname[$k],
									'skill_slug'  =>  $skillslug[$k],
									'user_id'     =>  $userid,
                                    'createdon'   =>  $dt,
                                    'class_type'  =>  $clsname,
                                    'syllb_name'  =>  $syllbname								
  									); */
						$data=array(
						            'year_id'     =>  $clsname,									
									'user_id'     =>  $userid,
                                    'createdon'   =>  $dt,
                                    'subject'  =>  $class_type,
                                    'syllb_name'  =>  $syllbname								
  									); 
									
						
						$qry=$this->db->insert('inst_syllabus',$data);		
												
						$i++;
					   //}
					   /* echo '<pre>';
					   print_r($data);die;
					   echo '<pre>'; */
					   if ($qry)
						{   
							return true;
						}
					   
	}


}
?>