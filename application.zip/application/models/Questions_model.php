<?php defined('BASEPATH') OR exit('No direct script access allowed');


class Questions_model extends CI_Model {

	 	var $CLASSID = '';
		
		
	public function __construct() {
		parent::__construct();
		$this->load->database();	
		
	}
	
	public function question_list($limit=0, $start=0, $status=false) {
            
		$this->db->limit($limit, $start);
	
		$this->db->select('*'); 
		$this->db->from('manage_question_'.$this->CLASSID);
		$this->db->where('ques_class', $this->CLASSID);
		$this->db->order_by('ques_id', 'DESC');
		return $this->db->get()->result();
	}
	
	
	public function question_details($id='')
	{
		$this->db->select('*'); 
		$this->db->from('manage_question_'.$this->CLASSID);
		$this->db->where('ques_id', $id);
		return $this->db->get()->row();	
	}
	
	
	
	public function quiz_status($id,$data)
	{
		$this->db->where('quiz_id', $id);
		return $this->db->update('manage_quiz',$data);	
			
	}

	
	
	public function Save_Update($data)
	{
		
	
	if($this->input->post('quiz_id')!='')
	{	
	$this->db->where('quiz_id', $this->input->post('quiz_id'));
	return $this->db->update('manage_quiz',$data);
	}	
	else
	{
	  return $this->db->insert('manage_quiz',$data);
		
	}	

	
	}
	
	
	
	public function GetDepartmeantName($dep_id="")
	{
	
	  
	    $this->db->select('quiz_name'); 
		$this->db->from('manage_quiz');
		$this->db->where('quiz_id', $dep_id);
		//$this->db->limit(0, 1);
	
		$dep_name=$this->db->get()->result();
		
		foreach($dep_name as $row)
		{
		return	$row->quiz_name;		
		}
		
	  
	}
	
	
	public function delete_quiz($dep_id){
			$this->db->where('quiz_id', $dep_id);
			$this->db->delete('manage_quiz');	
		}
	
	
	public function check_quiz($departnent)
		{
			$rowcount='';
			$this->db->select('*'); 
			$this->db->from('manage_quiz');
			$this->db->where('quiz_name', $departnent);
			$rowcount= $this->db->get()->num_rows();
			
			return $rowcount;	
		}
	
	
	
		
		public function question_list_count($status=false){
	
		$this->db->select('*'); 
		
		$query= $this->db->get('manage_question_'.$this->CLASSID);
		$this->db->where('ques_class', $this->CLASSID);	
		$rs= $query->num_rows();
		return $rs;
		}
		public function quiz_dropdown( $status=false) 
		{
            
		//$this->db->limit($limit, $start);
	
		$this->db->select('*'); 
		$this->db->from('manage_quiz');
		if($status==true)
		{
		$this->db->where('quiz_status', 1);	
		}	
		
		$this->db->order_by('quiz_name', 'ASC');
		//$this->db->limit(0, 50);
		return $this->db->get()->result();
		}
		
		
	public function Update_Question($data)
	{
		
	
		if($this->input->post('ques_id')!='')
		{	
		$this->db->where('ques_id', $this->input->post('ques_id'));
		return $this->db->update('manage_question_'.$this->CLASSID,$data);
		}	
			

	
	}
	
	public function Save_Question($data)
	{
		
		
		
		   $this->db->insert('manage_question_'.$this->CLASSID,$data);
		   return $this->db->insert_id();
			
		

	
	}
	
	public function Save_Answer($data)
	{
		
	
		
		   $this->db->insert('manage_answer_'.$this->CLASSID,$data);
		   return $this->db->insert_id();
			
		

	
	}
	
	public function quiz_questionlist($quiz_id='')
	{
		$this->db->select('*'); 
		$this->db->from('manage_question_'.$this->CLASSID);
		$this->db->where('ques_quizid', $quiz_id);
		return $this->db->get()->result();	
	}
	
	public function ques_answerlist($ques_id)
	{
		$this->db->select('*'); 
		$this->db->from('manage_answer_'.$this->CLASSID);
		
		$this->db->where('ans_quesid', $ques_id);
		return $this->db->get()->result();	
	}
	
	

	
	public function delete_question_by_quesid($id){
		$this->db->where('ques_id', $id);
		$this->db->delete('manage_question_'.$this->CLASSID);	
	}
	
	public function delete_answer_by_quesid($id){
		$this->db->where('ans_quesid', $id);
		$this->db->delete('manage_answer_'.$this->CLASSID);	
	}
	public function delete_answer_by_ansid($id){
		$this->db->where('ans_id', $id);
		$this->db->delete('manage_answer_'.$this->CLASSID);	
	}
	
	public function Save_RightAnswer($data,$qid)
	{
		
		if($qid!="")
		{	
		$this->db->where('ques_id', $qid);
		return $this->db->update('manage_question_'.$this->CLASSID,$data);
		}
			

	
	}
	
	
	
	public function question_list_subskill($subskill){
	
		$this->db->select('*'); 
		$this->db->from('manage_question_'.$this->CLASSID);
		$this->db->where('ques_class',$this->CLASSID);	
		$this->db->where('ques_subskillid',$subskill);	
		return $this->db->get()->result();	
	}
	
	public function random_question($subskill){
	
		$this->db->select('*'); 
		$this->db->from('manage_question_'.$this->CLASSID);
		$this->db->where('ques_class',$this->CLASSID);	
		$this->db->where('ques_subskillid',$subskill);
		$this->db->order_by('ques_id','RANDOM');

		$this->db->limit(1);		
		return $this->db->get()->result();	
	}
	
	public function get_answers($ques_id){
	
		$this->db->select('*'); 
		$this->db->from('manage_answer_'.$this->CLASSID);
		$this->db->where('ans_quesid',$ques_id);
		$this->db->order_by('ans_id');
		return $this->db->get()->result();	
	}

	public function Save_Exam($data)
	{		
	
	
	  return $this->db->insert('term_exams',$data);
		
		
	}
	public function delete_exam($id){
		$this->db->where('year_id', $id);
		$this->db->delete('term_exams');	
	}
	
	public function term_exam($year_id,$term_id){
	
		$this->db->select('*'); 
		$this->db->from('term_exams');
		$this->db->where('year_id',$year_id);	
		$this->db->where('term_id',$term_id);
		/*$this->db->order_by('question_id','RANDOM');
		$this->db->limit(1);
		*/
		$this->db->order_by('question_id','ASC');
		//$this->db->limit(1);
		return $this->db->get()->result();	
	}
	
	public function check_exam_status($user_id,$year_id,$term_id,$attempt)
	{
		
		$this->db->select('*'); 
		$this->db->from('student_exam');
		$this->db->where('user_id', $user_id);
		$this->db->where('year_id', $year_id);
		$this->db->where('term_id', $term_id);
		$this->db->where('attempt', $attempt);
		return $this->db->get()->row();	
	}
	
	public function total_exam_question($year_id,$term_id){
	
	$query = $this->db->query('SELECT * FROM term_exams where year_id="'.$year_id.'" and term_id="'.$term_id.'"');
	return $query->num_rows();
		
	}
	
	public function tota_attempt_question($userid,$year_id,$term_id,$attempt){
	
	$query = $this->db->query('SELECT * FROM sexam_history where user_id="'.$user_id.'" and year_id="'.$year_id.'" and term_id="'.$term_id.'" and attempt="'.$attempt.'"');
	return $query->num_rows();
		
	}
	
	
	
	public function get_exam_question($year_id,$term_id,$queses){
	
		$this->db->select('*'); 
		$this->db->from('term_exams');
		$this->db->where('year_id',$year_id);	
		$this->db->where('term_id',$term_id);
		$this->db->where_not_in('question_id',$queses);
		$this->db->order_by('question_id','RANDOM');
		$this->db->limit(1);
		return $res= $this->db->get()->row();	
		
	}
	
	
	
	
	
	public function term_exam_question($year_id,$term_id,$question_id){
	
		$this->db->select('*'); 
		$this->db->from('term_exams');
		$this->db->where('year_id',$year_id);	
		$this->db->where('term_id',$term_id);
		$this->db->where('question_id',$question_id);
		/*$this->db->order_by('question_id','RANDOM');
		$this->db->limit(1);
		*/
		
		return $this->db->get()->result();	
	}
	
	public function Save_Userexam($data)
	{
		
		
		   $this->db->insert('student_exam',$data);
		   return $this->db->insert_id();
	
	}
	
	public function Save_Examhistory($data)
	{
		
		
		   $this->db->insert('sexam_history',$data);
		   return $this->db->insert_id();
	
	}
	
	public function check_userexam($user_id,$year_id,$term_id,$attempt)
	{
		
		$this->db->select('*'); 
		$this->db->from('student_exam');
		$this->db->where('user_id', $user_id);
		$this->db->where('year_id', $year_id);
		$this->db->where('term_id', $term_id);
		$this->db->where('attempt', $attempt);
		return $this->db->get()->row();	
	}
	
	public function check_uexambyyear($user_id,$year_id)
	{
		
		$this->db->select('*'); 
		$this->db->from('student_exam');
		$this->db->where('user_id', $user_id);
		$this->db->where('year_id', $year_id);
		$this->db->order_by('exam_id', 'DESC');
		return $this->db->get()->row();	
	}
	
	
	public function check_termexam_date($year_id)
	{
		
		$this->db->select('*'); 
		$this->db->from('term_exam_date');
		$this->db->where('year_id', $year_id);
		return $this->db->get()->row();	
	}
	
	public function check_examhistory_question($user_id,$year_id,$term_id,$exam_attampt)
	{
		
		$this->db->select('*'); 
		$this->db->from('sexam_history');
		$this->db->where('user_id', $user_id);
		$this->db->where('year_id', $year_id);
		$this->db->where('term_id', $term_id);
		$this->db->where('attempt', $exam_attampt);
		$this->db->order_by('question_id', 'ASC');
		return $this->db->get()->result();	
	}
	public function Update_Examterm_status($data,$exam_id)
	{
		
	
		if($exam_id!='')
		{	
		$this->db->where('exam_id', $exam_id);
		return $this->db->update('student_exam',$data);
		}	
			

	
	}
	
	/*----Assessment Test Queries-----*/
	public function Save_Asstest($data)
	{		
	
	
	  return $this->db->insert('master_assessment',$data);
		
		
	}
	public function delete_asstest($id){
		$this->db->where('ass_current_year', $id);
		$this->db->delete('master_assessment');	
	}
	
	
	public function assessment_exam($year_id,$term_id,$ass_year_id){
	   
		$this->db->select('*'); 
		$this->db->from('master_assessment');
		$this->db->where('ass_year_id',$ass_year_id);	
		$this->db->where('ass_current_year',$year_id);	
		//$this->db->where('ass_year_id',$term_id);
		//$this->db->order_by('ass_id','RANDOM');
		/*$this->db->limit(1);
		*/
		$this->db->order_by('ass_year_id','ASC');
		//$this->db->limit(30);
		return $this->db->get()->result();	
	}
	
	public function asstest_exam_question($year_id,$term_id,$question_id){
	
		$this->db->select('*'); 
		$this->db->from('master_assessment');
		$this->db->where('ass_current_year',$year_id);	
		//$this->db->where('ass_year_id',$term_id);
		$this->db->where('ass_question',$question_id);
		/*$this->db->order_by('question_id','RANDOM');
		$this->db->limit(1);
		*/
		return $this->db->get()->result();
	}
	
	public function check_userassessment($user_id,$year_id,$assyear_id)
	{
		
		$this->db->select('*'); 
		$this->db->from('student_assessment_test');
		$this->db->where('user_id', $user_id);
		$this->db->where('year_id', $year_id);
		//$this->db->where('assyear_id', $assyear_id);
		return $this->db->get()->row();	
	}
	
	public function check_uasstestbyyear($user_id,$year_id)
	{
		
		$this->db->select('*'); 
		$this->db->from('student_assessment_test');
		$this->db->where('user_id', $user_id);
		$this->db->where('year_id', $year_id);
		$this->db->order_by('exam_id', 'DESC');
		return $this->db->get()->row();	
	}
	
	public function check_asstesthistory_question($user_id,$year_id,$assyear_id)
	{
		
		$this->db->select('*'); 
		$this->db->from('sasstest_history');
		$this->db->where('user_id', $user_id);
		$this->db->where('year_id', $year_id);
		$this->db->where('assyear_id',$assyear_id);
		$this->db->order_by('question_id', 'ASC');
		return $this->db->get()->result();	
	}
	
	public function Save_Userassessment($data)
	{
		
		
		   $this->db->insert('student_assessment_test',$data);
		   return $this->db->insert_id();
	
	}
	
	public function Save_Assessmenthistory($data)
	{
		
		
		   $this->db->insert('sasstest_history',$data);
		   return $this->db->insert_id();
	
	}
	public function Update_Asstterm_status($data,$exam_id)
	{
		
	
		if($exam_id!='')
		{	
		$this->db->where('exam_id', $exam_id);
		return $this->db->update('student_assessment_test',$data);
		}	
			

	
	}
	
	public function assessment_pastyear($year_id)
	{
		
		$this->db->select('ass_year_id'); 
		$this->db->from('master_assessment');
		$this->db->where('ass_current_year', $year_id);	
		$this->db->group_by('ass_year_id');	
		$this->db->order_by('ass_year_id', 'ASC');
		return $this->db->get()->result();	
	
	}
	public function assessment_time($year_id,$user_id)
	{
		
		$this->db->select('*'); 
		$this->db->from('student_assessment_test');
		$this->db->where('user_id', $user_id);
		$this->db->where('year_id', $year_id);
		return $this->db->get()->row();	
	
	}
	public function get_answers1($year_id,$ques_id){
	
		$this->db->select('*'); 
		$this->db->from('manage_answer_'.$year_id);
		$this->db->where('ans_quesid',$ques_id);
		$this->db->order_by('ans_id');
		return $this->db->get()->result();	
	}
	/*----End of Assessment Test Queries-----*/
	
	
	public function get_next_question($subskill,$offset){
		$this->db->select('*'); 
		$this->db->from('manage_question_'.$this->CLASSID);
		$this->db->where('ques_class',$this->CLASSID);	
		$this->db->where('ques_subskillid',$subskill);
		$this->db->limit(1,$offset);		
		return $this->db->get()->result();	
	}
	
	/*---home work exercise-------*/
public function check_userhomework($user_id,$year_id,$skill_id)
	{
		
		$this->db->select('*'); 
		$this->db->from('student_homeworktest');
		$this->db->where('user_id', $user_id);
		$this->db->where('year_id', $year_id);
		$this->db->where('skill_id', $skill_id);
		$this->db->where('exam_status', 'pending');
		$this->db->order_by('exam_id', 'DESC');
		return $this->db->get()->row();	
	}
	
	public function check_uhomeworkbyyear($user_id,$year_id,$skill_id)
	{
		
		$this->db->select('*'); 
		$this->db->from('student_homeworktest');
		$this->db->where('user_id', $user_id);
		$this->db->where('year_id', $year_id);
		$this->db->where('skill_id', $skill_id);
		$this->db->order_by('exam_id', 'DESC');
		return $this->db->get()->row();	
	}
	
	public function check_homehistory_question($user_id,$year_id,$skill_id)
	{
		
		$this->db->select('*'); 
		$this->db->from('student_home_history');
		$this->db->where('user_id', $user_id);
		$this->db->where('year_id', $year_id);
		$this->db->where('skill_id', $skill_id);
		$this->db->order_by('question_id', 'ASC');
		return $this->db->get()->result();	
	}
	
	public function Save_Userhomework($data)
	{
		
		
		   $this->db->insert('student_homeworktest',$data);
		   return $this->db->insert_id();
	
	}
	
	public function Save_Homeworkhistory($data)
	{
		
		
		   $this->db->insert('student_home_history',$data);
		   return $this->db->insert_id();
	
	}
	public function Update_Homework_status($data,$exam_id)
	{
		
	
		if($exam_id!='')
		{	
		$this->db->where('exam_id', $exam_id);
		return $this->db->update('student_homeworktest',$data);
		}	
			

	
	}
	
	public function homerandom_question($subskill){
	
		$this->db->select('*'); 
		$this->db->from('manage_question_'.$this->CLASSID);
		$this->db->where('ques_class',$this->CLASSID);	
		$this->db->where('ques_subskillid',$subskill);
		$this->db->order_by('ques_id','RANDOM');

		$this->db->limit(1);		
		return $this->db->get()->result();	
	}
/*---end of home work exercise-----*/	
/*---Class exercise-------*/
	public function check_userclassexcerise($user_id,$year_id,$skill_id)
	{
		
		$this->db->select('*'); 
		$this->db->from('student_classexcerise');
		$this->db->where('user_id', $user_id);
		$this->db->where('year_id', $year_id);
		$this->db->where('skill_id', $skill_id);
		$this->db->where('exam_status', 'pending');
		$this->db->order_by('exam_id', 'DESC');
		return $this->db->get()->row();	
	}
	
	public function check_uclassexcbyyear($user_id,$year_id,$skill_id)
	{
		
		$this->db->select('*'); 
		$this->db->from('student_homeworktest');
		$this->db->where('user_id', $user_id);
		$this->db->where('year_id', $year_id);
		$this->db->where('skill_id', $skill_id);
		$this->db->order_by('exam_id', 'DESC');
		return $this->db->get()->row();	
	}
	
	public function check_classexchistory_question($user_id,$year_id,$skill_id)
	{
		
		$this->db->select('*'); 
		$this->db->from('student_classexcerise_history');
		$this->db->where('user_id', $user_id);
		$this->db->where('year_id', $year_id);
		$this->db->where('skill_id', $skill_id);
		$this->db->order_by('question_id', 'ASC');
		return $this->db->get()->result();	
	}
	
	public function Save_UserClassexcerise($data)
	{
		
		
		   $this->db->insert('student_classexcerise',$data);
		   return $this->db->insert_id();
	
	}
	
	public function Save_Classexckhistory($data)
	{
		
		
		   $this->db->insert('student_classexcerise_history',$data);
		   return $this->db->insert_id();
	
	}
	public function Update_Classexcerise_status($data,$exam_id)
	{
		
	
		if($exam_id!='')
		{	
		$this->db->where('exam_id', $exam_id);
		return $this->db->update('student_classexcerise',$data);
		}	
			

	
	}
	public function check_question($year_id,$ques_id){
	
		$this->db->select('*'); 
		$this->db->from('manage_question_'.$year_id);
		$this->db->where('ques_id',$ques_id);		
		$res= $this->db->get()->result();
		if($res){
			return true;
		}
		return false;		
	}
/*---end of Class room exercise-----*/		

// Function for assesment -----//
public function check_assesmenthistory_question($user_id,$year_id){
	
		$this->db->select('*'); 
		$this->db->from('sasstest_history');
		$this->db->where('user_id', $user_id);
		$this->db->where('year_id', $year_id);
		return $this->db->get()->result();	
}

public function get_assessment_question($year_id,$assyear_id,$queses){
	
		$this->db->select('*'); 
		$this->db->from('master_assessment');
		$this->db->where('ass_current_year',$year_id);	
		$this->db->where('ass_year_id',$assyear_id);
		$this->db->where_not_in('ass_question',$queses);
		$this->db->order_by('ass_question','RANDOM');
		$this->db->limit(1);
		return $res= $this->db->get()->row();	
		
	}
		//sub skill model
public function skill_id($subskill_slug="",$year_id="")
	{
		if($subskill_slug!="")
			{	

				$get=$this->db->where(array('skill_slug'=>$subskill_slug,'skill_class'=>$year_id))->get('master_skill');
				return $get;
			}
	}
public function que_list($year_id="",$subskill_slug="")
	{
		$get=$this->db->where(array('ques_subskillid' => $subskill_slug,))->order_by('ques_id', 'DESC')->get('manage_question_'.$year_id);
		return $get;
	}
	
	
public function get_classexcercise_question($year_id,$skill_id,$queses){
	
		$table='manage_question_'.$year_id;
		$this->db->select('*'); 
		$this->db->from($table);
		$this->db->where('ques_subskillid',$skill_id);	
		$this->db->where_not_in('ques_id',$queses);
		$this->db->order_by('ques_id','RANDOM');
		$this->db->limit(1);
		return $res= $this->db->get()->row();	
		
	}	
public function get_classexchistory_question($user_id,$year_id,$skill_id,$exam_id)
	{
		
		$this->db->select('*'); 
		$this->db->from('student_classexcerise_history');
		$this->db->where('user_id', $user_id);
		$this->db->where('year_id', $year_id);
		$this->db->where('skill_id', $skill_id);
		$this->db->where('exam_id', $exam_id);
		return $this->db->get()->result();	
	}

public function record_questions_count()
		{
			$where=' 1 ';
				$where .= " and ques_class='". $this->CLASSID."' "; 
				if($_REQUEST['skill']!='')
				{
				$where .= " and ques_skillid='".$_REQUEST['skill']."' "; 
				
				}
				
				if($_REQUEST['uname']!='')
				{
				$where .= "and ( ques_name like '%".$_REQUEST['uname']."%'  ) "; 
				
				}
				
				if($_REQUEST['subskill']!='' )
				{
				$where .= " and ques_subskillid='".$_REQUEST['subskill']."' "; 
				
				}				
		
				$this->db->where($where);
				$query=$this->db->get('manage_question_'.$this->CLASSID);
				$rs= $query->num_rows();
			return $rs;
			
			
		}
public function search_questions_list($limit=0, $start=0) {
            
			$this->db->limit($limit, $start);
	
				
				$where=' 1 ';
				$where .= " and ques_class='". $this->CLASSID."' "; 
				if($_REQUEST['skill']!='')
				{
				$where .= " and ques_skillid='".$_REQUEST['skill']."' "; 
				
				}
				
				if($_REQUEST['uname']!='')
				{
				$where .= "and ( ques_name like '%".$_REQUEST['uname']."%'  ) "; 
				
				}
				
				if($_REQUEST['subskill']!='' )
				{
				$where .= " and ques_subskillid='".$_REQUEST['subskill']."' "; 
				
				}					
		
				$this->db->where($where);
				$query=$this->db->get('manage_question_'.$this->CLASSID);
				$rs=$query->result(); 
				
			
			return $rs;
			
			
		}
				
}
?>