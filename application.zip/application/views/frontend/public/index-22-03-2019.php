<?php 
if($this->session->userdata('user_id')!='')
{

	include(APPPATH.'/views/frontend/private/header.php');
	
}
else
{
	include('header.php');
}	
?>

<div id="carouselExampleControls" class="carousel slide" data-ride="carousel">
  <div class="carousel-inner">
    <figure class="carousel-item active">  
      <img class="d-block w-100" src="<?= base_url('assets/images/slide1.jpg')?>" alt="First slide">

<figcaption class="caption_slide">
   <div class="container"> <h3>Learn English</h3>
    <p>Building strong language skills is essential to a child’s academic learning and has a high correlation to their success in nearly every part of their lives. Our curriculum are specially designed to be fun, interactive and very effective in learning English.</p>
<a href="<?= base_url('register');?>" class="btn-mn btn-3 btn-3e button-org">JOIN CLASSES</a>

</div>
</figcaption>
  </figure>  
  
  
    
  </div>
  <a class="carousel-control-prev" href="#carouselExampleControls" role="button" data-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="sr-only">Previous</span>
  </a>
  <a class="carousel-control-next" href="#carouselExampleControls" role="button" data-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="sr-only">Next</span>
  </a> 
</div>

 <!-- Page Content -->
   <section id="maths_practise" class="space-75">
    <div class="container">
    <div class="col-md-12 col-xs-12 col-lg-12 col-sm-12">
      <!-- Page Heading -->
      <h1 class="text-center dis-inline">English Exercises - Kindergarten to Year 13</h1>

      <div class="row">
        <div class="col-lg-4 col-sm-6">
          <div class="card math-box cyan_bg wow fadeInUp  time2 animated">
            <a href="kindergarten"><div class="content_hover"><img class="math-img-top" src="<?= base_url('assets/images/Kindergarten.jpg')?>" alt="">
            <div class="icon-set cyan_bg">
            <img src="<?= base_url('assets/images/icon-kindergarten.png')?>" alt="" />
            </div>
            <p>Alphabet, Rhyming, Blending and Segmenting, Phonics, Synonyms, Antonyms, Sight Words, Parts of Speech and more.</p>
            </div></a>
            
            <div class="math-content">
            <p>Kindergarten <span class="float-right"><a href="kindergarten">Skills >> <?php echo $countskill_kg;?></a></span></p>
            </div>
          </div>
        </div>
        
        <div class="col-lg-4 col-sm-6">
          <div class="card math-box wow fadeInUp  time4 animated animation_started">
            <a href="year-1"><div class="content_hover"><img class="math-img-top" src="<?= base_url('assets/images/year-1.jpg')?>" alt="">
            <div class="icon-set">
            <img src="<?= base_url('assets/images/icon-year-1.png')?>" alt="" />
            </div>
            <p>Phonics (Consonant and vowels), Sight Words, Parts of Speech, Sentences, Literacy Skills, Synonyms, Antonyms and more.</p>
            </div></a>
            
           
            
            <div class="math-content">
            <p>YEAR 1 <span class="float-right"><a href="year-1">Skills  >> <?php echo $countskill_year1;?></a></span></p>
            </div>
          </div>
        </div>
        
        <div class="col-lg-4 col-sm-6">
          <div class="card math-box maroon_bg  wow fadeInUp  time6 animated animation_started">
            <a href="year-2"><div class="content_hover"><img class="math-img-top"src="<?= base_url('assets/images/year-2.jpg')?>" alt="">
            <div class="icon-set maroon_bg">
            <img src="<?= base_url('assets/images/icon-year-2.png')?>" alt="" />
            </div>
            <p>Diphthongs, Syllables, Nouns, Pronouns, Verbs, Articles, Adjectives, Prepositions, Alphabetical order, Word meanings, Phonics (Consonant and Vowels), Synonyms, Antonyms, Literacy Skills and more</p>
            </div></a>
            <div class="math-content">
            <p>YEAR 2 <span class="float-right"><a href="year-2">Skills  >> <?php echo $countskill_year2;?></a></span></p>
            </div>
          </div>
        </div>
        
           <div class="col-lg-4 col-sm-6">
          <div class="card math-box maroon_bg wow fadeInUp  time8 animated animation_started">
            <a href="year-3"><div class="content_hover"><img class="math-img-top" src="<?= base_url('assets/images/year-3.jpg')?>" alt="">
            <div class="icon-set maroon_bg">
            <img src="<?= base_url('assets/images/icon-year-1.png')?>" alt="" />
            </div>
            <p>Rhyming, Syllables, Sentence Structure, Nouns, Pronouns, Verbs, Articles, Adjectives and Adverbs, Prepositions, Word Meanings, Phonics (Consonant and Variant Vowels) and more</p>
            </div></a>
            <div class="icon-set maroon_bg">
            <img src="<?= base_url('assets/images/icon-year-3.png')?>" alt="" />
            </div>
            <div class="math-content">
            <p>YEAR 3 <span class="float-right"><a href="year-3">Skills  >> <?php echo $countskill_year3;?></a></span></p>
            </div>
          </div>
        </div>
        
        <div class="col-lg-4 col-sm-6">
          <div class="card math-box cyan_bg wow fadeInUp  time10 animated animation_started">
            <a href="year-4"><div class="content_hover"><img class="math-img-top" src="<?= base_url('assets/images/year-4.jpg')?>" alt="">
            <div class="icon-set cyan_bg">
            <img src="<?= base_url('assets/images/icon-year-1.png')?>" alt="" />
            </div>
            <p>Conjunctions, Contractions, Prefixes and Suffixes, Prepositions, Punctuation, Greek and Latin Roots, Figurative Language, Nouns, Pronouns, Verbs, Articles, Adjectives and Adverbs, and more</p>
            </div></a>
            <div class="icon-set cyan_bg">
            <img src="<?= base_url('assets/images/icon-year-4.png')?>" alt="" />
            </div>
            <div class="math-content">
            <p>YEAR 4 <span class="float-right"><a href="year-4">Skills  >> <?php echo $countskill_year4;?></a></span></p>
            </div>
          </div>
        </div>
        
        <div class="col-lg-4 col-sm-6">
          <div class="card math-box  wow fadeInUp  time12 animated animation_started">
            <a href="year-5"><div class="content_hover"><img class="math-img-top" src="<?= base_url('assets/images/year-5.jpg')?>" alt="">
            <div class="icon-set"> 
            <img src="<?= base_url('assets/images/icon-year-5.png')?>" alt="" />
            </div>
            <p>Conjunctions, Contractions, Prefixes and Suffixes, Homophones, Prepositions, Punctuation, Greek and Latin Roots, Figurative language, Nouns, Pronouns, Verbs, Articles, Adjectives and Adverbs, and more</p>
            </div></a>
            <div class="math-content">
            <p>YEAR 5 <span class="float-right"><a href="year-5">Skills  >> <?php echo $countskill_year5;?></a></span></p>
            </div>
          </div>
        </div>
        
           <div class="col-lg-4 col-sm-6">
          <div class="card math-box wow fadeInUp  time14 animated animation_started">
            <a href="year-6"><div class="content_hover"><img class="math-img-top" src="<?= base_url('assets/images/year-6.jpg')?>" alt="">
            <div class="icon-set">
            <img src="<?= base_url('assets/images/icon-year-6.png')?>" alt="" />
            </div>
            <p>Author's purpose and tone, Conjunctions, Contractions, Prefixes and Suffixes, Prepositions, Punctuation, Greek and Latin Roots, Synonyms, Antonyms, Nouns, Pronouns, Verbs, Adjectives and Adverbs and more</p>
            </div></a>
            <div class="icon-set">
            <img src="<?= base_url('assets/images/icon-year-6.png')?>" alt="" />
            </div>
            <div class="math-content">
            <p>YEAR 6 <span class="float-right"><a href="year-6">Skills  >> <?php echo $countskill_year6;?></a></span></p>
            </div>
          </div>
        </div>
        
        <div class="col-lg-4 col-sm-6">
          <div class="card math-box maroon_bg wow fadeInUp  time14 animated animation_started">
            <a href="year-7"><div class="content_hover"><img class="math-img-top" src="<?= base_url('assets/images/year-7.jpg')?>" alt="">
            <div class="icon-set cyan_bg">
            <img src="<?= base_url('assets/images/icon-year-7.png')?>" alt="" />
            </div>
            <p>Sentence Structure, Literary Devices, Author's Purpose and Tone, Contractions, Prefixes and Suffixes, Prepositions, Greek and Latin Roots, Synonyms, Antonyms, Nouns, Pronouns, Verbs, Adjectives and Adverbs and more</p>
            </div></a>
            <div class="icon-set maroon_bg"> 
            <img src="<?= base_url('assets/images/icon-year-7.png')?>" alt="" /> 
            </div>
            <div class="math-content">
            <p>YEAR 7 <span class="float-right"><a href="year-7">Skills  >> <?php echo $countskill_year7;?></a></span></p>
            </div>
          </div>
        </div>
        
        <div class="col-lg-4 col-sm-6">
          <div class="card math-box cyan_bg wow fadeInUp  time16 animated animation_started">
            <a href="year-8"><div class="content_hover"><img class="math-img-top" src="<?= base_url('assets/images/year-8.jpg')?>" alt="">
            <div class="icon-set cyan_bg"> 
            <img src="<?= base_url('assets/images/icon-year-8.png')?>" alt="" />
            </div>
            <p>Writing Clear and Concise Sentences, Context Clues, Literary Devices, Prefixes and Suffixes, Prepositions, Greek and Latin Roots, Nouns, Pronouns, Verbs, Adjectives and Adverbs and more</p>
            </div></a>
            <div class="math-content">
            <p>YEAR 8 <span class="float-right"><a href="year-8">Skills  >> <?php echo $countskill_year8;?></a></span></p>
            </div>
          </div>
        </div>
        
           <div class="col-lg-4 col-sm-6">
          <div class="card math-box cyan_bg wow fadeInUp  time18 animated animation_started">
            <a href="year-9"><div class="content_hover"><img class="math-img-top" src="<?= base_url('assets/images/year-9.jpg')?>" alt="">
            <div class="icon-set maroon_bg">
            <img src="<?= base_url('assets/images/icon-year-9.png')?>" alt="" />
            </div>
            <p>Writing Clear and Concise Sentences, Context Clues, Literary Devices, Prefixes and Suffixes, Prepositions, Sentence Structure, Nouns, Pronouns, Verbs, Adjectives and Adverbs and more</p>
            </div></a>
            <div class="icon-set cyan_bg">
            <img src="<?= base_url('assets/images/icon-year-9.png')?>" alt="" />
            </div>
            <div class="math-content">
            <p>YEAR 9 <span class="float-right"><a href="year-9">Skills  >> <?php echo $countskill_year9;?></a></span></p>
            </div>
          </div>
        </div>
        
        <div class="col-lg-4 col-sm-6">
          <div class="card math-box wow fadeInUp  time20 animated animation_started">
            <a href="year-10"><div class="content_hover"><img class="math-img-top" src="<?= base_url('assets/images/year-10.jpg')?>" alt="">
            <div class="icon-set maroon_bg">
            <img src="<?= base_url('assets/images/icon-year-10.png')?>" alt="" />
            </div>
            <p>Etymologies and Foreign Expressions, Writing Arguments, Context Clues, Literary Devices, Prefixes and Suffixes, Prepositions, Sentence Structure, Nouns, Pronouns, Verbs, Adjectives and Adverbs and more</p>
            </div></a>
            <div class="icon-set">
            <img src="<?= base_url('assets/images/icon-year-10.png')?>" alt="" />
            </div>
            <div class="math-content">
            <p>YEAR 10 <span class="float-right"><a href="year-10">Skills  >> <?php echo $countskill_year10;?></a></span></p>
            </div>
          </div>
        </div>
        
        <div class="col-lg-4 col-sm-6">
          <div class="card math-box maroon_bg wow fadeInUp  time22 animated animation_started">
            <a href="year-11"><div class="content_hover"><img class="math-img-top" src="<?= base_url('assets/images/year-11.jpg')?>" alt="">
            <div class="icon-set maroon_bg">
            <img src="<?= base_url('assets/images/icon-year-11.png')?>" alt="" />
            </div>
            <p>Literary Devices, Writing Arguments, Context Clues, Literary Devices, Prefixes and Suffixes, Sentence Structure, Synonyms, Antonyms, Nouns, Pronouns, Verbs, Adjectives and Adverbs and more</p>
            </div></a>
            <div class="math-content">
            <p>YEAR 11 <span class="float-right"><a href="year-11">Skills  >> <?php echo $countskill_year11;?></a></span></p>
            </div>
          </div>
        </div>
        
           <div class="col-lg-4 col-sm-6">
          <div class="card math-box maroon_bg wow fadeInUp  time24 animated animation_started">
            <a href="year-12"><div class="content_hover"><img class="math-img-top" src="<?= base_url('assets/images/year-12.jpg')?>" alt="">
            <div class="icon-set maroon_bg">
            <img src="<?= base_url('assets/images/icon-year-12.png')?>" alt="" />
            </div>
            <p>Writing clear and concise sentences, Writing Arguments, Literary Devices, Prefixes and Suffixes, Sentence Structure, Nouns, Pronouns, Verbs, Adjectives and Adverbs and more</p>
            </div></a>
            <div class="icon-set maroon_bg">
            <img src="<?= base_url('assets/images/icon-year-12.png')?>" alt="" />
            </div>
            <div class="math-content">
            <p>YEAR 12 <span class="float-right"><a href="year-12">Skills  >> <?php echo $countskill_year12;?></a></span></p>
            </div>
          </div>
        </div>
        
        <div class="col-lg-4 col-sm-6">
          <div class="card math-box wow cyan_bg fadeInUp  time26 animated animation_started">
            <a href="year-13"><div class="content_hover"><img class="math-img-top" src="<?= base_url('assets/images/year-13.jpg')?>" alt="">
            <div class="icon-set cyan_bg">
            <img src="<?= base_url('assets/images/icon-year-13.png')?>" alt="" />
            </div>
            <p>Writing clear and concise sentences, Writing Arguments, Literary Devices, Prefixes and Suffixes, Sentence Structure, Nouns, Pronouns, Verbs, Adjectives and Adverbs and more</p>
            </div></a>
            <div class="icon-set wow fadeInUp cyan_bg time28 animated animation_started">
            <img src="<?= base_url('assets/images/icon-year-13.png')?>" alt="" />
            </div>
            <div class="math-content">
            <p>YEAR 13 <span class="float-right"><a href="year-13">Skills  >> <?php echo $countskill_year13;?></a></span></p>
            </div>
          </div>
        </div>
         
        <div class="col-xs-12 col-sm-12 col-md-6 col-lg-4">
          <div class="card math-box yellow-bg">
            
            <p>English – Unlocking the Door to Unlimited Possibilities</p>
          </div>
        </div>
        
   
      </div>
      <!-- /.row -->


</div>
    </div>
    </section>
   
<section id="halping_kids" class="space-75">
   <div class="container">
   <h2 class="text-center">Helping KIDS Thrive, Not Just Survive</h2>
   <div class="row">
     <div class="col-xs-12 col-sm-6 col-md-4 col-lg-4">
     <div class="content_halping text-center">
     <img src="<?= base_url('assets/images/book.svg')?>" alt="" />
     <h4>Learning — Blended to Perfection</h4>
     <p>We develop our student's mindset to learn English through practice and practice makes perfect.</p>
     
     </div>
     
     </div>
     <div class="col-xs-12 col-sm-6 col-md-4 col-lg-4">
     <div class="content_halping text-center">
     <img src="<?= base_url('assets/images/medal.svg')?>" alt="" />
     <h4>Validated & Certified</h4>
     <p>Our English curriculum prepare our students to enroll for the international English examinations and certifications.</p>
     
     </div>
     
     </div>
     <div class="col-xs-12 col-sm-12 col-md-4 col-lg-4"> 
     <div class="content_halping text-center">
     <img src="<?= base_url('assets/images/trophy.svg')?>" alt="" />
     <h4>Achieve Your Dreams</h4>
     <p>We guide our students to achieve their goals in English.</p>
     
     </div>
     
     </div>
   </div>
   </div>
   </section>
   
   <section id="testimonial" class="space-75">
   <div class="container">
   <div class="row">
   <h2 class="text-center dis-inline">Student Testimonials</h2> 
   
<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
<div class="owl-carousel">
<div class="item">
<div class="testimonial_sec">
   <div class="quote"><img src="<?= base_url('assets/images/quate.png')?>" alt="" /></div>
   
   <h4>Evans T. & Sally T.</h4>
   
   <div class="more_text">
   We both learn alot from The University of English. A good place to learn English.
   </div>
   
   </div>
</div>
<div class="item">
<div class="testimonial_sec dark_green">
   <div class="quote"><img src="<?= base_url('assets/images/quate.png')?>" alt="" /></div>
   
   <h4>Charlotte M.</h4>
   
   <div class="more_text">
   My English has improved considerably since I joined the class at The University of English.
   </div>
   
   </div>
</div>
<div class="item">
<div class="testimonial_sec bg_org">
   <div class="quote"><img src="<?= base_url('assets/images/quate.png')?>" alt="" /></div>
   
   <h4>Gabriel S.</h4>
   
   <div class="more_text">
   Interesting to learn English this way.  Nowadays, I can do my English homework everyday through The University of English website.
   </div>
   
   </div>
</div>
<div class="item">
<div class="testimonial_sec dark_green">
   <div class="quote"><img src="<?= base_url('assets/images/quate.png')?>" alt="" /></div>
   
   <h4>Stephen K.</h4>
   
   <div class="more_text">
   Classroom and homework exercises really help me alot.  I can start to teach my classmates during English sessions.
   </div>
   
   </div>
</div>

<div class="item">
<div class="testimonial_sec">
   <div class="quote"><img src="<?= base_url('assets/images/quate.png')?>" alt="" /></div>
   
   <h4>Jayden M.</h4>
   
   <div class="more_text">
   Really appreciate those teaching staffs and I really learn alot of English in just a couple of weeks.
   </div>
   
   </div>
</div>
<div class="item">
<div class="testimonial_sec bg_org">
   <div class="quote"><img src="<?= base_url('assets/images/quate.png')?>" alt="" /></div>
   
   <h4>Hilton S.</h4>
   
   <div class="more_text">
   The homework really makes me learn alot.  Really enjoy coming to the class every week.
   </div>
   
   </div>
</div>

    

</div>
</div>

<div class="col-lg-12 col-sm-12 col-md-12 col-xs-12 text-center"><a href="testimonials" class="btn-mn btn-3 btn-3e button-org">View All Testimonials</a></div>
   </div>
   </section>

   
   <section id="newsletter_sec" class="space-75">
   <div class="container">
   <div class="row">
   <div class="col-xs-12 col-sm-12 col-md-6 col-lg-8">
  
   <div class="subscribe">
   <div class="row"> 
   <div class="col-xs-12 col-sm-3 col-md-2 col-lg-2 text-center"><img src="<?= base_url('assets/images/subscribe_icon.jpg')?>" alt="" /></div>
   <div class="col-xs-12 col-sm-9 col-md-10 col-lg-10"><h2>Subscribe To Our Newsletter</h2>
   <p>We will regularly updates our followers on the news related to English and also our institution development.</p>
</div>
   </div>
   </div>
   
   </div>
<div class="col-xs-12 col-sm-12 col-md-6 col-lg-4">
<h2>Your E-mail Address</h2>
<form>
<input type="text" placeholder="Email" /> <button type="submit"  value="Subscribe" class="btn-mn btn-3 btn-3e button-org">Subscribe</button>
</form>
</div>
</div>
   </div>
   </section>
   
   
 <!-- Page Content End -->
<?php 
if($this->session->userdata('user_id')!='')
{
	include(APPPATH.'/views/frontend/private/footer.php');
}
else
{
	include('footer.php');
}	
?>
