<?php 
if($this->session->userdata('user_id')!='')
{

	include(APPPATH.'/views/frontend/private/header.php');
	
}
else
{
	include('header.php');
}	
?>
<?php if($event==1){ ?>

<section id="title-inner">
  <div id="large-header">
    <canvas id="demo-canvas"></canvas>
    <div class="container">
      <div class="text-tit">
        <div class="bb"></div>
        <span class="lefttop-icon"></span>
        <h1><span>6 Reasons Why Singapore Math Might Just Be the Better Way</span></h1>
        <span class="rightbotm-icon"></span> </div>
    </div>
  </div>
</section>

<!-- Page Content inner -->

<section class="about_content content-text event-single-page space-75">
  <div class="container">
    <div class="event-single">
      <div class="media_single">
        <div class="row">
          <div class="col-xs-12 col-sm-12 col-md-8 col-lg-8">
            <div class="img-holder"> <img src="<?= base_url('assets/images/event-single.jpg')?>" alt="" /> <span class="date"> 02 <em>aug</em> </span> </div>
            <div class="single-text">
              <h4 class="title">6 Reasons Why Singapore Math Might Just Be the Better Way</h4>
              <p>When the ambiguous high school math problem went viral in April, complete with a
                handful of seemingly arbitrary answers, it sent many older Americans into a tailspin of</p>
              <p>But the quiz wasn't designed for American adults; it was developed for advanced teenagers in Singapore — and as it's reached stumped web surfers around the globe, it became the most visible example yet of a national approach
                to math education that's raising the bar.</p>
              <p>Since the 1980s, schools in Singapore have taken an innovative approach to teaching elementary math — a curriculum that focuses on problem solving with pictures and diagrams. Before the switch, the country's math students "weren't even registering on the charts as far as international ratings go," says Dan Brillon, director of Singapore Math Inc., a company that distributes Singaporean math textbooks in the United States.</p>
              <p>Within a decade, Singapore "shot to the top.</p>
              <p>curriculum coordinator at a school near Boston who helps to implement the Singapore math curriculum at schools across the country.</p>
              <p>And students and parents in Singapore know it.</p>
              <p>In the States, we tend to — whether we like it or not — we believe children are born with mathematical ability," Mahoney said. "But that's not true in countries like Singapore, where it's believed that e􀄱ort is the thing that makes you smarter in math.</p>
              <p>Here are six reasons why "Singapore Math" is catching on in American schools:</p>
              <p>Since the Trends in International Mathematics and Science Study started ranking countries' competitiveness in math literacy in 1995,
                Singapore has consistently ranked among the best. Established by the International Association for the Evaluation of Educational Achievement, TIMSS 2011, the most recent report, ranked Singaporean fourth-graders in </p>
              <p>Another international study, the Program for International Student Assessment, shows Singapore's 15-year-olds are among the best at
                problem solving, able to solve unstructured problems in unfamiliar contexts.</p>
              <p><em>2</em><strong>Singapore Math focuses
                on mastery, not just
                learning for a test.</strong> </p>
              <p>The Singaporean curriculum, which the country's Ministry of Education created,</p>
              <p>per grade level," Brillon said,"but really refining the curriculum allows students to hammer home those skills.</p>
              <p><em>3</em><strong>Visual and audible learners are thriving.</strong></p>
              <p>Learning math begins with the concrete: blocks, cards, buttons, whatever. Then there are abstract equations: 2 + 3 = 5. But Singapore
                math introduces the "pictorial" phase — a bridge between concrete and abstract.</p>
              <p>Based on the work of American psychologist Jerome Bruner, the Singaporean curriculum begins with hands-on group activities with
                objects like buttons or dice. Next, students move onto the pictorial phase — drawing representations of concrete objects before
                moving on to abstract equations.</p>
              <p>This visual approach, Brillon said, helps drive Singapore math's success. "If they were </p>
              <p><em>4</em> Layered strategies build upon one another.</p>
              <p>With the Singaporean curriculum, one skillset is a foundation for future lessons "like LEGO bricks carefully situated next to the other,"
                Mahoney said. This differs from the typical approach in the U.S., which follows a "spiral" — where material is revisited in the course of
                months or years, which Mahoney said is often jarring for teachers and students alike.</p>
              <p><em>5</em> It aligns with Common Core State Standards.</p>
              <p>When the Common Core standards were developed, policymakers looked to the success of other high-performing countries, including
                countries that scored well on the Trends in International Mathematics and Science Study. Remember: Singapore is consistently at the top.</p>
              <p>It's no surprise Common Core standards mirror several Singaporean approaches, including a narrower focus with greater depth. But to
                better align to the standards in each state, Brillon said Singapore Math Inc. introduced new textbooks last year.</p>
              
              <p><em>6</em> Studies show instant
                improvement.</p>
              <p>As a doctoral student at Northeastern University, Mahoney published the </p>
              <p>students were able to make substantial gains," Mahoney said. In June, a study released in the United Kingdom reached a similar conclusion: teaching Singapore math in the west can drive a small gain in students' math skills. After one academic year of Singapore math education, gains were equivalent to about one extra month of instruction, according to the study.</p>
              <p>Still, Mahoney said he is vying for a comprehensive, national study to investigate the effects of the Singapore math curriculumin the U.S. "It's not something that is radically different," Mahoney said. "It sounds exotic, but it's just elementary mathematics taught in a
                powerful and potent way."</p>
                
                
              <?php /*?><blockquote>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s.</blockquote><?php */?>
              <?php /*?><div class="tags yellow">
										<span>tags :</span>
										<a href="#">Fashion,</a>
										<a href="#">Electronics,</a>
										<a href="#">Mobiles,</a>
										<a href="#">Accessories</a>
									</div><?php */?>
            </div>
          </div>
          <div class="col-xs-12 col-sm-12 col-md-4 col-lg-4">
            <iframe src="https://www.facebook.com/plugins/page.php?href=https%3A%2F%2Fwww.facebook.com%2FTheUniversityOfMaths%2F&tabs=timeline&width=370&height=700&small_header=false&adapt_container_width=true&hide_cover=false&show_facepile=true&appId" width="370" height="700" style="border:none;overflow:hidden" scrolling="no" frameborder="0" allowTransparency="true" allow="encrypted-media"></iframe>
          </div>
        </div>
      </div>
    </div>
  </div>
</section> 

<?php } elseif($event==2){ ?>

<section id="title-inner">
  <div id="large-header">
    <canvas id="demo-canvas"></canvas>
    <div class="container">
      <div class="text-tit">
        <div class="bb"></div>
        <span class="lefttop-icon"></span>
        <h1><span>India's impressive concept about nothing</span></h1>
        <span class="rightbotm-icon"></span> </div>
    </div>
  </div>
</section>

<!-- Page Content inner -->

<section class="about_content content-text event-single-page space-75">
  <div class="container">
    <div class="event-single">
      <div class="media_single">
        <div class="row">
          <div class="col-xs-12 col-sm-12 col-md-8 col-lg-8">
            <div class="img-holder"> <img src="<?= base_url('assets/images/event-single.jpg')?>" alt="" /> <span class="date"> 02 <em>aug</em> </span> </div>
            <div class="single-text">
              <h4 class="title">India's impressive concept about nothing</h4>
              <p>In Gwalior, a congested city in the centre of the India, an 8th-Century fort rises with medieval swagger on
a plateau in the town's heart. Gwalior Fort is one of India's largest forts; but look among the soaring cupola-topped towers, intricate carvings and colourful frescoes and you'll find a small, 9th-Century temple
carved into its solid rock face.</p>
<strong>This is ground zero for zero</strong>
              <p>Chaturbhuj Temple is much like many other ancient temples in India - except that this is ground zero for
zero. It's famous for being the oldest example of zero as a written digit: carved into the temple wall is a
9th-Century inscription that includes the clearly visible number '270'.</p>

<p>The invention of the zero was a hugely significant mathematical development, one that is fundamental to
calculus, which made physics, engineering and much of modern technology possible. But what was it
about Indian culture that gave rise to this creation that's so important to modern India - and the modern
world?</p>
              <p>The earliest known example of zero written as a digit can be found in a temple inside Gwalior Fort in India</p>
<strong>Nothing from nothing</strong>

              <p>I recalled a <strong class="green-text">TED talk by renowned Indian mythologist Devdutt Pattanaik</strong> in which he tells a story
about Alexander the Great's visit to India. The world conqueror apparently met what he called a</p>

              <p>'gymnosophist' - a naked, wise man, possibly a yogi - sitting on a rock and staring at the sky, and asked
him, "What are you doing?".</p>
             
<strong>You may also be interested in:</strong>

<ul>
<li>Where algebra got its name</li>
<li>The island that forever changed science</li>
<li>The world's most innovative economy?</li>
</ul>

<p>"I'm experiencing nothingness. What are you doing?" the gymnosophist replied.</p>

<p>"I am conquering the world," Alexander said.</p>
<p>They both laughed; each one thought the other was a fool, and was wasting their life.</p>

<p>This story takes place long before that first zero was inscribed on Gwalior's temple wall, but the gymnosophist meditating on nothingness does in fact have a connection to the digit's invention. Indians, unlike people from many other cultures, were already philosophically open to the concept of nothingness. Systems such as yoga were developed to encourage meditation and the emptying of the mind, while
both the Buddhist and Hindu religions embrace the concept of nothingness as part of their teachings.</p>
<p>Both the Buddhist and Hindu religions embrace the concept of nothingness as part of their teachings (Credit:
Mariellen Ward)</p>

<p>Dr Peter Gobets, secretary of the Netherlands-based ZerOrigIndia Foundation, or the Zero Project, which researches the origins of the zero digit, noted in an article on the invention of zero that "Mathematical zero ('shunya' in Sanskrit) may have arisen from the contemporaneous philosophy of emptiness or Shunyata [a Buddhist doctrine of emptying one's mind from impressions and thoughts]".</p>

<p>In addition, the nation has long had a fascination with sophisticated mathematics. Early Indian mathematicians were obsessed with giant numbers, counting well into the trillions when the Ancient Greeks stopped at about 10,000. They even had different types of infinity</p>

<p>Hindu astronomers and mathematicians Aryabhata, born in 476, and Brahmagupta, born in 598, are both popularly believed to have been the first to formally describe the modern decimal place value system and present rules governing the use of the zero symbol. Although Gwalior has long been thought to be the site of the first occurrence of the zero written as a circle, an ancient Indian scroll called the
Bhakshali manuscript, which shows a placeholder dot symbol, was recently carbon dated to the 3rd or 4rd Centuries. It is now considered the earliest recorded occurrence of zero.</p>

<p>The mathematical zero - 'shunya' in Sanskrit - may have arisen from Shunyata, the Buddhist doctrine of emptying one's mind (Credit: Mariellen Ward)</p>

<p>Marcus du Sautoy, professor of mathematics at the University of Oxford, is quoted on the university's website as saying, "[T]he creation of zero as a number in its own right, which evolved from the placeholder dot symbol found in the Bakhshali manuscript, was one of the greatest breakthroughs in the history of mathematics. We now know that it was as early as the 3rd Century that mathematicians in India</p>

<p>planted the seed of the idea that would later become so fundamental to the modern world. The findings show how vibrant mathematics have been in the Indian sub-continent for centuries."</p>

<p>But equally interesting are the reasons as to why the zero wasn't developed elsewhere. One theory is that some cultures had a negative view of the concept of nothingness. For example, there was a time in the early days of Christianity in Europe when religious leaders banned the use of zero because they felt that, since God is in everything, a symbol that represented nothing must be satanic.</p>

<p>So maybe there is something to these connected ideas, to the spiritual wisdom of India that gave rise to meditation and the invention of zero. There's another connected idea, too, which has had a profound effect on the modern world.</p>

<strong>Silicon Valley, India-style</strong>

<p>As you drive out of Bengaluru's Kempegowda International Airport towards the city centre, about 37km away, you're greeted by several large signs stuck somewhat incongruously into the ground of rural India. They proclaim the names of the new gods of modern India, the companies at the forefront of the digital revolution. Intel, Google, Apple, Oracle, Microsoft, Adobe, Samsung and Amazon all have offices in
Bengaluru, along with home-grown heroes like Infosys and Wipro.</p>

<p>The sleek airport and shiny signs are the first indicators of transformation. Before the IT industry came to Bengaluru, it was called Bangalore, and was known as Garden City. Now it's Bengaluru and is known as the Silicon Valley of India.</p>

<p>What started in the 1970s as a single industrial park, Electronic City, to expand the electronics industry in the state of Karnataka, has paved the way for today's boomtown. The city now boasts many IT parks and is home to nearly 40% of the country's IT industry. Bengaluru may even overtake Silicon Valley, with predictions suggesting it could become the single largest IT hub on Earth by 2020, with two million IT
professionals, six million indirect IT jobs and $80 billion in IT exports.</p>

<strong>It's binary numbers that make this possible.</strong>
<p>Modern-day digital computers operate on the principle of two possible states, 'on' and 'off'. The 'on' state is assigned the value '1', while the 'off' state is assigned the value '0'. Or, zero.</p>

<p>"It is perhaps not surprising that binary number system was also invented in India, in the 2nd or 3rd Centuries BCE by a musicologist named Pingala, although this use was for prosody," said Subhash Kak, historian of science and astronomy and Regents Professor at Oklahoma State University.</p>

<p>Lalbagh Botanical Gardens is at the cultural and geographical centre of Bengaluru, a symbol of 'old Bangalore' and the first must-see place locals recommend. Originally designed in 1760 with many later</p>
<p>additions, it has a distinctly Victorian feel to it, featuring 150 types of roses and a glass pavilion made in the late 1800s and patterned after London's famous Crystal Palace. Lalbagh is a treasure in a city that is one of the fastest growing in Asia, and a charming reminder of the days when Bengaluru was a favourite spot for retired British civil servants during the days of the Raj. They built quaint cottages with large gardens and quietly whiled away their retirement years enjoying the temperate climate and ideal growing
conditions of the sleepy town.</p>

<p>But old Bangalore is disappearing beneath much-needed infrastructure construction and the city's ambitious expansion. In the 10 years from 1991 to 2001, Bengaluru grew a whopping 38%, and it's now the 18th most populous city in the world with 12 million people. The traffic is arguably the worst in India, as infrastructure planning has not kept pace with the development of the many IT parks and the neverending
influx of IT workers.</p>

<p>The chaos and congestion that's the hallmark of India's metropolises reaches something of a zenith in Bengaluru, where it can take an hour to drive 3km. Nevertheless, the inhabitants carry bravely on, living as close to the high-tech campuses as possible - and even on them in some cases - creating start-ups, designing software and supplying the world with IT products and know-how. It's hard to imagine the
number of computer chips and bits and programs that have come from Bengaluru, the number of computers and devices built and powered. And even more impossible to imagine is the number of binary-system zeroes it has all taken.</p>
<p>And yet all of this started in India... from nothing.</p>


<p><span class="green-text">Places That Changed the World</span> is a BBC Travel series looking into how a destination has made a
significant impact on the entire planet.</p>

<p>Join more than three million BBC Travel fans by liking us on <a href="#">Facebook</a>, or follow us
on <a href="#">Twitter</a> and <a href="#">Instagram.</a></p>

            </div>
          </div>
          <div class="col-xs-12 col-sm-12 col-md-4 col-lg-4">
            <iframe src="https://www.facebook.com/plugins/page.php?href=https%3A%2F%2Fwww.facebook.com%2FThe-University-of-Maths-484049115388250%2F&tabs=timeline&width=340&height=700&small_header=false&adapt_container_width=true&hide_cover=false&show_facepile=true&appId" width="340" height="700" style="border:none;overflow:hidden" scrolling="no" frameborder="0" allowTransparency="true" allow="encrypted-media"></iframe>
          </div>
        </div>
      </div>
    </div>
  </div>
</section> 

<?php }
elseif($event==3){ ?>

<section id="title-inner">
  <div id="large-header">
    <canvas id="demo-canvas"></canvas>
    <div class="container">
      <div class="text-tit">
        <div class="bb"></div>
        <span class="lefttop-icon"></span>
        <h1><span>Children in Singapore excel at math because parents care</span></h1>
        <span class="rightbotm-icon"></span> </div>
    </div>
  </div>
</section>

<!-- Page Content inner -->

<section class="about_content content-text event-single-page space-75">
  <div class="container">
    <div class="event-single">
      <div class="media_single">
        <div class="row">
          <div class="col-xs-12 col-sm-12 col-md-8 col-lg-8">
            <div class="img-holder"> <img src="<?= base_url('assets/images/event-single.jpg')?>" alt="" /> <span class="date"> 02 <em>aug</em> </span> </div>
            <div class="single-text">
              <h4 class="title">Children in Singapore excel at math because parents care</h4>
              <p>After spending close to 40 years in the math education game as a secondary teacher, mathematics consultant and teacher educator in Ontario and Singapore I regard the various solutions to the supposed mathematics "crisis" with detached bemusement. It is a little like watching a long running Broadway musical where the cast members have changed over the years: The actors change but all the songs and dance routines stay the same. They do so because they are what the audience wants to see. So it is with the teaching and learning of mathematics (and education in general); despite what various people say, we end up with the education system that we want.</p>

<p>In last year's labour unrest with Ontario teachers I did not read any articles in the media about parents being upset by the fact that children might not be getting the best math instruction; rather, the concern was exclusively about extra-curricular activities. Although it is rarely stated, our educational system is shaped more by our societal values and norms than by curriculum, teacher education programs, or teaching methods. This is the reason that the various solutions proposed to solve the math "crisis" won't work: They are not addressing the
real reasons why Canadian students are so handily beaten by Singaporeans.</p>

<p>Singapore is an island nation of approximately the size and population of the GTA. It is a thriving and successful country despite having no natural resources other than its population. All children are required to write examinations at the end of grade 6 and their results have a</p>

<p>If a child is not doing well in math it is not assumed to be a problem of the teacher, the school or the curriculum; rather, it is assumed to be a problem for the student and his or her parents to resolve. They may do this by hiring a tutor - tutoring is a huge business in Singapore with many teachers tutoring for a living rather than teaching in a school.</p>

<p>Alternatively, they may go to a local bookstore and buy a couple of books of extra practice questions from the thousands available covering all subjects and grade levels and then sit with their child to ensure that they actually do all the practice problems.</p>

<p>The result of this kind of behaviour is clear every time there is an international comparison of educational performance in mathematics and Singapore scores close to the top. Funnily enough, they also worry if they slip a position or two in the rankings! After spending many
hours observing in Singaporean classrooms I can tell you that the performance of their students is not a result of teaching methods, curriculum or school facilities. It is a result of cultural norms and societal expectations. Trying to make subtle changes in the way we teach math or give teachers a couple of workshops is unlikely to make our Canadian children perform as well as they do in Singapore.</p>


<p>We need to ask ourselves whether the results on international comparisons are sufficiently important to us as a society to make us willing to behave like Singaporeans. After all, despite what the doom merchants would have us believe, there is absolutely no credible evidence that rankings in these kinds of tests have any correlation with workplace productivity or competitiveness in the marketplace. They do correlate strongly with students' success in further math courses - and that is something that is very important to parents in Singapore.</p>

<p>Eric Wood is a former associate professor at the National Institute of Education in Singapore with responsibility for preparing secondary mathematics teachers.</p>
          
            </div>
          </div>
          <div class="col-xs-12 col-sm-12 col-md-4 col-lg-4">
            <iframe src="https://www.facebook.com/plugins/page.php?href=https%3A%2F%2Fwww.facebook.com%2FThe-University-of-Maths-484049115388250%2F&tabs=timeline&width=340&height=700&small_header=false&adapt_container_width=true&hide_cover=false&show_facepile=true&appId" width="340" height="700" style="border:none;overflow:hidden" scrolling="no" frameborder="0" allowTransparency="true" allow="encrypted-media"></iframe>
          </div>
        </div>
      </div>
    </div>
  </div>
</section> 

<?php }
elseif($event==4){ ?>

<section id="title-inner">
  <div id="large-header">
    <canvas id="demo-canvas"></canvas>
    <div class="container">
      <div class="text-tit">
        <div class="bb"></div>
        <span class="lefttop-icon"></span>
        <h1><span>Why is Singapore Math so popular overseas?</span></h1>
        <span class="rightbotm-icon"></span> </div>
    </div>
  </div>
</section>

<!-- Page Content inner -->

<section class="about_content content-text event-single-page space-75">
  <div class="container">
    <div class="event-single">
      <div class="media_single">
        <div class="row">
          <div class="col-xs-12 col-sm-12 col-md-8 col-lg-8">
            <div class="img-holder"> <img src="<?= base_url('assets/images/event-single.jpg')?>" alt="" /> <span class="date"> 02 <em>aug</em> </span> </div>
            <div class="single-text">
              <h4 class="title">Why is Singapore Math so popular overseas?</h4>
             <p>What is Singapore Math and why is it so popular in other countries? Is it true that this method makes math easily understood by kids? Find answers to all these questions and find out how Singapore Math works right here.</p>
             
             <strong>What is Singapore Math?</strong>
             
<p>What folks the world over refer to as 'Singapore Math' is just 'math' to us here in Singapore. It is a special method of teaching math that was developed in 1982 for children from kindergarten through grade 6, as part of the national curriculum under the supervision of the Ministry of Education.</p>

<p>Before this method was introduced here in Singapore, primary schools used mathematic textbooks from other countries. In 1981, the Curriculum Planning and Development Division (then Curriculum Development Institute of Singapore) began plans on the new curriculum.</p>

<p>In 1982 the series of textbooks named 'Primary Mathematics' were distributed to schools nationwide. These textbooks were revised once in 1992, with more emphasis put on problem solving.</p>

<strong>Singapore Math's popularity overseas</strong>
<p>The effects of the new curriculum were obvious in an international assessment conducted by the Trends International Mathematics and Science Society (TIMSS) done on 4th and 8th graders.</p>

<p>This assessment ranked Singaporean students first in the years 1995, 1999 and 2003. That's why mathematicians and educators in other countries started paying closer attention to Singapore Math, and textbooks such as Primary Mathematics.</p>

<p>In 1998, Jeff and Dawn Thomas from Oregon, U.S.A. established a company named Singapore Math to distribute books to schools and homeschooling parents throughout the U.S. They did this after using the method with their own child.</p>

<p>As Singapore Math became more popular, more schools in the U.S and in other countries such as the United Kingdom, Canada and Israel also started using it. As a result, many schools claimed there was a definite improvement in student test scores.</p>

<strong>How does Singapore Math work?</strong>

<p>Singapore Math focuses mainly on building fundamental math skills, rather than focusing on content.</p>

<strong>The three-step learning approach</strong>

<p>This particular learning approach is based on the theories of American psychologist Jerome Bruner. He suggests that people learn by first handling real-life objects, then transition into understanding something pictorially and then symbolically.</p>

<p>So if you follow this process when teaching children, they will have a greater understanding of what they are learning, rather than just memorising facts.</p>

<p>The first step of the three-step approach is the concrete step, where teachers use something kids can touch and feel like dice, blocks or colour pencils to show concepts such as addition and subtraction.</p>

<p>After this, kids can progress to the pictorial stage and strengthen their knowledge of the concepts they have learnt by using diagrams called 'bar-models.' A rectangular bar shape would represent numbers.</p>

<p>This bar method can be used for subtraction, multiplication, division, fractions, ratios and decimals as well. (More on this later)</p>

<h5>So what 'key concepts' does the Singapore Math system teach? Let's have a look...</h5>

<p>There are two key concepts that children learn in the Singapore Math system. Let's explore these two concepts by solving simple problems.</p>

<strong>The part whole concept</strong> 
<p>Through this concept, a child is taught to understand the concept of 'parts', and that the sum of these parts make the 'whole'.</p>
<p>Here's a sample problem: "If Isabelle has 3 balls and Leanne has 2, how many balls do both have?"</p>
<p>A child can draw a bar to represent the total, then divide it into a slightly larger portion and a smaller portion.</p>
<p>The part whole concept can be used for subtraction, division and multiplication too.</p>
<strong>The comparison concept</strong>
<p>While the part whole concept uses one full bar to represent the whole, the comparison model uses two parallel bars.</p>
<p>For instance, let's solve this problem: "If Emily has 5 pencils and 3 erasers, how many more pencils does Emily have?"</p>
<strong>What about your child? What Singapore Math concepts or models does he or she already know? Please do leave a comment and let us know!</strong>
            </div>
          </div>
          <div class="col-xs-12 col-sm-12 col-md-4 col-lg-4">
            <iframe src="https://www.facebook.com/plugins/page.php?href=https%3A%2F%2Fwww.facebook.com%2FThe-University-of-Maths-484049115388250%2F&tabs=timeline&width=340&height=700&small_header=false&adapt_container_width=true&hide_cover=false&show_facepile=true&appId" width="340" height="700" style="border:none;overflow:hidden" scrolling="no" frameborder="0" allowTransparency="true" allow="encrypted-media"></iframe>
          </div>
        </div>
      </div>
    </div>
  </div>
</section> 

<?php }
elseif($event==5){ ?>

<section id="title-inner">
  <div id="large-header">
    <canvas id="demo-canvas"></canvas>
    <div class="container">
      <div class="text-tit">
        <div class="bb"></div>
        <span class="lefttop-icon"></span>
        <h1><span>Singapore Math Is Popular Among Educators Worldwide. Why?</span></h1>
        <span class="rightbotm-icon"></span> </div>
    </div>
  </div>
</section>

<!-- Page Content inner -->

<section class="about_content content-text event-single-page space-75">
  <div class="container">
    <div class="event-single">
      <div class="media_single">
        <div class="row">
          <div class="col-xs-12 col-sm-12 col-md-8 col-lg-8">
            <div class="img-holder"> <img src="<?= base_url('assets/images/event-single.jpg')?>" alt="" /> <span class="date"> 02 <em>aug</em> </span> </div>
            <div class="single-text">
              <h4 class="title">Singapore Math Is Popular Among Educators Worldwide. Why?</h4>
              
              <p>Singapore Math has gone beyond helping Singaporean students excel in the classroom to becoming a commercial product used widely around the world.</p>
              <p>AsianScientist (Jun. 16, 2016) - How does one explain the concept of x to a seven-yearold? The answer, say Singapore math educators, is not to think outside of the box, but to use the box.</p>          
              
<p>They are referring to the bar model method developed by the country's Ministry of Education more than three decades ago. Students draw a long box or bar to represent a
certain quantity, and when two or more quantities are being compared, the bars can be
divided into units to reflect the difference in values. Each bar is labeled, and the
unknown is denoted by a question mark.</p>

<strong>A simple bar model diagram used in Singapore Math that aids in visualization.
Credit: Claudia Chong</strong>

<p>Bar modeling allows students to visually appreciate the relationship between compared quantities, as well as abstract concepts in problem-solving. With such innovative methods in its math curriculum, it is no wonder that Singapore was among the top ranked countries in 1995, 1999, 2003 and 2007 for the Trends in International Mathematics and Science Study.</p>

<p>Furthermore, the Global Competitiveness Report 2015-2016 released by the World</p>
<p>Economic Forum placed Singapore ??rst out of 140 countries in quality of math and science education.</p>
<p>But even starker is the fact that Singapore Math has gone beyond helping Singaporean students clinch top positions in international math assessments - it has been successfully transplanted into foreign markets, reaching the shores of over 25 countries such as the US, France and Saudi Arabia.</p>

<h5>The appeal of Singapore Math</h5>

<p>US-based company Singapore Math Inc. first introduced the Singapore Math textbook series Primary Mathematics (3rd Edition) to the US in 1998. Since then, states such as California and Oregon have approved the use of these textbooks in all kindergarten and
elementary schools, International Enterprise Singapore revealed in 2009. Singapore Math textbooks have also found their way into domestic settings for homeschooling purposes. But what exactly makes the Singapore model of math education so attractive to Western countries?</p>

<blockquote>"What sets Singapore textbooks apart is that fewer topics are introduced at each grade level," says Kelly Barten, marketing manager of Singapore Math Inc., in an interview with Asian Scientist Magazine. "As a result, more time is spent on each topic, allowing for student mastery of the concepts."</blockquote>

<p>Barten adds that the structure of Singapore Math is closely aligned with a student's cognitive development, making for a highly marketable curriculum. The current math education system in Singapore is the result of a complete restructure during the 1980s. The new system moved away from rote learning and towards a deeper understanding of concepts. Curriculum designers drew upon educational psychologist
Jerome Bruner's theory that learning takes place in three steps: through the use of real objects, then via pictures, and lastly, with the aid of symbols. This is called the Concrete- Pictorial-Abstract, or C-P-A, approach.</p>

<blockquote>"In the same way, when introducing word problems to be solved for the ??rst time,
stories or contexts that students are familiar with are discussed ??rst," shares Dr.
Ridzuan Abdul Rahim, a math specialist at the Singapore Ministry of Education.
"After which, the pictorial representation of the problem is developed to render a
solution of the problem in its abstract form."</blockquote>
             
            </div>
          </div>
          <div class="col-xs-12 col-sm-12 col-md-4 col-lg-4">
            <iframe src="https://www.facebook.com/plugins/page.php?href=https%3A%2F%2Fwww.facebook.com%2FThe-University-of-Maths-484049115388250%2F&tabs=timeline&width=340&height=700&small_header=false&adapt_container_width=true&hide_cover=false&show_facepile=true&appId" width="340" height="700" style="border:none;overflow:hidden" scrolling="no" frameborder="0" allowTransparency="true" allow="encrypted-media"></iframe>
          </div>
        </div>
      </div>
    </div>
  </div>
</section> 


<?php }
elseif($event==6){ ?>

<section id="title-inner">
  <div id="large-header">
    <canvas id="demo-canvas"></canvas>
    <div class="container">
      <div class="text-tit">
        <div class="bb"></div>
        <span class="lefttop-icon"></span>
        <h1><span>Singapore Math Pros and Cons</span></h1>
        <span class="rightbotm-icon"></span> </div>
    </div>
  </div>
</section>

<!-- Page Content inner -->

<section class="about_content content-text event-single-page space-75">
  <div class="container">
    <div class="event-single">
      <div class="media_single">
        <div class="row">
          <div class="col-xs-12 col-sm-12 col-md-8 col-lg-8">
            <div class="img-holder"> <img src="<?= base_url('assets/images/event-single.jpg')?>" alt="" /> <span class="date"> 02 <em>aug</em> </span> </div>
            <div class="single-text">
              <h4 class="title">Singapore Math Pros and Cons</h4>
              
              <h5>The Benefits and Disadvantages of the Singapore Math Method</h5>
              <p>The Singapore Math method marked a change in the way math was taught in many American classrooms. The program uses a three-step learning model, moving from the concrete (such as showing something using manipulatives) to the pictorial (creating a
visual representation on paper), to the abstract (solving problems).</p>

<p>So what is Singapore Math? Let's start with a little background:</p>

<p>What is referred to as Singapore Math in other countries is, for Singapore, simply math. The program was developed under the supervision of the Singaporean Minister of Education and introduced as the Primary Mathematics Series in 1982. For close to 20 years, this program remained the only series used in Singaporean classrooms.</p>

<p>In 1998, Jeff and Dawn Thomas wondered if that the math program they brought back from Singapore and used to supplement their own child's schoolwork might be useful to schools and home-schooling families in the U.S. The couple incorporated under the name Singaporemath.com and their books began being marketed under the name Singapore Math textbooks.</p>

<p>Despite is popularity among some educators, as with any program, Singapore Math has pros and cons.</p>

<p>It's been widely criticized as being confusing for children to learn as part of a Common Core standards framework, with some educators complaining that it unnecessarily complicates the teaching of mathematical principles to young children.</p>

<p>The framework of Singapore Math is developed around the idea that learning to problem-solve and develop mathematical thinking are the key factors in being successful in math. It states that "the development of mathematical problem-solving ability is dependent on ??ve inter-related components, namely, Concepts, Skills, Processes, Attitudes and Metacognition."</p>

<h5>Pros of Singapore Math</h5>
<p>Textbooks and workbooks are simple to read with concise graphics. Closely aligned with the Common Core State Standards.</p> 
<p>Textbooks are sequential, building on previously learned concepts and skills, which offers the opportunity for learning acceleration without the need for supplemental work. </p>
<p>Asks for students to build meaning to learn concepts and skills, as opposed to rote memorization of rules and formulas.</p>
<p>Covers fewer topics in a year, but in an in-depth way that ensures students have a
foundation to move forward without needing to re-learn concepts.</p>

<h5>Cons of Singapore Math</h5>

<p>Requires extensive and ongoing teacher training, which is neither financially or practically feasible in a number of school districts.</p>
<p>Materials are consumable and must be re-ordered for every classroom every year. This can put a huge financial burden on already strained school budgets. Less of a focus on applied mathematics than traditional U.S. math textbooks. For instance, the Everyday Mathematics program emphasizes data analysis using real-life, multiple step math problems, while Singapore Math's approach is more ideological. Doesn't work well for a nomadic student population. Many students move in and out of school districts, which isn't a big problem when the math programs are similar. However, since Singapore Math is so sequential and doesn't re-teach concepts or skills, using the program may set these students up for failure, whether they're moving into or out of a district using it.</p>

<p>Despite the number of pros to Singapore Math and some research suggesting that it is superior to U.S. textbooks, some schools are ??nding that the method is not easy to implement.</p>
              
             
            </div>
          </div>
          <div class="col-xs-12 col-sm-12 col-md-4 col-lg-4">
            <iframe src="https://www.facebook.com/plugins/page.php?href=https%3A%2F%2Fwww.facebook.com%2FThe-University-of-Maths-484049115388250%2F&tabs=timeline&width=340&height=700&small_header=false&adapt_container_width=true&hide_cover=false&show_facepile=true&appId" width="340" height="700" style="border:none;overflow:hidden" scrolling="no" frameborder="0" allowTransparency="true" allow="encrypted-media"></iframe>
          </div>
        </div>
      </div>
    </div>
  </div>
</section> 


<?php }
elseif($event==7){ ?>

<section id="title-inner">
  <div id="large-header">
    <canvas id="demo-canvas"></canvas>
    <div class="container">
      <div class="text-tit">
        <div class="bb"></div>
        <span class="lefttop-icon"></span>
        <h1><span>Singapore maths inspires UK educators</span></h1>
        <span class="rightbotm-icon"></span> </div>
    </div>
  </div>
</section>

<!-- Page Content inner -->

<section class="about_content content-text event-single-page space-75">
  <div class="container">
    <div class="event-single">
      <div class="media_single">
        <div class="row">
          <div class="col-xs-12 col-sm-12 col-md-8 col-lg-8">
            <div class="img-holder"> <img src="<?= base_url('assets/images/event-single.jpg')?>" alt="" /> <span class="date"> 02 <em>aug</em> </span> </div>
            <div class="single-text">
              <h4 class="title">Singapore maths inspires UK educators</h4>
              
             <p>The Singapore style of teaching mathematics is already being used in thousands of schools across the United States. Now, it is making inroads into British schools as well.</p>
             
             <p>The Inspire Maths series of textbooks, adapted from the books here, were trialled in 70 British primary schools by the Department for Education over the past two years.</p>
             
             <p>A study found that they were effective in helping children master the subject better.</p>
             
             <p>Now, with another &pound;41 million (S$72 million) from the British government - to fund a network of "mastery specialist teachers" - the Singapore style of teaching maths may reach as many as 8,000 primary schools in Britain over the next few years.</p>
              
              <p>The Inspire Maths series published by Oxford University Press was adapted from the My Pals Are Here! textbooks published by Marshall Cavendish Education for schools here.</p>
              
              <p>Independent research conducted by the Oxford University Department of Education last year found that British schoolchildren made more progress in maths when teachers used Singapore-style methods.</p>
              
              <h5>SURPRISING RESULTS</h5>
              
              <strong>This boost to progress was surprising because pupils had been in a classroom setting for only a short period and because it often takes time to embed new teaching approaches.</strong>
              
              <p>PROFESSOR JAMES HALL, lead author of the study and lecturer at the University of Exeter, on the use of the Inspire Maths series of textbooks.</p>
              
              <h5>EFFECTIVE METHOD</h5>
              
             <blockquote> We are excited about this research and that it demonstrates the effectiveness of a
mastery method of teaching mathematics in UK classrooms that has been so
successful in Singapore.
MS LEE FEI CHEN, Marshall Cavendish Education's head of publishing.</blockquote>

<p>Researchers found that pupils shot ahead of their peers when taught the Singapore way, which focuses on
mastering core principles as "building blocks".</p>

<p>The "mastery" method, as Singapore's approach is called in Britain, introduces core concepts such as times tables, addition and subtraction gradually, until learners are confident. Ideas are broken down into small steps, using real-life objects such as cubes and beads to illustrate a point, before moving on to drawings and then concepts.</p>

<p>The research combined child assessments with classroom observations and interviews with teachers.</p>

<p>Teachers reported that the programme could boost children's motivation and engagement, and the evaluation found that it could be used creatively and flexibly.</p>

<p>Researchers also found that teachers value the professional development provided to support their use of the
Inspire Maths resources.</p>

<p>Professor James Hall, lead author of the study and now a lecturer at the University of Exeter, said: "This boost to progress was surprising because pupils had been in a classroom setting for only a short period and because it often takes time to embed new teaching approaches."</p>

<p>The study involved two groups of children aged five to six - a total of 550 - learning maths in 12 English schools in 2015 to last year.</p>

<p>The first group learnt maths the normal British way for the first term, then switched to using the Inspire Maths textbook in the second term. The second group used the textbook for both terms, and made better overall progress than the first group.</p>

<p>Oxford University Press' editorial director for primary maths Jill Cornish said: "We now have clear evidence that a mastery approach can make a real difference to maths classrooms."</p>

<p>But, she said, Singapore maths cannot be a "quick fix".</p>

<p>First, the pressure on schools in England to cover a large number of maths topics in the national curriculum each year creates tension with the Singapore maths approach, which emphasises building solid foundations before moving on.</p>

<p>She added that teachers need more professional development and that school management teams need to be brought on board.</p>

<p>Marshall Cavendish Education's head of publishing Lee Fei Chen said: "We are excited about this research and that it demonstrates the effectiveness of a mastery method of teaching mathematics in UK classrooms that has been so successful in Singapore."</p>

<p>The Singapore style of teaching maths has gained attention because of the Republic's high placings in global benchmarking tests.</p>

<p>Singapore students were ranked No. 1 in maths, science and reading in the 2015 Programme for International Student Assessment test results released in December last year. Britain was ranked 27th in maths.</p>

<p>Besides Britain and the US, 15 countries - including South Africa, Brunei and the Netherlands - are using
customised textbooks based on Singapore maths produced by Marshall Cavendish Education.</p>

<p>Prime Minister Lee Hsien Loong on Thursday (April 6) shared this article on his Facebook page and said he was
"glad that our methods are helping children in other countries learn and do better in maths".</p>

             
            </div>
          </div>
          <div class="col-xs-12 col-sm-12 col-md-4 col-lg-4">
            <iframe src="https://www.facebook.com/plugins/page.php?href=https%3A%2F%2Fwww.facebook.com%2FThe-University-of-Maths-484049115388250%2F&tabs=timeline&width=340&height=700&small_header=false&adapt_container_width=true&hide_cover=false&show_facepile=true&appId" width="340" height="700" style="border:none;overflow:hidden" scrolling="no" frameborder="0" allowTransparency="true" allow="encrypted-media"></iframe>
          </div>
        </div>
      </div>
    </div>
  </div>
</section> 

<?php }
elseif($event==8){ ?>

<section id="title-inner">
  <div id="large-header">
    <canvas id="demo-canvas"></canvas>
    <div class="container">
      <div class="text-tit">
        <div class="bb"></div>
        <span class="lefttop-icon"></span>
        <h1><span>Singapore maths: How a radical new way of teaching
equips UK pupils to tackle a tougher curriculum</span></h1>
        <span class="rightbotm-icon"></span> </div>
    </div>
  </div>
</section>

<!-- Page Content inner -->

<section class="about_content content-text event-single-page space-75">
  <div class="container">
    <div class="event-single">
      <div class="media_single">
        <div class="row">
          <div class="col-xs-12 col-sm-12 col-md-8 col-lg-8">
            <div class="img-holder"> <img src="<?= base_url('assets/images/event-single.jpg')?>" alt="" /> <span class="date"> 02 <em>aug</em> </span> </div>
            <div class="single-text">
              <h4 class="title">Singapore maths: How a radical new way of teaching
equips UK pupils to tackle a tougher curriculum</h4>
            <p>The system, known as 'maths mastery', relies on teaching fewer subjects, but in far greater depth</p>  
            <p>Charlotte, seven, glances at the sum on the whiteboard - 520 minus 269 - and shakes 10 little yellow squares of card out of a bag on her desk. "We're renaming a 10 for 10 ones," she says, swapping them
for a single green stick, also made of card. The Year Three class is grappling with subtraction, although the chorus of correct answers suggests there is little struggling going on.</p>
<p>With their handy props, the pupils at Three Bridges primary school, in Southall, west London, are at the front line of what promises to be a revolution in mathematics teaching: maths, Singapore-style.</p>

<p>Hundreds of head teachers across England and Wales are turning to Singapore maths to help pupils cope with the new, tougher national curriculum. The system, similar to its Shanghai cousin, relies on teaching fewer subjects, but in far greater depth.</p>

<ul>
<li><strong>There Are 7 Types of English Surnames - Which One Is Yours?</strong>
<p>Ancestry</p></li>
<li><strong>Play this for 1 minute and see why everyone is addicted</strong>
<p>Throne: Free Online Game</p></li>
<li><strong>Syria's Assad has become Israel's ally</strong>
<p>Haaretz</p></li>
</ul>
               
<p>It is also known as "maths mastery" because it relies on pupils mastering each step before moving on. It relies on text books, anathema to British classrooms for the past generation. Barely one in 10 schools uses text books, but that number is tipped to soar. One Singaporestyle maths publisher, Maths No Problem, has seen demand for its books increase six-fold since the last academic year, and has had to reprint the whole primary series twice this term.</p>

<p>Charlotte, at Three Bridges, which began introducing elements of Singapore-style teaching nearly three years ago, is a fan of the system, mainly because she likes the props. Those bits of card are among trays and trays of objects in the school's new maths storeroom. "They make it a bit easier to explain," adds Charlotte, highlighting another key tenet of the Singapore way: getting students, from Reception age up, to teach their friends as they go along.</p>

<p>This means teachers will stop streaming and mix up different abilities instead. Or, as a Department for Education spokesperson puts it: "We expect the majority of pupils will move through the programmes of study at broadly the same pace."</p>

<p>Emma Valerio, maths co-ordinator at Three Bridges, has a ready reply to parents who fear highflyers will be held back. "We used to set across year groups, so Year Three pupils would be learning mathematicians aren't the ones given the next level of maths; they develop their own.</p>

<p>And it hasn't held back students in Singapore, which overhauled its maths teaching in the Eighties. The latest Programme for International Student Assessment (Pisa) results from The Organisation for Economic Co-operation and Development (OECD) puts Singapore's 15-yearolds in second place for their maths skills, behind Shanghai's; their British peers are in 26th place.</p>

<p>Early results here look promising: a recent study by the Institute of Education at the University of London and the University of Cambridge looked at the progress made after one year by pupils studying under the maths mastery scheme at 90 primary and 50 secondary schools: the effects were "small but positive"</p>

<p>Steve McCormack, at the government-funded National Centre for Excellence in the Teaching of Mathematics, said: "We're in the early stages of something that could take up to a decade to bear real fruit. But the potential is huge."</p>



            </div>
          </div>
          <div class="col-xs-12 col-sm-12 col-md-4 col-lg-4">
            <iframe src="https://www.facebook.com/plugins/page.php?href=https%3A%2F%2Fwww.facebook.com%2FThe-University-of-Maths-484049115388250%2F&tabs=timeline&width=340&height=700&small_header=false&adapt_container_width=true&hide_cover=false&show_facepile=true&appId" width="340" height="700" style="border:none;overflow:hidden" scrolling="no" frameborder="0" allowTransparency="true" allow="encrypted-media"></iframe>
          </div>
        </div>
      </div>
    </div>
  </div>
</section> 


<?php }
elseif($event==9){ ?>

<section id="title-inner">
  <div id="large-header">
    <canvas id="demo-canvas"></canvas>
    <div class="container">
      <div class="text-tit">
        <div class="bb"></div>
        <span class="lefttop-icon"></span>
        <h1><span>Singapore students top global ranking in maths and science</span></h1>
        <span class="rightbotm-icon"></span> </div>
    </div>
  </div>
</section>

<!-- Page Content inner -->

<section class="about_content content-text event-single-page space-75">
  <div class="container">
    <div class="event-single">
      <div class="media_single">
        <div class="row">
          <div class="col-xs-12 col-sm-12 col-md-8 col-lg-8">
            <div class="img-holder"> <img src="<?= base_url('assets/images/event-single.jpg')?>" alt="" /> <span class="date"> 02 <em>aug</em> </span> </div>
            <div class="single-text">
              <h4 class="title">Singapore students top global ranking in maths and science</h4>
           <p>The study assessed Primary 4 and Secondary 2 pupils in 64 education systems. It found that students in Singapore had a
strong mastery in both subjects, and were able to apply their knowledge and conceptual understanding to solve problems.</p>

<p>SINGAPORE: Singapore students are the world's best in mathematics and science, according to an international benchmarking study released on Tuesday (Nov 29).</p>

<p>Primary 4 and Secondary 2 students here topped both subjects in the Trends in International Mathematics and Science Study (TIMSS), which assessed pupils from 63 other education systems around the world.</p>

<p>Not only are Singapore students scoring well in those subjects, they also have more positive attitudes towards learning and are immersed in condusive learning environments, the survey found.</p>

<p>About 6,500 Primary 4 students and 6,100 Secondary 2 students - all randomly selected from across all schools in Singapore - took part in the latest study which has been conducted every four years since 1995.</p>

<p>At the Primary 4 level for instance, for mathematics, students here achieved the highest average score of 618. Hong Kong came in second with 615 followed by South Korea with 608. The same students got the highest average score of 590 for science, ahead of South Korea (589) and Japan (569).</p>

<p>The findings also showed improvements by Singapore students over the years, especially in higher-order thinking skills.</p>
<p>The Ministry of Education (MOE) said: "This reflects our curricular shifts towards a greater emphasis on such thinking skills over the years." Going forward, MOE will put greater focus on critical thinking skills in examinations.</p>

<p>"It's not about making exams harder, it's about whether the exams test the skills that we want our students to develop," said Ms Low Khah Gek, deputy director-general of education (schools). "So in this case, we do want our students to be able to think critically, and also to be able to explain their thinking."</p>

<p>MOE credited the students' positive learning attitudes to the learning environment both at home and in school, adding that more than eight in 10 students in Primary 4 and Secondary 2 said that their math and science teachers are clear in their expectations, are good at explaining concepts, and listen to their views.</p>

<p>The global study also revealed that the Singapore education system supports students across all achievement levels, MOE said. The proportion of Primary 4 and Secondary 2 students who did not attain the lowest international benchmark remained very small in both subjects, and below the international median.</p>

<p>One per cent of Primary 4 students in Singapore who took part in the study did not attain the "low" international benchmark in mathematics, while 3 per cent did not attain that benchmark in science. This is compared to the international median of 7 per cent and 5 per cent respectively.</p>

<h5>Sample of a Primary 4 Maths item at the "low" benchmark.</h5>

<p>For the Secondary 2 level, 1 percent did not attain the "low" international benchmark in mathematics and 3 per cent did not attain the benchmark in science. This is compared to the international median of 16 per
cent for both subjects.</p>

<p>We are proud of our students," said Ms Low. "Our teachers have provided quality learning experiences for them, and we are heartened that our teaching and learning systems are strong.</p>

<p>She added that schools will continue to work closely with parents and the larger community "to further build on our students' strong foundation and prepare them well for their next stage of education and for a fulfilling career ahead.</p>


            </div>
          </div>
          <div class="col-xs-12 col-sm-12 col-md-4 col-lg-4">
            <iframe src="https://www.facebook.com/plugins/page.php?href=https%3A%2F%2Fwww.facebook.com%2FThe-University-of-Maths-484049115388250%2F&tabs=timeline&width=340&height=700&small_header=false&adapt_container_width=true&hide_cover=false&show_facepile=true&appId" width="340" height="700" style="border:none;overflow:hidden" scrolling="no" frameborder="0" allowTransparency="true" allow="encrypted-media"></iframe>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>


<?php }
elseif($event==10){ ?>

<section id="title-inner">
  <div id="large-header">
    <canvas id="demo-canvas"></canvas>
    <div class="container">
      <div class="text-tit">
        <div class="bb"></div>
        <span class="lefttop-icon"></span>
        <h1><span>Why are Singaporeans so good at Math?</span></h1>
        <span class="rightbotm-icon"></span> </div>
    </div>
  </div>
</section>

<!-- Page Content inner -->

<section class="about_content content-text event-single-page space-75">
  <div class="container">
    <div class="event-single">
      <div class="media_single">
        <div class="row">
          <div class="col-xs-12 col-sm-12 col-md-8 col-lg-8">
            <div class="img-holder"> <img src="<?= base_url('assets/images/event-single.jpg')?>" alt="" /> <span class="date"> 02 <em>aug</em> </span> </div>
            <div class="single-text">
              <h4 class="title">Why are Singaporeans so good at Math?</h4>
           <p>As a local student majoring in mathematics, my experience is an emphatic no. In my opinion, it is a mistake to view performances of Singaporean students for international science or mathematics competition as an appropriate assessment of the general proficiency of math or science in Singaporeans. Since my background is strictly in mathematics, my argument thereafter only applies to mathematics.</p>

<p>To begin with, mathematics below high school level is not a good representation of formal mathematics played at an undergraduate or professional level. High school mathematics is designed with the intention to prepare students sufficiently for the basic rigor of practical mathematics used in other fields of work such as engineering, humanities or the social sciences. In this regard, mathematics competitions, while it is true that it borrows elements of problem solving from formal mathematics, is to encourage interest in students on formal
mathematics and is, not in any way, intended to be used as a yardstick to determine one's mathematical capability. Even among some professional mathematicians, there is some level of consensus against these competitions to promote mathematical interest since it provides a wrong representation of formal mathematics and alienates potentially good mathematicians who may be slower but more careful thinkers by encouraging speed and memory.</p>

<p>This brings me to the second argument which was once raised in the mathematical community on why so many students struggled in math at anundergraduate level despite their clear strength in it at lower levels. One of the answers proposed was that students couldn't leave the high school mindset of mathematics and aren't used to being stuck on a problem. They don't realize that professional mathematicians spend years getting stuck on just a few problems and the good ones took a painfully long time to learn the required tricks for getting unstuck. In a fast paced Singaporean high school setting where the quality of questions is sacrificed by a shorter stipulated examination time, students continue to be awarded by subscribing to a collection of recipes and the relative crammed curriculum penalizes students who take the time to learn the concepts thoroughly and getting unstuck on challenging abstract problems, it then becomes trivial to see how out-of-touch our college students suddenly become once the reality of formal mathematics hit them hard; some faltered with hurt ego, puzzled at themselves despite years of comfort in mathematical learning. Mathematics educator Hughes Hallet put it even more bluntly on her
assessment of American mathematics on the same problem more than 30 years</p>

<p>In fact, at least in my context, international students, with their earlier exposure to formal mathematics in their high school, have been far outperforming Singaporean students at least in terms of grades for almost all mathematical modules. When their mathematical foundation is already firm, the influence of Matthew's effect on the gap between the international and local students couldn't be more obvious. I think it is sad because Singaporeans students can be fairly good in mathematics but we weren't prepared for formal mathematics, or at least there may not be any clear incentives for the education ministry to be convinced in giving us the time and resources to do so earlier. Unless your question excludes formal mathematics and pertains strictly to lower level mathematics, myself included previously,your trust or belief in our people's or at least our own seemingly high level of mathematical skills based on prior high school proficiency is understandably misplaced.</p>

<h5>Take your writing to the next level.</h5>
<p>Grammarly's free writing app makes sure everything you type is easy to read,
effective, and mistake-free.</p>

<strong>Related Questions</strong>

<ul>
<li>What are some good traits of Singaporeans?</li>
<li>When did Singaporean students start saying "math" rather than "maths" (or rather "matzz")?</li>
<li>How good is Singaporeans' English compared to Hong Kongers'?</li>
<li>Why are the French good at math?</li>
<li>Singaporeans: Why are some Singaporeans who have migrated for good so self-entitled?</li>
</ul>

<p>My O level scores for both my Elementary Mathematics and Principle of Accounts got a B3</p>
<p>I can see why it is easy to assume that all Singaporeans are good in math and science.</p>
<p>In 2015, Singapore topped and lead the way in being the best for mathematics and science in the OECD rankings.</p>
<p>What I would admit however, is that all Singaporeans who have at least went
through formal education, will have covered all the basic fundamentals of</p>
            </div>
          </div>
          <div class="col-xs-12 col-sm-12 col-md-4 col-lg-4">
            <iframe src="https://www.facebook.com/plugins/page.php?href=https%3A%2F%2Fwww.facebook.com%2FThe-University-of-Maths-484049115388250%2F&tabs=timeline&width=340&height=700&small_header=false&adapt_container_width=true&hide_cover=false&show_facepile=true&appId" width="340" height="700" style="border:none;overflow:hidden" scrolling="no" frameborder="0" allowTransparency="true" allow="encrypted-media"></iframe>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>


<?php }
elseif($event==11){ ?>

<section id="title-inner">
  <div id="large-header">
    <canvas id="demo-canvas"></canvas>
    <div class="container">
      <div class="text-tit">
        <div class="bb"></div>
        <span class="lefttop-icon"></span>
        <h1><span>Why Do Singapore Students Surpass the Rest of the
World in Math and Science?</span></h1>
        <span class="rightbotm-icon"></span> </div>
    </div>
  </div>
</section>

<!-- Page Content inner -->

<section class="about_content content-text event-single-page space-75">
  <div class="container">
    <div class="event-single">
      <div class="media_single">
        <div class="row">
          <div class="col-xs-12 col-sm-12 col-md-8 col-lg-8">
            <div class="img-holder"> <img src="<?= base_url('assets/images/event-single.jpg')?>" alt="" /> <span class="date"> 02 <em>aug</em> </span> </div>
            <div class="single-text">
              <h4 class="title">Why Do Singapore Students Surpass the Rest of the
World in Math and Science?</h4>
           <p>The latest results from the Trends in International Mathematics and Science Study (TIMSS)--an international assessment of 60 participating countries--have been released to prove that once again Singapore's students dominate both math and science in every tested grade level.</p>
           
           <p>This raises a familiar question: <strong>What makes Singapore
students so STEM-savvy and what can U.S. students learn
from them to improve?</strong></p>

<p>While U.S. students have shown long-term improvement since TIMSS was first administered in 1995, the results are lackluster for a country that has been tirelessly focused on improving its students' skills in math and science fields.</p>

<p>Here are four things Singapore does di??erent from the U.S. when it comes to math, and possibly four things the U.S. can keep in mind to help to raise student achievement:</p>

<h5>Foundational Learning/Deep Mastery</h5>

<p>Experts agree that part of the reason why Singapore students are so successful in math is because their curriculum teaches them a deep mastery of the subject through carefully calculated foundational learning; each grade level is a building block.</p>

<p>While American math instruction often relies on drilling and memorization of many skills
each year, Singapore math focuses on children not just learning but also truly mastering a
limited number of concepts each school year. The goal is for children to perform well
because they understand the material on a deeper level; they are not just learning it for the
test," says PBS.org.</p>

<p>This approach helps students surpass memorization to truly understand the material, also making them less likely to forget important concepts in-between grade level learning.</p>

<h5>A Culture of Growth Mindset</h5>

<p>Singapore's Ministry of Education heavily believes in "research-proven pedagogical approaches that lead to lasting learning beyond the test," says KQED News.</p>

<p>One of these pedagogical approaches is helping students obtain a growth mindset to ultimately help them persevere, especially when they are confronted with the difficult material associated with advanced math.</p>

<p>A growth mindset, as de??ned and popularized by Carol Dweck, is the idea that intelligence is not a set of fixed traits but rather is something that can be developed and improved through hard work and education.</p>

<p>Experts say students are more likely to succeed particularly in diffcult subjects like math when they ditch the feeling that they're simply just not good at it and replace it with the feeling that they can ultimately succeed if they keep trying.</p>

<p>The support of this mindset is speculated to be one reason why Singapore students are continually able to succeed.</p>

<h5>Emphasis on Visual Learning</h5>

<p>Singapore Math does something dramatically di??erent when it comes to word problems," says an administrator for Martin Elementary School in a letter to parents explaining why the school has chosen to teach Singapore math.</p>

<p>It relies on model drawing, which uses units to visually represent a word problem. Students learn to visualize what a word problem is saying so they can understand the meaning and thus how to solve the problem.</p>

<p>Word problems are often where students struggle the most when being tested on difficult math concepts, but Singapore students routinely tackle them with ease.</p>

<p>This is because instead of focusing on the concrete meaning of the words within the problems, Singapore students turn the words into pictorial models that "transforms words into recognizable pictures for young minds."</p>

<p>" ...Singaporean students are exposed to higher-level, multi - step word problems than are U.S. students, and proficiency in solving these complex problems is a key factor in why they have fared so well on international mathematics assessments," said Bill Jackson, a math teacher in Scarsdale Public Schools in an article for The Daily Riff.</p>

<h5>Mental Math as a Core Principle</h5>

<p>Singapore students are encouraged to become successful at doing math in their heads.</p>

<p>"Mental math is one of the cornerstones of Singapore Math as its emphasis is on helping students to calculate mathematically in their heads, thus developing number sense and place value," says the administration of Martin Elementary School.</p>

<p>This helps Singapore students not only get math questions right, but get them right quickly without the interference of outside tools.</p>

            </div>
          </div>
          <div class="col-xs-12 col-sm-12 col-md-4 col-lg-4">
            <iframe src="https://www.facebook.com/plugins/page.php?href=https%3A%2F%2Fwww.facebook.com%2FThe-University-of-Maths-484049115388250%2F&tabs=timeline&width=340&height=700&small_header=false&adapt_container_width=true&hide_cover=false&show_facepile=true&appId" width="340" height="700" style="border:none;overflow:hidden" scrolling="no" frameborder="0" allowTransparency="true" allow="encrypted-media"></iframe>
          </div>
        </div>
      </div>
    </div>
  </div>
</section> 


<?php }
elseif($event==12){ ?>

<section id="title-inner">
  <div id="large-header">
    <canvas id="demo-canvas"></canvas>
    <div class="container">
      <div class="text-tit">
        <div class="bb"></div>
        <span class="lefttop-icon"></span>
        <h1><span>Why Singapore's kids are so good at maths</span></h1>
        <span class="rightbotm-icon"></span> </div>
    </div>
  </div>
</section>

<!-- Page Content inner -->

<section class="about_content content-text event-single-page space-75">
  <div class="container">
    <div class="event-single">
      <div class="media_single">
        <div class="row">
          <div class="col-xs-12 col-sm-12 col-md-8 col-lg-8">
            <div class="img-holder"> <img src="<?= base_url('assets/images/event-single.jpg')?>" alt="" /> <span class="date"> 02 <em>aug</em> </span> </div>
            <div class="single-text">
              <h4 class="title">Why Singapore's kids are so good at maths</h4>
              <p>The city-state regularly tops global league tables. What's the secret of its achievement?</p>
              <p>Sie Yu Chuah smiles when asked how his parents would react to a low test score. "My parents are not that strict but they have high expectations of me," he says. "I have to do well. Excel at my studies. That's what they expect from me." The cheerful, slightly built 13-year-old is a pupil at Admiralty, a government secondary school in the northern suburbs of Singapore that opened in 2002.</p>
              
              <p>A city-state of just 5.5 million people, Singapore is routinely ranked at or near the top in global comparisons of mathematical ability and boasts one of the most admired education systems in the world. In a league table based on test scores from 76 countries published by the OECD in May last year, Singapore came first, followed by Hong Kong, South Korea, Japan and Taiwan. The rankings, based on testing 15-year-olds' abilities in maths and science, reinforced a sense that western children were slipping behind their Asian peers. The UK was in 20th place and the US 28th in the table.</p>
              
              <p>At meetings of the world's education ministers, when it is Singapore's turn to speak, "everyone listens very closely", says Andreas Schleicher, head of the OECD's education assessment programme. Governments around the world have sought to incorporate elements of the "Singapore model" into their own approach to teaching maths and science. The latest is the UK, which earlier this month announced that half of England's primary schools would adopt the style of maths teaching that is used in Singapore, with up to &pound;41m in funding over four years to train teachers and provide new textbooks. But what is it about Singapore's system that enables its
children to outperform their international peers? And how easy will it be for other countries to import its success?</p>

<p>A densely populated speck of land in Southeast Asia, Singapore is bordered by Malaysia to the north and the leviathan archipelago of Indonesia to the south. The former British trading post gained self-rule in 1959 and was briefly part of a Malaysian federation before becoming fully independent in 1965. A sense of being dwarfed by vast neighbours runs deep in the national psyche, inspiring both fear and pride. In a speech to trade union activists on May Day last year, prime minister Lee Hsien Loong told citizens: "To survive, you have to be exceptional." The alternative, he warned, was being "pushed around, shoved about, trampled upon; that's the end of Singapore and the end of us".</p>

<p>Every morning, Admiralty pupils gather for assembly beneath banners that make the same point in less rhetorical fashion. "No one owes Singapore a living," declares one of the hoardings. "We must ourselves defend Singapore," another reads.</p>

<p>For admirers of the city-state's educational model, the good news is that its world-beating school system was created in a relatively short period of time. Under British rule, education had been the preserve of the affluent. Most of the population - Chinese, Malay and Tamil migrants and their descendants - were illiterate. Singapore's post-independence government, led by its first prime minister Lee Kuan Yew, expanded the school system to cover the entire population. Attracting foreign investors and building a successful manufacturing sector was regarded as a crucial step in the state's postcolonial development. Lee, an authoritarian and perfectionist who led the country for some 30 years, believed that schools served a dual purpose: to forge a unified English-speaking nation from a multilingual population, and to supply factories with workers. For Singapore to survive and prosper, he said in 1966, "what is required is a rugged, resolute, highly trained, highly disciplined community".</p>

<p>Education is still discussed by the city-state's politicians primarily in terms of economic utility. In his speech in May 2015, Lee Hsien Loong described</p>

<h5>Mathematics in Singapore is not about knowing everything. It's about thinking like a mathematician</h5>
<p>Andreas Schleicher, head of the OECD's education assessment programme</p>

<p>a conversation with the South Korean minister for education. "We compared notes and I told him in Singapore we try to train people for the jobs they can fill. When our students graduate they find jobs straightaway. He was envious," Lee said.</p>

<p>Lee went on to note disparagingly that South Korea has more institutions teaching German literature
than Germany does: "How many German teachers do you need in Korea?" he asked, pointing out that Korean students with a degree in subjects such as German would face the same problem of youth unemployment as in many other countries.</p>

<p>Maths and science are core subjects in Singapore, taught throughout primary and secondary education. While students can choose to study humanities for A-levels, they must continue studying either maths or at least one science subject until they leave school (the reverse is also true: science students must take one subject from the humanities). From the later years of primary school onwards, children have specialist maths teachers.</p>

<p>The "Singapore method" was first developed by a team of teachers in the city-state in the 1980s, who were given the task of creating high-quality teaching materials by the ministry of education. They studied the latest behavioural science research as well as travelling to schools in other countries, including Canada and Japan, to compare the effectiveness of different teaching methods. Aiming to move away from simple rote-learning and to focus instead on teaching children how to problem solve, the textbooks the group produced were influenced by educational psychologists such as the American Jerome Bruner, who posited that people learn in three stages: by using real objects, then pictures, and then through symbols. That theory contributed to Singapore's strong emphasis on modelling mathematical problems with visual aids; using coloured blocks to represent fractions or ratios, for example.</p>

<p>The Singapore curriculum is more stripped down at primary level than in many western countries, covering fewer topics but doing so in far greater depth - a crucial factor in its effectiveness, according to the OECD's Schleicher. "When you look at England and the US, [their curriculums] are mile-wide and inch-deep," he says. "They teach a lot of things but at a shallow level. Mathematics in Singapore is not about knowing everything. It's about thinking like a mathematician."</p>

<p>It is taken for granted in the west that some children have greater ability at particular subjects than others. Not so in Singapore, where diligence is prized over talent. Tim Oates, who was in charge of a review of England's national curriculum in 2010-2013 and is now director of research at the exam board Cambridge Assessment, says this approach is finally being adopted in the English system. "It is a different approach to ability - really, a major overhaul of the way in which children are viewed," he says. "A switch from an ability-based model of individualised learning, to a model [which says that] all children are capable of anything, depending on how it is presented to them and the effort which they put into learning it.</p>

<p>Linked to this idea, the Asian approach to maths also favours teaching the class as a whole, rather than breaking the class into smaller groups of different abilities to work through exercises. The whole-class approach allows the teacher to spot weaknesses and intervene swiftly if a child needs help, rather than waiting for them to get stuck on a problem and calling for attention.</p>

<p>The classrooms at Admiralty are sparsely decorated. When I visit a class of 13-year-olds, there's a single artwork on the back wall; a paper cut-out of a cherry tree scattering blossom. At the front, where the teacher stands, is a whiteboard, a projector, a Singapore flag and a clock. I am later told that other decorations had been removed to avoid distracting or aiding students during
a round of tests.</p>

<p>The subject is English, a second language for most of the children here, who speak either Malay or Chinese at home. At the front of the class, the teacher, Wendy Chen, is showing a film of migrant workers responding to racist comments. It's a controversial subject: foreign labourers who work in construction, manufacturing and domestic service are often targets of racial prejudice in Singapore. Chen strips the language down to its constituent parts, asking the 13 - year-old students to look at the use of the pronouns "we" and "they". She hands out a newspaper cutting, again about migrant workers, and asks them to analyse it. "Underline who, what, when, where, how," she instructs briskly.</p>

<p>The atmosphere is industrious. Throughout the day, the children work quietly at their tasks with relatively little chatter. Corporal punishment is permitted as a last resort - for boys only - at Singapore schools. When the teachers need to command attention, they strike an insistent note rather than raising their voices. One teacher, as she senses her class flagging, begins to pepper her instructions with the phrase "my dears". Further absorbing discipline, many of the children join police or military cadet organisations, and can be seen dressed in uniform and standing to attention in the schoolyard after class. For the boys, who face two years' national service after graduating from high school, it's a particularly useful preparation.</p>

<p>Science is next. The children are being taught programming using a small circuit board, hooked up to an LED. Lines of code vary the light's colour. Last year, students in this class built a robotic arm. This year, the goal is to build a miniature driverless car - a palm-sized robot with wheels. "Ambitious goals - broken into small steps," says principal Toh Thiam Chye as he observes the class at work. The lights might be incorporated into the driverless car project as part of an LED messaging system, he says. The science teacher, pacing around the lab, says that the children are becoming so familiar with the computer code that some are experimenting with it. "They are tinkering with changing the display... changing the colours of the LED," she notes with approval.</p>

<p>There's a break for lunch; the children spill out from the boxy concrete building to grab plates of rice or noodles in the canteen. Like much of Singapore's architecture, the school is composed of a series of rectangles; rectangular classrooms face on to a rectangular yard. Its whitewashed walls are relieved by occasional stripes of blue or yellow paint. But unlike Singapore's office buildings, which are so deeply chilled by air conditioning that workers regularly wrap themselves in sweaters, the classrooms are open to the tropical humidity. Ceiling fans stir the air and the chatter of other children sometimes drifts through the open windows.</p>

<p>Pupils at Admiralty are gently steered away from the humanities and nudged towards science, Toh Thiam Chye says. After-hours activities such as a robotics club are intended to instil a love of scientific inquiry, as well as prepare for a more automated future. "We want to prepare them for the 21st-century workplace and we also want to meet the needs of the economy," he says.
The island has a "manpower constraint" - of its 5.5 million population, 1.6 million are foreign workers and their dependents. "What we need to do is be ahead of the curve," the principal says, referring to future demand for workers. A spokeswoman for the ministry of education later clarifies that this is not a matter of policy and that Singapore values the arts; children are encouraged to pursue their strengths, she adds. Admiralty has a strong emphasis on science, while other schools favour humanities, she says. Nevertheless, older Singaporeans I spoke to describe being pushed in the direction of science if they were deemed bright enough to pursue quantitative subjects.</p>

<p>In a maths lesson after lunch, the teacher gets pupils out of their seats as their attention begins to flag in the mounting heat. She invites volunteers to stand at the whiteboard and solve algebraic equations in front of the class. There's an atmosphere of cheerful rivalry. As one boy stumbles through an answer, then goes back and corrects it, a bumptious classmate hoots at him: "Still wrong!"</p>

<p>In the closing minutes of the class, the children are set a test. They work on tablet computers and as they answer, their scores are projected on to the screen at the front. One boy, working fast, lifts his tablet in the air with pride. He has got to the end and his tablet screen displays his results as a pie chart that's nearly all green. Hardly any wrong answers. A classmate high-fives him.</p>

<p>Singapore's success is not about money. The city-state spends about three per cent of GDP on education, compared with about six per cent in the UK and nearly eight per cent in Sweden. But the Singapore system is remarkably effective at offering teachers the freedom to improve their practice. Teachers are given time in the school day to evaluate their work, and to observe each other's lessons. A successful teacher is not pushed towards management, as is often the case elsewhere, but given opportunities to be a mentor or take a hand in designing the curriculum. Schleicher of the OECD says: "In other school systems we make the best teacher a poor administrator."</p>

<p>East Asian countries tend to favour bigger class sizes, he adds, which means teachers spend less time in front of the class each week. In Korea and Japan, secondary school teachers spend about 15 hours a week teaching, compared with nearly 20 hours in England and more than 27 hours a week in the US. This frees up more time to prepare lessons or critique the ones they've delivered.</p>

<p>Yet for all the admiration Singapore's school system earns abroad, it is frequently disparaged at home. Privately, parents confide fears that the exam-oriented system places too much strain on their children, and worry that the emphasis on academic achievement from an early age can come at the expense of a balanced upbringing. Children are often tutored after school for hours in order to pass their exams. In contrast, the education system in Finland - which is also highly rated by the OECD - emphasises social development ahead of academia in a child's early years, focusing on play rather than classroom work. Melissa Benn, the British writer and education</p>

<p>campaigner, says: "There is a tradition in European education of starting school later in life, and much more inquiry through play. I think there's a strong argument for emphasising the benefit of play." Every country has its own distinctive approach to education, Benn argues, adding: "What England is good at is a more relaxed and more independent way of thinking."</p>

<p>Within Singapore, there are also concerns that the existing system sharpens inequality, and that streaming skews the system against late developers. While the government's educational motto is that "every school is a good school", not every Singaporean parent subscribes to this belief. There is intense competition to get into the most prestigious schools, such as the Raffles Institution, set up in the 19th century by Singapore's British founder, Sir Stamford Raffles. It is one of a few state-funded but independently run elite schools on the island. All schools in Singapore charge some level of fees; about S$25 a month, or &pound;14, at neighbourhood schools, which is a modest sum for most people. But independent schools can set higher fees, as well as restrict class sizes and design their own curricula.</p>

<p>At the Raffles Institution's annual Founder's Day last year, school principal Chan Poh Meng expressed the fear that the school had become dominated by middle-class families who could coach their children most effectively through the primary school leaving exam, which determines whether pupils carry on into secondary education or are diverted on to a less challenging academic track. Like many other east Asian nations, Singapore has a thriving tuition industry. Private crammers do not dominate children's lives to the dismal extent that they do in South Korea (where the government has had to ban tuition centres from teaching after 10pm) but, for many Singaporean pupils, the formal end of the school day does not mean the end of lessons. A few years ago, a survey by the ministry of education found that more than half of primary school pupils were receiving private tuition in subjects they were already doing well in.</p>

<p>Meritocracy is an element of the glue that binds Singapore together. Alongside the promise of shared prosperity and security, the idea that the brightest can rise to the top is a component of the political bargain that the city-state has struck with its citizens, under which some political freedoms are restricted in exchange for significant material benefits. But the opportunity to ascend from humble origins to the elite of Singapore's society is becoming increasingly rare, observers say. Social mobility is diminishing in Singapore because of the rising cost of education, says Michael Barr, an associate professor in international relations at Flinders University in
Adelaide. "A few decades ago, education was a way that poor people could rise," he says. "That has become less and less so. It costs money to engage in tuition. It costs money to engage in extra-curricular activities. You have to be middle-class to have the resources to put into your child's education; a tiger mother with deep pockets."</p>

<p>Perhaps the most stinging criticism, and one that's often aired in private by concerned parents, is that Singapore's system deters creativity.</p>

<p>While Singapore is not the only country to look at Silicon Valley and wonder about its own lack of entrepreneurial spirit, parents here worry that a prescriptive education may dull their children's creative edge. An academic at a Singapore university told me that many of his students had been fashioned into "learning machines", unable to deal with a situation that did not have a binary "right or wrong" answer.</p>

<p>A Singaporean bank executive and father of three, who asked not to be named, criticised a narrow focus on achieving top grades, which he regarded as the product of hard work as much as intelligence. "It's a system that really channels you through the network as they deem fit. It's their criteria, which is grades," he says. "There's nothing else. My question is: is that a fair assessment of someone's capability? I don't know whether you associate top grades with high IQ. I don't think so."</p>

<h5>One academic at a Singapore university said many of his students had been fashioned into 'learning machines'</h5>

<p>e praised the system for developing good "technical skills" in maths and imparting facts but said there was an unhealthy emphasis on drilling children according to an approved method. In his experience, children were marked down for using their own methods to solve maths puzzles, even if the answers were correct, he said. "When they're given a set of [maths] problems... some children turn to their own logic. And the answer's right, but they're considered wrong. You're stifling someone's ability to think for themselves. You're like
robots. You can't think out of the box."</p>

<p>The perceived rigidity of Singapore's education taps into broader anxieties among the island's population. Singaporeans frequently use the Hokkien Chinese word kiasu to describe themselves. The term translates as "being afraid to lose out", and can be used to describe a boor who overloads his plate at a buffet at the expense of fellow diners, or a driver who refuses to let a fellow motorist change lanes. When applied to education, kiasu refers to parents who push their children hard from a well-founded fear that they will lose out to their peers. But it is also used as shorthand for a concern that Singaporeans lack imagination and enterprise. In a parliamentary debate this year, the Singaporean MP Kuik Shiao-Yin expressed concern that an ingrained aversion to loss was creating a generation of "grantpreneurs" who chased government grants for small businesses rather than taking risks to build innovative companies.</p>

<p>It's hard to quantify the difference in creativity between nations. It's true that two of the bestknown names in Singapore's tech start-up scene - the ride-sharing app Grab and the online entertainment company Garena - were both founded by entrepreneurs brought up abroad: Malaysia in the case of Grab, and China in the case of Garena. Then again, this is a small island.</p>

<p>Just over a decade ago, Singapore's government - conscious of the criticism that their school system is too strait-laced - sought to relax it, adopting the slogan "teach less, learn more". They wanted to spur independent thinking and encourage students to follow their passions. The syllabus was trimmed and homework reduced, and students were also given more choice over the subjects they study.</p>

<p>But Linda Lim, a Singaporean professor at the University of Michigan's Ross School of Business, says the government's attempts to loosen the school system have had little impact. "These changes are so far too limited to overcome the entrenched institutional and cultural bias of schools and parents toward exam results, which they accurately perceive to be the gateway to university admissions and highly compensated civil service and multinational jobs."</p>   

<p>A potential danger for Singapore is that advanced economies increasingly require soft skills - such as imagination or the ability to take risks - as well as hard ones. A system that was effective in an era when mass manufacturing provided employment risks being insufficient for an age when creativity and innovation bring the greatest career rewards.</p>

<p>And yet, it might prove unwise to bet against a nation that has proven nimble in adapting to past changes. For all the admiration their school system attracts, Singaporeans pay close attention to different styles of education abroad, and seek to import the best foreign ideas.</p>

<p>Toh Thiam Chye, the principal of Admiralty, recalls a visit to an alternative school in Canada where pupils were allowed to choose on a daily basis what they studied. He describes the school, gently, as a "little bit unstructured". He was concerned that the amount of time spent reaching a consensus about the day's lesson was eating into time spent actually teaching. But even in an environment so radically different from Singapore's tightly scripted classrooms, he found a useful insight. "I learnt about consultation and character development," Toh says. "Touching base with students. Enticing them to share experiences."
</p>

<h5>Elements of the Singapore method to try at home</h5>

<ul>
<li>Be a positive role model for maths. Never claim, "I was rubbish at maths," because every child can be good at maths with self-confidence and support.</li>
<li>Encourage your child to demonstrate their understanding in a variety of ways, for example by explaining their thinking out loud, drawing a picture or building a physical model.</li>
<li>Praise children for effort, explanations and perseverance in problem-solving rather than getting the answers right. Build confidence by viewing mistakes as valuable to learning.</li>
<li>Make maths relevant by turning everyday life into a mathematical conversation. For example, "How many parked cars will we pass on the way to school?"</li>
<li>Look for multiple ways to solve a problem. Harness creativity rather than insist, "You should do it this way because that's how I was taught." Discuss with your child which method they prefer and why.</li>
</ul>
<p>Tips by Kate Moore, of Maths - No Problem!, a leading provider of Singapore Maths textbooks and training in the UK</p>
            </div>
          </div>
          <div class="col-xs-12 col-sm-12 col-md-4 col-lg-4">
           <iframe src="https://www.facebook.com/plugins/page.php?href=https%3A%2F%2Fwww.facebook.com%2FThe-University-of-Maths-484049115388250%2F&tabs=timeline&width=340&height=700&small_header=false&adapt_container_width=true&hide_cover=false&show_facepile=true&appId" width="340" height="700" style="border:none;overflow:hidden" scrolling="no" frameborder="0" allowTransparency="true" allow="encrypted-media"></iframe>
          </div>
        </div>
      </div>
    </div>
  </div>
</section> 

<?php } else{}?>

<!-- Page Content End -->
<?php 
if($this->session->userdata('user_id')!='')
{
	include(APPPATH.'/views/frontend/private/footer.php');
}
else
{
	include('footer.php');
}	
?>
