
	<section class="bannerSec subBann innerPage">	 	
		<div class="">
			<div class="container">
				<div class="innerBox">
					<h1>Lost your password ?</h1>										
				</div>				
			</div>
		</div>
	</section>
	<section class="logForm">
		<div class="auth-box">
            <div class="loginform">                    
                <!-- Form -->
					<form action="<?php echo BASE_URL.'login';?>" method="post" id="signupForm">
                <div class="row">
					<div class="col-12">
						<!--<p class="error">Login ID is required.</p>
<p class="error successfully-msg">password changed successfully.</p>-->
	
<?php if (validation_errors()) : ?>
											<div class="col-md-12">
												<div class="alert alert-danger" role="alert">
													<?= validation_errors() ?>
												</div>
											</div>
											<?php endif; ?>
										<?php if ($error!=''){ ?>
											<div class="col-md-12">
												<div class="alert alert-danger" role="alert">
													<?= $error ?>
												</div>
											</div>
										<?php } ?>
						<div class="input-group mb-3">
							
							<input class="form-control form-control-lg" type="text" name="emailid" placeholder="Enter login ID" />
							<p>You will receive a temporary password on your registered email.</p>
							<label>Email</label>
                        </div>
                 
					
                        <div class="form-group text-center">
                            <div class="col-xs-12 p-b-20">
                                <button class="btn btn-block btn-lg btnBox btn-Color" type="submit">Reset Password</button>
                            </div>
                        </div>
                    </div>
                </div>
				</form>
            </div>                
        </div>
	</section>	
