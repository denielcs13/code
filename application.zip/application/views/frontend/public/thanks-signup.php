<?php 
if($this->session->userdata('user_id')!='')
{

	//include(APPPATH.'/views/frontend/private/header.php');
    include('header.php');
	
}
else
{
	include('header.php');
}	
?>

<section class="bannerSec subBann innerPage">	 	
		<div class="">
			<div class="container">
				<div class="innerBox">
					<h1>Thanks</h1>										
				</div>				
			</div>
		</div>
	</section>
	<section class="logForm">
		<div class="auth-box">
            <div class="loginform">                    
                <!-- Form -->
                <div class="row">
					<div class="col-12">
						<div class="text-center">
    <h5>Thank you for your Registration.</h5>
	<!-- 04-27-19 p>Login Details has been sent to your email id. Please check your Inbox.</p-->
	<!--p>Note: These e-mails sometimes land in your spam folder. </p-->
	<p>Please login with your email and password.</p>
    </div>
                    </div>
                </div>
            </div>                
        </div>
	</section>	

 <!-- Page Content End -->
<?php 
if($this->session->userdata('user_id')!='')
{
	//include(APPPATH.'/views/frontend/private/footer.php');
    include('footer.php');
}
else
{
	include('footer.php');
}	
?>
 <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>

<script type="text/javascript">
jQuery(document).ready(function(){

    jQuery('#reg_year').change(function(){
		
      var yearid=$('#reg_year').val();
            jQuery.ajax({
                type : 'POST',
                url : '<?php echo BASE_URL.'ajaxcall/yearsprice';?>',
                data : {yearid:yearid}
				,	
        success: function(result){
           // alert(result);
           jQuery( "#priceshow" ).html('Price $'+result);
		    jQuery("#yearprice").val(result);
        }


    });
    });


    
});



		

</script>
