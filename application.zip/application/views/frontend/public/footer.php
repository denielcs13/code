<footer class="footer">
		<div class="container">
			<div class="row">
				<div class="col-lg-3 col-md-3 col-sm-12 fBox">
					<h3>About</h3>
					<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut sodales gravida ante, id semper nisl mollis quis. Proin quam mauris, rhoncus vel dignissim sed, rhoncus ac elit.</p>
					<div class="socials_icon"> 
						<a href="#"><i class="fa fa-facebook"></i></a>
						<a href="#"><i class="fa fa-twitter"></i></a>
						<a href="#"><i class="fa fa-instagram"></i></a>
					</div>
				</div>
				<div class="col-lg-3 col-md-3 col-sm-12 sBox">
					<h3>Contact</h3>
					<ul>
						<li><span>Lorem, ipsum dolor, sit amet</span></li>
						<li>Tel.: 123 456 7890</li>
					</ul>
				</div>
				<div class="col-lg-3 col-md-3 col-sm-12 tBox">
					<h3>Pages</h3>
					<ul>
						
						<li><a href="#">Home</a></li>						
						<li><a href="#">Courses</a></li>
						<li><a href="#">Blog</a></li>
						<li><a href="#">Shortcodes</a></li>
						<li><a href="#">Membership Account</a></li>
						<li><a href="#">Typography</a></li>
					</ul>
				</div>
				<div class="col-lg-3 col-md-3 col-sm-12 fBox">
					<h3>About</h3>
					<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut sodales gravida ante, id semper nisl mollis quis. Proin quam mauris, rhoncus vel dignissim sed, rhoncus ac elit.</p>
					<div class="socials_icon"> 
						<a href="#"><i class="fa fa-facebook"></i></a>
						<a href="#"><i class="fa fa-twitter"></i></a>
						<a href="#"><i class="fa fa-instagram"></i></a>						
					</div>
				</div>
			</div>
		</div>
	</footer>	

	<script src="<?= base_url('assets/js/jquery.min.js')?>"></script>
	<script src="<?= base_url('assets/js/owl.carousel.min.js')?>"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js"></script>
	<script src="<?= base_url('assets/js/bootstrap.popper.min.js')?>"></script>
	<script src="<?= base_url('assets/js/bootstrap.min.js')?>"></script>
	<script src="<?= base_url('assets/js/sticky.js')?>"></script>	
	<script src="<?= base_url('assets/js/inputjs.min.js')?>"></script>
	<script src="<?= base_url('assets/js/timecount.js')?>"></script>
	<script>
		$(document).ready(function() {
			$("#owl-demo").owlCarousel({		 
				navigation :false,
				singleItem:true,
				autoplay:true,
				autoplayTimeout:5000,
				items : 1,
				mouseDrag :false,
				touchDrag :false,
				pagination :false,			 
				animateIn: 'fadeIn',
				animateOut: 'fadeOut'  
			});
		});
	</script>	
	<script type="text/javascript">	
		jQuery(document).ready(function(){
			jQuery("input[name='etype']:radio")
			.change(function() {
			  jQuery("#students").toggle($(this).val() == "pwov");
			  jQuery("#parents").toggle($(this).val() == "pwv");
			  jQuery("#institute").toggle($(this).val() == "pwvi");
			});	
		});
	</script>
	<script type="text/javascript">
		var selector = '.md a';
		$(selector).on('click', function(){
			$(selector).removeClass('showBtn');
			$(this).addClass('showBtn');
		});
	</script>
	
	<script>
		$.widget("tj.olympicspicker", $.ui.spinner, {
			options: {
				min: 1,
				//max: 2012,
				//step: 4
			}
		});
		$(".ew input").olympicspicker();
	</script>
	<script>
		$('.cd100').countdown100({
			endtimeHours: 1,
			endtimeMinutes: 0,
			endtimeSeconds: 0,
			timeZone: ""			
		});
	</script>	
	
</body>
</html>