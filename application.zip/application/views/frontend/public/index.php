<?php 
if($this->session->userdata('user_id')!='')
{

	//include(APPPATH.'/views/frontend/private/header.php');
    include('header.php');
	
}
else
{
	include('header.php');
}	
?>

<section class="bannerSec">		
		<div class="">
			<div class="container">
				<div class="innerBox">
					<h1>Helping Kids Thrive, Not Just Survive.</h1>
					<p>We're an international education institution with the  mission to make learning easy and fun!</p>
					<span class="boxBtn">
						<a href="#" class="btnBox">Learner</a>
						<a href="#" class="btnBox">Teacher</a>
						<a href="#" class="btnBox">Parent</a>
					</span>
				</div>
				<div class="bannRightBox">
					<div class="riBoxBn">
						<img src="<?= base_url('assets/img/banner1.png')?>">
					</div>
				</div>
			</div>
		</div>
	</section>
	<section class="eduPlex">			
		<div class="container">		
			<h2>Why EduPlex Pro</h2>
			<div class="row">
				<div class="col-xs-12 col-sm-12 col-md-4 col-lg-4 tm">
					<div class="content_halping math-box">
						<img src="<?= base_url('assets/img/book.svg')?>" alt="">
						<h4>Quality content </h4>
						<p>Curated for today's tech-savy generation and thoroughly assessed to make learning stress free and effective</p>
					</div>
				</div>
				<div class="col-xs-12 col-sm-12 col-md-4 col-lg-4 tm">
					<div class="content_halping math-box">
						<img src="<?= base_url('assets/img/medal.svg')?>" alt="">
						<h4>Customized learning </h4>
						<p>Well-designed curriculum enables students to learn on their own pace, teachers to customize curriculum, and parents to monitor the progress</p>						 
					</div>					 
				</div>
				<div class="col-xs-12 col-sm-12 col-md-4 col-lg-4 tm"> 
					<div class="content_halping math-box">
						<img src="<?= base_url('assets/img/trophy.svg')?>" alt="">
						<h4>Interactive learning</h4>
						<p>Built to ignite the curiosity, this unique system strengthen the core concepts and develops critical thinking abilities</p>					 
					</div>					 
				</div>
			</div>	
		</div>		
	</section>
	<section class="teachersBox">
		<div class="container">			
				
			<div class="row">
			<div class="col-xs-12 col-sm-12 col-md-6 col-lg-6">
					<div class="teachRight">
						<h6>Teachers</h6>
						<h2>Design customized content based on the needs of your students.</h2>
						<p>Online courses open the opportunity for learning to almost anyone, regardless of their scheduling commitments.</p>
						<span class="boxBtn"><a href="#" class="btnBox">Teachers, get started for free</a></span>
					</div>
				</div>
			</div>
		</div>
	</section>
	<section class="teachersBo td">
		<div class="container">			
				
			<div class="row">
			<div class="col-xs-12 col-sm-12 col-md-6 col-lg-6">
					
				</div>
			<div class="col-xs-12 col-sm-12 col-md-6 col-lg-6">
					<div class="teachRight">
						<h6>Learners</h6>
						<h2>What we learn with pleasure we never forget.</h2>
						<p>Online courses open the opportunity for learning to almost anyone, regardless of their scheduling commitments.</p>
						<span class="boxBtn"><a href="#" class="btnBox">Learners, get started for free</a></span>
					</div>
				</div>
			</div>
		</div>
	</section>
	<section class="teachersBo td mpa">
		<div class="container">			
				
			<div class="row">
			<div class="col-xs-12 col-sm-12 col-md-6 col-lg-6">
					<div class="teachRight">
						<h6>Parents</h6>
						<h2>Let your child learn more, grow more and do more.</h2>
						<p>Online courses open the opportunity for learning to almost anyone, regardless of their scheduling commitments.</p>
						<span class="boxBtn"><a href="#" class="btnBox">Parents, get started for free</a></span>
					</div>
				</div>
			</div>
		</div>
	</section>
	
	<section class="becomBox">
		<div class="container">
			<div class="row">
				<div class="col-xs-12 col-sm-12 col-md-6 col-lg-6 btBox">
					<div class="beInner">
						<img src="<?= base_url('assets/img/beco1.png')?>">
						<div class="becomText">
							<h3>Become an Instructor</h3>
							<p>Teach what you love. Masterstudy gives you the tools to create a course.</p>
							<a href="#" class="btnBox"> Start teaching </a>
						</div>
					</div>
				</div>
				<div class="col-xs-12 col-sm-12 col-md-6 col-lg-6">
					<div class="beInner">
						<img src="<?= base_url('assets/img/beco2.png')?>">
						<div class="becomText">
							<h3>Setup For Business</h3>
							<p>Get unlimited access to 2,500 of Udemy’s top courses for your team.</p>
							<a href="#" class="btnBox"> Doing Business </a>
						</div>	
					</div>
				</div>
			</div>
		</div>
	</section>
	
	<section class="testBox">
			<div id="owl-demo" class="owl-carousel owl-theme">		 
					<div class="item">
						<div class="rew" style="background-image:url(<?= base_url('assets/img/slider1.jpg')?>)">
							<!-- <img src="img/slider1.jpg"> -->
							<div class="sliderText">
								<h3>Come as you are</h3>
								<p>The response to your MasterStudy has been really overwhelming! Those who participated in the workshop are spreading the word here on campus and the “buzz” is on. The VP of Instruction wants you to come back! Her goal is to have more faculty trained. She also wants to attend a workshop herself. Our President told me Masterstudy needs to be the cornerstone of our success program.”</p>
								<h5>Tim Sab</h5>
								<h6>General Developer, Stylemix Themes</h6>
							</div>
						</div>
					</div>
					<div class="item">
						<div class="rew" style="background-image:url(<?= base_url('assets/img/slider2.jpg')?>)">							
							<div class="sliderText">
								<h3>Investing for Your Future</h3>
								<p>The response to your MasterStudy has been really overwhelming! Those who participated in the workshop are spreading the word here on campus and the “buzz” is on. The VP of Instruction wants you to come back! Her goal is to have more faculty trained. She also wants to attend a workshop herself. Our President told me Masterstudy needs to be the cornerstone of our success program.”</p>
								<h5>Tim Sab</h5>
								<h6>General Developer, Stylemix Themes</h6>
							</div>
						</div>
					</div>
					<div class="item">
						<div class="rew" style="background-image:url(<?= base_url('assets/img/slider3.jpg')?>)">							
							<div class="sliderText">
								<h3>Come as you are</h3>
								<p>The response to your MasterStudy has been really overwhelming! Those who participated in the workshop are spreading the word here on campus and the “buzz” is on. The VP of Instruction wants you to come back! Her goal is to have more faculty trained. She also wants to attend a workshop herself. Our President told me Masterstudy needs to be the cornerstone of our success program.”</p>
								<h5>Tim Sab</h5>
								<h6>General Developer, Stylemix Themes</h6>
							</div>
						</div>
					</div>
				</div>
	</section>
   
   
 <!-- Page Content End -->
 
 
 
 
 
<?php 
if($this->session->userdata('user_id')!='')
{
	//include(APPPATH.'/views/frontend/private/footer.php');
    include('footer.php');
}
else
{
	include('footer.php');
}	
?>
