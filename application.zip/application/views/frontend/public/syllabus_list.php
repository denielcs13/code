	<section class="bannerSec subBann innerPage">		
		<div class="">
			<div class="container">
				<div class="innerBox">
					<h1><?php echo $year_dtl->class_name;?></h1>										
				</div>
			</div>
		</div>
	</section>
	
	<section class="box">
		<div class="container">
          	
					<div class="inset-1">
						<div class="card-group-custom card-group-timeline">
						<?php
						for($p=0;$p<=13;$p++)
						{
							
							if($p==0)
							{
								$classsug='kindergarten';
								$classs_name='Kg';
								$cssclass='kind';
								$activecss='showBtn';
							}
							else
							{
								$classsug='year-'.$p;
								$classs_name=$p.' Year';
								$cssclass='year'.$p;
								//$activecss='showBtn';
						
							}
							
							if($this->uri->segment(2)==$classsug)
							{
								$activecss='showBtn';
							}
							else
							{
								$activecss='';
							}
							?>
							<article class="card card-custom card-timeline md">
								<div class="card-header" role="tab">
									<div class="card-title">
										<a class="card-link <?=$cssclass?> <?=$activecss?>"  href="<?=base_url($this->uri->segment(1)."/".$classsug)?>"><?=$classs_name;?>
											<div class="card-arrow"></div>
										</a>
									</div>
								</div>						  
							</article>
							
							<?php
						}
						?>
							
							
						
                      </div>
                    </div>
			
			
			<!-- Bootstrap Tabs -->		
            <div class="tab-content">
				<div id="kg" class="tab-pane active">
               <div class="row">
			   <?php
			         $i=0;

                $x='A';

                foreach($SylList as $SylListDetail)
				{
					?>
                    <div class="col-xs-12 col-sm-12 col-md-4 col-lg-4">
                     <div class="box-syllabus">
                        <h3><?=$x.' '.$SylListDetail->skill_name?></h3>
                        <div class="text-content">
							<ul>
								<?php 

                                   $parent_skill=$SylListDetail->skill_id;

                                   $subskill=$this->main_model->get_detail($obj,'master_skill',array('skill_class'=>$year_id,'skill_parent'=>$parent_skill),$insgle=null,'skill_order','asc');

                                   $j=1;

                                   foreach($subskill as $subskilldatail){

                                   $class=$this->uri->segment(1);

                               ?>

                               <?php 

                               if($this->session->userdata('user_id')!=""){

                               ?>

                              <li><a href="<?=base_url($class.'/'.$year.'/'.$subskilldatail->skill_slug)?>"><strong><?=$x.'.'.$j?></strong> <?=$subskilldatail->skill_name?></a></li>

                              <?php 

							   }
							   else
							   {

                              ?>

                              <!--<li><strong><?=$x.'.'.$j?></strong> <?=$subskilldatail->skill_name?></li>-->
							   <li><a href="<?=base_url($class.'/'.$year.'/'.$subskilldatail->skill_slug)?>"><strong><?=$x.'.'.$j?></strong> <?=$subskilldatail->skill_name?></a></li>

                              <?php 

							   }
								   }

                              ?>

                            </ul>
                        </div>
                     </div>
					</div>
                  
                <?php
				 $i++;

                  $x++;
				}
?>				
                  
                  
                                 </div>
								 </div>
            </div>
         </div>
	</section>

	
