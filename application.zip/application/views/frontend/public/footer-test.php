 
<footer>
<div class="container">
<div class="row">
<div class="col-xs-12 col-sm-12 col-md-12 col-lg-7">
<div class="left_bar">
<h4>TheUniversity Web.</h4>
<p>We are an international education institution that specialized in teaching English for children from kindergarten to Year 13. We believe all children need a proper balance of Learn, Explore and Play during a child development process.
A child needs maths to help them to achieve better quality life.</p>
<p>
<div class="counter">
 Questions answered <h3><?php //echo  get_counter();?></h3>
</div>
</p>
<div class="row space_top_90 color_text space_bottom_23 botttom_link">

<div class="col-xs-12 col-sm-7 col-md-8 col-lg-8">
<div class="foot_cont">
<h5>Get in Touch</h5>
<ul>
<li><i class="fa fa-home" aria-hidden="true"></i> TheUniversity Web.</li>
<li><i class="fa fa-phone-square" aria-hidden="true"></i><a href="tel:0123456789">012 345 6789</a></li>
<li><i class="fa fa-envelope-square" aria-hidden="true"></i><a href="mailto:ask@theuniversityofmaths.com">ask@theuniversityofenglish.com</a></li>
</ul>
</div>
</div>

<div class="col-xs-12 col-sm-5 col-md-4 col-lg-4">
<h5>Company</h5>
<ul>
<li><a href="<?= base_url('contact-us');?>">Contact Us</a></li>
</ul>

</div>


</div>

</div>
</div>

<div class="col-xs-12 col-sm-12 col-md-12 col-lg-5">
<div class="rightbar">
<div class="row">
<div class="col-xs-12 col-sm-5 col-md-5 col-lg-6">
<h5>Resources</h5>

<ul>
<li><a href="<?= base_url('help-center');?>">Help Center</a></li>
<li><a href="<?= base_url('faqs');?>">FAQ's</a></li>
<li><a href="<?= base_url('term-conditions');?>">Term & Conditions</a></li>
<li><a href="<?= base_url('privacy-policy');?>">Privacy Policy</a></li>
<li><a href="<?= base_url('disclaimer');?>">Disclaimer</a></li>
<li><a href="<?= base_url('testimonials');?>">Testimonials</a></li>
</ul>

</div>


<div class="col-xs-12 col-sm-6 col-md-6 col-lg-6">
<h5>Follow Us</h5>
<ul class="social">
<li><a href="https://www.facebook.com/" class="fb" target="_blank"><i class="fa fa-facebook" aria-hidden="true"></i></a></li>
<li><a href="https://twitter.com/" class="tw" target="_blank"><i class="fa fa-twitter" aria-hidden="true"></i></a></li>
<li><a href="https://plus.google.com/discover" class="gplus" target="_blank"><i class="fa fa-google-plus" aria-hidden="true"></i></a></li>
<li><a href="https://www.youtube.com/" class="yt" target="_blank"><i class="fa fa-youtube" aria-hidden="true"></i></a></li>

<li><a href="https://www.instagram.com/accounts/login/?hl=en" class="insta" target="_blank"><i class="fa fa-instagram" aria-hidden="true"></i></a></li>
<li><a href="https://www.linkedin.com/uas/login" class="link" target="_blank"><i class="fa fa-linkedin" aria-hidden="true"></i></a></li>
<li><a href="https://www.pinterest.com/" class="pin" target="_blank"><i class="fa fa-pinterest" aria-hidden="true"></i></a></li>
</ul>

</div>

</div>


</div>

</div>

</div>

<div class="copy_right">
<p class="text-left">© 2019 - <?php echo date('Y');?> TheUniversity Web. All Rights Reserved.</p>
</div>
</div>

<div class="foot_bottom">
<div class="container">
<div class="row">
<div class="col-sm-3 col-md-3 col-lg-3 col-xs-3 col">
<p><a href="<?= base_url('help-center');?>"><span class="icon_btm"><i class="fa fa-phone" aria-hidden="true"></i> </span><small>Help and Support</small></a></p>
</div>
<div class="col-sm-3 col-md-3 col-lg-3 col-xs-3 col">
<p><a href="<?= base_url('contact-us');?>"><span class="icon_btm"><i class="fa fa-mobile" aria-hidden="true"></i> </span><small>Request and call back</small></a></p>
</div>
<div class="col-sm-3 col-md-3 col-lg-3 col-xs-3 col">
<!-- <p><a href="<?= base_url('our-centers');?>"><span class="icon_btm"><i class="fa fa-life-ring" aria-hidden="true"></i> </span><small>Our Centers</small></a> --></p>
</div>

<div class="col-sm-3 col-md-3 col-lg-3 col-xs-3 col">
<a href="#" class="live-chat_btn float-right"><span class="icon_live"><i class="fa fa-comments" aria-hidden="true"></i></span><small>Live Chat</small></a>
</div>
</div>
</div>
</div>

</footer>
 <script>
$('document').ready(function(){
$('.boxText').children('input').attr('maxlength','1');
})
</script>
<a id="back2Top" title="Back to top" href="#">&#10148;</a>
 
<!-- Bootstrap core JavaScript --> 
<script src="<?= base_url('assets/js/jquery.min.js')?>"></script> 
<script src="<?= base_url('assets/js/bootstrap.bundle.min.js')?>"></script> 
<script src="<?= base_url('assets/js/main.js')?>"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1/jquery.min.js"></script>
<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
<script src="<?= base_url('assets/js/jquery.slicknav.js')?>"></script>
<script src="<?= base_url('assets/js/demo-2.js')?>"></script>

<script src="<?= base_url('assets/js/owl.carousel.js')?>"></script>
<script src="<?= base_url('assets/js/owl.carousel.min.js')?>"></script> 
<?php 
if($this->session->userdata('user_id')):

?>
<script>
var stinterval;
stinterval=setInterval(unsetsession,5000);
function unsetsession(){
    var url= '<?=base_url('logout1')?>';
    $.get(url,function(data){
       if(data)
       {
        clearInterval(stinterval);
        window.location.reload();
       } 
    });
}


</script>
<?php 
endif;
?>

<script>
            $(document).ready(function() {
              var owl = $('.owl-carousel');
              owl.owlCarousel({
				items: 1,
                margin: 10,
                nav: true,
                loop: true,
				 autoplay: true,
                responsive: {
                  0: {
                    items: 1
                  },
                  600: {
                    items: 2
                  },
                  1000: {
                    items: 3
                  }
                }
              })
            })
          </script> 
  <script type="text/javascript">
    $("#msg").hide().slideDown().delay(3000).fadeOut();
</script>
      
          
</body>
</html>