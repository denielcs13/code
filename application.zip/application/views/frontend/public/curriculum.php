<?php 
if($this->session->userdata('user_id')!='')
{

	include(APPPATH.'/views/frontend/private/header.php');
	
}
else
{
	include('header.php');
}	
?>

<section id="title-inner" style="background-image:url(<?= base_url('assets/images/curriculum.jpg')?>);">
  <div id="large-header">
    <canvas id="demo-canvas"></canvas>
    <div class="container">
      <div class="text-tit">
        <div class="bb"></div>
        <span class="lefttop-icon"></span>
        <h1> <span>Curriculum</span> </h1>
        <span class="rightbotm-icon"></span> </div>
    </div>
  </div>
</section>

<!-- Page Content inner -->
<section class="space-75 about_content curriculum-page content-text">
  <div class="container">
    <h2>Why we follow the Cambridge Mathematics Framework ?</h2>
    <p>The Cambridge Mathematics Framework is designed to be a common frame of reference for learning mathematics. Its purpose is to inform the work of the professional communities designing and enacting mathematics curricula.</p>
    <strong>The Cambridge Mathematics Framework will:</strong>
    <ul>
      <li>be a map of the full domain of mathematical knowledge from pre-school to the end of the upper secondary phase of education and training arrangements</li>
      <li>be loosely age-related and based on progressions in organising concepts and principles</li>
      <li>be the basis for different curriculum pathways which will flesh out a more detailed hierarchy</li>
      <li>be a basis for deriving standards</li>
      <li>be illustrated by indicative content and exemplar performances</li>
      <li>be evidenced both from the study of a range of mathematics curricula and mathematics assessments, and from a theoretical perspective of conceptual progression</li>
      <li>allow for the description of skills and dispositions necessary for effective use of mathematics.</li>
    </ul>
    <strong>Reports:-</strong>
    <ul class="reports">
      <li><a href="assets/pdf/cambridge_mathematics_framework.pdf" target="_blank" class="download-btn">Cambridge Mathematics Framework Report</a></li>
      <li><a href="assets/pdf/cambridge_primary_maths_curriculum_outline.pdf" target="_blank" class="download-btn">Cambridge Primary Maths Curriculum Outline</a></li>
      <li><a href="assets/pdf/cambridge_lower_secondary_maths_curriculum_outline.pdf" target="_blank" class="download-btn">Cambridge Lower Secondary Maths Curriculum Outline</a></li>
      <li><a href="assets/pdf/cambridge_international_curriculum.pdf" target="_blank" class="download-btn">Cambridge International Curriculum</a></li>
    </ul>
    <h3>Why we follow the Singapore and Hong Kong Mathematics Teaching Method ?</h3>
    <p>Singapore and Hong Kong Mathematics Teaching Method supports young learners with stimulating and engaging content that makes maths fun, while ensuring that every learner has a firm understanding of new concepts, and is progressing to their full potential.</p>
    <p>Our teaching adopts a Singaporean and Hong Kong approach to mathematics, and offers activities that are carefully scaffolded to provide a solid foundation for new concepts before introducing more challenging activities that will develop thinking skills.</p>
    
    <img src="<?= base_url('assets/images/pisa-average.jpg')?>" alt="" /> 
    <strong>Reports:-</strong>
    <ul class="reports">
      <li><a href="assets/pdf/PISA_2015_results.pdf" target="_blank" class="download-btn">PISA 2015 Results</a></li> 
    </ul>
  </div>
</section>

<!-- Page Content End -->
<?php 
if($this->session->userdata('user_id')!='')
{
	include(APPPATH.'/views/frontend/private/footer.php');
}
else
{
	include('footer.php');
}	
?>
