	
	<section class="bannerSec subBann innerPage">		
		<div class="">
			<div class="container">
				<div class="innerBox">
					<h1>Add Syllabus Skills</h1>										
				</div>
			</div>
		</div>
	</section>
	
	<section class="addSkillbox">
		<div class="container">
		<?php

        if($this->session->flashdata('msg'))
        {?>
            <div id="msg" style="border: 1px solid;height: 34px;box-shadow: aquamarine;box-shadow: 0px 0px 0px 1px black;">
            <?PHP
            echo "<span> ".$this->session->flashdata('msg')."</span>";
       
          ?></div> <?PHP }?>
		  <form  method="post" action="">   <input type="hidden" name="sid" value="<?php echo $sylb_info->sid;?>" />   <input type="hidden" name="class_type" value="<?php echo $sylb_info->subject;?>" />   <input type="hidden" name="year_id" value="<?php echo $sylb_info->year_id;?>" />   <input type="hidden" name="user_id" value="<?php echo $sylb_info->user_id;?>" /> 
          	<div class="mainSkills">
				<div class="col-lg-12 col-md-12 col-sm-12">
					<div class="form-group row">
						<h5>You are going to skill in <b><?php echo $sylb_info->syllb_name;?></b></h5>
						<label class="col-sm-12 text-left control-label col-form-label">Class Name*</label>
						<div class="col-sm-12">
							<select class="form-control custom-select" name="class_name" id="class_role" onchange="ajaxskill(this.value);">
								<option value="">Select</option>
								<?php  
                    $i = 1;
                    if($year_dtl){
                    foreach($year_dtl as $year_dt){
                      ?>
                      <option value="<?=$year_dt->class_id;?>"><?=$year_dt->class_name;?></option>
                      <?php $i++;}}else{?>                      
                       
                        <option value="">No data find</option>                  
                      
                    <?php } ?>							
							</select>
                        <span class="danger-error"><?=form_error('class_name')?></span>							
						</div>
					</div>
				</div><!--row end-->
			
			<div class="inset-1" id="inset1" style="display:none">
				<div class="card-group-custom card-group-timeline">
					<article class="card card-custom card-timeline md">
						<div class="card-header" role="tab">
							<div class="card-title">
								<a class="card-link kind showBtn">Kg
									<div class="card-arrow"></div>
								</a>
							</div>
						</div>						  
					</article>
					<article class="card card-custom card-timeline md">
						<div class="card-header" role="tab">
							<div class="card-title">
								<a class="card-link year1">1 Year
									<div class="card-arrow"></div>
								</a>
							</div>
						</div>						  
					</article>
					<article class="card card-custom card-timeline md">
						<div class="card-header" role="tab">
							<div class="card-title">
								<a class="card-link year2">2 Year
									<div class="card-arrow"></div>
								</a>
							</div>
						</div>						  
					</article>
					<article class="card card-custom card-timeline md">
						<div class="card-header" role="tab">
							<div class="card-title">
								<a class="card-link year3">3 Year
									<div class="card-arrow"></div>
								</a>
							</div>
						</div>						  
					</article>
					<article class="card card-custom card-timeline md">
						<div class="card-header" role="tab">
							<div class="card-title">
								<a class="card-link year4">4 Year
									<div class="card-arrow"></div>
								</a>
							</div>
						</div>						  
					</article>
					<article class="card card-custom card-timeline md">
						<div class="card-header" role="tab">
							<div class="card-title">
								<a class="card-link year5">5 Year
									<div class="card-arrow"></div>
								</a>
							</div>
						</div>						  
					</article>
					<article class="card card-custom card-timeline md">
						<div class="card-header" role="tab">
							<div class="card-title">
								<a class="card-link year6">6 Year
									<div class="card-arrow"></div>
								</a>
							</div>
						</div>						  
					</article>
					<article class="card card-custom card-timeline md">
						<div class="card-header" role="tab">
							<div class="card-title">
								<a class="card-link year7">7 Year
									<div class="card-arrow"></div>
								</a>
							</div>
						</div>						  
					</article>
					<article class="card card-custom card-timeline md">
						<div class="card-header" role="tab">
							<div class="card-title">
								<a class="card-link year8">8 Year
									<div class="card-arrow"></div>
								</a>
							</div>
						</div>						  
					</article>
					<article class="card card-custom card-timeline md">
						<div class="card-header" role="tab">
							<div class="card-title">
								<a class="card-link year9">9 Year
									<div class="card-arrow"></div>
								</a>
							</div>
						</div>						  
					</article>
					<article class="card card-custom card-timeline md">
						<div class="card-header" role="tab">
							<div class="card-title">
								<a class="card-link year10">10 Year
									<div class="card-arrow"></div>
								</a>
							</div>
						</div>						  
					</article>
					<article class="card card-custom card-timeline md">
						<div class="card-header" role="tab">
							<div class="card-title">
								<a class="card-link year11">11 Year
									<div class="card-arrow"></div>
								</a>
							</div>
						</div>						  
					</article>
					<article class="card card-custom card-timeline md">
						<div class="card-header" role="tab">
							<div class="card-title">
								<a class="card-link year12">12 Year
									<div class="card-arrow"></div>
								</a>
							</div>
						</div>						  
					</article>
					<article class="card card-custom card-timeline md">
						<div class="card-header" role="tab">
							<div class="card-title">
								<a class="card-link year13">13 Year
									<div class="card-arrow"></div>
								</a>
							</div>
						</div>						  
					</article>
				</div>
            </div>		
			
			<!-- Bootstrap Tabs -->		
            <div class="tab-content" id="allskill" style="display:none">
			
            </div>
			<div class="col text-right bottBtn">
				<button type="submit" name="submit" class="btnBox btForm">Add</button>
			</div>
		</div>
		</form>
		</div>
	</section>
	<script type="text/javascript">
function ajaxskill(year_id)
{   	

    if (year_id.length === 0)
    {
        $('#allskill').hide();
		//$('.tab-content').hide();
		
		
    }
    else
    {

        var post_data = {			'obj': 'main',	
            'sid': <?php echo $this->uri->segment(2);?>,
            'year_id':year_id
            };

        $.ajax({
            type: "POST",
            url: "<?php echo site_url('ajaxcall/get_allskill'); ?>",
            data: post_data,
            success: function (data) {
                // return success
                if (data.length > 0) {
                    $('#allskill').html(data).show();
					$('#inset1').show();
                }
            }
         });
		 

     }
 }	
</script>
