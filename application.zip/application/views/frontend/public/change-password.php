	
	<section class="bannerSec subBann innerPage">		
		<div class="">
			<div class="container">
				<div class="innerBox">
					<h1>Change Password</h1>										
				</div>				
			</div>
		</div>
	</section>
		 
	<section class="sinUpBox">
		<div class="container">
		   <?php

        if($this->session->flashdata('msg'))
        {?>
	      <div class="row">
								<div class="col-md-12">
									<div class="alert" role="alert">
									<?php echo $this->session->flashdata('msg');?>
									</div>
								</div>
			</div>
             <?PHP }?>
			<div class="row">
				<!--Left Box-->
				<div class="col-lg-12">
					<!--Form Box-->
					<div id="students" class="sibord"  style="display:block;">
					<form  method="post" action="">
						<div class="row">
							<div class="col-lg-4 col-md-4 col-sm-12">
								<div class="form-group row">
									<label class="col-sm-12 text-left control-label col-form-label">Old Password</label>
									<div class="col-sm-12">
										<input type="password" name="old_password" id="old_password" class="form-control" placeholder="Please Enter Old Password" value="<?=  set_value('old_password'); ?>"/>
										
										<span class="danger-error"><?=form_error('old_password')?></span>                     						   
									</div>
								</div>
							</div>						
						
							<div class="col-lg-4 col-md-4 col-sm-12">
								<div class="form-group row">
									<label class="col-sm-12 text-left control-label col-form-label">New Password</label>
									<div class="col-sm-12">
										<input type="password" name="new_password" id="new_password" class="form-control" placeholder="Please Enter New Password" value="<?=set_value('new_password'); ?>"/>
										
										<span class="danger-error"><?=form_error('new_password')?></span>                     						   
									</div>
								</div>
							</div>
							<div class="col-lg-4 col-md-4 col-sm-12">
								<div class="form-group row">
									<label class="col-sm-12 text-left control-label col-form-label">Confirm Password</label>
									<div class="col-sm-12">
										<input type="password" name="conf_password" id="conf_password" class="form-control" placeholder="Please Enter Confirm Password" value="<?= set_value('conf_password'); ?>"/>
										
										<span class="danger-error"><?=form_error('conf_password')?></span>                     						   
									</div>
								</div>
							</div>
							
							<div class="col-lg-12 col-md-12 col-sm-12 text-right">
								<button type="submit" name="submit" class="btnBox btForm">Save</button>
							</div>
						</div><!--row end-->
						</form>
					</div>				
			</div><!--row end-->
		</div>
	</section>
