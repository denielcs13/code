<?php 
if($this->session->userdata('user_id')!='')
{

	include(APPPATH.'/views/frontend/private/header.php');
	
}
else
{
	include('header.php');
}	
?>

<!-- Page Content inner -->
<div class="login-page signup-page">
  <div class="container">
    <div class="row">
      <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 space-75">
        <div class="row res-space-0">
          <div class="col-md-2"></div>
          <div class="col-xs-12 col-sm-12 col-md-12 col-lg-8 shadow-box">
            <div class="bg-form">
              <div class="row">
                <div class="col-xs-12 col-md-6 p-left15 mobile-none">
                  <div class="login-bg">
                    <div class="text-content">
                      <h2>Hello<br />
                        World.</h2>
                      <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the</p>
                    </div>
                  </div>
                </div>
                <div class="col-xs-12 col-md-6">
                  <div class="form-section">
                    <h1>Membership</h1>
                    <form class="cmxform" id="signupForm" method="post" action="">
                      <div class="row">
                        <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
						<?php if (validation_errors()) : ?>
										
												<div class="alert alert-danger" role="alert">
													<?= validation_errors() ?>
												</div>
										
											<?php endif; ?>
                          <p class="error">Email is required.</p>
                          <div class="input-field">
                            <input type="text" name="reg_email" id="reg_email" value="" placeholder="Email" />
                          </div>
                          <div class="row">
                            <div class="col-lg-6">
                              <div class="input-field">
                                <input type="text" name="reg_fname" id="reg_email" placeholder="Student First Name" value=""/>
                              </div>
                            </div>
                            <div class="col-lg-6">
                              <div class="input-field">
                                <input type="text" name="reg_lname" id="reg_email" placeholder="Student Last Name" value="" />
                              </div>
                            </div>
                          </div>
                          <div class="input-field">
                            <select name="reg_year" id="reg_year1">
                              <option value="">Select Year</option>
                              <?php
					if($year_list)
					{
						foreach($year_list as $years)
						{
							echo '<option value="'.$years->class_id.'">'.$years->class_name.'</option>';
						}
					}
					?>
                            </select>
                          </div>
                          <!--<div class="input-field">
                            <input type="text" name="reg_mobile" placeholder="Phone" />
                          </div>-->
                          <button class="btn-mn btn-3 btn-3e button-org">Sign Up</button>
                        </div>
                      </div>
                    </form>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="col-md-2"></div>
        </div>
      </div>
    </div>
  </div>
</div>

<!-- Page Content End -->
<?php 
if($this->session->userdata('user_id')!='')
{
	include(APPPATH.'/views/frontend/private/footer.php');
}
else
{
	include('footer.php');
}	
?>

<?php /*?><script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script><?php */?>
<script type="text/javascript">
/*jQuery(document).ready(function(){

    jQuery('#reg_year').change(function(){
		
      var yearid=$('#reg_year').val();
            jQuery.ajax({
                type : 'POST',
                url : '<?php echo BASE_URL.'ajaxcall/yearsprice';?>',
                data : {yearid:yearid}
				,	
        success: function(result){
           // alert(result);
           jQuery( "#priceshow" ).html('Price $'+result);
		    jQuery("#yearprice").val(result);
        }


    });
    });    
});
*/
jQuery(document).ready(function(){

    jQuery('#reg_email').blur(function(){
		
      var email=$('#reg_email').val();
            jQuery.ajax({
                type : 'POST',
                url : '<?php echo BASE_URL.'ajaxcall/useremailcheck1';?>',
                data : {email:email}
				,	
        success: function(result){
           // alert(result);
          jQuery( "#emailmsg" ).html(result);
		   //jQuery("#emailmsg").val(result);
        }


    });
    });    
});
</script> 


