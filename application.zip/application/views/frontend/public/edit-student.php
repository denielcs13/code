	<section class="bannerSec subBann innerPage">		
		<div class="">
			<div class="container">
				<div class="innerBox">
					<h1>Edit Student</h1>										
				</div>				
			</div>
		</div>
	</section>
		 
	<section class="sinUpBox">
		<div class="container">
			<div class="row">
				<!--Left Box-->
				<div class="col-lg-12">
					<!--Form Box-->
					<div id="students" class="sibord"  style="display:block;">
						<form class="cmxform" id="signupForm" method="post" action="">
                      <div class="row">
                        <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
						<?php if (validation_errors()){ ?>
										
												<div class="alert alert-danger" role="alert">
													<?= validation_errors() ?>
												</div>
										
						<?php }
							elseif($this->session->flashdata('msg') != null && $this->session->flashdata('msg') != "")
								{ 
								?>
								<div class="alert alert-danger" role="alert">
										<?php echo $this->session->flashdata('msg');?>
								</div>
											
							<?php }	?>
              
                        
                                                  
                   	<div class="col-lg-4 col-md-4 col-sm-12">
								<div class="form-group row">
									<label class="col-sm-12 text-left control-label col-form-label">Email</label>
									<div class="col-sm-12">
										 <div id="msgemail"></div> 
 <input type="text" class="form-control" name="reg_email" id="reg_email" value="<?= (isset($stud_detail->email) && !empty($stud_detail->email)) ? $stud_detail->email : set_value('reg_email'); ?>" placeholder="Student’s Login Email " /> 										
									</div>
								</div>
							</div>
							
							<div class="col-lg-4 col-md-4 col-sm-12">
								<div class="form-group row">
									<label class="col-sm-12 text-left control-label col-form-label">Password</label>
									<div class="col-sm-12">
										
 <input type="password" class="form-control" name="reg_pwd" id="reg_pwd" placeholder="Password" value=""/> 										
									</div>
								</div>
							</div>
								<div class="col-lg-4 col-md-4 col-sm-12">
								<div class="form-group row">
									<label class="col-sm-12 text-left control-label col-form-label">Student Name</label>
									<div class="col-sm-12">
										
<input type="text" class="form-control" name="reg_fname" id="reg_fname" placeholder="Student's Full Name" value="<?= (isset($stud_detail->first_name) && !empty($stud_detail->first_name)) ? $stud_detail->first_name : set_value('reg_fname'); ?>"/> 										
									</div>
								</div>
							</div>
									<div class="col-lg-4 col-md-4 col-sm-12">
								<div class="form-group row">
									<label class="col-sm-12 text-left control-label col-form-label">Class</label>
									<div class="col-sm-12">
										
<select name="reg_class" id="reg_class" class="form-control custom-select">
							  <option value="<?= $stud_detail->class_name; ?>" <?= ((isset($stud_detail->class_name) && $stud_detail->class_name == $stud_detail->class_name) || ($stud_detail->class_name == set_value('reg_class'))) ? 'selected' : ''; ?>><?php
							  if(!empty($stud_detail->class_name)){
					if($stud_detail->class_name=='1'){
					echo "Kindergarten";
				}else
				{
					echo "Year ".($stud_detail->class_name - 1);
					
				}
				}else{	
				}
							   ?></option>
                                <option value="">Select</option>
                                <?php 
                    $i = 1;
                    if($year_dtl){
                    foreach($year_dtl as $year_dt){
                      ?>
                      <option value="<?=$year_dt->class_id;?>"><?=$year_dt->class_name;?></option>
                      <?php $i++;}}else{?>                      
                       
                        <option value="">No data find</option>                 
                      
                    <?php } ?>

                              </select> 										
									</div>
								</div>
							</div>
                        
                            	<div class="col-lg-12 col-md-12 col-sm-12 text-right">
								<button type="submit" name="submit" class="btnBox btForm"><?= ($this->uri->segment(2) != '') ? 'Update' : 'Add'; ?></button>
							</div>             
                          
                          </div>                         
                          
                          
                        </div>
                      </div>
                    </form>
					</div>				
			</div><!--row end-->
		</div>
	</section>
	<script type="text/javascript">

jQuery(document).ready(function(){

    jQuery('#reg_email').blur(function(){
	var email=$('#reg_email').val();
    jQuery.post('<?=base_url('useremailcheck1');?>',{email:email},function(result){
           if(result=="<span style='color:green'>You can register with us.</span>")
           {
            jQuery('.button-org').removeAttr('disabled');
            jQuery( "#msgemail" ).html(result);
           }else{
            jQuery('.button-org').prop('disabled','true');
            jQuery( "#msgemail" ).html(result);
           }
          
		   console.log(result);
        });
    });    
});
</script> 

	
