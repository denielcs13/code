

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<link rel="shortcut icon" href="http://aiits.in/assets/images/favicon.png" />

<link href="http://aiits.in/assets/images/60x60.png" rel="apple-touch-icon" />
<link href="http://aiits.in/assets/images/76x76.png" rel="apple-touch-icon" sizes="76x76" />
<link href="http://aiits.in/assets/images/120x120.png" rel="apple-touch-icon" sizes="120x120" />
<link href="http://aiits.in/assets/images/152x152.png" rel="apple-touch-icon" sizes="152x152" />

<meta name="description" content="">
<meta name="author" content="">
<title>The University Of Education </title>

<!-- Bootstrap core CSS -->
<link href="https://fonts.googleapis.com/css?family=Montserrat:100,300,400,500,600,700,800,900&display=swap" rel="stylesheet">

<link href="https://fonts.googleapis.com/css?family=Lato:100,300,400,700,900&display=swap" rel="stylesheet">
<link href="assets/css/bootstrap.min.css" rel="stylesheet">
<link href="assets/css/font-awesome.min.css" rel="stylesheet" />
<link href="assets/css/font-awesome.css" rel="stylesheet" />
<link href="assets/css/animate.css" rel="stylesheet" />
<link href="assets/css/404.css" rel="stylesheet" />
<link href="assets/css/title.css" rel="stylesheet" /> 
<link href="assets/css/owl.carousel.min.css" rel="stylesheet" />
<link href="assets/css/owl.carousel.css" rel="stylesheet" />
<script src="https://cdnjs.cloudflare.com/ajax/libs/modernizr/2.6.2/modernizr.min.js"></script>
<script src="assets/js/wow.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
<script src='assets/js/unispeech.js'></script>
<!-- Custom styles for this template -->
<!--<link href="http://aiits.in/assets/style.css" rel="stylesheet">-->
<link href="assets/style.css" rel="stylesheet">
</head>
<body>

	<header class="header fadeInDown" >
		<div class="container">
			<div class="row">
				<div class="col-xs-12 col-sm-4 col-md-2 col-lg-2 logo-sect">
					<div class="logo text">
						<a href="index.php"><img src="<?= base_url('assets/images/logo.png')?>"></a>
					</div>
				</div>
				<div class="col-xs-12 col-sm-8 col-md-10 col-lg-10 text-right">
					<div class="btnButton">
						<ul>
							<li class="hoveMenu">
								<a href="#">Grade</a>
								<ul class="hoMenu">
									<li><a href="#">Kindergarten</a></li>
									<li><a href="#">Year 1</a></li>									
									<li><a href="#">Year 2</a></li>									
									<li><a href="#">Year 3</a></li>									
									<li><a href="#">Year 4</a></li>									
									<li><a href="#">Year 5</a></li>									
								</ul>
							</li>
							<li>
								<a href="#">Country</a>
							</li>
							<li>
								<a href="#">Login</a>
							</li>
							<li>
								<a href="#" class="btnBox">Sign up</a>
							</li>
						</ul>
					</div>
				</div>
			</div>
		</div>
	</header>
	
	<div class="bannerSec">
		<div class="container">
		<div class="innerBox">
			<div class="bannText">				
				<div class="txtBann">
					<h1>Helping Kids Thrive, Not Just Survive.</h1>
					<p>We're an international education institution with the  mission to make learning easy and fun!</p>
					<span class="boxBtn">
						<a href="#" class="btnBox">Learner</a>
						<a href="#" class="btnBox">Teacher</a>
						<a href="#" class="btnBox">Parent</a>
					</span>
				</div>	
			</div>
		</div>
		<div class="bannRightBox" /*style="background-image:url(img/banner.png);"*/>
			<div class="riBoxBn">
				<img src="<?= base_url('assets/images/banner1.png')?>">
			</div>
		</div>
		</div>
	</div>
	
	<section class="eduPlex">			
		
			<div class="container">		
				<h2>Why EduPlex Pro</h2>
				<div class="row">
					<div class="col-xs-12 col-sm-6 col-md-4 col-lg-4 tm">
						 <div class="content_halping math-box">
							 <img src="http://aiits.in/assets/images/book.svg" alt="" />
							 <h4>Quality content </h4>
							 <p>Curated for today's tech-savy generation and thoroughly assessed to make learning stress free and effective</p>
						 
						 </div>
					 
					</div>
					 <div class="col-xs-12 col-sm-6 col-md-4 col-lg-4 tm">
						 <div class="content_halping math-box">
							 <img src="http://aiits.in/assets/images/medal.svg" alt="" />
							 <h4>Customized learning </h4>
							 <p>Well-designed curriculum enables students to learn on their own pace, teachers to customize curriculum, and parents to monitor the progress</p>						 
						 </div>					 
					 </div>
					 <div class="col-xs-12 col-sm-12 col-md-4 col-lg-4 tm"> 
						 <div class="content_halping math-box">
							 <img src="http://aiits.in/assets/images/trophy.svg" alt="" />
							 <h4>Interactive learning</h4>
							 <p>Built to ignite the curiosity, this unique system strengthen the core concepts and develops critical thinking abilities</p>					 
						 </div>					 
					 </div>
				</div>	
			</div>
		
	</section>
	
	
	<section class="teachersBox">
		<div class="container">			
				
			<div class="row">
			<div class="col-xs-12 col-sm-12 col-md-6 col-lg-6">
					<div class="teachRight">
						<h6>Teachers</h6>
						<h2>Design content based on the needs of your students.</h2>
						<p>Online courses open the opportunity for learning to almost anyone, regardless of their scheduling commitments.</p>
						<span class="boxBtn"><a href="#" class="btnBox">Teachers, let's get started</a></span>
					</div>
				</div>
			</div>
		</div>
	</section>
	
	
	<section class="teachersBo td">
		<div class="container">			
				
			<div class="row">
			<div class="col-xs-12 col-sm-12 col-md-6 col-lg-6">
					<div class="teachRight">
						<h6>Learners</h6>
						<h2>What we learn with pleasure we never forget.</h2>
						<p>Online courses open the opportunity for learning to almost anyone, regardless of their scheduling commitments.</p>
						<span class="boxBtn"><a href="#" class="btnBox">Learners, let's get started</a></span>
					</div>
				</div>
			</div>
		</div>
	</section>
	
	
	<section id="testimonial" class="space-75">
   <div class="container">
   <div class="row">
   <h2 class="text-center dis-inline">Testimonials</h2> 
   
<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
<div class="owl-carousel">
<div class="item">
<div class="testimonial_sec">
   <div class="quote"><img src="http://aiits.in/assets/images/quate.png" alt="" /></div>
   
   <h4>Evans T. & Sally T.</h4>
   
   <div class="more_text">
   We both learn alot from The University of English. A good place to learn English.
   </div>
   
   </div>
</div>
<div class="item">
<div class="testimonial_sec dark_green">
   <div class="quote"><img src="http://aiits.in/assets/images/quate.png" alt="" /></div>
   
   <h4>Charlotte M.</h4>
   
   <div class="more_text">
   My English has improved considerably since I joined the class at The University of English.
   </div>
   
   </div>
</div>
<div class="item">
<div class="testimonial_sec bg_org">
   <div class="quote"><img src="http://aiits.in/assets/images/quate.png" alt="" /></div>
   
   <h4>Gabriel S.</h4>
   
   <div class="more_text">
   Interesting to learn English this way.  Nowadays, I can do my English homework everyday through The University of English website.
   </div>
   
   </div>
</div>
<div class="item">
<div class="testimonial_sec dark_green">
   <div class="quote"><img src="http://aiits.in/assets/images/quate.png" alt="" /></div>
   
   <h4>Stephen K.</h4>
   
   <div class="more_text">
   Classroom and homework exercises really help me alot.  I can start to teach my classmates during English sessions.
   </div>
   
   </div>
</div>

<div class="item">
<div class="testimonial_sec">
   <div class="quote"><img src="http://aiits.in/assets/images/quate.png" alt="" /></div>
   
   <h4>Jayden M.</h4>
   
   <div class="more_text">
   Really appreciate those teaching staffs and I really learn alot of English in just a couple of weeks.
   </div>
   
   </div>
</div>
<div class="item">
<div class="testimonial_sec bg_org">
   <div class="quote"><img src="http://aiits.in/assets/images/quate.png" alt="" /></div>
   
   <h4>Hilton S.</h4>
   
   <div class="more_text">
   The homework really makes me learn alot.  Really enjoy coming to the class every week.
   </div>
   
   </div>
</div>

    

</div>
</div>

<span class="boxBtn"><a href="#" class="btnBox">View All Testimonials</a></span>


   </div>
   </section>
	
	<!--
	
	
	
	
	
	<section class="teachersBox">
		<div class="container">			
				
			<div class="row">
			<div class="col-xs-12 col-sm-12 col-md-6 col-lg-6 bkGimg" style="background-image:url(images/year-3.jpg)">
				
				</div>
				<div class="col-xs-12 col-sm-12 col-md-6 col-lg-6">
					<div class="teachRight">
						<h6>Teachers</h6>
						<h3>Design customized content based on the needs of your students</h3>
						<span class="boxBtn"><a href="#" class="btnBox">Teachers, let's get started</a></span>
					</div>
				</div>
			</div>
		</div>
	</section>

	<section class="teachersBox">
		<div class="container">			
				
			<div class="row">
				<div class="col-xs-12 col-sm-12 col-md-6 col-lg-6">
					<div class="teachRight">
						<h6>Learners</h6>
						<h3>What we learn with pleasure we never forget.</h3>
						<span class="boxBtn"><a href="#" class="btnBox">Learners, let's get started</a></span>
					</div>
				</div>
				<div class="col-xs-12 col-sm-12 col-md-6 col-lg-6 bkGimg" style="background-image:url(images/membershipBg.jpg)">
				
				</div>
			</div>
		</div>
	</section>

	
	
	
	<section class="teachersBox">
		<div class="container">			
				
			<div class="row">
			<div class="col-xs-12 col-sm-12 col-md-6 col-lg-6 bkGimg" style="background-image:url(images/year-3.jpg)">

				</div>
				<div class="col-xs-12 col-sm-12 col-md-6 col-lg-6">
					<div class="teachRight">
						<h6>Parents</h6>
						<h3>Let your child learn more, grow more and do more.</h3>
						<span class="boxBtn"><a href="#" class="btnBox">Parents, let's get started.</a></span>
					</div>
				</div>
			</div>
		</div>
	</section>
	
	
	<section class="eduPlex">
		<svg viewBox="0 0 1366 631" height="631" class="_dkkao8NaN" preserveAspectRatio="none" aria-hidden="true"><path d="M1366 614.626V42.2878C1216.44 32.481 1071.16 25.6274 902.892 20.0618C647.674 11.6203 291.457 3.37253 0 0.135254V612.111C313.572 631.987 694.403 637.367 1189.78 619.86C1248.63 617.783 1307.48 616.071 1366 614.626Z" fill="#a6b1bb"></path></svg>	
		<div class="eduPlexText">
			<div class="container">
				<div class="row">
					<h2 class="text-center dis-inline">Testimonial</h2>    
					<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
						<div class="owl-carousel">
							<div class="item">
								<div class="testimonial_sec">
									<div class="quote"><img src="http://aiits.in/assets/images/quate.png" alt="" /></div>
									<h4>Evans T. & Sally T.</h4>
									<div class="more_text">
										We both learn alot from The University of English. A good place to learn English.
									</div>
								</div>
							</div>
							<div class="item">
								<div class="testimonial_sec dark_green">
								   <div class="quote"><img src="http://aiits.in/assets/images/quate.png" alt="" /></div>
								   
								   <h4>Charlotte M.</h4>
								   
								   <div class="more_text">
								   My English has improved considerably since I joined the class at The University of English.
								   </div>
								   
								   </div>
								</div>
								<div class="item">
								<div class="testimonial_sec bg_org">
								   <div class="quote"><img src="http://aiits.in/assets/images/quate.png" alt="" /></div>
								   
								   <h4>Gabriel S.</h4>
								   
								   <div class="more_text">
								   Interesting to learn English this way.  Nowadays, I can do my English homework everyday through The University of English website.
								   </div>
								   
								   </div>
								</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>

-->




























   <!--
   <section id="newsletter_sec" class="space-75">
   <div class="container">
   <div class="row">
   <div class="col-xs-12 col-sm-12 col-md-6 col-lg-8">
  
   <div class="subscribe">
   <div class="row"> 
   <div class="col-xs-12 col-sm-3 col-md-2 col-lg-2 text-center"><img src="http://aiits.in/assets/images/subscribe_icon.jpg" alt="" /></div>
   <div class="col-xs-12 col-sm-9 col-md-10 col-lg-10"><h2>Subscribe To Our Newsletter</h2>
   <p>We will regularly updates our followers on the news related to English and also our institution development.</p>
</div>
   </div>
   </div>
   
   </div>
<div class="col-xs-12 col-sm-12 col-md-6 col-lg-4">
<h2>Your E-mail Address</h2>
<form>
<input type="text" placeholder="Email" /> <button type="submit"  value="Subscribe" class="btn-mn btn-3 btn-3e button-org">Subscribe</button>
</form>
</div>
</div>
   </div>
   </section>
   -->
   
 <!-- Page Content End -->
 
 
 
 
 
 
<footer>
<div class="container">
<div class="row">
<div class="col-xs-12 col-sm-12 col-md-12 col-lg-7">
<div class="left_bar">
<h4>TheUniversity Web.</h4>
<p>We are an international education institution that specialized in teaching English for children from kindergarten to Year 13. We believe all children need a proper balance of Learn, Explore and Play during a child development process.
A child needs maths to help them to achieve better quality life.</p>
<p>
<div class="counter">
 Questions answered <h3></h3>
</div>
</p>
<div class="row space_top_90 color_text space_bottom_23 botttom_link">

<div class="col-xs-12 col-sm-7 col-md-8 col-lg-8">
<div class="foot_cont">
<h5>Get in Touch</h5>
<ul>
<li><i class="fa fa-home" aria-hidden="true"></i> TheUniversity Web.</li>
<li><i class="fa fa-phone-square" aria-hidden="true"></i><a href="tel:0123456789">012 345 6789</a></li>
<li><i class="fa fa-envelope-square" aria-hidden="true"></i><a href="mailto:ask@theuniversityofmaths.com">ask@theuniversityofenglish.com</a></li>
</ul>
</div>
</div>

<div class="col-xs-12 col-sm-5 col-md-4 col-lg-4">
<h5>Company</h5>
<ul>
<li><a href="http://aiits.in/contact-us">Contact Us</a></li>
</ul>

</div>


</div>

</div>
</div>

<div class="col-xs-12 col-sm-12 col-md-12 col-lg-5">
<div class="rightbar">
<div class="row">
<div class="col-xs-12 col-sm-5 col-md-5 col-lg-6">
<h5>Resources</h5>

<ul>
<li><a href="http://aiits.in/help-center">Help Center</a></li>
<li><a href="http://aiits.in/faqs">FAQ's</a></li>
<li><a href="http://aiits.in/term-conditions">Term & Conditions</a></li>
<li><a href="http://aiits.in/privacy-policy">Privacy Policy</a></li>
<li><a href="http://aiits.in/disclaimer">Disclaimer</a></li>
<li><a href="http://aiits.in/testimonials">Testimonials</a></li>
</ul>

</div>


<div class="col-xs-12 col-sm-6 col-md-6 col-lg-6">
<h5>Follow Us</h5>
<ul class="social">
<li><a href="https://www.facebook.com/" class="fb" target="_blank"><i class="fa fa-facebook" aria-hidden="true"></i></a></li>
<li><a href="https://twitter.com/" class="tw" target="_blank"><i class="fa fa-twitter" aria-hidden="true"></i></a></li>
<li><a href="https://plus.google.com/discover" class="gplus" target="_blank"><i class="fa fa-google-plus" aria-hidden="true"></i></a></li>
<li><a href="https://www.youtube.com/" class="yt" target="_blank"><i class="fa fa-youtube" aria-hidden="true"></i></a></li>

<li><a href="https://www.instagram.com/accounts/login/?hl=en" class="insta" target="_blank"><i class="fa fa-instagram" aria-hidden="true"></i></a></li>
<li><a href="https://www.linkedin.com/uas/login" class="link" target="_blank"><i class="fa fa-linkedin" aria-hidden="true"></i></a></li>
<li><a href="https://www.pinterest.com/" class="pin" target="_blank"><i class="fa fa-pinterest" aria-hidden="true"></i></a></li>
</ul>

</div>

</div>


</div>

</div>

</div>

<div class="copy_right">
<p class="text-left">© 2019 - 2019 TheUniversity Web. All Rights Reserved.</p>
</div>
</div>

<div class="foot_bottom">
<div class="container">
<div class="row">
<div class="col-sm-3 col-md-3 col-lg-3 col-xs-3 col">
<p><a href="http://aiits.in/help-center"><span class="icon_btm"><i class="fa fa-phone" aria-hidden="true"></i> </span><small>Help and Support</small></a></p>
</div>
<div class="col-sm-3 col-md-3 col-lg-3 col-xs-3 col">
<p><a href="http://aiits.in/contact-us"><span class="icon_btm"><i class="fa fa-mobile" aria-hidden="true"></i> </span><small>Request and call back</small></a></p>
</div>
<div class="col-sm-3 col-md-3 col-lg-3 col-xs-3 col">
<!-- <p><a href="http://aiits.in/our-centers"><span class="icon_btm"><i class="fa fa-life-ring" aria-hidden="true"></i> </span><small>Our Centers</small></a> --></p>
</div>

<div class="col-sm-3 col-md-3 col-lg-3 col-xs-3 col">
<a href="#" class="live-chat_btn float-right"><span class="icon_live"><i class="fa fa-comments" aria-hidden="true"></i></span><small>Live Chat</small></a>
</div>
</div>
</div>
</div>

</footer>
 <script>
$('document').ready(function(){
$('.boxText').children('input').attr('maxlength','1');
})
</script>
<a id="back2Top" title="Back to top" href="#">&#10148;</a>
 
<!-- Bootstrap core JavaScript --> 
<script src="assets/js/jquery.min.js"></script> 
<script src="assets/js/bootstrap.bundle.min.js"></script> 
<script src="assets/js/main.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1/jquery.min.js"></script>
<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
<script src="assets/js/jquery.slicknav.js"></script>
<script src="assets/js/demo-2.js"></script>

<script src="assets/js/owl.carousel.js"></script>
<script src="assets/js/owl.carousel.min.js"></script> 


	<script>
		$(document).ready(function() {
 
		  $("#owl-demo").owlCarousel({
		 
			  navigation : true,
			  slideSpeed : 300,
			  paginationSpeed : 400,
			  singleItem:true,
			  items : 1,
			  transitionStyle:true
		 
		 
		  });
		 
		});
	</script>	

<script>
            $(document).ready(function() {
              var owl = $('.owl-carousel');
              owl.owlCarousel({
				items: 1,
                margin: 10,
                nav: true,
                loop: true,
				 autoplay: true,
                responsive: {
                  0: {
                    items: 1
                  },
                  600: {
                    items: 2
                  },
                  1000: {
                    items: 3
                  }
                }
              })
            })
          </script> 
		  
		  
  <script type="text/javascript">
    $("#msg").hide().slideDown().delay(3000).fadeOut();
 </script>
	
      
          
</body>
</html>