 
<footer>
<div class="container">
<div class="row">
<div class="col-xs-12 col-sm-12 col-md-12 col-lg-7">
<div class="left_bar">
<h4>THE UNIVERSITY OF MATHS</h4>
<p>We are an international education institution that specialized in teaching Mathematics for children from kindergarten to Year 13. We believe all children need a proper balance of Learn, Explore and Play during a child development process.
A child needs maths to help them to achieve better quality life.</p>

<div class="row space_top_90 color_text space_bottom_23 botttom_link">

<div class="col-xs-12 col-sm-7 col-md-8 col-lg-8">
<div class="foot_cont">
<h5>Get in Touch</h5>
<ul>
<li><i class="fa fa-home" aria-hidden="true"></i> 2A Wagener Place, Mt Albert, Auckland (H.Q.)</li>
<li><i class="fa fa-phone-square" aria-hidden="true"></i><a href="tel:+64 0226458491">+64 0226458491</a></li>
<li><i class="fa fa-envelope-square" aria-hidden="true"></i><a href="mailto:ask@theuniversityofmaths.com">ask@theuniversityofmaths.com</a></li>
</ul>
</div>
</div>

<div class="col-xs-12 col-sm-5 col-md-4 col-lg-4">
<h5>Company</h5>
<ul>
<li><a href="<?= base_url('contact-us');?>">Contact Us</a></li>
</ul>

</div>


</div>

</div>
</div>

<div class="col-xs-12 col-sm-12 col-md-12 col-lg-5">
<div class="rightbar">
<div class="row">
<div class="col-xs-12 col-sm-5 col-md-5 col-lg-6">
<h5>Resources</h5>

<ul>
<li><a href="<?= base_url('help-center');?>">Help Center</a></li>
<li><a href="<?= base_url('faqs');?>">FAQ's</a></li>
<li><a href="<?= base_url('term-conditions');?>">Term & Conditions</a></li>
<li><a href="<?= base_url('privacy-policy');?>">Privacy Policy</a></li>
<li><a href="<?= base_url('disclaimer');?>">Disclaimer</a></li>
<li><a href="<?= base_url('testimonials');?>">Testimonials</a></li>
</ul>

</div>
<div class="col-xs-12 col-sm-6 col-md-6 col-lg-6">
<h5>Important Links</h5>

<ul>
<li><a href="<?= base_url('who-are-we');?>">Who are we</a></li>
<li><a href="<?= base_url('admissions');?>">Admissions</a></li>
<li><a href="<?= base_url('students');?>">Students</a></li>
<li><a href="<?= base_url('parents');?>">Parents</a></li>
<li><a href="<?= base_url('curriculum');?>">Curriculum</a></li>
<li><a href="<?= base_url('booking-payment');?>">Booking & Payment</a></li>
<li><a href="<?= base_url('media-event');?>">Media & Events</a></li>
</ul>

</div>
</div>

<div class="row space_top_35 space_bottom_23 color_text botttom_link">

<div class="col-xs-12 col-sm-5 col-md-5 col-lg-5">

<h5>Work With Us</h5>
<ul>
<li><a href="<?= base_url('become-an-instructor');?>">Become an instructor</a></li>
<!--<li><a href="<?= base_url('become-an-affiliate');?>">Become an affiliate</a></li>-->
</ul>

</div>

<div class="col-xs-12 col-sm-7 col-md-7 col-lg-7">
<h5>Follow Us</h5>
<ul class="social">
<li><a href="https://www.facebook.com/" class="fb" target="_blank"><i class="fa fa-facebook" aria-hidden="true"></i></a></li>
<li><a href="https://twitter.com/" class="tw" target="_blank"><i class="fa fa-twitter" aria-hidden="true"></i></a></li>
<li><a href="https://plus.google.com/discover" class="gplus" target="_blank"><i class="fa fa-google-plus" aria-hidden="true"></i></a></li>
<li><a href="https://www.youtube.com/" class="yt" target="_blank"><i class="fa fa-youtube" aria-hidden="true"></i></a></li>

<li><a href="https://www.instagram.com/accounts/login/?hl=en" class="insta" target="_blank"><i class="fa fa-instagram" aria-hidden="true"></i></a></li>
<li><a href="https://www.linkedin.com/uas/login" class="link" target="_blank"><i class="fa fa-linkedin" aria-hidden="true"></i></a></li>
<li><a href="https://www.pinterest.com/" class="pin" target="_blank"><i class="fa fa-pinterest" aria-hidden="true"></i></a></li>
</ul>

</div>




</div>
</div>

</div>

</div>

<div class="copy_right">
<p class="text-left">© 2018 - <?php echo date('Y');?> The University Of Maths - A Unit of MyUni Education Group LTD. All Rights Reserved.</p>
</div>
</div>

<div class="foot_bottom">
<div class="container">
<div class="row">
<div class="col-sm-3 col-md-3 col-lg-3 col-xs-3 col">
<p><a href="<?= base_url('help-center');?>"><span class="icon_btm"><i class="fa fa-phone" aria-hidden="true"></i> </span><small>Help and Support</small></a></p>
</div>
<div class="col-sm-3 col-md-3 col-lg-3 col-xs-3 col">
<p><a href="<?= base_url('contact-us');?>"><span class="icon_btm"><i class="fa fa-mobile" aria-hidden="true"></i> </span><small>Request and call back</small></a></p>
</div>
<div class="col-sm-3 col-md-3 col-lg-3 col-xs-3 col">
<p><a href="<?= base_url('our-centers');?>"><span class="icon_btm"><i class="fa fa-life-ring" aria-hidden="true"></i> </span><small>Our Centers</small></a></p>
</div>

<div class="col-sm-3 col-md-3 col-lg-3 col-xs-3 col">
<a href="#" class="live-chat_btn float-right"><span class="icon_live"><i class="fa fa-comments" aria-hidden="true"></i></span><small>Live Chat</small></a>
</div>
</div>
</div>
</div>

</footer>

<a id="back2Top" title="Back to top" href="#">&#10148;</a>
 
<!-- Bootstrap core JavaScript --> 
<script src="<?= base_url('assets/js/jquery.min.js')?>"></script> 
<script src="<?= base_url('assets/js/bootstrap.bundle.min.js')?>"></script> 
<script src="<?= base_url('assets/js/main.js')?>"></script>
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1/jquery.min.js"></script>
<script src="<?= base_url('assets/js/jquery.slicknav.js')?>"></script>
<script src="<?= base_url('assets/js/demo-2.js')?>"></script>

<script src="<?= base_url('assets/js/owl.carousel.js')?>"></script>
<script src="<?= base_url('assets/js/owl.carousel.min.js')?>"></script> 

<script>
            $(document).ready(function() {
              var owl = $('.owl-carousel');
              owl.owlCarousel({
				items: 1,
                margin: 10,
                nav: true,
                loop: true,
				 autoplay: true,
                responsive: {
                  0: {
                    items: 1
                  },
                  600: {
                    items: 2
                  },
                  1000: {
                    items: 3
                  }
                }
              })
            })
          </script> 
  <script type="text/javascript">
    $("#msg").hide().slideDown().delay(3000).fadeOut();

  </script>
          
          
</body>
</html>