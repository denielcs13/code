<?php 
if($this->session->userdata('user_id')!='')
{

	include(APPPATH.'/views/frontend/private/header.php');
	
}
else
{
	include('header.php');
}	
?>
<section id="title-inner" style="background-image:url(<?= base_url('assets/images/students.jpg')?>);">
<div id="large-header">   
<canvas id="demo-canvas"></canvas>
<div class="container">
<div class="text-tit">
 <div class="bb"></div>
<span class="lefttop-icon"></span>
<h1>
<span>Students</span>
</h1>
<span class="rightbotm-icon"></span>
</div>



</div></div>





</section>

 <!-- Page Content inner -->
 
 <section class="about_content content-text space-75">
 <div class="container">
 <div class="row">
 
 
 <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
 <strong class="ling-heg40 blue-text">As a student in the University, the rules and regulations are as follow:</strong>

 <ul>
 <li>Must behave and show respect to others</li>
 <li>Be a punctual person</li>
 <li>Follow instructions, i.e. do homework and ask questions if have difficulties</li>
 </ul>
 
 <p>We have 3 classes from every Monday to Friday, starting from 3:30pm – 7:00pm and 6 classes on every Saturday, starting from
10:00am – 5:15pm.  Every class is design to have first 10 mins lecture, 45 mins practice exercise and last 5 mins Q&A and 
end-of-class briefing.</p>


<div class="row bg-grey m-btm-20">
 
<div class="col-xs-12 col-sm-12 col-md-6 col-lg-6">
<strong class="ling-heg40 blue-text">Monday – Friday</strong>
<ul>
<li>Class A: 3:30pm – 4:30pm</li>
<li>Class B: 4:45pm – 5:45pm</li>
<li>Class C: 6:00pm – 7:00pm</li>
</ul>
</div>

<div class="col-xs-12 col-sm-12 col-md-6 col-lg-6">
<strong class="ling-heg40 blue-text">Saturday</strong>
<ul>
<li>Class A: 10:00am – 11:00am</li>
<li>Class B: 11:15am – 12:15pm</li>
<li>Class C: 12:30pm – 1:30pm</li>
<li>Class D: 1:45pm – 2:45pm</li>
<li>Class E: 3:00pm – 4:00pm</li>
<li>Class F: 4:15pm – 5:15pm</li>
</ul>
</div>

</div>

<p>Once you have booked for a class and suddenly got urgent appointment, please go to the Booking & Payment option to make the
cancellation and book for another day, with the condition of 12 hours before the class commence.  If the student didn't reschedule
the class (12 hours before the class commence) and didn't turn up at the class, the University policy will not refund and student 
cannot reschedule the missing class again. If student didn't do their homework on time, reminder email and text message will be
send out to the parents to remind their child to do their homework regularly.</p>
 
 </div>
 
 
 
 
 </div>
 </div>
 </section>

   
    
 <!-- Page Content End -->
<?php 
if($this->session->userdata('user_id')!='')
{
	include(APPPATH.'/views/frontend/private/footer.php');
}
else
{
	include('footer.php');
}	
?>