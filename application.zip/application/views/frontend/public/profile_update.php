	
	<section class="bannerSec subBann innerPage">		
		<div class="">
			<div class="container">
				<div class="innerBox">
					<h1>Profile</h1>										
				</div>				
			</div>
		</div>
	</section>
		 
	<section class="sinUpBox">
		<div class="container">
		   <?php

        if($this->session->flashdata('msg'))
        {?>
            <div id="msg" style="border: 1px solid;height: 34px;box-shadow: aquamarine;box-shadow: 0px 0px 0px 1px black;">
            <?PHP
            echo "<span> ".$this->session->flashdata('msg')."</span>";
       
          ?></div> <?PHP }?>
			<div class="row">
				<!--Left Box-->
				<div class="col-lg-12">
					<!--Form Box-->
					<div id="students" class="sibord"  style="display:block;">
					<form action="" method="post" enctype="multipart/form-data">
      <div class="row">
         
         <div class="col-sm-12 col-lg-6">
            <div class="form-group row">
               <label for="fname2" class="col-sm-3 text-left control-label col-form-label">Full Name</label>					
               <div class="col-sm-9">					   
               <input type="text" class="form-control" name="f_name" value="<?=($user->first_name)?$user->first_name:set_value('f_name')?>" placeholder="First Name">
               <span class="danger-error"><?=form_error('f_name')?></span>					
               </div>
            </div>
         </div>
		 <?php if($this->session->userdata('user_type')=='6'){?>
         <div class="col-sm-12 col-lg-6">
            <div class="form-group row">
               <label for="fname2" class="col-sm-3 text-left control-label col-form-label">Class Name</label>                    
               <div class="col-sm-9">                			   
                <select class="form-control custom-select" data-placeholder="Select Class" name="class_name" tabindex="1">
				 <option value="">Select</option>
				<option value="<?= $user->class_name; ?>" <?= ((isset($user->class_name) && $user->class_name == $user->class_name) || ($user->class_name == set_value('class_name'))) ? 'selected' : ''; ?>><?php 
				if(!empty($user->class_name)){
					if($user->class_name=='1'){
					echo "Kindergarten";
				}else
				{
					echo "Year ".($user->class_name - 1);
					
				}
				}else{
				echo "Select";	
				} ?></option>
                               
                                <?php  
                    $i = 1;
                    if($year_dtl){
                    foreach($year_dtl as $year_dt){
                      ?>
                      <option value="<?=$year_dt->class_id;?>"><?=$year_dt->class_name;?></option>
                      <?php $i++;}}else{?>                      
                       
                        <option value="">No data find</option>                 
                      
                    <?php } ?>

                     </select>			   
                                   
               <span class="danger-error"><?=form_error('class_name')?></span>
               </div>
            </div>
         </div>
		 <?php } ?>		 		 <?php if($this->session->userdata('user_type')=='7'){?>         <div class="col-sm-12 col-lg-6">            <div class="form-group row">               <label for="fname2" class="col-sm-3 text-left control-label col-form-label">#Childrens</label>                                   <div class="col-sm-9"> 			   <input type="text" name="chldr_num" value="<?=($user->chldr_num)?$user->chldr_num:set_value('chldr_num')?>" class="form-control" placeholder="#Childrens">                <span class="danger-error"><?=form_error('chldr_num')?></span>               </div>            </div>         </div>		 <?php } ?>		 		 <?php if($this->session->userdata('user_type')=='8'){?>         <div class="col-sm-12 col-lg-6">            <div class="form-group row">               <label for="fname2" class="col-sm-3 text-left control-label col-form-label">Institute Name</label>                                   <div class="col-sm-9"> 			   <input type="text" name="inst_name" value="<?=($user->inst_name)?$user->inst_name:set_value('inst_name')?>" class="form-control" placeholder="Institute Name">                <span class="danger-error"><?=form_error('inst_name')?></span>               </div>            </div>         </div>		          <div class="col-sm-12 col-lg-6">            <div class="form-group row">               <label for="fname2" class="col-sm-3 text-left control-label col-form-label">Type</label>                                   <div class="col-sm-9">                  <select class="form-control custom-select" data-placeholder="Select Country" name="inst_type" tabindex="1">                     <option value="" >Type</option>                     <option value="<?= $user->inst_type; ?>" <?= ((isset($user->inst_type) && $user->inst_type == $user->inst_type) || ($user->inst_type == set_value('inst_type'))) ? 'selected' : ''; ?>><?= $user->inst_type; ?></option>                     <option value="School">School</option>                     <option value="Coaching Center">Coaching Center</option>                  </select>               <span class="danger-error"><?=form_error('inst_type')?></span>               </div>            </div>         </div>		 		 <div class="col-sm-12 col-lg-6">            <div class="form-group row">               <label for="fname2" class="col-sm-3 text-left control-label col-form-label">Designation</label>                                   <div class="col-sm-9">                  <select class="form-control custom-select" data-placeholder="Select Country" name="dsgn_name" tabindex="1">                     <option value="" >Select</option>                     <option value="<?= $user->dsgn_name; ?>" <?= ((isset($user->dsgn_name) && $user->dsgn_name == $user->dsgn_name) || ($user->dsgn_name == set_value('dsgn_name'))) ? 'selected' : ''; ?>><?= $user->dsgn_name; ?></option>                                 <option value="Teacher">Teacher</option>                                 <option value="Principal">Principal</option>                                 <option value="Admin">Admin</option>                                 <option value="Director">Director</option>                  </select>               <span class="danger-error"><?=form_error('dsgn_name')?></span>               </div>            </div>         </div>		 		 		 <?php } ?>
         <div class="col-sm-12 col-lg-6">
            <div class="form-group row">
               <label for="fname2" class="col-sm-3 text-left control-label col-form-label">Date of Birth</label>                    
               <div class="col-sm-9">                        
               <input type="date" name="dob" value="<?=($user->dob)?$user->dob:set_value('dob')?>" class="form-control" placeholder="Date of Birth">                    
               <span class="danger-error"><?=form_error('dob')?></span>
               </div>
            </div>
         </div>
         <div class="col-sm-12 col-lg-6">
            <div class="form-group row">
               <label for="fname2" class="col-sm-3 text-left control-label col-form-label">Phone</label>                    
               <div class="col-sm-9">                        
               <input type="text" name="phone" class="phone" value="<?=($user->phone)?$user->phone:set_value('phone')?>" class="form-control" placeholder="Phone">                    
               <span class="danger-error"><?=form_error('phone')?></span>
               </div>
            </div>
         </div>
         <div class="col-sm-12 col-lg-6">
            <div class="form-group row">
               <label for="fname2" class="col-sm-3 text-left control-label col-form-label">Address</label>                    
               <div class="col-sm-9">                        
               <input type="text" name="address" value="<?=($user->address)?$user->address:set_value('address')?>" class="form-control" placeholder="Address">                    
               <span class="danger-error"><?=form_error('address')?></span>
               </div>
            </div>
         </div>
         <div class="col-sm-12 col-lg-6">
            <div class="form-group row">
               <label for="fname2" class="col-sm-3 text-left control-label col-form-label">Email</label>                    
               <div class="col-sm-9">                        
               <input type="text" readonly="" name="email" value="<?=($user->email)?$user->email:set_value('email')?>" class="form-control" placeholder="Email">                    
               <span class="danger-error"><?=form_error('email')?></span>
               </div>
            </div>
         </div>
         <div class="col-sm-12 col-lg-6">
            <div class="form-group row">
               <label for="nname" class="col-sm-3 text-left control-label col-form-label">Country</label>                    
               <div class="col-sm-9">
                <select id="country3" name ="Country" class="form-control custom-select countries">
							   <option value="">Select Country</option>
							   <?php
							if(!empty($country_list))
							{
								foreach($country_list as $countries)
								{
									?>
							   <option value="<?= $countries->id; ?>" <?= ((isset($user->country) && $countries->id == $user->country) || ($countries->id == set_value('Country'))) ? 'selected' : ''; ?>><?= $countries->name; ?></option>
							   <?php
								}
							}
							?>
				</select>
               <span class="danger-error"><?=form_error('Country')?></span>
               </div>
            </div>
         </div>
         <div class="col-sm-12 col-lg-6">
            <div class="form-group row">
               <label for="fname2" class="col-sm-3 text-left control-label col-form-label">City</label>                    
               <div class="col-sm-9">                        
               <input type="text" name="city" value="<?=($user->city)?$user->city:set_value('city')?>" class="form-control" placeholder="City">                    
              <span class="danger-error"><?=form_error('city')?></span>
               </div>
            </div>
         </div>
         <div class="col-sm-12 col-lg-6">
            <div class="form-group row">
               <label for="nname" class="col-sm-3 text-left control-label col-form-label">State</label>                    
               <div class="col-sm-9">                  
				  <select name ="state" id ="state3" class="form-control custom-select states" >
							   <option value="">Select State</option>
							   <?php
							if(!empty($state_list))
							{
								foreach($state_list as $states)
								{
									?>
							   <option value="<?= $states->id; ?>" <?= ((isset($user->state) && $states->id == $user->state) || ($states->id == set_value('state'))) ? 'selected' : ''; ?>><?= $states->name; ?></option>
							   <?php
								}
							}
							?>
							   
				 </select>
               <span class="danger-error"><?=form_error('state')?></span>
               </div>
            </div>
         </div>
         <div class="col-sm-12 col-lg-6">
            <div class="form-group row">
               <label for="fname2" class="col-sm-3 text-left control-label col-form-label">Zip Code</label>                    
               <div class="col-sm-9">                        
               <input type="text" name="zip" value="<?=($user->zipcode)?$user->zipcode:set_value('zip')?>" class="form-control" placeholder="zip">                    
               <span class="danger-error"><?=form_error('zip')?></span>
               </div>
            </div>
         </div>
         <!--<div class="col-sm-12 col-lg-6">
            <div class="form-group row">
               <label for="fname2" class="col-sm-3 text-left control-label col-form-label">Select Image</label>                    
               <div class="col-sm-9">                        
               <input type="file"   name="file">                  
               
               </div>
            </div>
         </div>-->
         <div class="col-sm-12 col-lg-12">
            <div class="card-body">
               <div class="form-group m-b-0 text-right">						
               <button type="submit" class="btnBox btForm">Submit</button>	</div>
            </div>
         </div>
      </div>
      </form>
					</div>				
			</div><!--row end-->
		</div>
	</section>
<script>
function ajaxCall() {
        this.send = function(data, url, method, success, type) {
          type = type||'json';
          var successRes = function(data) {
              success(data);
          }

          var errorRes = function(e) {
              console.log(e);
              alert("Error found \nError Code: "+e.status+" \nError Message: "+e.statusText);
          }
            $.ajax({
                url: url,
                type: method,
                data: data,
                success: successRes,
                error: errorRes,
                dataType: type,
                timeout: 60000
            });

          }

        }

function locationInfo() {
    //var rootUrl = "apiv1.php";
    var call = new ajaxCall();
	
    this.getStates = function(id) {
        $(".states option:gt(0)").remove();       
        var url1 = '<?=base_url('unieducation/all_states_list/');?>';
        var method = "post";
        var data = {country_id:id};
        $('.states').find("option:eq(0)").html("Please wait..");
        call.send(data, url1, method, function(data) {
            $('.states').find("option:eq(0)").html("Select State");
            if(data.success == true){
                $.each(data.state_lst, function (item, i) {
                                $('.states').append('<option value="' + i.id + '">' + i.name +'</option>');
                            });
                $(".states").prop("disabled",false);
            }
            else{
                alert(data.msg);
            }
        }); 
    };

    this.getCountries = function() {
        var url = '<?=base_url('unieducation/all_country_list');?>';
        var method = "post";
        var data = {};
        $('.countries').find("option:eq(0)").html("Please wait..");
        call.send(data, url, method, function(data) {
            $('.countries').find("option:eq(0)").html("Select Country");
            console.log(data);
            if(data.success == true){
                $.each(data.country_lst, function (item, i) {
                                $('.countries').append('<option value="' + i.id + '">' + i.name +'</option>');
                            });
                $(".countries").prop("disabled",false);
            }
            else{
                alert(data.msg);
            }
        }); 
    };

}

$(function() {
var loc = new locationInfo();
loc.getCountries();
 $(".countries").on("change", function(ev) {
        var countryId = $(this).val()
        if(countryId != ''){
        loc.getStates(countryId);
        }
        else{
            $(".states option:gt(0)").remove();
        }
    });
 // $(".states").on("change", function(ev) {
        // var stateId = $(this).val()
        // if(stateId != ''){
        // loc.getCities(stateId);
        // }
        // else{
            // $(".cities option:gt(0)").remove();
        // }
    // });
});

</script>
<script type="text/javascript">
$(".phone").keyup(function() {
	//var number = $(this).val().replace(/[^\d]/g, '');
    //$(this).val(number.replace(/^(\d{3})(\d{3})(\d)+$/, "$1-$2-$3"));
	
	var number = $(this).val().replace(/[^\d]/g, '')
    if (number.length == 7) {
      number = number.replace(/(\d{3})(\d{4})/, "$1-$2");
    } else if (number.length == 10) {
      number = number.replace(/(\d{3})(\d{3})(\d{4})/, "$1-$2-$3");
     
    }
    $(this).val(number)
    $(".phone").attr({ maxLength : 10 });
});
</script>