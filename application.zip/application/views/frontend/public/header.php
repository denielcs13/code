<?php

//$this->session->userdata('login_status');
if($this->session->userdata('profile_update')=='no')
{
    $table="temp_main_user";
}
else
{
    $table="main_user";
}
$usertable=$this->main_model->get_detail($this->db,$table,array('user_id'=>$this->session->userdata('user_id'),'user_type'=>'6'),'single');

if($usertable)
{
    if($usertable->login_status!=$this->session->userdata('login_status'))
    {
      redirect(base_url('logout'));  
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>

<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<link rel="shortcut icon" href="<?= base_url('assets/images/favicon.png')?>" />
	<link href="https://fonts.googleapis.com/css?family=Lato&display=swap" rel="stylesheet"> 
	<link rel="stylesheet" href="<?= base_url('assets/css/font-awesome.min.css')?>">	
	<link rel="stylesheet" href="<?= base_url('assets/css/owl.carousel.min.css')?>">
	<link rel="stylesheet" href="<?= base_url('assets/css/bootstrap.min.css')?>">
	<link rel="stylesheet" href="<?= base_url('assets/css/style.css')?>">	
	<script src="https://cdnjs.cloudflare.com/ajax/libs/modernizr/2.6.2/modernizr.min.js"></script>

<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
	<meta name="description" content="">
<meta name="author" content="">
<title>The University Of Education </title>

</head>

<body>
	<header class="header">
		<div class="container">
			<div class="row">
				<div class="col-xs-12 col-sm-4 col-md-2 col-lg-2 logo-sect">
					<div class="logo text">
						<a href="/"><img src="<?= base_url('assets/img/logo.png')?>"></a>
					</div>
				</div>
				<div class="col-xs-12 col-sm-8 col-md-10 col-lg-10 mBox">
					<button class="navbar-toggler collapsed" type="button" data-toggle="collapse" data-target="#menu" aria-controls="menu" aria-expanded="false" aria-label="Toggle navigation">
						<span class="navbar-toggler-icon"></span>
						<span class="navbar-toggler-icon"></span>
						<span class="navbar-toggler-icon"></span>
					</button>
				</div>
				<div class="col-xs-12 col-sm-12 col-md-10 col-lg-10 text-right collapse" id="menu">
					<div class="btnButton">
						<ul>
							<li><a href="<?=base_url('math')?>">Maths</a></li>
							<li><a href="<?=base_url('english')?>">English</a></li>	
							<li><a href="<?=base_url('chinese')?>">Chinese</a></li>
		<?php
		if($this->session->userdata('username')!='' && $this->session->userdata('username')!=null)
		{
			?>
		<li><a href="<?php echo BASE_URL.'logout';?>">Logout</a></li>
		<li><a href="<?php echo BASE_URL.'dashboard';?>" class="btnBox">Dashboard</a></li>
	
		<?php 
		}
		else
		{
			?>
	
		<li><a href="<?php echo BASE_URL.'login';?>">Login</a></li>
		<li><a href="<?php echo BASE_URL.'register';?>" class="btnBox">Sign Up For Free</a></li>
		<?php
		}
		?>		
						</ul>
					</div>
				</div>
				
			</div>
		</div>
	</header>	
