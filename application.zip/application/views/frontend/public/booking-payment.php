<?php 
if($this->session->userdata('user_id')!='')
{

	include(APPPATH.'/views/frontend/private/header.php');
	
}
else
{
	include('header.php');
}	
?>

<section id="title-inner" class="bgcolor-text">
<canvas id="demo-canvas"></canvas>
<div class="container">
<div class="text-tit">
<h1>
<span>Booking Payment</span>
</h1>
</div>

</div>
</section>
<!-- Page Content inner -->


 
 <section class="about_content content-text space-75">
 <div class="container">
 <div class="row">
 
 <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">

<strong>Student can book their class :-</strong>
<ul>
<li>Every week – on different day (i.e. week 1 on Monday, week 2 on Tuesday and week 3 on Wednesday, etc</li>
<li>Same day every week (i.e. every Monday for Semester 1 or every Friday for Semester 2)</li>
<li>Alternate day (i.e. week 1 on Monday, week 2 on Thursday, week 3 on Monday and week 4 on Thursday, etc…)</li>
<li>Twice or more classes per/week (i.e. on every Monday and Friday)</li>
</ul>

<p>The system will send at class reminders to student and/or parents through email/text message 3 days before and one day before the class.</p>
 
 </div>
 
 
 
 
 </div>
 </div>
 </section>
 
   
    
 <!-- Page Content End -->
<?php 
if($this->session->userdata('user_id')!='')
{
	include(APPPATH.'/views/frontend/private/footer.php');
}
else
{
	include('footer.php');
}	
?>