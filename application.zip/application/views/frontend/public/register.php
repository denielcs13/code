  <link rel="stylesheet" href="<?= base_url('assets/build/css/intlTelInput.css')?>">
  <link rel="stylesheet" href="<?= base_url('assets/build/css/demo.css')?>">
<section class="bannerSec subBann innerPage">		
		<div class="">
			<div class="container">
				<div class="innerBox">
					<h1>SIGN UP</h1>										
				</div>				
			</div>
		</div>
	</section>
		 
	<section class="sinUpBox">
		<div class="container">
		   <form class="cmxform" id="signupForm" method="post" action="">
			<div class="row">
				<!--Left Box-->
				<div class="col-lg-9 col-md-9">
					<div class="row siTab">
						<div class="col-md-4 sinMain btnBox"> <input class="col-form-label" type="radio" id="wedd" name="etype" value="pwov" <?if(!empty($is_active))
								echo $is_active;  
							  ?> >Students </div>
						<div class="col-md-4 sinMain btnBox"> <input class="col-form-label" type="radio" name="etype" value="pwv" id="oth" <?if(!empty($is_active1))
								echo $is_active1;  
							  ?>  >Parents</div>
						<div class="col-md-4 sinMain btnBox"><input class="col-form-label" type="radio" name="etype" value="pwvi" id="othi" <?if(!empty($is_active2))
								echo $is_active2;  
							  ?>>Institute</div>
					</div>
					
					<!--Form Box-->
					<div id="students" class="sibord"  style="<?if(!empty($is_active)){
					  echo 'display: block;';  
					  //echo $const;
				   }else{
					 echo 'display: none;';   
				   }
								 
							  ?>">
						<div class="row">
							<div class="col-lg-6 col-md-6 col-sm-12">
								<div class="form-group row">
									<label class="col-sm-12 text-left control-label col-form-label">Country*</label>
									<div class="col-sm-12">
										
											<select  class="form-control custom-select countries" name="country"  id="countryId" >
								<option value="">Select Country</option>
								<? if(!empty($const)){?>
								<option value="<? if(!empty($const)){
								echo $const[0]->id;
								}else{
								echo '';	
								} ?>" <?=((isset($const)) && (set_value('country'))) ? 'selected' : ''; ?>><? if(!empty($const)){echo $const[0]->name;} ?></option>
								<? }?>
								</select>
                              <span class="error"><?= form_error('country'); ?></span>
									</div>
								</div>
							</div>
							<div class="col-lg-6 col-md-6 col-sm-12">
								<div class="form-group row">
									<label class="col-sm-12 text-left control-label col-form-label">State*</label>
									<div class="col-sm-12">
										<select name="state"  id="stateId" class="form-control custom-select states">
								<option value="">Select State</option>
								<option value="<? if(!empty($consts)){
								echo $consts[0]->id;
								}else{
								echo '';	
								} ?>" <?=((isset($consts)) && (set_value('state'))) ? 'selected' : ''; ?>><? if(!empty($consts)){echo $consts[0]->name;} ?></option>
							  </select>							  
                                <span class="error"><?= form_error('state'); ?></span>                    						   
									</div>
								</div>
							</div>
							<div class="col-lg-6 col-md-6 col-sm-12">
								<div class="form-group row">
									<label class="col-sm-12 text-left control-label col-form-label">City*</label>
									<div class="col-sm-12">
										<input type="text" class="form-control" name="reg_city_stdn" id="reg_city_stdn" placeholder="Current City" value="<?= (isset($emp->reg_city_stdn) && !empty($emp->reg_city_stdn)) ? $emp->reg_city_stdn : set_value('reg_city_stdn'); ?>"/>								
                                <span class="error"><?= form_error('reg_city_stdn'); ?></span>                     						   
									</div>
								</div>
							</div>
							<div class="col-lg-6 col-md-6 col-sm-12">
								<div class="form-group row">
									<label class="col-sm-12 text-left control-label col-form-label">Zip*</label>
									<div class="col-sm-12">
										
								<input class="form-control" type="number" name="reg_zip_stdn" id="reg_zip_stdn" placeholder="Zip" value="<?= (isset($emp->reg_zip_stdn) && !empty($emp->reg_zip_stdn)) ? $emp->reg_zip_stdn : set_value('reg_zip_stdn'); ?>" />
								 <span class="error"><?= form_error('reg_zip_stdn'); ?></span>			
									</div>
								</div>
							</div>
							<div class="col-lg-12 col-md-12 col-sm-12">
								<div class="form-group row">
									<label class="col-sm-12 text-left control-label col-form-label">Name*</label>
									<div class="col-sm-12">
										
										<input type="text" class="form-control"  name="reg_fname_stdn" id="reg_fname_stdn" placeholder="Full Name" value="<?= (isset($emp->reg_fname_stdn) && !empty($emp->reg_fname_stdn)) ? $emp->reg_fname_stdn : set_value('reg_fname_stdn'); ?>"/>
								<span class="error"><?= form_error('reg_fname_stdn'); ?></span>                     						   
									</div>
								</div>
							</div>			
							<div class="col-lg-6 col-md-6 col-sm-12">
								<div class="form-group row">
									<label class="col-sm-12 text-left control-label col-form-label">Email*</label>
									<div class="col-sm-12">
									
										<input class="form-control" type="text" name="reg_email_stdn" id="reg_email" value="<?= (isset($emp->reg_email_stdn) && !empty($emp->reg_email_stdn)) ? $emp->reg_email_stdn : set_value('reg_email_stdn'); ?>" placeholder="Email" />
										 <div id="msgemail"></div>
                          
                            <span class="error"><?= form_error('reg_email_stdn'); ?></span>                     						   
									</div>
								</div>
							</div>
							<div class="col-lg-6 col-md-6 col-sm-12">
								<div class="form-group row">
									<label class="col-sm-12 text-left control-label col-form-label">Phone*</label>
									<div class="col-sm-12">
										
										<?php
							if(!empty($phone_code))
							{
								//echo '<span class="phonecode">+'.$phone_code.'</span>';
							}	
								?>
							<input type="text" class="form-control" name="reg_phn_stdn" id="phone" value="<?= (isset($emp->reg_phn_stdn) && !empty($emp->reg_phn_stdn)) ? $emp->phone : set_value('reg_phn_stdn'); ?>"  />                      						   
									</div>
								</div>
							</div>
									<div class="col-lg-12 col-md-12 col-sm-12">
								<div class="form-group row">
									<label class="col-sm-12 text-left control-label col-form-label">Class*</label>
									<div class="col-sm-12">
										
										 <select name="reg_class_stdn" id="reg_class_stdn" class="form-control custom-select">
                                <option value="">Select</option>
								<? if(!empty($cls_st)){?>
								<option value="<? if(!empty($cls_st)){
								echo $cls_st;
								}else{
								echo '';	
								} ?>" <?=((isset($cls_st)) && (set_value('reg_class_stdn'))) ? 'selected' : ''; ?>><? if(!empty($cls_st)){echo $cls_st;} ?></option>
								<? }?>
								
                                <?php 

                    $i = 1;

                    if($year_dtl){

                    foreach($year_dtl as $year_dt){

                      ?>

                      <option value="<?=$year_dt->class_id;?>"><?=$year_dt->class_name;?></option>

                      <?php $i++;}}else{?>                      

                       

                        <option value="">No data find</option>                 

                      

                    <?php } ?>
                      </select>
                     <span class="error"><?= form_error('reg_class_stdn'); ?></span>	                      						   
									</div>
								</div>
							</div>
									
							<div class="col-lg-6 col-md-6 col-sm-12">
								<div class="form-group row">
									<label class="col-sm-12 text-left control-label col-form-label">Password</label>
									<div class="col-sm-12">
										
 <input type="password" name="reg_pwd_stdn" id="reg_pwd_stdn" class="form-control" placeholder="Password" value="<?= (isset($emp->reg_pwd_stdn) && !empty($emp->reg_pwd_stdn)) ? $emp->reg_pwd_stdn : set_value('reg_pwd_stdn'); ?>"/>
								 <span class="error"><?= form_error('reg_pwd_stdn'); ?></span>										
									</div>
								</div>
							</div>
							<div class="col-lg-6 col-md-6 col-sm-12">
								<div class="form-group row">
									<label class="col-sm-12 text-left control-label col-form-label">Confirm Password</label>
									<div class="col-sm-12">
										
										
										 <input type="password" class="form-control" name="reg_cpwd_stdn" id="reg_cpwd_stdn" placeholder="Confirm Password" value="<?= (isset($emp->reg_cpwd_stdn) && !empty($emp->reg_cpwd_stdn)) ? $emp->reg_cpwd_stdn : set_value('reg_cpwd_stdn'); ?>"/>
								<span class="error"><?= form_error('reg_cpwd_stdn'); ?></span>
										</div>
								</div>
							</div>
							<div class="col-lg-12 col-md-12 col-sm-12 text-right">
								<button class="btnBox btForm">Sign Up</button>
							</div>
						</div><!--row end-->
					</div>
					<!--Parents Form Here-->
					<div id="parents" class="sibord"  style="<?if(!empty($is_active1)){
					  echo 'display: block;';  
					  //echo $const;
				   }else{
					 echo 'display: none;';   
				   }
								 
							  ?>">					
						<div class="row">
							<div class="col-lg-6 col-md-6 col-sm-12">
								<div class="form-group row">
									<label class="col-sm-12 text-left control-label col-form-label">Country*</label>
									<div class="col-sm-12">
										
<select id="country1" class="form-control custom-select countries" name ="country1">
							   <option value="">Select Country</option>
							   <? if(!empty($const)){?>
							   <option value="<? if(!empty($const)){
								echo $const[0]->id;
								}else{
								echo '';	
								} ?>" <?=((isset($const)) && (set_value('country1'))) ? 'selected' : ''; ?>><? if(!empty($const)){echo $const[0]->name;} ?></option>
							   <? } ?>
							   </select>							   
							   <span class="error"><?= form_error('country1'); ?></span>  										
									</div>
								</div>
							</div>
							<div class="col-lg-6 col-md-6 col-sm-12">
								<div class="form-group row">
									<label class="col-sm-12 text-left control-label col-form-label">State*</label>
									<div class="col-sm-12">
										
<select name ="state1" id ="state1" class="form-control custom-select states">
							   <option value="">Select State</option>
							   <option value="<? if(!empty($consts)){
								echo $consts[0]->id;
								}else{
								echo '';	
								} ?>" <?=((isset($consts)) && (set_value('state1'))) ? 'selected' : ''; ?>><? if(!empty($consts)){echo $consts[0]->name;} ?></option>
							   
							   </select>
                              <span class="error"><?= form_error('state1'); ?></span>  										
									</div>
								</div>
							</div>
							<div class="col-lg-6 col-md-6 col-sm-12">
								<div class="form-group row">
									<label class="col-sm-12 text-left control-label col-form-label">City*</label>
									<div class="col-sm-12">
										
										<input class="form-control" type="text" name="reg_city" id="reg_city" placeholder="Current City" value="<?= (isset($emp->reg_city) && !empty($emp->reg_city)) ? $emp->reg_city : set_value('reg_city'); ?>"/>
								<span class="error"><?= form_error('reg_city'); ?></span>                     						   
									</div>
								</div>
							</div>
							<div class="col-lg-6 col-md-6 col-sm-12">
								<div class="form-group row">
									<label class="col-sm-12 text-left control-label col-form-label">Zip*</label>
									<div class="col-sm-12">
										
										<input class="form-control" type="number" name="reg_zip" id="reg_zip" placeholder="Zip" value="<?= (isset($emp->reg_zip) && !empty($emp->reg_zip)) ? $emp->reg_zip : set_value('reg_zip'); ?>" />
								 <span class="error"><?= form_error('reg_zip'); ?></span>
							                   						   
									</div>
								</div>
							</div>
							<div class="col-lg-12 col-md-12 col-sm-12">
								<div class="form-group row">
									<label class="col-sm-12 text-left control-label col-form-label">Name*</label>
									<div class="col-sm-12">
										<input class="form-control" type="text" name="reg_fname" id="reg_fname" placeholder="Full Name" value="<?= (isset($emp->reg_fname) && !empty($emp->reg_fname)) ? $emp->reg_fname : set_value('reg_fname'); ?>"/>
								<span class="error"><?= form_error('reg_fname'); ?></span>                     						   
									</div>
								</div>
							</div>
							<div class="col-lg-6 col-md-6 col-sm-12">
								<div class="form-group row">
									<label class="col-sm-12 text-left control-label col-form-label">Email*</label>
									<div class="col-sm-12">
									<input class="form-control" type="text" name="reg_email_prnt" id="reg_email_prnt" value="<?= (isset($emp->reg_email_prnt) && !empty($emp->reg_email_prnt)) ? $emp->reg_email_prnt : set_value('reg_email_prnt'); ?>" placeholder="Email" />
									 <div id="msgemail1"></div>
							<span class="error"><?= form_error('reg_email_prnt'); ?></span>                     						   
									</div>
								</div>
							</div>
							<div class="col-lg-6 col-md-6 col-sm-12">
								<div class="form-group row">
									<label class="col-sm-12 text-left control-label col-form-label">Phone*</label>
									<div class="col-sm-12">
										
										<?php
							if(!empty($phone_code))
							{
								//echo '<span class="phonecode">+'.$phone_code.'</span>';
							}	
								?>
                                <input type="text" class="form-control phone" name="reg_phn" id="reg_phn" placeholder="Phone" value="<?= (isset($emp->reg_phn) && !empty($emp->reg_phn)) ? $emp->reg_phn : set_value('reg_phn'); ?>" min="10"/>
								<span class="error"><?= form_error('reg_phn'); ?></span>
									</div>
								</div>
							</div>
							<div class="col-lg-12 col-md-12 col-sm-12">
								<div class="form-group row">
									<label class="col-sm-2 text-left control-label col-form-label">Childrens*</label>
									<div class="col-sm-12 ew">
										<!-- <input type="number" class="form-control" placeholder="Childrens"> -->
										
										<input id="olympics" type="number" name="reg_cnum"   value="<?= (isset($emp->reg_cnum) && !empty($emp->reg_cnum)) ? $emp->reg_cnum : set_value('reg_cnum'); ?>" min="1"/>
								<span class="error"><?= form_error('reg_cnum'); ?></span>
									</div>
								</div>
							</div>
							<div class="col-lg-6 col-md-6 col-sm-12">
								<div class="form-group row">
									<label class="col-sm-12 text-left control-label col-form-label">Password</label>
									<div class="col-sm-12">
										<input class="form-control" type="password" name="reg_pwd_prnt" id="reg_pwd_prnt" placeholder="Password" value="<?= (isset($emp->reg_pwd_prnt) && !empty($emp->reg_pwd_prnt)) ? $emp->reg_pwd_prnt : set_value('reg_pwd_prnt'); ?>"/>
								<span class="error"><?= form_error('reg_pwd_prnt'); ?></span>                     						   
									</div>
								</div>
							</div>
							<div class="col-lg-6 col-md-6 col-sm-12">
								<div class="form-group row">
									<label class="col-sm-12 text-left control-label col-form-label">Confirm Password</label>
									<div class="col-sm-12">
										
										<input class="form-control" type="password" name="reg_cpwd_prnt" id="reg_cpwd_prnt" placeholder="Confirm Password" value="<?= (isset($emp->reg_cpwd_prnt) && !empty($emp->reg_cpwd_prnt)) ? $emp->reg_cpwd_prnt : set_value('reg_cpwd_prnt'); ?>"/>
								<span class="error"><?= form_error('reg_cpwd_prnt'); ?></span>
										</div>
								</div>
							</div>
							<div class="col-lg-12 col-md-12 col-sm-12 text-right">
								<button class="btnBox btForm">Sign Up</button>
							</div>
						</div><!--row end-->
					</div>
					<div id="institute" class="sibord"  style="<?if(!empty($is_active2)){
					  echo 'display: block;';  
				   }else{
					 echo 'display: none;';   
				   }
								 
							  ?>">
						<div  class="row">
							<div class="col-lg-6 col-md-6 col-sm-12">
								<div class="form-group row">
									<label class="col-sm-12 text-left control-label col-form-label">Country*</label>
									<div class="col-sm-12">
										
<select id="country3" name ="country3" class="form-control custom-select countries">
							   <option value="">Select Country</option>
							   <? if(!empty($const)){?>
							   <option value="<? if(!empty($const)){
								echo $const[0]->id;
								}else{
								echo '';	
								} ?>" <?=((isset($const)) && (set_value('country3'))) ? 'selected' : ''; ?>><? if(!empty($const)){echo $const[0]->name;} ?></option>
							   <? } ?>
							   </select>
							   <span class="error"><?= form_error('country3'); ?></span>  										
									</div>
								</div>
							</div>
							<div class="col-lg-6 col-md-6 col-sm-12">
								<div class="form-group row">
									<label class="col-sm-12 text-left control-label col-form-label">State*</label>
									<div class="col-sm-12">
										
<select name ="state3" id ="state3" class="form-control custom-select states" >
							   <option value="">Select State</option>
							   <option value="<? if(!empty($consts)){
								echo $consts[0]->id;
								}else{
								echo '';	
								} ?>" <?=((isset($consts)) && (set_value('state3'))) ? 'selected' : ''; ?>><? if(!empty($consts)){echo $consts[0]->name;} ?></option>
							   </select>
                                <span class="error"><?= form_error('state3'); ?></span> 										
									</div>
								</div>
							</div>
							<div class="col-lg-6 col-md-6 col-sm-12">
								<div class="form-group row">
									<label class="col-sm-12 text-left control-label col-form-label">City*</label>
									<div class="col-sm-12">
										<input class="form-control" type="text" name="reg_city_ins" id="reg_city_ins" placeholder="Current City" value="<?= (isset($emp->reg_city_ins) && !empty($emp->reg_city_ins)) ? $emp->reg_city_ins : set_value('reg_city_ins'); ?>"/>
								<span class="error"><?= form_error('reg_city_ins'); ?></span>                     						   
									</div>
								</div>
							</div>
							<div class="col-lg-6 col-md-6 col-sm-12">
								<div class="form-group row">
									<label class="col-sm-12 text-left control-label col-form-label">Zip*</label>
									<div class="col-sm-12">
								<input class="form-control" type="number" name="reg_zip_ins" id="reg_zip_ins" placeholder="Zip" value="<?= (isset($emp->reg_zip_ins) && !empty($emp->reg_zip_ins)) ? $emp->reg_zip_ins : set_value('reg_zip_ins'); ?>" />
								 <span class="error"><?= form_error('reg_zip_ins'); ?></span>                     						   
									</div>
								</div>
							</div>
							<div class="col-lg-12 col-md-12 col-sm-12">
								<div class="form-group row">
									<label class="col-sm-12 text-left control-label col-form-label">Institute Name</label>
									<div class="col-sm-12">
										<input class="form-control" type="text" name="reg_instname" id="reg_instname" placeholder="Institute Name" value="<?= (isset($emp->reg_instname) && !empty($emp->reg_instname)) ? $emp->reg_instname : set_value('reg_instname'); ?>"/>                     						   
									</div>
								</div>
							</div>
							<div class="col-lg-6 col-md-6 col-sm-12">
								<div class="form-group row">
									<label class="col-sm-12 text-left control-label col-form-label">Type*</label>
									<div class="col-sm-12">
										
<select class="form-control custom-select" name="inst_cntr_type" id="inst_cntr_type">
                                <option value="">Select</option>
								<? if(!empty($cntr)){?>
								<option value="<? if(!empty($cntr)){
								echo $cntr;
								}else{
								echo '';	
								} ?>" <?=((isset($cntr)) && (set_value('inst_cntr_type'))) ? 'selected' : ''; ?>><? if(!empty($cntr)){echo $cntr;} ?></option>
								<? } ?>
                                 <option value="School">School</option>
								 <option value="College">College</option>
                                 <option value="Tutoring Center">Tutoring Center</option>                                 
                               </select>										
									</div>
								</div>
							</div>
							<div class="col-lg-6 col-md-6 col-sm-12">
								<div class="form-group row">
									<label class="col-sm-12 text-left control-label col-form-label">Designation*</label>
									<div class="col-sm-12">
										
<select class="form-control custom-select" name="inst_dsgn_type" id="inst_dsgn_type">
                                <option value="">Select</option>
								<? if(!empty($desgn)){?>
								<option value="<? if(!empty($desgn)){
								echo $desgn;
								}else{
                                echo '';									
								} ?>" <?=((isset($desgn)) && (set_value('inst_dsgn_type'))) ? 'selected' : ''; ?>><? if(!empty($desgn)){echo $desgn;} ?></option>
								<? } ?>
								<option value="Admin">Admin</option>
								<option value="Principal">Principal</option>
                                <option value="Teacher">Teacher</option>
                                 </select>
							   <span class="error"><?= form_error('inst_dsgn_type'); ?></span>										
									</div>
								</div>
							</div>
							<div class="col-lg-12 col-md-12 col-sm-12">
								<div class="form-group row">
									<label class="col-sm-12 text-left control-label col-form-label">Name*</label>
									<div class="col-sm-12">
										<input class="form-control" type="text" name="reg_fname_ins" id="reg_fname_ins" placeholder="Full Name" value="<?= (isset($emp->reg_fname_ins) && !empty($emp->reg_fname_ins)) ? $emp->reg_fname_ins : set_value('reg_fname_ins'); ?>"/>
								<span class="error"><?= form_error('reg_fname_ins'); ?></span>                     						   
									</div>
								</div>
							</div>
							<div class="col-lg-6 col-md-6 col-sm-12">
								<div class="form-group row">
									<label class="col-sm-12 text-left control-label col-form-label">Email*</label>
									<div class="col-sm-12">
										<input class="form-control" type="text" name="reg_email_ins" id="reg_email_ins" value="<?= (isset($emp->reg_email_ins) && !empty($emp->reg_email_ins)) ? $emp->reg_email_ins : set_value('reg_email_ins'); ?>" placeholder="Email" />
										 <div id="msgemail2"></div>
							<span class="error"><?= form_error('reg_email_ins'); ?></span>                     						   
									</div>
								</div>
							</div>
							<div class="col-lg-6 col-md-6 col-sm-12">
								<div class="form-group row">
									<label class="col-sm-12 text-left control-label col-form-label">Phone*</label>
									<div class="col-sm-12">
										<?php
							if(!empty($phone_code))
							{
								//echo '<span class="phonecode">+'.$phone_code.'</span>';
							}	
								?>
                                <input class="form-control" type="text" class="phone" name="reg_phn_ins" id="reg_phn_ins" placeholder="Phone" value="<?= (isset($emp->reg_phn_ins) && !empty($emp->reg_phn_ins)) ? $emp->reg_phn_ins : set_value('reg_phn_ins'); ?>"/>
								<span class="error"><?= form_error('reg_phn_ins'); ?></span>                     						   
									</div>
								</div>
							</div>
							<div class="col-lg-6 col-md-6 col-sm-12">
								<div class="form-group row">
									<label class="col-sm-12 text-left control-label col-form-label">Password</label>
									<div class="col-sm-12">
								<input class="form-control" type="password" name="reg_pwd_ins" id="reg_pwd_ins" placeholder="Password" value="<?= (isset($emp->reg_pwd_ins) && !empty($emp->reg_pwd_ins)) ? $emp->reg_pwd_ins : set_value('reg_pwd_ins'); ?>"/>
								<span class="error"><?= form_error('reg_pwd_ins'); ?></span>                     						   
									</div>
								</div>
							</div>
							<div class="col-lg-6 col-md-6 col-sm-12">
								<div class="form-group row">
									<label class="col-sm-12 text-left control-label col-form-label">Confirm Password</label>
									<div class="col-sm-12">
										
										<input class="form-control" type="password" name="reg_cpwd_ins" id="reg_cpwd_ins" placeholder="Confirm Password" value="<?= (isset($emp->reg_cpwd_ins) && !empty($emp->reg_cpwd_ins)) ? $emp->reg_cpwd_ins : set_value('reg_cpwd_ins'); ?>"/>
								<span class="error"><?= form_error('reg_cpwd_ins'); ?></span>
										</div>
								</div>
							</div>
							<div class="col-lg-12 col-md-12 col-sm-12 text-right">
								<button class="btnBox btForm">Sign Up</button>
							</div>
						</div><!--row end-->
					</div>	
				</div>
				<!--Right summary Box-->
				<div class="col-lg-3 col-md-3 repBox">
					<div class="summaryBox">
						<h3>Purchase summary</h3>
						<ul>
							<li><a href="roster.php">Roster</a></li>
							<li><a href="students-quickview.php">STUDENTS QUICKVIEW</a></li>
							<li><a href="score-grid.php">SCORE GRID</a></li>
							<li><a href="add-syllabus.php">ADD SYLLABUS</a></li>
							<li><a href="syllabus-list.php">SYLLABUS LIST</a></li>
							<li><a href="add-syllabus-skills.php">ADD SYLLABUS SKILLS</a></li>
						</ul>
					</div>
				</div>
			</div>
			
			</form>
			
		</div>
	</section>

<?php /*?><script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script><?php */?>
<script src="<?= base_url('assets/build/js/intlTelInput.js')?>"></script>
<script type="text/javascript">

jQuery(document).ready(function(){

    jQuery('#reg_email,#reg_email_prnt,#reg_email_ins').blur(function(){
		
		var rt = $("input[name='etype']:checked").val();
		
		var email;
		if(rt=='pwov'){
		email=jQuery('#reg_email').val();
     jQuery.post('<?=base_url('useremailcheck1');?>',{email:email},function(result){
           if(result=="<span style='color:green'>You can register with us.</span>")
           {
            jQuery('.button-org').removeAttr('disabled');
            jQuery( "#msgemail" ).html(result);
			
           }else{
            jQuery('.button-org').prop('disabled','true');
            jQuery( "#msgemail" ).html(result);
			
           }
          
		   console.log(result);
        });		
		}else if(rt=='pwv'){
		 email=jQuery('#reg_email_prnt').val();
		 jQuery.post('<?=base_url('useremailcheck1');?>',{email:email},function(result){
           if(result=="<span style='color:green'>You can register with us.</span>")
           {
            jQuery('.button-org').removeAttr('disabled');
            jQuery( "#msgemail1" ).html(result);
			
           }else{
            jQuery('.button-org').prop('disabled','true');
            jQuery( "#msgemail1" ).html(result);
			
           }
          
		   console.log(result);
        });
			
		}else if(rt=='pwvi'){
			email=jQuery('#reg_email_ins').val();
			jQuery.post('<?=base_url('useremailcheck1');?>',{email:email},function(result){
           if(result=="<span style='color:green'>You can register with us.</span>")
           {
            jQuery('.button-org').removeAttr('disabled');
            jQuery( "#msgemail2" ).html(result);
			
           }else{
            jQuery('.button-org').prop('disabled','true');
            jQuery( "#msgemail2" ).html(result);
			
           }
          
		   console.log(result);
        });
		}
		//console.log(rt);
		
	//var email=$('#reg_email').val();
    // jQuery.post('<?=base_url('useremailcheck1');?>',{email:email},function(result){
           // if(result=="<span style='color:green'>You can register with us.</span>")
           // {
            // jQuery('.button-org').removeAttr('disabled');
            // jQuery( "#msgemail" ).html(result);
			// jQuery( "#msgemail" ).html(result);
			// jQuery( "#msgemail" ).html(result);
           // }else{
            // jQuery('.button-org').prop('disabled','true');
            // jQuery( "#msgemail" ).html(result);
			// jQuery( "#msgemail" ).html(result);
			// jQuery( "#msgemail" ).html(result);
           // }
          
		   // console.log(result);
        // });
    }); 

    jQuery("input[name='etype']:radio")
    .change(function() {
      jQuery("#students").toggle($(this).val() == "pwov");
      jQuery("#parents").toggle($(this).val() == "pwv");
	  jQuery("#institute").toggle($(this).val() == "pwvi");
      
});


// $(document).on('change','.countries',function(){           
            
            // var id = $("#countryId").val();
            // /* added $("option:selected", this).text() == 'BD - Team Member' as extra field*/
            
            
                // $.ajax({
                    // type: 'post',
                    // url: '<?=base_url('unieducation/all_states_list/');?>',
                    // crossDomain: true,
                    // data:{country_id:id},
                    // dataType: 'json', 
                    // success: function (data) {
						// console.log(data);
                        // if (data.success == true)
                        // {
                            // $.each(data.state_lst, function (item, i) {
                                // $('.states').append('<option value="' + i.id + '">' + i.name +'</option>');
                            // });
							// $(".states").prop("disabled",false);
                            
                            
                        // }
                    // }
                // });
            
        // });
	
	
	
	
});
</script>
<!--script language="javascript">
	populateCountries("country", "state");
    populateCountries("country1", "state1");
    populateCountries("country3", "state3");
	// first parameter is id of country drop-down and second parameter is id of state drop-down
	populateCountries("country2");
	populateCountries("country2");
</script-->
<script>
function ajaxCall() {
        this.send = function(data, url, method, success, type) {
          type = type||'json';
          var successRes = function(data) {
              success(data);
          }

          var errorRes = function(e) {
              console.log(e);
              alert("Error found \nError Code: "+e.status+" \nError Message: "+e.statusText);
          }
            $.ajax({
                url: url,
                type: method,
                data: data,
                success: successRes,
                error: errorRes,
                dataType: type,
                timeout: 60000
            });

          }

        }

function locationInfo() {
    //var rootUrl = "apiv1.php";
    var call = new ajaxCall();
	
    this.getStates = function(id) {
        $(".states option:gt(0)").remove();       
        var url1 = '<?=base_url('unieducation/all_states_list/');?>';
        var method = "post";
        var data = {country_id:id};
        $('.states').find("option:eq(0)").html("Please wait..");
        call.send(data, url1, method, function(data) {
            $('.states').find("option:eq(0)").html("Select State");
            if(data.success == true){
                $.each(data.state_lst, function (item, i) {
                                $('.states').append('<option value="' + i.id + '">' + i.name +'</option>');
                            });
                $(".states").prop("disabled",false);
            }
            else{
                alert(data.msg);
            }
        }); 
    };

    this.getCountries = function() {
        var url = '<?=base_url('unieducation/all_country_list');?>';
        var method = "post";
        var data = {};
        $('.countries').find("option:eq(0)").html("Please wait..");
        call.send(data, url, method, function(data) {
            $('.countries').find("option:eq(0)").html("Select Country");
            console.log(data);
            if(data.success == true){
                $.each(data.country_lst, function (item, i) {
					if(i.id == '<?php echo $ip_country;?>')
					{
						var selecedval=' selected';
						var loc = new locationInfo();
						 loc.getStates(<?php echo $ip_country;?>);
					}
					else
					{
						var selecedval='';
					}
                                $('.countries').append('<option value="' + i.id + '" '+selecedval+'>' + i.name +'</option>');
                            });
                $(".countries").prop("disabled",false);
            }
            else{
                alert(data.msg);
            }
        }); 
    };

}

$(function() {
var loc = new locationInfo();
loc.getCountries();
 $(".countries").on("change", function(ev) {
        var countryId = $(this).val()
        if(countryId != ''){
        loc.getStates(countryId);
		//alert('test4');
		//$("#phone").intlTelInput({autoPlaceholder: "Tel"});
		
        }
        else{
            $(".states option:gt(0)").remove();
        }
    });
 // $(".states").on("change", function(ev) {
        // var stateId = $(this).val()
        // if(stateId != ''){
        // loc.getCities(stateId);
        // }
        // else{
            // $(".cities option:gt(0)").remove();
        // }
    // });
});

</script>


<script type="text/javascript">
$(document).ready(function () {
    $("#reg_cnum").keydown(function (e) {
        if (e.shiftKey) e.preventDefault();
        else {
            var nKeyCode = e.keyCode;
            //Ignore Backspace and Tab keys
            if (nKeyCode == 8 || nKeyCode == 9) return;
            if (nKeyCode < 95) {
                if (nKeyCode < 48 || nKeyCode > 57) e.preventDefault();
            } else {
                if (nKeyCode < 96 || nKeyCode > 105) e.preventDefault();
            }
        }
    });
});
</script>

<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.14.10/jquery.mask.js"></script>

<script type="text/javascript">
/* $(".phone").keyup(function() {
	//var number = $(this).val().replace(/[^\d]/g, '');
    //$(this).val(number.replace(/^(\d{3})(\d{3})(\d)+$/, "$1-$2-$3"));
	
	var number = $(this).val().replace(/[^\d]/g, '')
    if (number.length == 7) {
      number = number.replace(/(\d{3})(\d{4})/, "$1-$2");
    } else if (number.length == 10) {
      number = number.replace(/(\d{3})(\d{3})(\d{4})/, "$1-$2-$3");
     
    }
    $(this).val(number)
    $(".phone").attr({ maxLength : 10 });
}); */
</script>
 

  <script>
   $("#phone").intlTelInput({preferredCountries: ['<?php echo strtolower($shortname);?>']});

   $("#reg_phn").intlTelInput({preferredCountries: ['<?php echo strtolower($shortname);?>']});
    $("#reg_phn_ins").intlTelInput({preferredCountries: ['<?php echo strtolower($shortname);?>']});
/*     var input = document.querySelector("#phone");
    window.intlTelInput(input, {
    //allowDropdown: true,
      // autoHideDialCode: false,
      // autoPlaceholder: "off",
     // dropdownContainer: document.body,
      // excludeCountries: ["us"],
      formatOnDisplay: true,
      // geoIpLookup: function(callback) {
      //   $.get("http://ipinfo.io", function() {}, "jsonp").always(function(resp) {
      //     var countryCode = (resp && resp.country) ? resp.country : "";
      //     callback(countryCode);
      //   });
      // },
       //hiddenInput: "full_number",
     //initialCountry: "auto",
      // localizedCountries: { 'in': 'India' },
      // nationalMode: false,
      // onlyCountries: ['us', 'gb', 'ch', 'ca', 'do'],
      //placeholderNumberType: "MOBILE",
       preferredCountries: ['<?php echo $shortname;?>'],
       separateDialCode: true,
      utilsScript: "build/js/utils.js",
    });
	
	var input1 = document.querySelector("#reg_phn");
    window.intlTelInput(input1, {
    //allowDropdown: true,
      // autoHideDialCode: false,
      // autoPlaceholder: "off",
     // dropdownContainer: document.body,
      // excludeCountries: ["us"],
      formatOnDisplay: true,
      // geoIpLookup: function(callback) {
      //   $.get("http://ipinfo.io", function() {}, "jsonp").always(function(resp) {
      //     var countryCode = (resp && resp.country) ? resp.country : "";
      //     callback(countryCode);
      //   });
      // },
       //hiddenInput: "full_number",
     //initialCountry: "auto",
      // localizedCountries: { 'in': 'India' },
      // nationalMode: false,
      // onlyCountries: ['us', 'gb', 'ch', 'ca', 'do'],
      //placeholderNumberType: "MOBILE",
       preferredCountries: ['<?php echo $shortname;?>'],
       separateDialCode: true,
      utilsScript: "build/js/utils.js",
    });
	
	var input2 = document.querySelector("#reg_phn_ins");
    window.intlTelInput(input2, {
    //allowDropdown: true,
      // autoHideDialCode: false,
      // autoPlaceholder: "off",
     // dropdownContainer: document.body,
      // excludeCountries: ["us"],
      formatOnDisplay: true,
      // geoIpLookup: function(callback) {
      //   $.get("http://ipinfo.io", function() {}, "jsonp").always(function(resp) {
      //     var countryCode = (resp && resp.country) ? resp.country : "";
      //     callback(countryCode);
      //   });
      // },
       //hiddenInput: "full_number",
     //initialCountry: "auto",
      // localizedCountries: { 'in': 'India' },
      // nationalMode: false,
      // onlyCountries: ['us', 'gb', 'ch', 'ca', 'do'],
      //placeholderNumberType: "MOBILE",
       preferredCountries: ['<?php echo $shortname;?>'],
       separateDialCode: true,
      utilsScript: "build/js/utils.js",
    }); */
  </script>

