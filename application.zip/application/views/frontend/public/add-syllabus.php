	
	<section class="bannerSec subBann innerPage">		
		<div class="">
			<div class="container">
				<div class="innerBox">
					<h1>Add syllabus</h1>										
				</div>				
			</div>
		</div>
	</section>
		 
	<section class="sinUpBox">
		<div class="container">
		   <?php

        if($this->session->flashdata('msg'))
        {?>
            <div id="msg" style="border: 1px solid;height: 34px;box-shadow: aquamarine;box-shadow: 0px 0px 0px 1px black;">
            <?PHP
            echo "<span> ".$this->session->flashdata('msg')."</span>";
       
          ?></div> <?PHP }?>
			<div class="row">
				<!--Left Box-->
				<div class="col-lg-12">
					<!--Form Box-->
					<div id="students" class="sibord"  style="display:block;">
					<form  method="post" action="">
						<div class="row">
							<div class="col-lg-4 col-md-4 col-sm-12">
								<div class="form-group row">
									<label class="col-sm-12 text-left control-label col-form-label">Syllabus name*</label>
									<div class="col-sm-12">
										<input type="text" name="syllb_name" id="syllb_name" class="form-control" placeholder="Please Enter Syllabus Name">
										
										<span class="danger-error"><?=form_error('syllb_name')?></span>                     						   
									</div>
								</div>
							</div>						
						
							<div class="col-lg-4 col-md-4 col-sm-12">
								<div class="form-group row">
									<label class="col-sm-12 text-left control-label col-form-label">Subject*</label>
									<div class="col-sm-12">
										<select class="form-control custom-select" name="class_type" id="class_type">
											<option value="">Select</option>
											<option value="math">Math</option>
											<option value="english">English</option>
											<option value="chinees">Chinees</option>
										</select>
										<span class="danger-error"><?=form_error('class_type')?></span>                      						   
									</div>
								</div>
							</div>
							<div class="col-lg-4 col-md-4 col-sm-12">
								<div class="form-group row">
									<label class="col-sm-12 text-left control-label col-form-label">Class Name*</label>
									<div class="col-sm-12">
										<select class="form-control custom-select" name="class_name" id="class_role">
											<option value="">Select</option>
											 <?php  
											$i = 1;
											if($year_dtl){
											foreach($year_dtl as $year_dt){
											  ?>
											<option value="<?=$year_dt->class_id;?>"><?=$year_dt->class_name;?></option>
											<?php $i++;}}else{?>                      
                                           <option value="">No data find</option>
                                          <?php } ?>							
										</select>
										<span class="danger-error"><?=form_error('class_name')?></span>                      						   
									</div>
								</div>
							</div>
							
							<div class="col-lg-12 col-md-12 col-sm-12 text-right">
								<button type="submit" name="submit" class="btnBox btForm">Add</button>
							</div>
						</div><!--row end-->
						</form>
					</div>				
			</div><!--row end-->
		</div>
	</section>
<script type="text/javascript">

jQuery(document).ready(function(){
	
    //05-02-19
    $(document).on('change','#class_type',function(){
            var cls_type = $("option:selected", this).text();
			var c_type = $("#class_type").val();
                        
			$('#div_cls_type').append('<input type="hidden" name="cls_type1" id="type_id1" value="'+c_type+'">');
           //$('#div_cls_type').val(c_type);
		   });   

   //05-02-19
    $(document).on('change','#class_role',function(){
            var cls_name = $("option:selected", this).text();
			var t_name = $("#t_name").val();
            var cls_id = $("#class_role").val();
            var ctype_id1 = $("#type_id1").val(); 			
            			
			$('#subclass_div').append('<input type="hidden" name="cls_id" id="cls_id1" value="'+cls_id+'"><input type="hidden" name="clstype_id" id="clstype_id1" value="'+ctype_id1+'">');
           });   
});


function ajaxSearch()
{   var cls_id = $("#cls_id1").val();
    var cls_id_type = $("#clstype_id1").val();    	
    var input_data = $('#t_name').val();
	//console.log(cls_id_type);  

    if (input_data.length === 0)
    {
        $('#suggestions').hide();
    }
    else
    {

        var post_data = {
            'search_data': input_data,
            'id':cls_id,
			'cls_type':cls_id_type
            };

        $.ajax({
            type: "POST",
            url: "<?php echo base_url('classnamecheck'); ?>",
            data: post_data,
            success: function (data) {
                // return success
                if (data.length > 0) {
                    $('#suggestions').show();
                    $('#autoSuggestionsList').addClass('auto_list');
                    $('#autoSuggestionsList').html(data);
                }
            }
         });

     }
 }	
</script>