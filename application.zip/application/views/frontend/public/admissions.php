<?php 
if($this->session->userdata('user_id')!='')
{

	include(APPPATH.'/views/frontend/private/header.php');
	
}
else
{
	include('header.php');
}	
?>
<section id="title-inner" style="background-image:url(<?= base_url('assets/images/admission.jpg')?>);">
<div id="large-header">   
<canvas id="demo-canvas"></canvas>
<div class="container">
<div class="text-tit">
 <div class="bb"></div>
<span class="lefttop-icon"></span>
<h1>
<span>Admission</span>
</h1>
<span class="rightbotm-icon"></span>
</div>

</div></div>

</section>

 <!-- Page Content inner -->
  <section class="about_content content-text space-75">
 <div class="container">
 <div class="row">
 
 <div class="col-xs-12 col-sm-12 col-md-7 col-lg-7">
 <p>Our schedule is based on local school term time table and students will attend our class weekly</p>
<h2>Class: Kindergarten to Year 13</h2>
<p>(Note to parents: Currently we only offer English classes from year 1 to year 8. We will make announcement once other years are also opened for enrolment.)</p>
<p>Tuition fee：$25 per lesson (60 min) </p>
<p>We accept payment from paying for each lesson (no less than 48 hours of the class commencing) up to a maximum period of one school term. </p>
<ul>
<li>
Term 1:  Monday 4 February – Saturday 13 April
</li>
<li>
Term 2:  Monday 29 April – 6 July
</li>
<li>
Term 3:  Monday 22 July – Saturday 28 September
</li>
<li>
Term 4:  Monday 14 October – Saturday 21 December
</li>
</ul>

<p>There will be no regular class during term break but we may have special classes’ arrangement (e.g. revision session, catch up session). You may keep an eye on our email communications.  </p>

<p>* MY UNI IS CLOSED ON THE FOLLOWING DAYS FOR 2019. You may attend makeup classes in any of our centres in the same week based on availability. Please contact our staff during our opening hours.*</p>

<p></p>

<ul>
<li>
<strong>New Year’s Day:</strong> Tuesday 1 January (term break)
</li>
<li>
<strong>Day after New Year’s Day:</strong> Tuesday 2 January (term break)
</li>
<li>
<strong>Auckland Anniversary Day:</strong> Monday 28 January (term break)
</li>
<li>
<strong>Waitangi Day:</strong>Wednesday 6 February (Term 1)
</li>

<li>
<strong>Good Friday:</strong>Friday 19 April (term break)
</li>

<li>
<strong>Easter Monday:</strong>Monday 22 April (term break)
</li>

<li>
<strong>ANZAC Day:</strong>Thursday 25 April (term break)
</li>
<li>
<strong>Queen’s Birthday:</strong>Monday 3 June (term 2)
</li>
<li>
<strong>Labour Day:</strong>Monday 28 October (term 4)
</li>
<li>
<strong>Christmas Day: </strong>Wednesday 25 December (term break)
</li>
<li>
<strong>Boxing Day: </strong>Thursday 26 December (term break)
</li>

</ul>
 </div>
 
 <div class="col-xs-12 col-sm-12 col-md-5 col-lg-5">
 <div class="img-hvr"><img src="<?= base_url('assets/images/who-we-are.jpg')?>" alt="" title="" /></div>
 </div>
 
 </div>
 </div>
 </section>
 
   <section class="about_content content-text space-75">
 <div class="container">
 <div class="row">
 
 <div class="col-xs-12 col-sm-12 col-md-7 col-lg-7">
<h2>Enrolment and payment can all be completed online. Just a few easy steps and you will be enrolled with us!</h2>

<ul>
<li>
Parents will first need to <a href="<?php echo base_url().'register';?>">register</a> an account on our website  </li>
<li>
Once your account is set up,you may login to our website. Go to <a href="<?php echo base_url().'booking-payment';?>">Booking & Payment</a>  and select your child’s desired classes based on our schedule. In general, our classes operate from 3:30 pm – 6:00 pm on weekdays and 10:00 am – 5:30 pm on Saturdays. You can select credit card, debit card or PayPal for payment.
</li>
<li>
If you need to change any confirmed class, you may do so via our <a href="<?php echo base_url().'booking-payment';?>">Booking & Payment </a> 48 hours ahead of the class commencin. There will be no refund for no-show or failing to reschedule before 48 hours of the class commencing.
</li>
<li>
Email confirmation and class reminder will be sent out before class.
</li>

<li>
Email confirmation and class reminder will be sent out before class.
</li>
</ul>



<p></p>

</div>
 
 <div class="col-xs-12 col-sm-12 col-md-5 col-lg-5">
 <div class="img-hvr"><img src="<?= base_url('assets/images/who-we-are.jpg')?>" alt="" title="" /></div>
 </div>
 
 </div>
 </div>
 </section>
 
 
 
 


 
   
   
   
   
   
   <section class="white-sec space-75">
   <div class="container">

   <div class="content-text">
   

<div class="row">
<div class="col-xs-12 col-sm-6 col-md-3 col-lg-3">
<div class="trainers_box">
<div class="icon-circle">
<img  src="<?= base_url('assets/images/kids-trdined.png')?>" alt="" />
</div>
<h3>3,000+</h3>
<h4>Kids Trained</h4>

</div>
</div>
<div class="col-xs-12 col-sm-6 col-md-3 col-lg-3">
<div class="trainers_box">
<div class="icon-circle">
<img  src="<?= base_url('assets/images/qualified-trainers.png')?>" alt="" />
</div>
<h3>410+</h3>
<h4>Qualified Trainers</h4>

</div>
</div>
<div class="col-xs-12 col-sm-6 col-md-3 col-lg-3">
<div class="trainers_box">
<div class="icon-circle">
<img  src="<?= base_url('assets/images/skills.png')?>" alt="" />
</div>
<h3>190+</h3>
<h4>Skills</h4>

</div>
</div>
<div class="col-xs-12 col-sm-6 col-md-3 col-lg-3">
<div class="trainers_box">
<div class="icon-circle">
<img  src="<?= base_url('assets/images/global-accreditations.png')?>" alt="" />
</div>
<h3>120+</h3>
<h4>Global Accreditations</h4>

</div>
</div>
</div>

</div>
</div>
   </section>
    
 <!-- Page Content End -->
<?php 
if($this->session->userdata('user_id')!='')
{
	include(APPPATH.'/views/frontend/private/footer.php');
}
else
{
	include('footer.php');
}	
?>