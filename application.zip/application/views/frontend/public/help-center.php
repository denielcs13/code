

<section id="title-inner" style="background-image:url(<?= base_url('assets/images/help-center.jpg')?>);">
<div id="large-header">   
<canvas id="demo-canvas"></canvas>
<div class="container">
<div class="text-tit">
 <div class="bb"></div>
<span class="lefttop-icon"></span>
<h1>
<span>Help Center</span>
</h1>
<span class="rightbotm-icon"></span>
</div>

</div></div>

</section>

 <!-- Page Content inner -->
 
 <section class="about_content content-text space-75">
 <div class="container">
 <div class="row">
 
 <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut sodales gravida ante, id semper nisl mollis quis. Proin quam mauris
rhoncus vel dignissim sed, rhoncus ac elit. Vivamus tristique nisi id elit adipiscing ultricies. </p>

<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut sodales gravida ante, id semper nisl mollis quis. Proin quam mauris
rhoncus vel dignissim sed, rhoncus ac elit. Vivamus tristique nisi id elit adipiscing ultricies. </p>

<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut sodales gravida ante, id semper nisl mollis quis. Proin quam mauris
rhoncus vel dignissim sed, rhoncus ac elit. Vivamus tristique nisi id elit adipiscing ultricies. </p>

<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut sodales gravida ante, id semper nisl mollis quis. Proin quam mauris
rhoncus vel dignissim sed, rhoncus ac elit. Vivamus tristique nisi id elit adipiscing ultricies. </p>
 </div>
 
 
 
 
 </div>
 </div>
 </section>
