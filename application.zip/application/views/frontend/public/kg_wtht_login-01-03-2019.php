<?php include('header.php'); ?>
<?php  $img=ucfirst($year_dtl->class_slug.'_bg.jpg');?>
<?php
if($this->session->userdata('loginyear')!="")
{
	$years=explode(',',$this->session->userdata('loginyear'));
	if(!in_array($year_id,$years))
	{
		redirect(base_url().'dashboard');
		exit;
	}
}
?>
<section id="title-inner" style="background-image:url(<?= base_url('assets/images/'.$img)?>);">
  <div id="large-header">
    <canvas id="demo-canvas"></canvas>
    <div class="container">
      <div class="text-tit">
        <div class="bb"></div>
        <span class="lefttop-icon"></span>
        <h1> <span><?php echo $year_dtl->class_name;?></span> </h1>
        <span class="rightbotm-icon"></span> </div>
    </div>
  </div> 
</section>


<!-- Page Content inner -->

<section class="about_content content-text syllabus-page space-75">
  <div class="container">
      <!-- Bootstrap Tabs -->
      
      <div class="tab-content">
        <?php 
		
		$res=$this->db->query('select * from master_syllabus where class_id="'.$year_id.'" order by term_id,skill_order ASC');
		 $SylList= $res->result();
		$array_term=array();
		$array_skill=array();
		
      if($SylList != null && $SylList != ""){
			global $order_arr;
			$tid=0;$wid=0;
			$aveageweek=0;
			foreach($SylList as $result){
			if(!in_array($result->term_id,$array_term)){
				
			?>
        <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
         <!-- <h2 class="blue-title">Term <?php echo $result->term_id;?></h2>-->
          <div class="row">
            <?php 
				}
				$term= $this->main_model->get_detail('master_terms','term_id',$result->term_id);
				$skl_dtl= $this->main_model->get_detail('master_skill','skill_id',$result->skill_id);
				$query=$this->db->query('select * from syllabus_week_subskill where skill_id = "'.$result->skill_id.'" and term_id="'.$result->term_id.'" order by subskill_order'); 
				$ct2= $query->num_rows();
				$comp2=0;

	?>
            <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
              <div class="syllabus-sec">
			 
                <h3><?php echo $order_arr[$result->skill_order].'. '.$skl_dtl->skill_name;?></h3>
			
                <div class="row">
               


                </div>
              </div>
            </div>
          <?php
		  if(!in_array($result->term_id,$array_term)){
				$array_term[]=$result->term_id;?>
          </div>
        </div>
		  <?PHP } } ?>
     <?PHP } ?>
   
      
      </div>

	  
	  
	  
	  
  </div>
</section>
<?php include('footer.php'); ?>
