
<section id="title-inner" style="background-image:url(<?= base_url('assets/images/Testomonials.jpg')?>);">
<div id="large-header">   
<canvas id="demo-canvas"></canvas>
<div class="container">
<div class="text-tit">
 <div class="bb"></div>
<span class="lefttop-icon"></span>
<h1>
<span>Testimonials</span>
</h1>
<span class="rightbotm-icon"></span>
</div>

</div></div>

</section>

 <!-- Page Content inner -->
 
 
 <section class="about_content content-text testimonial space-75">
 <div class="container">
 <div class="row">
 <div class="col-xs-12 col-sm-12 col-md-6 col-lg-6 col-xl-6">
                  <div class="testimonial_content">
                      <div class="test">
                        <p>The homework really makes me learn alot.  Really enjoy coming to the class every week.</p>
                         <h4>Hilton S.</h4>
                      </div>

                  </div>
              </div>
              
<div class="col-xs-12 col-sm-12 col-md-6 col-lg-6 col-xl-6">
                  <div class="testimonial_content">
                      <div class="test">
                        <p>We both learn alot from The University of Maths. A good place to learn Maths.</p>
                                  <h4>Evans T. & Sally T.</h4>
                      </div>
            
                  </div>
              </div>
              
<div class="col-xs-12 col-sm-12 col-md-6 col-lg-6 col-xl-6">
                  <div class="testimonial_content">
                      <div class="test">
                        <p>My Maths has improved considerably since I joined the class at The University of Maths.</p>
                         <h4>Charlotte M.</h4>
                      </div>
                      
                  </div>
              </div>
              
  <div class="col-xs-12 col-sm-12 col-md-6 col-lg-6 col-xl-6">
                  <div class="testimonial_content">
                      <div class="test">
                        <p>Interesting to learn Maths this way.  Nowadays, I can do my Maths homework everyday through The University of Maths website.</p>
                         <h4>Gabriel S.</h4>
                      </div>
                      
                  </div>
              </div>
              
              
               <div class="col-xs-12 col-sm-12 col-md-6 col-lg-6 col-xl-6">
                  <div class="testimonial_content">
                      <div class="test">
                        <p>Classroom and homework exercises really help me alot.  I can start to teach my classmates during Maths sessions.</p>
                         <h4>Stephen K.</h4>
                      </div>

                  </div>
              </div>
              
<div class="col-xs-12 col-sm-12 col-md-6 col-lg-6 col-xl-6">
                  <div class="testimonial_content">
                      <div class="test">
                        <p>Really appreciate those teaching staffs and I really learn alot of Maths in just a couple of weeks.</p>
                                  <h4>Jayden M.</h4>
                      </div>
            
                  </div>
              </div>
              

              
  
              </div>
              
              <?php /*?><div class="row">
 <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
 <ul class="pagination float-right">
 <li><a href="#">1</a></li>
 <li><a href="#">2</a></li>
 <li><a href="#">3</a></li>
 <li><a href="#">4</a></li>
 <li><a href="#">5</a></li>
 <li><a href="#">Next</a></li>
 </ul>
 </div>
 </div><?php */?>
 </div>
 </section>
 