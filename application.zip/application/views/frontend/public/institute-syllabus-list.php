
	<section class="bannerSec subBann innerPage">		
		<div class="">
			<div class="container">
				<div class="innerBox">
					<h1>Syllabus List</h1>										
				</div>				
			</div>
		</div>
	</section>
	
   <script> 
 function cnfdel(id){
		var url="<?php echo base_url().'delete-inst-syllabus/';?>";
	   if (confirm("Are you sure want to delete this Syllabus?")) {
       window.location.href = url+"/"+id;
		}
    return false;
 }
 </script>
 
	<section class="rosterBox">
		<div class="container">
		<?php 
						if($this->session->flashdata('msgdelinst') != null && $this->session->flashdata('msgdelinst') != "")
							{ 
							?>
							<div class="row">
								<div class="col-md-12">									
									<?php echo $this->session->flashdata('msgdelinst');?>
								</div>
							</div>
							<?php 
							} else if($this->session->flashdata('msgadd') != null && $this->session->flashdata('msgadd') != "")
							{ 
							?>
							<div class="row">
								<div class="col-md-12">
									<div class="alert" role="alert">
									<?php echo $this->session->flashdata('msgadd');?>
									</div>
								</div>
							</div>
							<?php 
							} 
						?>
			<div class="row">
				<div class="col-lg-12">
					<h2>Syllabus List</h2>						
				</div>								
			</div>
			<div class="row">
			<div class="col-md-12">	
			<span class="mecBox" style="float: right;">			    			      <a href="<?=base_url('add-syllabus');?>" name="add_stud"  class="btn-mn btn-3 btn-3e mts">Add Syllabus</a>				 			   </span>
			</div>
			</div>
			<div class="row mt-4">
				
				<div class="col-lg-12 rostForm">					
					<div class="table-responsive-md">
						<table class="table table-bordered">
							<thead>
								<tr>
									<th class="text-center">#</th>
									<th>Name</th>
									<th>Class</th>
									<th>Subject	</th>
									<th class="text-center">Skill</th>
									<th class="text-center">Action</th>									
								</tr>
							</thead>
							<tbody>
							<?php 
										$i = 1;
										if($syl_lst){
										foreach($syl_lst as $syl_ls){
											?>
								<tr>
									<td class="text-center"><?php echo $i;?></td>
									<td><?php echo $syl_ls->syllb_name;?></td>
									<td><?php 
									 if($syl_ls->year_id=='1'){
									 echo "Kindergarten";
									 }else {
										echo "Year ".($syl_ls->year_id - 1); 
									 }
									 ?></td>
									<td><?php echo ucfirst($syl_ls->subject);?></td>
									<td class="text-center"><a href="<?=base_url('add-syllabus-skills/'.$syl_ls->sid);?>" data-title="Add Skill"><i class="fa fa-plus"></i></a> | <a href="<?=base_url('inst-syllabus-skills/'.$syl_ls->sid);?>" data-title="View Skill"><i class="fa fa-eye"></i></a></td>
									<td class="text-center"><a href="javascript:void(0)" onclick="cnfdel(<?php echo $syl_ls->sid;?>)" data-title="Delete"><i class="fa fa-trash"></i></a></td>
								</tr>
								<?php $i++;}}else{?>
											
										    <tr>
												<td colspan="5">No record found</td>
                                              
                                            </tr>
											
										<?php } ?>
								
							</tbody>							
						</table>
					</div>
				</div>
			</div>
		</div>
	</section>
