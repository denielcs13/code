
	<section class="bannerSec subBann innerPage">		
		<div class="">
			<div class="container">
				<div class="innerBox">
					<h1><?php echo $syllinfo->syllb_name;?></h1>										
				</div>
			</div>
		</div>
	</section>
	
	<section class="box">
		<div class="container">
          	<!-- Bootstrap Tabs -->		
            <div class="tab-content">
               <div class="row">
               <?php
			  $i=0;
			$x='A';
			
			$main_parent='';
			    foreach($ques_lst as $ques_ls)
				{
					$parentid=$ques_ls->skill_parent;
					if($parentid != $main_parent)
					{
						
						if($i%3==0){
					echo '</div><div class="row">';	 
				 }
						
						if($ques_ls->class_type=='math')
						{
						$obj=$this->math;
						$objdata["obj"]= $obj;  
						}
						elseif($ques_ls->class_type=='english')
						{
						 $obj=$this->english;     
						}
							
						$pskillinfo=$this->main_model->get_detail($obj,'master_skill',array('skill_class'=>$ques_ls->skill_year,'skill_id'=>$ques_ls->skill_parent),"single"); 
					?>
                  <div class="col-xs-12 col-sm-12 col-md-4 col-lg-4">
                     <div class="box-syllabus"> 
					<h3><?php echo $x.' '.$pskillinfo->skill_name;?></h3>					 
                        <div class="text-content">
                           <ul>
                               <?php
                                       
								$parent_skill=$ques_ls->skill_parent;
                               $subskill=$this->main_model->student_question_details('inst_skill',array('sid'=>$ques_ls->sid,'skill_parent'=>$ques_ls->skill_parent));
                                                               $j=1;
                                                               foreach($subskill as $subskilldatail)
																   {
																	if($subskilldatail->skill_year==1)
																	{
																	$cltypes='kindergarten';
																	}else{
																		$cltypes='year-'.($subskilldatail->skill_year-1);
																	}																		
                               ?>
                               
                              <li><a href="<?=base_url($subskilldatail->class_type.'/'.$cltypes.'/'.$subskilldatail->skill_slug);?>"><strong><?=$x.'.'.$j?></strong> <?=$subskilldatail->skill_name?></a></li>
                              
                              <?php 
							    $j++;
								
								  }
                              ?>
							  
                              </ul>
                        </div>
                     </div>
                  </div>
				  <?php
				  $x++;
				  $i++;
					}
				  $main_parent=$parentid;
				  
				}
				?>
                  
                  
                  
               </div>
            </div>
         </div>
	</section>
