<?php 
if($this->session->userdata('user_id')!='')
{

	include(APPPATH.'/views/frontend/private/header.php');
	
}
else
{
	include('header.php');
}	
?>

<section id="title-inner" style="background-image:url(<?= base_url('assets/images/Year-13_bg.jpg')?>);">
<div id="large-header">   
<canvas id="demo-canvas"></canvas>
<div class="container">
<div class="text-tit">
 <div class="bb"></div>
<span class="lefttop-icon"></span>
<h1>
<span>Tauranga</span>
</h1>
<span class="rightbotm-icon"></span>
</div>

</div></div>

</section>

 <!-- Page Content inner -->

<section class="conatct-page"> 
<div class="conatct_detail bg-grey space-75">
<div class="container">
<div class="row">
<div class="col-xs-12 col-sm-6 col-md-3 col-lg-3">
<div class="detail-box">
<span class="contact-icon"><img  src="<?= base_url('assets/images/address-icon.png')?>" alt="" title="" /></span>
<h4>ADDRESS</h4>
<p>Block A, Lorem ipsum Rd, NZ</p>
</div>
</div>
<div class="col-xs-12 col-sm-6 col-md-3 col-lg-3">
<div class="detail-box">
<span class="contact-icon"><img  src="<?= base_url('assets/images/phon-icon.png')?>" alt="" title="" /></span>
<h4>PHONE NUMBER</h4>
<p><a href="#">123 456 7890</a></p>
</div>
</div>
<div class="col-xs-12 col-sm-6 col-md-3 col-lg-3">
<div class="detail-box">
<span class="contact-icon"><img  src="<?= base_url('assets/images/address-icon.png')?>" alt="" title="" /></span>
<h4>EMAIL</h4>
<p><a href="#">loremipsum@gmail.com</a></p>
</div>
</div>
<div class="col-xs-12 col-sm-6 col-md-3 col-lg-3">
<div class="detail-box">
<span class="contact-icon"><img  src="<?= base_url('assets/images/address-icon.png')?>" alt="" title="" /></span>
<h4>OUR WEBSITE</h4>
<p><a href="#">www.loremipsum.com</a></p>
</div>
</div>
</div>
</div>
</div>

<div class="contact-form space-75">
<div class="container">
<div class="row">

<div class="col-xs-12 col-sm-6 col-md-8 col-lg-8">
<h3>Get In Touch</h3>
<form>
<div class="row">
<div class="col-xs-12 col-sm-6 col-md-6 col-lg-6">
<input type="text" placeholder="First Name" class="input-text" />
</div>

<div class="col-xs-12 col-sm-6 col-md-6 col-lg-6">
<input type="text" placeholder="Last Name" class="input-text" />
</div>

<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
<input type="text" placeholder="Your Email" class="input-text" />
</div>


<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
<textarea class="textarea-text"  placeholder="Write Message"></textarea>
</div>

<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
<button type="submit" class="orange_btn">Submit</button>
</div>

</div>
</form>

</div>

<div class="col-xs-12 col-sm-6 col-md-4 col-lg-4">
<div class="right-box">
<h5>Tauranga</h5>
<ul>
<li><span class="icon_detail"><i class="fa fa-map-marker" aria-hidden="true"></i></span>1234 Lorem ipsum Rd, NZ</li>
<li><span class="icon_detail"><i class="fa fa-phone" aria-hidden="true"></i></span><a href="#">123 456 7890</a></li>
<li><span class="icon_detail"><i class="fa fa-fax" aria-hidden="true"></i></span>123 456 7890</li>
</ul>
<strong>Need Help? Have Question?
Check Out Our Help Center.</strong>

</div>

<div class="right-box">
<h5>Auckland</h5>
<ul>
<li><span class="icon_detail"><i class="fa fa-map-marker" aria-hidden="true"></i></span>1234 Lorem ipsum Rd, NZ</li>
<li><span class="icon_detail"><i class="fa fa-phone" aria-hidden="true"></i></span><a href="#">123 456 7890</a></li>
<li><span class="icon_detail"><i class="fa fa-fax" aria-hidden="true"></i></span>123 456 7890</li>
</ul>
<strong>Need Help? Have Question?
Check Out Our Help Center.</strong>

</div>

</div>

</div>
</div>
</div>

<div class="contact-map">
<img  src="<?= base_url('assets/images/map.jpg')?>" alt="" />

</div>

</section>   
    
 <!-- Page Content End -->
 
<?php 
if($this->session->userdata('user_id')!='')
{
	include(APPPATH.'/views/frontend/private/footer.php');
}
else
{
	include('footer.php');
}	
?>

