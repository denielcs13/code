<section id="title-inner" style="background-image:url(<?= base_url('assets/images/profile.jpg')?>);">
<div id="large-header">   
<canvas id="demo-canvas"></canvas>
<div class="container">
<div class="text-tit">
 <div class="bb"></div>
<span class="lefttop-icon"></span>
<h1>
<span>Spanish</span>
</h1>
<span class="rightbotm-icon"></span>
</div>

</div></div>

</section>
<script> 
 function cnfdel(id){
		var url="<?php echo base_url().'delete-student/';?>";
	   if (confirm("Are you sure want to delete this student?")) {
       window.location.href = url+"/"+id;
		}
    return false;
 }
 </script>
<section class="about_content content-text syllabus-page space-75 profile contentBox">
   <div class="container"> 
        <?php 
			if($this->session->flashdata('msgdelete') != null && $this->session->flashdata('msgdelete') != "")
			{ 
			?>
			<div class="row">
				<div class="col-md-12">
					<div class="alert" role="alert">
					<?php echo $this->session->flashdata('msgdelete');?>
					</div>
				</div>
			</div>
			<?php 
			} else if($this->session->flashdata('msgadd') != null && $this->session->flashdata('msgadd') != "")
			{ 
			?>
			<div class="row">
				<div class="col-md-12">
					<div class="alert" role="alert">
					<?php echo $this->session->flashdata('msgadd');?>
					</div>
				</div>
			</div>
			<?php 
			} 
			?>
			<div class="row">	

				<div class="col-lg-4 col-sm-6">
				  <div class="card math-box cyan_bg wow fadeInUp  time2 animated">
					<div class="content_main">
						<div class="content_img" style="background-image: url(https://www.theuniversityofmaths.com/assets/images/Kindergarten.jpg)"></div>
					</div>            
					<div class="math-content">
						<p><a href="#">Kindergarten</a></p>
					</div>
				  </div>
				</div>
				<div class="col-lg-4 col-sm-6">
					<div class="card math-box wow fadeInUp  time4 animated animation_started">
						<div class="content_main">
							<div class="content_img" style="background-image:url(https://www.theuniversityofmaths.com/assets/images/year-1.jpg)">
							</div>
						</div>
						<div class="math-content">
							<p><a href="#">YEAR 1</a></p>
						</div>
					</div>
				</div>			
				<div class="col-lg-4 col-sm-6">
					<div class="card math-box maroon_bg  wow fadeInUp  time6 animated animation_started">
						<div class="content_main">
							<div class="content_img" style="background-image:url(https://www.theuniversityofmaths.com/assets/images/year-2.jpg)">
							</div>
						</div>
						<div class="math-content">
							<p><a href="#">YEAR 2</a></p>
						</div>
					</div>
				</div>
				<div class="col-lg-4 col-sm-6">
					<div class="card math-box yer3_bg wow fadeInUp  time8 animated animation_started">
						<div class="content_main">
							<div class="content_img" style="background-image:url(https://www.theuniversityofmaths.com/assets/images/year-3.jpg)"></div>
						</div>
						<div class="math-content">
							<p><a href="#">YEAR 3</a></p>
						</div>
					</div>
				</div>
				<div class="col-lg-4 col-sm-6">
					<div class="card math-box yer4_bg wow fadeInUp  time10 animated animation_started">
						<div class="content_main">
							<div class="content_img" style="background-image:url(https://www.theuniversityofmaths.com/assets/images/year-4.jpg)"></div>
						</div>
						<div class="math-content">
							<p><a href="#">YEAR 4</a></p>
						</div>
					</div>
				</div>
				<div class="col-lg-4 col-sm-6">
					<div class="card math-box yer5_bg wow fadeInUp time12 animated animation_started">
						<div class="content_main">
							<div class="content_img" style="background-image:url(https://www.theuniversityofmaths.com/assets/images/year-5.jpg)"></div>
						</div>
						<div class="math-content">
							<p><a href="#">YEAR 5</a></p>
						</div>
					</div>
				</div>
				<div class="col-lg-4 col-sm-6">
					<div class="card math-box yer6_bg wow fadeInUp  time14 animated animation_started">
						<div class="content_main">
							<div class="content_img" style="background-image:url(https://www.theuniversityofmaths.com/assets/images/year-6.jpg">
							</div>
						</div>
						<div class="math-content">
							<p><a href="#">YEAR 6</a></p>
						</div>
					</div>
				</div>
				<div class="col-lg-4 col-sm-6">
					<div class="card math-box yer7_bg wow fadeInUp  time14 animated animation_started">
						<div class="content_main">
							<div class="content_img" style="background-image:url(https://www.theuniversityofmaths.com/assets/images/year-7.jpg)"></div>
						</div>
						<div class="math-content">
							<p><a href="#">YEAR 7</a></p>
						</div>
					</div>
				</div>
				<div class="col-lg-4 col-sm-6">
					<div class="card math-box yer8_bg cyan_bg wow fadeInUp  time16 animated animation_started">
						<div class="content_main">
							<div class="content_img" style="background-image:url(https://www.theuniversityofmaths.com/assets/images/year-8.jpg)"></div>
						</div>
						<div class="math-content">
							<p><a href="#">YEAR 8</a></p>
						</div>
					</div>
				</div>		
				<div class="col-lg-4 col-sm-6">
					<div class="card math-box yer9_bg cyan_bg wow fadeInUp  time18 animated animation_started">				   
						<div class="content_main">
							<div class="content_img" style="background-image:url(https://www.theuniversityofmaths.com/assets/images/year-9.jpg)"></div>
						</div>					
						<div class="math-content">
							<p><a href="#">YEAR 9</a></p>
						</div>
					</div>
				</div>			
				<div class="col-lg-4 col-sm-6">
					<div class="card math-box yer10_bg wow fadeInUp  time20 animated animation_started">
						<div class="content_main">
							<div class="content_img" style="background-image:url(https://www.theuniversityofmaths.com/assets/images/year-10.jpg)">
							</div>
						</div>
						<div class="math-content">
							<p><a href="#">YEAR 10</a></p>
						</div>
					</div>
				</div>
				<div class="col-lg-4 col-sm-6">
					<div class="card math-box yer11_bg maroon_bg wow fadeInUp  time22 animated animation_started">
						<div class="content_main">
							<div class="content_img" style="background-image:url(https://www.theuniversityofmaths.com/assets/images/year-11.jpg)"></div>
						</div>
						<div class="math-content">
							<p><a href="#">YEAR 11</a></p>
						</div>
					</div>
				</div>
				<div class="col-lg-4 col-sm-6">
					<div class="card math-box yer12_bg maroon_bg wow fadeInUp  time24 animated animation_started">
						<div class="content_main">
							<div class="content_img" style="background-image:url(https://www.theuniversityofmaths.com/assets/images/year-12.jpg)"></div>
						</div>			   
						<div class="math-content">
							<p><a href="#">YEAR 12</a></p>
						</div>
					</div>
				</div>
				<div class="col-lg-4 col-sm-6">
					<div class="card math-box yer13_bg wow cyan_bg fadeInUp  time26 animated animation_started">
						<div class="content_main">
							<div class="content_img" style="background-image:url(https://www.theuniversityofmaths.com/assets/images/year-13.jpg)"></div>
						</div>
						<div class="math-content">
							<p><a href="#">YEAR 13</a></p>
						</div>
					</div>
				</div>
				
			</div>
		</div>
</section>