<?php 
if($this->session->userdata('user_id')!='')
{

	include(APPPATH.'/views/frontend/private/header.php');
	
}
else
{
	include('header.php');
}	
?>
<section id="title-inner" style="background-image:url(<?= base_url('assets/images/who-are-we.jpg')?>);">
<div id="large-header">   
<canvas id="demo-canvas"></canvas>
<div class="container">
<div class="text-tit">
 <div class="bb"></div>
<span class="lefttop-icon"></span>
<h1>
<span>About us</span>
</h1>
<span class="rightbotm-icon"></span>
</div>

</div></div>

</section>

 <!-- Page Content inner -->
  <section class="about_content content-text space-75">
 <div class="container">
 <div class="row">
 
 <div class="col-xs-12 col-sm-12 col-md-7 col-lg-7">
<h2>Who we are</h2>
<ul>
<li>
We belong to the umbrella group of Education Group. We are an international education institution that specialises in providing after-school tuition for children from Kindergarten to Year 13.
</li>
<li>
The University of English will give your child the best start in life with our popular syllabus which follow Cambridge English Teaching Framework as blueprint. They are specially designed to be fun, interactive and very effective in learning English.
</li>
</ul>
 </div>
 
 <div class="col-xs-12 col-sm-12 col-md-5 col-lg-5">
 <div class="img-hvr"><img src="<?= base_url('assets/images/who-we-are.jpg')?>" alt="" title="" /></div>
 </div>
 
 </div>
 </div>
 </section>
 
   
     
   <section class="mission space-75">
   <div class="container">
   <div class="content-text space-left-right50">
   <h3 class="text-center">Mission</h3>
   <p>We aim to offer the best quality yet affordable tuition service to our children in NZ and the rest of the world.</p>
   </div>
   </div>
   
   </section>
   <section class="about_content white-sec space-75">
   <div class="container">

   <div class="content-text">
   <h2>Our beliefs</h2>
  
<ul>
<li>
Every child should have access to good quality education in a fair environment. That’s why we charge at a genuine affordable price across countries.
</li>
<li>
Building strong language skills is essential to a child’s academic learning and has a high correlation to their success in nearly every part of their lives.
</li>

</ul>
</div>
</div>
</section>   
   
 
<section class="mission space-75">
   <div class="container">
   <div class="content-text space-left-right50">
   <h3 class="text-center">Why The University of English?</h3>
  
   </div>
   </div>
   
   </section>
   <section class="about_content white-sec space-75">
   <div class="container">

   <div class="content-text">
   <h2>We are the first after-school tuition centre in NZ which offers:</h2>
  
<ul>
<li>
<strong>Small Group Lecturing</strong> by our professional tutors followed by 45mins supervised exercise practice. Students are grouped with students of a similar level which facilitates discussion and improved learning outcomes
</li>
<li>
<strong>Tailor-made curriculum</strong> based on the Cambridge Framework curriculum as a blueprint
</li>
<li>
<strong>Innovative teaching system.</strong> Detailed progress reports of students’ performance are accessible to students and parents on our website or mobile App, and
</li>
<li>
<strong>1-year scholarship scheme</strong> to recognise high achievers and students that demonstrate significant progress.
</li>
</ul>
</div>
</div>
</section>  






 
 <section class="about_content content-text space-75">
 
 

 <div class="container">
 <div class="row">
 
 <div class="col-xs-12 col-sm-12 col-md-7 col-lg-7">
 <ul>
 <li>We are an international education institution that specialized in teaching Mathematics for children from kindergarten to Year 13.</li>
 <li>We follow the UK National Mathematics Curriculum & Cambridge Mathematics Framework as our blueprint.</li>
 <li>Our teaching approach follows the Singapore and Hong Kong Mathematics Teaching Methods.</li>
 <li>We believe all children need a proper balance of Learn, Explore and Play during a child development process.</li>
 <li>We also believe to be excel in Maths is to "practice" and practice makes perfect as the result.</li>
 <li>Our objective is to develop a child into "whole person development exercise" through teaching them Maths.</li>
 </ul>
 </div>
 
 <div class="col-xs-12 col-sm-12 col-md-5 col-lg-5">
 <div class="img-hvr"><img src="<?= base_url('assets/images/who-we-are.jpg')?>" alt="" title="" /></div>
 </div>
 
 
 </div>
 
 
 </div>
 </section>
 
 
 
 
 
   
   
   
   
   <section class="white-sec space-75">
   <div class="container">

   <div class="content-text">
   <p class="text-center  space-left-right50">We want more students to learn Mathematics and we want more quialified trainers to join us. These are what we have achieved so far. We are working hard everyday.</p>

<div class="row">
<div class="col-xs-12 col-sm-6 col-md-3 col-lg-3">
<div class="trainers_box">
<div class="icon-circle">
<img src="<?= base_url('assets/images/kids-trdined.png')?>" alt="" />
</div>
<h3>3,000+</h3>
<h4>Kids Trained</h4>

</div>
</div>
<div class="col-xs-12 col-sm-6 col-md-3 col-lg-3">
<div class="trainers_box">
<div class="icon-circle">
<img src="<?= base_url('assets/images/qualified-trainers.png')?>" alt="" />
</div>
<h3>410+</h3>
<h4>Qualified Trainers</h4>

</div>
</div>
<div class="col-xs-12 col-sm-6 col-md-3 col-lg-3">
<div class="trainers_box">
<div class="icon-circle">
<img src="<?= base_url('assets/images/skills.png')?>" alt="" />
</div>
<h3>190+</h3>
<h4>Skills</h4>

</div>
</div>
<div class="col-xs-12 col-sm-6 col-md-3 col-lg-3">
<div class="trainers_box">
<div class="icon-circle">
<img src="<?= base_url('assets/images/global-accreditations.png')?>" alt="" />
</div>
<h3>120+</h3>
<h4>Global Accreditations</h4>

</div>
</div>
</div>

</div>
</div>
   </section>
    
 <!-- Page Content End -->
<?php 
if($this->session->userdata('user_id')!='')
{
	include(APPPATH.'/views/frontend/private/footer.php');
}
else
{
	include('footer.php');
}	
?>