<?php 
if($this->session->userdata('user_id')!='')
{

	//include(APPPATH.'/views/frontend/private/header.php');
    include('header.php');
	
}
else
{
	include('header.php');
}	
?>

<div id="carouselExampleControls" class="carousel slide" data-ride="carousel">
  <div class="carousel-inner">
    <figure class="carousel-item active">  
      <img class="d-block w-100" src="<?= base_url('assets/images/slide1.jpg')?>" alt="First slide">

<figcaption class="caption_slide">
   <div class="container"> <h3>Learn English  &nbsp;</h3>
    <p> Building strong language skills is essential to a child’s academic learning and has a high correlation to their success in nearly every part of their lives. &nbsp;</p>
<a href="<?= base_url('register');?>" class="btn-mn btn-3 btn-3e button-org">JOIN CLASSES</a> 

</div>
</figcaption>
  </figure>  
  
  
    
  </div>
  <a class="carousel-control-prev" href="#carouselExampleControls" role="button" data-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="sr-only">Previous</span>
  </a>
  <a class="carousel-control-next" href="#carouselExampleControls" role="button" data-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="sr-only">Next</span>
  </a> 
</div>

 <!-- Page Content -->
   <!-- Page Content -->
   <section id="maths_practise" class="space-75">
    <div class="container">
    <div class="col-md-12 col-xs-12 col-lg-12 col-sm-12">
      <!-- Page Heading -->
      <h1 class="text-center dis-inline">Practise - Kindergarten to Year 13</h1>

      <div class="row">
        <div class="col-lg-4 col-sm-6">
          <div class="card math-box cyan_bg wow fadeInUp  time2 animated">
            <div class="content_main">
				<div class="content_img" style="background-image: url(https://www.theuniversityofmaths.com/assets/images/Kindergarten.jpg)">
					<!--<img class="math-img-top" src="https://www.theuniversityofmaths.com/assets/images/Kindergarten.jpg" alt="">-->
				</div>
				<div class="content_links">
					<ul>
						<li><a href="<?=base_url('math/kindergarten')?>" class="btn btn-4 btn-4a icon-arrow-right mts">Maths</a></li>
						<li><a href="<?=base_url('english/kindergarten')?>" class="btn btn-4 btn-4a icon-arrow-right eng">English</a></li>
						<li><a href="syllabus-lists.php>" class="btn btn-4 btn-4a icon-arrow-right chi">Chinese</a></li>
						<li><a href="#" class="btn btn-4 btn-4a icon-arrow-right chemi">Chemistry</a></li>
						<li><a href="#" class="btn btn-4 btn-4a icon-arrow-right phy">Physics</a></li>
						<li><a href="#" class="btn btn-4 btn-4a icon-arrow-right bio">Biology</a></li>		
					</ul>
				</div>
			</div>            
            <div class="math-content">
				<p>Kindergarten </p>
            </div>
          </div>
        </div>
        
        <div class="col-lg-4 col-sm-6">
          <div class="card math-box wow fadeInUp  time4 animated animation_started">
           <div class="content_main">
					<div class="content_img" style="background-image:url(https://www.theuniversityofmaths.com/assets/images/year-1.jpg)">
						<!--<img class="math-img-top" src="https://www.theuniversityofmaths.com/assets/images/year-1.jpg" alt="">-->
					</div>
					<div class="content_links">
						<ul>
							<li><a href="<?=base_url('math/year-1')?>" class="btn btn-4 btn-4a icon-arrow-right mts">Maths</a></li>
							<li><a href="<?=base_url('english/year-1')?>" class="btn btn-4 btn-4a icon-arrow-right eng">English</a></li>
							<li><a href="#" class="btn btn-4 btn-4a icon-arrow-right chi">Chinese</a></li>
							<li><a href="#" class="btn btn-4 btn-4a icon-arrow-right chemi">Chemistry</a></li>
							<li><a href="#" class="btn btn-4 btn-4a icon-arrow-right phy">Physics</a></li>
							<!-- <li><a href="#" class="btn-mn btn-3 btn-3e bio">Biology</a></li>	-->
							<li><a href="#" class="btn btn-4 btn-4a icon-arrow-right bio">Biology</a></li>	
						</ul>
					</div>
			</div>
			<div class="math-content">
				<p>YEAR 1</p>
            </div>
          </div>
        </div>
        
        <div class="col-lg-4 col-sm-6">
          <div class="card math-box maroon_bg  wow fadeInUp  time6 animated animation_started">
           
				<div class="content_main">
					<div class="content_img" style="background-image:url(https://www.theuniversityofmaths.com/assets/images/year-2.jpg)">
						<!--<img class="math-img-top"src="https://www.theuniversityofmaths.com/assets/images/year-2.jpg" alt="">-->
					</div>
					<div class="content_links">
						<ul>
							<li><a href="<?=base_url('math/year-2')?>" class="btn btn-4 btn-4a icon-arrow-right mts">Maths</a></li>
							<li><a href="<?=base_url('english/year-2')?>" class="btn btn-4 btn-4a icon-arrow-right eng">English</a></li>
							<li><a href="#" class="btn btn-4 btn-4a icon-arrow-right chi">Chinese</a></li>
							<li><a href="#" class="btn btn-4 btn-4a icon-arrow-right chemi">Chemistry</a></li>
							<li><a href="#" class="btn btn-4 btn-4a icon-arrow-right phy">Physics</a></li>
							<li><a href="#" class="btn btn-4 btn-4a icon-arrow-right bio">Biology</a></li>	
						</ul>
					</div>
				</div>
			
            <div class="math-content">
            <p>YEAR 2 </p>
            </div>
          </div>
        </div>
        
           <div class="col-lg-4 col-sm-6">
          <div class="card math-box yer3_bg wow fadeInUp  time8 animated animation_started">
           <div class="content_main">
			<div class="content_img" style="background-image:url(https://www.theuniversityofmaths.com/assets/images/year-3.jpg)">
				<!--<img class="math-img-top" src="https://www.theuniversityofmaths.com/assets/images/year-3.jpg" alt="">-->
			</div>
			<div class="content_links">
						<ul>
							<li><a href="<?=base_url('math/year-3')?>" class="btn btn-4 btn-4a icon-arrow-right mts">Maths</a></li>
							<li><a href="<?=base_url('english/year-3')?>" class="btn btn-4 btn-4a icon-arrow-right eng">English</a></li>
							<li><a href="#" class="btn btn-4 btn-4a icon-arrow-right chi">Chinese</a></li>
							<li><a href="#" class="btn btn-4 btn-4a icon-arrow-right chemi">Chemistry</a></li>
							<li><a href="#" class="btn btn-4 btn-4a icon-arrow-right phy">Physics</a></li>
							<li><a href="#" class="btn btn-4 btn-4a icon-arrow-right bio">Biology</a></li>		
						</ul>
					</div>
           </div>
           
            <div class="math-content">
            <p>YEAR 3 </p>
            </div>
          </div>
        </div>
        
        <div class="col-lg-4 col-sm-6">
          <div class="card math-box yer4_bg wow fadeInUp  time10 animated animation_started">
            
			<div class="content_main">
				<div class="content_img" style="background-image:url(https://www.theuniversityofmaths.com/assets/images/year-4.jpg)">
				
				</div>
				<div class="content_links">
						<ul>
							<li><a href="<?=base_url('math/year-4')?>" class="btn btn-4 btn-4a icon-arrow-right mts">Maths</a></li>
							<li><a href="<?=base_url('english/year-4')?>" class="btn btn-4 btn-4a icon-arrow-right eng">English</a></li>
							<li><a href="#" class="btn btn-4 btn-4a icon-arrow-right chi">Chinese</a></li>
							<li><a href="#" class="btn btn-4 btn-4a icon-arrow-right chemi">Chemistry</a></li>
							<li><a href="#" class="btn btn-4 btn-4a icon-arrow-right phy">Physics</a></li>
							<li><a href="#" class="btn btn-4 btn-4a icon-arrow-right bio">Biology</a></li>		
						</ul>
					</div>
				</div>
            <div class="math-content">
            <p>YEAR 4</p>
            </div>
          </div>
        </div>
        
        <div class="col-lg-4 col-sm-6">
          <div class="card math-box yer5_bg wow fadeInUp time12 animated animation_started">
            
			<div class="content_main">
			<div class="content_img" style="background-image:url(https://www.theuniversityofmaths.com/assets/images/year-5.jpg)">
			<!--<img class="math-img-top" src="https://www.theuniversityofmaths.com/assets/images/year-5.jpg" alt="")>-->
			</div>
            <div class="content_links">
						<ul>
							<li><a href="<?=base_url('math/year-5')?>" class="btn btn-4 btn-4a icon-arrow-right mts">Maths</a></li>
							<li><a href="<?=base_url('english/year-5')?>" class="btn btn-4 btn-4a icon-arrow-right eng">English</a></li>
							<li><a href="#" class="btn btn-4 btn-4a icon-arrow-right chi">Chinese</a></li>
							<li><a href="#" class="btn btn-4 btn-4a icon-arrow-right chemi">Chemistry</a></li>
							<li><a href="#" class="btn btn-4 btn-4a icon-arrow-right phy">Physics</a></li>
							<li><a href="#" class="btn btn-4 btn-4a icon-arrow-right bio">Biology</a></li>		
						</ul>
					</div>
            </div>
            <div class="math-content">
            <p>YEAR 5 </p>
            </div>
          </div>
        </div>
        
           <div class="col-lg-4 col-sm-6">
			<div class="card math-box yer6_bg wow fadeInUp  time14 animated animation_started">
            
			<div class="content_main">
			<div class="content_img" style="background-image:url(https://www.theuniversityofmaths.com/assets/images/year-6.jpg">
			<!--<img class="math-img-top" src="https://www.theuniversityofmaths.com/assets/images/year-6.jpg" alt="">-->
			</div>
           <div class="content_links">
						<ul>
							<li><a href="<?=base_url('math/year-6')?>" class="btn btn-4 btn-4a icon-arrow-right mts">Maths</a></li>
							<li><a href="<?=base_url('english/year-6')?>" class="btn btn-4 btn-4a icon-arrow-right eng">English</a></li>
							<li><a href="#" class="btn btn-4 btn-4a icon-arrow-right chi">Chinese</a></li>
							<li><a href="#" class="btn btn-4 btn-4a icon-arrow-right chemi">Chemistry</a></li>
							<li><a href="#" class="btn btn-4 btn-4a icon-arrow-right phy">Physics</a></li>
							<li><a href="#" class="btn btn-4 btn-4a icon-arrow-right bio">Biology</a></li>		
						</ul>
			</div>
            </div>
            
            <div class="math-content">
            <p>YEAR 6</p>
            </div>
          </div>
        </div>
        
        <div class="col-lg-4 col-sm-6">
          <div class="card math-box yer7_bg wow fadeInUp  time14 animated animation_started">
           
			<div class="content_main">
			<div class="content_img" style="background-image:url(https://www.theuniversityofmaths.com/assets/images/year-7.jpg)">
			<!--<img class="math-img-top" src="https://www.theuniversityofmaths.com/assets/images/year-7.jpg" alt="">-->
			</div>
			<div class="content_links">
						<ul>
							<li><a href="<?=base_url('math/year-7')?>" class="btn btn-4 btn-4a icon-arrow-right mts">Maths</a></li>
							<li><a href="<?=base_url('english/year-7')?>" class="btn btn-4 btn-4a icon-arrow-right eng">English</a></li>
							<li><a href="#" class="btn btn-4 btn-4a icon-arrow-right chi">Chinese</a></li>	
							<li><a href="#" class="btn btn-4 btn-4a icon-arrow-right chemi">Chemistry</a></li>
							<li><a href="#" class="btn btn-4 btn-4a icon-arrow-right phy">Physics</a></li>
							<li><a href="#" class="btn btn-4 btn-4a icon-arrow-right bio">Biology</a></li>		
						</ul>
					</div></div>
            
            <div class="math-content">
            <p>YEAR 7 </p>
            </div>
          </div>
        </div>
        
        <div class="col-lg-4 col-sm-6">
          <div class="card math-box yer8_bg cyan_bg wow fadeInUp  time16 animated animation_started">
           
			<div class="content_main">
			<div class="content_img" style="background-image:url(https://www.theuniversityofmaths.com/assets/images/year-8.jpg)">
			<!--<img class="math-img-top" src="https://www.theuniversityofmaths.com/assets/images/year-8.jpg" alt="">-->
			</div>
            <div class="content_links">
						<ul>
							<li><a href="<?=base_url('math/year-8')?>" class="btn btn-4 btn-4a icon-arrow-right mts">Maths</a></li>
							<li><a href="<?=base_url('english/year-8')?>" class="btn btn-4 btn-4a icon-arrow-right eng">English</a></li>
							<li><a href="#" class="btn btn-4 btn-4a icon-arrow-right chi">Chinese</a></li>
							<li><a href="#" class="btn btn-4 btn-4a icon-arrow-right chemi">Chemistry</a></li>
							<li><a href="#" class="btn btn-4 btn-4a icon-arrow-right phy">Physics</a></li>
							<li><a href="#" class="btn btn-4 btn-4a icon-arrow-right bio">Biology</a></li>		
						</ul>
					</div>
            </div>
            <div class="math-content">
            <p>YEAR 8</p>
            </div>
          </div>
        </div>
        
           <div class="col-lg-4 col-sm-6">
          <div class="card math-box yer9_bg cyan_bg wow fadeInUp  time18 animated animation_started">
           
			<div class="content_main">
			<div class="content_img" style="background-image:url(https://www.theuniversityofmaths.com/assets/images/year-9.jpg)">
			<!--<img class="math-img-top" src="https://www.theuniversityofmaths.com/assets/images/year-9.jpg" alt="">-->
			</div>
            <div class="content_links">
						<ul>
							<li><a href="<?=base_url('math/year-9')?>" class="btn btn-4 btn-4a icon-arrow-right mts">Maths</a></li>
							<li><a href="<?=base_url('english/year-9')?>" class="btn btn-4 btn-4a icon-arrow-right eng">English</a></li>
							<li><a href="#" class="btn btn-4 btn-4a icon-arrow-right chi">Chinese</a></li>
							<li><a href="#" class="btn btn-4 btn-4a icon-arrow-right chemi">Chemistry</a></li>
							<li><a href="#" class="btn btn-4 btn-4a icon-arrow-right phy">Physics</a></li>
							<li><a href="#" class="btn btn-4 btn-4a icon-arrow-right bio">Biology</a></li>		
						</ul>
					</div>
					</div>
					
            
            <div class="math-content">
            <p>YEAR 9 </p>
            </div>
          </div>
        </div>
        
        <div class="col-lg-4 col-sm-6">
          <div class="card math-box yer10_bg wow fadeInUp  time20 animated animation_started">
          
			<div class="content_main">
			<div class="content_img" style="background-image:url(https://www.theuniversityofmaths.com/assets/images/year-10.jpg)">
			<!--<img class="math-img-top" src="https://www.theuniversityofmaths.com/assets/images/year-10.jpg" alt="">-->
			</div>
            <div class="content_links">
						<ul>
							<li><a href="<?=base_url('math/year-10')?>" class="btn btn-4 btn-4a icon-arrow-right mts">Maths</a></li>
							<li><a href="<?=base_url('english/year-10')?>" class="btn btn-4 btn-4a icon-arrow-right eng">English</a></li>
							<li><a href="#" class="btn btn-4 btn-4a icon-arrow-right chi">Chinese</a></li>
							<li><a href="#" class="btn btn-4 btn-4a icon-arrow-right chemi">Chemistry</a></li>
							<li><a href="#" class="btn btn-4 btn-4a icon-arrow-right phy">Physics</a></li>
							<li><a href="#" class="btn btn-4 btn-4a icon-arrow-right bio">Biology</a></li>		
						</ul>
					</div></div>
           
            <div class="math-content">
            <p>YEAR 10</p>
            </div>
          </div>
        </div>
        
        <div class="col-lg-4 col-sm-6">
          <div class="card math-box yer11_bg maroon_bg wow fadeInUp  time22 animated animation_started">
           
			<div class="content_main">
			<div class="content_img" style="background-image:url(https://www.theuniversityofmaths.com/assets/images/year-11.jpg)">
			<!--<img class="math-img-top" src="https://www.theuniversityofmaths.com/assets/images/year-11.jpg" alt="">-->
			</div>
           <div class="content_links">
						<ul>
							<li><a href="<?=base_url('math/year-11')?>" class="btn btn-4 btn-4a icon-arrow-right mts">Maths</a></li>
							<li><a href="#" class="btn btn-4 btn-4a icon-arrow-right eng">English</a></li>
							<li><a href="#" class="btn btn-4 btn-4a icon-arrow-right chi">Chinese</a></li>
							<li><a href="#" class="btn btn-4 btn-4a icon-arrow-right chemi">Chemistry</a></li>
							<li><a href="#" class="btn btn-4 btn-4a icon-arrow-right phy">Physics</a></li>
							<li><a href="#" class="btn btn-4 btn-4a icon-arrow-right bio">Biology</a></li>		
						</ul>
					</div></div>
            <div class="math-content">
            <p>YEAR 11 </p>
            </div>
          </div>
        </div>
        
           <div class="col-lg-4 col-sm-6">
          <div class="card math-box yer12_bg maroon_bg wow fadeInUp  time24 animated animation_started">
           
			<div class="content_main">
			<div class="content_img" style="background-image:url(https://www.theuniversityofmaths.com/assets/images/year-12.jpg)">
			<!--<img class="math-img-top" src="" alt="">-->
			</div>
            <div class="content_links">
						<ul>
							<li><a href="<?=base_url('math/year-12')?>" class="btn btn-4 btn-4a icon-arrow-right mts">Maths</a></li>
							<li><a href="<?=base_url('english/year-12')?>" class="btn btn-4 btn-4a icon-arrow-right eng">English</a></li>
							<li><a href="#" class="btn btn-4 btn-4a icon-arrow-right chi">Chinese</a></li>
							<li><a href="#" class="btn btn-4 btn-4a icon-arrow-right chemi">Chemistry</a></li>
							<li><a href="#" class="btn btn-4 btn-4a icon-arrow-right phy">Physics</a></li>
							<li><a href="#" class="btn btn-4 btn-4a icon-arrow-right bio">Biology</a></li>		
						</ul>
					</div></div>
           
            <div class="math-content">
            <p>YEAR 12 </p>
            </div>
          </div>
        </div>
        
        <div class="col-lg-4 col-sm-6">
          <div class="card math-box yer13_bg wow cyan_bg fadeInUp  time26 animated animation_started">
            
			<div class="content_main">
			<div class="content_img" style="background-image:url(https://www.theuniversityofmaths.com/assets/images/year-13.jpg)">
				<!--<img class="math-img-top" src="https://www.theuniversityofmaths.com/assets/images/year-13.jpg" alt="">-->
            </div>
			<div class="content_links">
						<ul>
							<li><a href="<?=base_url('math/year-13')?>" class="btn btn-4 btn-4a icon-arrow-right mts">Maths</a></li>
							<li><a href="<?=base_url('english/year-13')?>" class="btn btn-4 btn-4a icon-arrow-right eng">English</a></li>
							<li><a href="#" class="btn btn-4 btn-4a icon-arrow-right chi">Chinese</a></li>
							<li><a href="#" class="btn btn-4 btn-4a icon-arrow-right chemi">Chemistry</a></li>
							<li><a href="#" class="btn btn-4 btn-4a icon-arrow-right phy">Physics</a></li>
							<li><a href="#" class="btn btn-4 btn-4a icon-arrow-right bio">Biology</a></li>		
						</ul>
					</div></div>
            
            <div class="math-content">
            <p>YEAR 13</p>
            </div>
          </div>
        </div>
         
        <div class="col-xs-12 col-sm-12 col-md-6 col-lg-4">
          <div class="card math-box yellow-bg">
            
            <p>We are using Mathematics Intelligence Systems to teach and monitor our student learning process.</p>
          </div>
        </div>
        
   
      </div>
      <!-- /.row -->


</div>
    </div>
    </section>
<section id="halping_kids" class="space-75">
   <div class="container">
   <h2 class="text-center">Helping KIDS Thrive, Not Just Survive</h2>
   <div class="row">
     <div class="col-xs-12 col-sm-6 col-md-4 col-lg-4">
     <div class="content_halping text-center">
     <img src="<?= base_url('assets/images/book.svg')?>" alt="" />
     <h4>Learning — Blended to Perfection</h4>
     <p>We develop our student's mindset to learn English through practice and practice makes perfect.</p>
     
     </div>
     
     </div>
     <div class="col-xs-12 col-sm-6 col-md-4 col-lg-4">
     <div class="content_halping text-center">
     <img src="<?= base_url('assets/images/medal.svg')?>" alt="" />
     <h4>Validated & Certified</h4>
     <p>Our English curriculum prepare our students to enroll for the international English examinations and certifications.</p>
     
     </div>
     
     </div>
     <div class="col-xs-12 col-sm-12 col-md-4 col-lg-4"> 
     <div class="content_halping text-center">
     <img src="<?= base_url('assets/images/trophy.svg')?>" alt="" />
     <h4>Achieve Your Dreams</h4>
     <p>We guide our students to achieve their goals in English.</p>
     
     </div>
     
     </div>
   </div>
   </div>
   </section>
   
   <section id="testimonial" class="space-75">
   <div class="container">
   <div class="row">
   <h2 class="text-center dis-inline">Student Testimonials</h2> 
   
<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
<div class="owl-carousel">
<div class="item">
<div class="testimonial_sec">
   <div class="quote"><img src="<?= base_url('assets/images/quate.png')?>" alt="" /></div>
   
   <h4>Evans T. & Sally T.</h4>
   
   <div class="more_text">
   We both learn alot from The University of English. A good place to learn English.
   </div>
   
   </div>
</div>
<div class="item">
<div class="testimonial_sec dark_green">
   <div class="quote"><img src="<?= base_url('assets/images/quate.png')?>" alt="" /></div>
   
   <h4>Charlotte M.</h4>
   
   <div class="more_text">
   My English has improved considerably since I joined the class at The University of English.
   </div>
   
   </div>
</div>
<div class="item">
<div class="testimonial_sec bg_org">
   <div class="quote"><img src="<?= base_url('assets/images/quate.png')?>" alt="" /></div>
   
   <h4>Gabriel S.</h4>
   
   <div class="more_text">
   Interesting to learn English this way.  Nowadays, I can do my English homework everyday through The University of English website.
   </div>
   
   </div>
</div>
<div class="item">
<div class="testimonial_sec dark_green">
   <div class="quote"><img src="<?= base_url('assets/images/quate.png')?>" alt="" /></div>
   
   <h4>Stephen K.</h4>
   
   <div class="more_text">
   Classroom and homework exercises really help me alot.  I can start to teach my classmates during English sessions.
   </div>
   
   </div>
</div>

<div class="item">
<div class="testimonial_sec">
   <div class="quote"><img src="<?= base_url('assets/images/quate.png')?>" alt="" /></div>
   
   <h4>Jayden M.</h4>
   
   <div class="more_text">
   Really appreciate those teaching staffs and I really learn alot of English in just a couple of weeks.
   </div>
   
   </div>
</div>
<div class="item">
<div class="testimonial_sec bg_org">
   <div class="quote"><img src="<?= base_url('assets/images/quate.png')?>" alt="" /></div>
   
   <h4>Hilton S.</h4>
   
   <div class="more_text">
   The homework really makes me learn alot.  Really enjoy coming to the class every week.
   </div>
   
   </div>
</div>

    

</div>
</div>

<div class="col-lg-12 col-sm-12 col-md-12 col-xs-12 text-center"><a href="testimonials" class="btn-mn btn-3 btn-3e button-org">View All Testimonials</a></div>
   </div>
   </section>

   
   <section id="newsletter_sec" class="space-75">
   <div class="container">
   <div class="row">
   <div class="col-xs-12 col-sm-12 col-md-6 col-lg-8">
  
   <div class="subscribe">
   <div class="row"> 
   <div class="col-xs-12 col-sm-3 col-md-2 col-lg-2 text-center"><img src="<?= base_url('assets/images/subscribe_icon.jpg')?>" alt="" /></div>
   <div class="col-xs-12 col-sm-9 col-md-10 col-lg-10"><h2>Subscribe To Our Newsletter</h2>
   <p>We will regularly updates our followers on the news related to English and also our institution development.</p>
</div>
   </div>
   </div>
   
   </div>
<div class="col-xs-12 col-sm-12 col-md-6 col-lg-4">
<h2>Your E-mail Address</h2>
<form>
<input type="text" placeholder="Email" /> <button type="submit"  value="Subscribe" class="btn-mn btn-3 btn-3e button-org">Subscribe</button>
</form>
</div>
</div>
   </div>
   </section>
   
   
 <!-- Page Content End -->
 
 
 
 
 
<?php 
if($this->session->userdata('user_id')!='')
{
	//include(APPPATH.'/views/frontend/private/footer.php');
    include('footer.php');
}
else
{
	include('footer.php');
}	
?>
