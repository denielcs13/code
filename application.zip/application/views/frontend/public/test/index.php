<div class="bannerSec">
		<div class="container">
		<div class="innerBox">
			<div class="bannText">				
				<div class="txtBann">
					<h1>Helping Kids Thrive, Not Just Survive.</h1>
					<p>We're an international education institution with the  mission to make learning easy and fun!</p>
					<span class="boxBtn">
						<a href="#" class="btnBox">Learner</a>
						<a href="#" class="btnBox">Teacher</a>
						<a href="#" class="btnBox">Parent</a>
					</span>
				</div>	
			</div>
		</div>
		<div class="bannRightBox" /*style="background-image:url(img/banner.png);"*/>
			<div class="riBoxBn">
				<img src="<?= base_url('assets/images/banner1.png')?>">
			</div>
		</div>
		</div>
	</div>
	
	<section class="eduPlex">			
		
			<div class="container">		
				<h2>Why EduPlex Pro</h2>
				<div class="row">
					<div class="col-xs-12 col-sm-6 col-md-4 col-lg-4 tm">
						 <div class="content_halping math-box">
							 <img src="http://aiits.in/assets/images/book.svg" alt="" />
							 <h4>Quality content </h4>
							 <p>Curated for today's tech-savy generation and thoroughly assessed to make learning stress free and effective</p>
						 
						 </div>
					 
					</div>
					 <div class="col-xs-12 col-sm-6 col-md-4 col-lg-4 tm">
						 <div class="content_halping math-box">
							 <img src="http://aiits.in/assets/images/medal.svg" alt="" />
							 <h4>Customized learning </h4>
							 <p>Well-designed curriculum enables students to learn on their own pace, teachers to customize curriculum, and parents to monitor the progress</p>						 
						 </div>					 
					 </div>
					 <div class="col-xs-12 col-sm-12 col-md-4 col-lg-4 tm"> 
						 <div class="content_halping math-box">
							 <img src="http://aiits.in/assets/images/trophy.svg" alt="" />
							 <h4>Interactive learning</h4>
							 <p>Built to ignite the curiosity, this unique system strengthen the core concepts and develops critical thinking abilities</p>					 
						 </div>					 
					 </div>
				</div>	
			</div>
		
	</section>
	
	
	<section class="teachersBox">
		<div class="container">			
				
			<div class="row">
			<div class="col-xs-12 col-sm-12 col-md-6 col-lg-6">
					<div class="teachRight">
						<h6>Teachers</h6>
						<h2>Design customized content based on the needs of your students</h2>
						<p>Online courses open the opportunity for learning to almost anyone, regardless of their scheduling commitments.</p>
						<span class="boxBtn"><a href="#" class="btnBox">Teachers, get started for free</a></span>
					</div>
				</div>
			</div>
		</div>
	</section>
	
	<section class="teachersBo td">
		<div class="container">			
				
			<div class="row">
			<div class="col-xs-12 col-sm-12 col-md-6 col-lg-6">
					
				</div>
			<div class="col-xs-12 col-sm-12 col-md-6 col-lg-6">
					<div class="teachRight">
						<h6>Learners</h6>
						<h2>What we learn with pleasure we never forget.</h2>
						<p>Online courses open the opportunity for learning to almost anyone, regardless of their scheduling commitments.</p>
						<span class="boxBtn"><a href="#" class="btnBox">Learners, get started for free</a></span>
					</div>
				</div>
			</div>
		</div>
	</section>
	
	<section class="teachersBo td mpa">
		<div class="container">			
				
			<div class="row">
			<div class="col-xs-12 col-sm-12 col-md-6 col-lg-6">
					<div class="teachRight">
						<h6>Parents</h6>
						<h2>Let your child learn more, grow more and do more.</h2>
						<p>Online courses open the opportunity for learning to almost anyone, regardless of their scheduling commitments.</p>
						<span class="boxBtn"><a href="#" class="btnBox">Parents, get started for free</a></span>
					</div>
				</div>
			</div>
		</div>
	</section>
	
	
	
	
	
	
	<section id="testimonial" class="space-75">
   <div class="container">
   <div class="row">
   <h2 class="text-center dis-inline">Testimonials</h2> 
   
<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
<div class="owl-carousel">
<div class="item">
<div class="testimonial_sec">
   <div class="quote"><img src="http://aiits.in/assets/images/quate.png" alt="" /></div>
   
   <h4>Evans T. & Sally T.</h4>
   
   <div class="more_text">
   We both learn alot from The University of English. A good place to learn English.
   </div>
   
   </div>
</div>
<div class="item">
<div class="testimonial_sec dark_green">
   <div class="quote"><img src="http://aiits.in/assets/images/quate.png" alt="" /></div>
   
   <h4>Charlotte M.</h4>
   
   <div class="more_text">
   My English has improved considerably since I joined the class at The University of English.
   </div>
   
   </div>
</div>
<div class="item">
<div class="testimonial_sec bg_org">
   <div class="quote"><img src="http://aiits.in/assets/images/quate.png" alt="" /></div>
   
   <h4>Gabriel S.</h4>
   
   <div class="more_text">
   Interesting to learn English this way.  Nowadays, I can do my English homework everyday through The University of English website.
   </div>
   
   </div>
</div>
<div class="item">
<div class="testimonial_sec dark_green">
   <div class="quote"><img src="http://aiits.in/assets/images/quate.png" alt="" /></div>
   
   <h4>Stephen K.</h4>
   
   <div class="more_text">
   Classroom and homework exercises really help me alot.  I can start to teach my classmates during English sessions.
   </div>
   
   </div>
</div>

<div class="item">
<div class="testimonial_sec">
   <div class="quote"><img src="http://aiits.in/assets/images/quate.png" alt="" /></div>
   
   <h4>Jayden M.</h4>
   
   <div class="more_text">
   Really appreciate those teaching staffs and I really learn alot of English in just a couple of weeks.
   </div>
   
   </div>
</div>
<div class="item">
<div class="testimonial_sec bg_org">
   <div class="quote"><img src="http://aiits.in/assets/images/quate.png" alt="" /></div>
   
   <h4>Hilton S.</h4>
   
   <div class="more_text">
   The homework really makes me learn alot.  Really enjoy coming to the class every week.
   </div>
   
   </div>
</div>

    

</div>
</div>

<!--<span class="boxBtn"><a href="#" class="btnBox">View All Testimonials</a></span>-->


   </div>
   </section>
	
	<!--
	
	
	
	
	
	<section class="teachersBox">
		<div class="container">			
				
			<div class="row">
			<div class="col-xs-12 col-sm-12 col-md-6 col-lg-6 bkGimg" style="background-image:url(images/year-3.jpg)">
				
				</div>
				<div class="col-xs-12 col-sm-12 col-md-6 col-lg-6">
					<div class="teachRight">
						<h6>Teachers</h6>
						<h3>Design customized content based on the needs of your students</h3>
						<span class="boxBtn"><a href="#" class="btnBox">Teachers, let's get started</a></span>
					</div>
				</div>
			</div>
		</div>
	</section>

	<section class="teachersBox">
		<div class="container">			
				
			<div class="row">
				<div class="col-xs-12 col-sm-12 col-md-6 col-lg-6">
					<div class="teachRight">
						<h6>Learners</h6>
						<h3>What we learn with pleasure we never forget.</h3>
						<span class="boxBtn"><a href="#" class="btnBox">Learners, let's get started</a></span>
					</div>
				</div>
				<div class="col-xs-12 col-sm-12 col-md-6 col-lg-6 bkGimg" style="background-image:url(images/membershipBg.jpg)">
				
				</div>
			</div>
		</div>
	</section>

	
	
	
	<section class="teachersBox">
		<div class="container">			
				
			<div class="row">
			<div class="col-xs-12 col-sm-12 col-md-6 col-lg-6 bkGimg" style="background-image:url(images/year-3.jpg)">

				</div>
				<div class="col-xs-12 col-sm-12 col-md-6 col-lg-6">
					<div class="teachRight">
						<h6>Parents</h6>
						<h3>Let your child learn more, grow more and do more.</h3>
						<span class="boxBtn"><a href="#" class="btnBox">Parents, let's get started.</a></span>
					</div>
				</div>
			</div>
		</div>
	</section>
	
	
	<section class="eduPlex">
		<svg viewBox="0 0 1366 631" height="631" class="_dkkao8NaN" preserveAspectRatio="none" aria-hidden="true"><path d="M1366 614.626V42.2878C1216.44 32.481 1071.16 25.6274 902.892 20.0618C647.674 11.6203 291.457 3.37253 0 0.135254V612.111C313.572 631.987 694.403 637.367 1189.78 619.86C1248.63 617.783 1307.48 616.071 1366 614.626Z" fill="#a6b1bb"></path></svg>	
		<div class="eduPlexText">
			<div class="container">
				<div class="row">
					<h2 class="text-center dis-inline">Testimonial</h2>    
					<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
						<div class="owl-carousel">
							<div class="item">
								<div class="testimonial_sec">
									<div class="quote"><img src="http://aiits.in/assets/images/quate.png" alt="" /></div>
									<h4>Evans T. & Sally T.</h4>
									<div class="more_text">
										We both learn alot from The University of English. A good place to learn English.
									</div>
								</div>
							</div>
							<div class="item">
								<div class="testimonial_sec dark_green">
								   <div class="quote"><img src="http://aiits.in/assets/images/quate.png" alt="" /></div>
								   
								   <h4>Charlotte M.</h4>
								   
								   <div class="more_text">
								   My English has improved considerably since I joined the class at The University of English.
								   </div>
								   
								   </div>
								</div>
								<div class="item">
								<div class="testimonial_sec bg_org">
								   <div class="quote"><img src="http://aiits.in/assets/images/quate.png" alt="" /></div>
								   
								   <h4>Gabriel S.</h4>
								   
								   <div class="more_text">
								   Interesting to learn English this way.  Nowadays, I can do my English homework everyday through The University of English website.
								   </div>
								   
								   </div>
								</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>

-->




























   <!--
   <section id="newsletter_sec" class="space-75">
   <div class="container">
   <div class="row">
   <div class="col-xs-12 col-sm-12 col-md-6 col-lg-8">
  
   <div class="subscribe">
   <div class="row"> 
   <div class="col-xs-12 col-sm-3 col-md-2 col-lg-2 text-center"><img src="http://aiits.in/assets/images/subscribe_icon.jpg" alt="" /></div>
   <div class="col-xs-12 col-sm-9 col-md-10 col-lg-10"><h2>Subscribe To Our Newsletter</h2>
   <p>We will regularly updates our followers on the news related to English and also our institution development.</p>
</div>
   </div>
   </div>
   
   </div>
<div class="col-xs-12 col-sm-12 col-md-6 col-lg-4">
<h2>Your E-mail Address</h2>
<form>
<input type="text" placeholder="Email" /> <button type="submit"  value="Subscribe" class="btn-mn btn-3 btn-3e button-org">Subscribe</button>
</form>
</div>
</div>
   </div>
   </section>
   -->
   
 <!-- Page Content End -->
 
 
 
 
 