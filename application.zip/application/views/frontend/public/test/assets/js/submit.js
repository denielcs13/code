
 $('#btntestexam').click(function(event) {
      for (instance in CKEDITOR.instances) {
        CKEDITOR.instances[instance].updateElement();
    }
	 form = $("#testexmfrm").serialize();
		// form = new FormData(this);

	var ques_type=$('input[name="ques_type"]').val();
	ques_type = "["+ques_type+"]";
	parsedText = JSON.parse(ques_type)

	if(parsedText[0]=='1'){
		var x = document.forms["myForm"]["answerid"].value;
		if (x==""){
		   return false;
		}
	}
	else if(parsedText[0]=='22'){
		var val = [];
		$("input[name='answerid[]']:checked").each( function (i) {
          val[i] = $(this).val();
        });
		if(val==""){
			return false;
		}
		
	}	
	else if(parsedText[0]=='26' || parsedText[0]=='32'){
		var x = document.forms["myForm"]["input1"].value;
		if (x==""){
		   return false;
		}
		
	  var atr = $("input[name='input1']").attr('type');
	  if(atr=='checkbox'){
		 var val = [];
		$("input[type='checkbox']:checked").each( function (i) {
          val[i] = $(this).val();
        });
		if(val==""){
			return false;
		}
	  }
	}	
     $.ajax({
       type: "POST",
       url: "<?php echo site_url('ajaxcall/ajax_testexam'); ?>",
       data: form,	  

       success: function(data){
         
		    $('#question_list').html(data);
       }

     });
     event.preventDefault();
     return false;  //stop the actual form post !important!

  });