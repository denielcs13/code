	<section class="bannerSec subBann innerPage">		
		<div class="">
			<div class="container">
				<div class="innerBox">
					<h1><?php echo ucfirst($class_type);?></h1>										
				</div>				
			</div>
		</div>
	</section>
	 
	<section class="box">
		<div class="container">
		
		<?php 
			if($this->session->flashdata('msgdelete') != null && $this->session->flashdata('msgdelete') != "")
			{ 
			?>
			<div class="row">
				<div class="col-md-12">
					<div class="alert" role="alert">
					<?php echo $this->session->flashdata('msgdelete');?>
					</div>
				</div>
			</div>
			<?php 
			} else if($this->session->flashdata('msgadd') != null && $this->session->flashdata('msgadd') != "")
			{ 
			?>
				<div class="row">
				<div class="col-md-12">
					<div class="alert" role="alert">
					<?php echo $this->session->flashdata('msgadd');?>
					</div>
				</div>
			</div>
			<?php 
			} 
			?>
			<div class="row">
			
			<?php 
							$arryearcss=array('lowerKin','classi','classii','classiii','classiv','classv','classvi','classvii','classviii','classix','classx','classxi','classxii','classxiii');
							
							$i = 0;
							$c=1;
							$clnumber='';
							$totalskill=0;
							if($year_dtl){
							foreach($year_dtl as $stdn_cls){
						?>
				<div class="borBox <?php echo $arryearcss[$i];?>">
					<div class="subL text-center">
						<h2><?php 
						if($i==0)
						{
						echo 'K';
						$class_topic='kindergarten';
						$class_slug='kindergarten';
						}
						else
						{
							$clnumber= strtoupper(str_replace('class','',$arryearcss[$i]));
							echo $clnumber;
							$class_topic='Class '.$clnumber;
							$class_slug='year-'.$i;
						}?></h2>
					</div>
					<div class="subC">
						<h3><?php echo $class_topic;?></h3>
						<p>Includes: <a href="#">Count dots - up to 3</a>|<a href="#">Count shapes - up to 5</a>|<a href="#">More</a>|<a href="#">Top and bottom</a>|<a href="#">Long and short</a></p>
					</div>
					<div class="subR text-center">
					<?php
					$obj=$this->$class_type;  
					$totalskill=$this->main_model->count_skills_peryear($obj,$c);
					?>
						<a href="<?php echo base_url($class_type.'/'.$class_slug);?>" class="btnBox"> See all <?php echo $totalskill;?> skills</a>
					</div>
				</div>
				
							<?php $i++;
							$c++;
							
							}}?>
				
	
				
			</div>
		</div>
	</section>
	