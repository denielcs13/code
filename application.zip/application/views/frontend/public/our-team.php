<?php 
if($this->session->userdata('user_id')!='')
{

	include(APPPATH.'/views/frontend/private/header.php');
	
}
else
{
	include('header.php');
}	
?>
<section id="title-inner">
<div class="container">
<h1 class="text-center">Our Team</h1>
</div>


</section>

 <!-- Page Content inner -->
 
 <section class="about_content content-text our-team-page space-75">
 <div class="container">
 <div class="row">
 
 <div class="col-xs-12 col-sm-12 col-md-6 col-lg-6">
										<div class="team-box">
                                        <div class="content-holder">
                                        <span>Ms. LOREM IPSUM</span>
											<em class="yellow">Position</em>
											<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry.</p>
											<ul class="social-icons">
												<li><a href="#"><i aria-hidden="true" class="fa fa-facebook"></i></a></li>
												<li><a href="#"><i aria-hidden="true" class="fa fa-twitter"></i></a></li>
												<li><a href="#"><i aria-hidden="true" class="fa fa-google-plus"></i></a></li>
											</ul>
                                        
                                        </div>
                                        
										<div class="img-box">
										<img  src="<?= base_url('assets/images/male-placeholder.jpg')?>" alt="team" class="allign-left">	
										</div>
                                        
                                        </div>
									</div>
 <div class="col-xs-12 col-sm-12 col-md-6 col-lg-6">
										<div class="team-box">
                                        <div class="content-holder">
                                        <span>Ms. LOREM IPSUM</span>
											<em class="yellow">Position</em>
											<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry.</p>
											<ul class="social-icons">
												<li><a href="#"><i aria-hidden="true" class="fa fa-facebook"></i></a></li>
												<li><a href="#"><i aria-hidden="true" class="fa fa-twitter"></i></a></li>
												<li><a href="#"><i aria-hidden="true" class="fa fa-google-plus"></i></a></li>
											</ul>
                                        
                                        </div>
                                        
										<div class="img-box">
										<img  src="<?= base_url('assets/images/female-placeholder.jpg')?>" alt="team" class="allign-left">	
										</div>
                                        
                                        </div>
									</div>
                                                                      
 <div class="col-xs-12 col-sm-12 col-md-6 col-lg-6">
										<div class="team-box">
                                        <div class="content-holder">
                                        <span>Ms. LOREM IPSUM</span>
											<em class="yellow">Position</em>
											<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry.</p>
											<ul class="social-icons">
												<li><a href="#"><i aria-hidden="true" class="fa fa-facebook"></i></a></li>
												<li><a href="#"><i aria-hidden="true" class="fa fa-twitter"></i></a></li>
												<li><a href="#"><i aria-hidden="true" class="fa fa-google-plus"></i></a></li>
											</ul>
                                        
                                        </div>
                                        
										<div class="img-box">
										<img  src="<?= base_url('assets/images/male-placeholder.jpg')?>" alt="team" class="allign-left">	
										</div>
                                        
                                        </div>
									</div>
 <div class="col-xs-12 col-sm-12 col-md-6 col-lg-6">
										<div class="team-box">
                                        <div class="content-holder">
                                        <span>Ms. LOREM IPSUM</span>
											<em class="yellow">Position</em>
											<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry.</p>
											<ul class="social-icons">
												<li><a href="#"><i aria-hidden="true" class="fa fa-facebook"></i></a></li>
												<li><a href="#"><i aria-hidden="true" class="fa fa-twitter"></i></a></li>
												<li><a href="#"><i aria-hidden="true" class="fa fa-google-plus"></i></a></li>
											</ul>
                                        
                                        </div>
                                        
										<div class="img-box">
										<img  src="<?= base_url('assets/images/female-placeholder.jpg')?>" alt="team" class="allign-left">	
										</div>
                                        
                                        </div>
									</div>
                                    
 <div class="col-xs-12 col-sm-12 col-md-6 col-lg-6">
										<div class="team-box">
                                        <div class="content-holder">
                                        <span>Ms. LOREM IPSUM</span>
											<em class="yellow">Position</em>
											<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry.</p>
											<ul class="social-icons">
												<li><a href="#"><i aria-hidden="true" class="fa fa-facebook"></i></a></li>
												<li><a href="#"><i aria-hidden="true" class="fa fa-twitter"></i></a></li>
												<li><a href="#"><i aria-hidden="true" class="fa fa-google-plus"></i></a></li>
											</ul>
                                        
                                        </div>
                                        
										<div class="img-box"> 
										<img  src="<?= base_url('assets/images/male-placeholder.jpg')?>" alt="team" class="allign-left">	
										</div>
                                        
                                        </div>
									</div>
 <div class="col-xs-12 col-sm-12 col-md-6 col-lg-6">
										<div class="team-box">
                                        <div class="content-holder">
                                        <span>Ms. LOREM IPSUM</span>
											<em class="yellow">Position</em>
											<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry.</p>
											<ul class="social-icons">
												<li><a href="#"><i aria-hidden="true" class="fa fa-facebook"></i></a></li>
												<li><a href="#"><i aria-hidden="true" class="fa fa-twitter"></i></a></li>
												<li><a href="#"><i aria-hidden="true" class="fa fa-google-plus"></i></a></li>
											</ul>
                                        
                                        </div>
                                        
										<div class="img-box">
										<img  src="<?= base_url('assets/images/female-placeholder.jpg')?>" alt="team" class="allign-left">	
										</div>
                                        
                                        </div>
									</div>


 
 </div>
 </div>
 </section>
 
 

    
 <!-- Page Content End -->
<?php 
if($this->session->userdata('user_id')!='')
{
	include(APPPATH.'/views/frontend/private/footer.php');
}
else
{
	include('footer.php');
}	
?>