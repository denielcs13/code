<?php 
if($this->session->userdata('user_id')!='')
{

	include(APPPATH.'/views/frontend/private/header.php');
	
}
else
{
	include('header.php');
}	
?>
<section id="title-inner" style="background-image:url(<?= base_url('assets/images/become-a-instructor.jpg')?>);">
<div id="large-header">   
<canvas id="demo-canvas"></canvas>
<div class="container">
<div class="text-tit">
 <div class="bb"></div>
<span class="lefttop-icon"></span>
<h1>
<span>Become an instructor</span>
</h1>
<span class="rightbotm-icon"></span>
</div>



</div></div>

</section>

 <!-- Page Content inner -->
 
 <div class="login-page become-an-instructor-page">

<div class="container">
<div class="row">


<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 space-75">
<div class="row">
<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12"><p>We are always welcome new instructors to join our institution.  Since we have several education campuses throughout, we would like those who are interested to join our institution to email us your personal resume to <a href="mailto:email@myemail.com">email@myemail.com</a>  We will get back to you as soon as possible once we receive your application.</p></div>


<div class="col-xs-12 col-sm-12 col-md-5 col-lg-5">
<div class="img-hvr mobile-none"><img src="<?= base_url('assets/images/become-a-instructor-content.jpg')?>" alt="" title="" /></div>

</div>

<div class="col-xs-12 col-sm-12 col-md-7 col-lg-7">

    <?php

        if($this->session->flashdata('msg'))
        {?>
            <div id="msg" style="border: 1px solid;height: 34px;box-shadow: aquamarine;box-shadow: 0px 0px 0px 1px black;">
            <?PHP
            echo "<span> ".$this->session->flashdata('msg')."</span>";
       
          ?></div> <?PHP }?>


  
    

<div class="form-section"> 
<form action="<?=base_url('become-an-instructor')?>" method="post" enctype="multipart/form-data"  >
<div class="row">
<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
<p class="error">Username is required.</p>



<div class="row">
<div class="col-lg-6"><div class="input-field">
<input  type="text" placeholder="First Name" name="fname" value="<?=set_value('fanme');?>" /> 
 <span><?=form_error('fanme')?></span>    
</div>

</div>

<div class="col-lg-6">

<div class="input-field">
<input type="text" placeholder="Last Name" name="lname" value="<?=set_value('lname');?>" />
 <span><?=form_error('lname')?></span>
             
</div></div>

</div>

<div class="row marg-top25">

<h4 class="col-xs-12 col-sm-12 col-md-12 col-lg-12">Total Work Experience</h4> 
<div class="col-xs-12 col-sm-12 col-md-6 col-lg-6">
<div class="input-field">
					<select name="exp_yr">
                    <option>Select Year (s)</option>
                    <option>0</option>
                    <option>1</option>
                    <option>2</option>
                    <option>3</option>
                    <option>4</option>
                    <option>5</option>
                    <option>6</option>
                    <option>7</option>
                    <option>8</option>
                    <option>9</option>
                    <option>10</option>
                    </select>
    <span><?=form_error('exp_yr')?></span>

</div>
</div>
<div class="col-xs-12 col-sm-12 col-md-6 col-lg-6">
<div class="input-field">
					<select name="exp_mn" >
                    <option>Select Month(s)</option>
                    <option>0</option>
                    <option>1</option>
                    <option>2</option>
                    <option>3</option>
                    <option>4</option>
                    <option>5</option>
                    <option>6</option>
                    <option>7</option>
                    <option>8</option>
                    <option>9</option>
                    <option>10</option> 
                    </select>
    <span><?=form_error('exp_mn')?></span>
</div>
</div>

</div>


<div class="row">
<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
<div class="input-field marg-top25">
	<select name="job_title" >
                <option>Job Title</option>
                <option>Job Title 1</option>
                <option>Job Title 2</option>
                <option>Job Title 3</option>
                <option>Job Title 4</option>
                <option>Job Title 5</option>
                <option>Job Title 6</option>
                <option>Job Title 7</option>
                <option>Job Title 8</option>
                </select>	
    <span><?=form_error('job_title')?></span>
</div>
</div>
</div>

<div class="row">
<div class="col-xs-12 col-sm-12 col-md-6 col-lg-6">
<div class="input-field">
<input type="text" placeholder="Email" name="email" value="<?=set_value('email');?>" />
<span><?=form_error('email')?></span>


</div>
</div>

<div class="col-xs-12 col-sm-12 col-md-6 col-lg-6">
<div class="input-field">
<input type="text" placeholder="Phone" name="phone" value="<?=set_value('phone');?>" />
<span><?=form_error('phone')?></span>

</div>
</div>
</div>

<div class="row">
<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
</div>
</div>



<div class="row">
<div class="col-xs-12 col-sm-12 col-md-6 col-lg-6">
<div class="input-field marg-top25">
					<select name="state" >
                    <option style="display: none">Select a State</option>
                    <option value="1">State 1</option>
                    <option value="2">State 2</option>
                    <option value="3">State 3</option>
                    <option value="4">State 4</option>
                    <option value="5">State 5</option>
                    <option value="6">State 6</option>
                    <option value="7">State 7</option>
                    <option value="8">State 8</option>
                    <option value="9">State 9</option>
                    <option value="10">State 10</option>
                    </select>
    <span><?=form_error('state')?></span>

</div>
</div>

<div class="col-xs-12 col-sm-12 col-md-6 col-lg-6">

<div class="input-field">
<input type="text" placeholder="City" name="city" value="<?=set_value('city');?>" />
<span><?=form_error('city')?></span>
</div>
</div>

</div>

<div class="row">
<div class="col-xs-12 col-sm-12 col-md-3 col-lg-3">
<div class="input-field">

<span class="input input--hoshi">
					<label class="file-label">
                    <input type="file" name="resume" value="<?=set_value('fanme');?>"/>
                    <small class="font-size14">
        Upload Resume
</small>
                    </label>
				</span>
</div>
</div>

<div class="col-xs-12 col-sm-12 col-md-9 col-md-9">
<h4 class="ling-heg58 font-size15">Upload your Resume</h4>
</div>
</div>


<div class="marg-top25 col-md-12 text-center">
<button type="Submit" class="btn-mn btn-3 btn-3e button-org">Submit</button> 
</div>



</div>


</div>
</form>
</div>

</div>





</div>
</div>

</div>
</div>

</div>
    
 <!-- Page Content End -->
<?php 
if($this->session->userdata('user_id')!='')
{
	include(APPPATH.'/views/frontend/private/footer.php');
}
else
{
	include('footer.php');
}	
?>