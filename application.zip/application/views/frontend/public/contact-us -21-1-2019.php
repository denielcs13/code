<?php 
if($this->session->userdata('user_id')!='')
{

	include(APPPATH.'/views/frontend/private/header.php');
	
}
else
{
	include('header.php');
}	
?>

<section id="title-inner" style="background-image:url(<?= base_url('assets/images/contact-us.jpg')?>);">
<div id="large-header">   
<canvas id="demo-canvas"></canvas>
<div class="container">
<div class="text-tit">
 <div class="bb"></div>
<span class="lefttop-icon"></span>
<h1>
<span>Contact Us</span>
</h1>
<span class="rightbotm-icon"></span>
</div>

</div></div>

</section>

 <!-- Page Content inner -->

<section class="conatct-page"> 
<div class="conatct_detail bg-grey space-75">
<div class="container">
<div class="row">
<div class="col-xs-12 col-sm-6 col-md-6 col-lg-3">
<div class="detail-box">
<span class="contact-icon"><img  src="<?= base_url('assets/images/address-icon.png')?>" alt="" title="" /></span>
<h4>ADDRESS</h4>
<p>2A Wagener Place, Mt Albert, Auckland (H.Q.)</p>
</div>
</div>
<div class="col-xs-12 col-sm-6 col-md-6 col-lg-3">
<div class="detail-box">
<span class="contact-icon"><img  src="<?= base_url('assets/images/phon-icon.png')?>" alt="" title="" /></span>
<h4>PHONE NUMBER</h4>
<p><a href="tel:+64 0226458491">+64 0226458491</a></p>
</div>
</div>
<div class="col-xs-12 col-sm-6 col-md-6 col-lg-3">
<div class="detail-box">
<span class="contact-icon"><img  src="<?= base_url('assets/images/address-icon.png')?>" alt="" title="" /></span>
<h4>EMAIL</h4>
<p><a href="mailto:ask@theuniversityofmaths.com">ask@theuniversityofenglish.com</a></p>
</div>
</div>
<div class="col-xs-12 col-sm-6 col-md-6 col-lg-3">
<div class="detail-box">
<span class="contact-icon"><img  src="<?= base_url('assets/images/address-icon.png')?>" alt="" title="" /></span>
<h4>OUR WEBSITE</h4>
<p><a href="https://www.theuniversityofmaths.com/">www.theuniversityofenglish.com</a></p>
</div>
</div>

<div class="col-md-12 col-lg-12 text-center"><a href="<?= base_url('our-centers');?>" class="btn-mn btn-3 btn-3e button-org">View Our Centers</a></div>
</div>
</div>
</div>

<div class="login-page contact-form space-75">
<div class="container">
<div class="row">
  <?php

        if($this->session->flashdata('msg'))
        {?>
            <div id="msg" style="border: 1px solid;height: 34px;box-shadow: aquamarine;box-shadow: 0px 0px 0px 1px black;">
            <?PHP
            echo "<span> ".$this->session->flashdata('msg')."</span>";
       
          ?></div> <?PHP }?>
<div class="col-md-2"></div>
<div class="col-xs-12 col-sm-12 col-md-12 col-lg-8">
<h3 class="text-center">Get In Touch</h3>
<div class="form-section"> 
<form action="<?php echo base_url('contact-us')?>" method="post">
<div class="row">
<div class="col-xs-12 col-sm-6 col-md-6 col-lg-6">
<div class="input-field">
	<input type="text" name="fname" placeholder="First Name" value="<?=set_value('fname');?>" />
    <span style="color: red;"><?=form_error('fname'); ?></span>
</div>
</div>

<div class="col-xs-12 col-sm-6 col-md-6 col-lg-6">
<div class="input-field">
	<input type="text" name="lname" placeholder="Last Name" value="<?=set_value('lname');?>"  /></div>
	<span style="color: red;"><?=form_error('lname'); ?></span>
</div>

<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
<div class="input-field">
	<input type="text" name="email" placeholder="Your Email" value="<?=set_value('email');?>"  /></div>
	<span style="color: red;"><?=form_error('email'); ?></span>
</div>


<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
<div class="input-field" >
	<textarea  placeholder="Write Message" name="msg"></textarea>
	<span style="color: red;"><?=form_error('msg'); ?></span>
</div> 

</div>

<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 text-center">
<input type="hidden" name="cdate" value="<?php echo date("Y-m-d H:i:s");?>" />
<button type="submit" class="btn-mn btn-3 btn-3e button-org">Submit</button>
</div>

</div>
</form>
</div>
</div>
<div class="col-md-2"></div>


</div>
</div>
</div>



</section>   
    
 <!-- Page Content End -->
 
<?php 
if($this->session->userdata('user_id')!='')
{
	include(APPPATH.'/views/frontend/private/footer.php');
}
else
{
	include('footer.php');
}	
?>

