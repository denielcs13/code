	<section class="bannerSec subBann innerPage">		
		<div class="">
			<div class="container">
				<div class="innerBox">
					<h1>Approve Student</h1>										
				</div>				
			</div>
		</div>
	</section>
		 
	<section class="sinUpBox">
		<div class="container">
			<div class="row">
				<!--Left Box-->
				<div class="col-lg-12">
					<!--Form Box-->
					<div id="students" class="sibord"  style="display:block;">
						 <form  method="post" action="">
                      <div class="row">
                        <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
						   <?php

        if($this->session->flashdata('msg'))
        {?>
            <div id="msg" style="border: 1px solid;height: 34px;box-shadow: aquamarine;box-shadow: 0px 0px 0px 1px black;">
            <?PHP
            echo "<span> ".$this->session->flashdata('msg')."</span>";
       
          ?></div> <?PHP }?>
                        
                                                 
                   	<div class="col-lg-4 col-md-4 col-sm-12">
								<div class="form-group row">
									<label class="col-sm-12 text-left control-label col-form-label">Email</label>
									<div class="col-sm-12">
										<div id="msgemail"></div>   
 
  <input type="text" class="form-control" name="reg_email" id="reg_email" value="" placeholder="Student’s Email " />    
									</div>
								</div>
							</div>
							
							
							
							
                        
                            	<div class="col-lg-12 col-md-12 col-sm-12 text-right">
								
									<div class="card-body">
               <div id="btn1" class="form-group m-b-0 text-right">						
               <button type="submit" name="approve" class="btnBox btForm">Approve</button></div>
			   <div id="btn2" class="form-group m-b-0 text-right" style="display:none;">			
               <button  type="submit" name="remove" class="btnBox btForm">Remove</button></div>
            </div>
							</div>             
                          
                          </div>                         
                          
                          
                        </div>
                      </div>
                    </form>
					</div>				
			</div><!--row end-->
		</div>
	</section>
<script type="text/javascript">

jQuery(document).ready(function(){

    jQuery('#reg_email').blur(function(){
	var email=$('#reg_email').val();
    jQuery.post('<?=base_url('studentemailcheck');?>',{email:email},function(result){
           if(result=="<span style='color:green'>Email is available to add with you.</span>")
           {
            //jQuery('.button-org').removeAttr('disabled');
			jQuery("#btn1").show();
			jQuery("#btn2").hide();
			
            jQuery( "#msgemail" ).html(result);
           }else{
            //jQuery('.button-org').prop('disabled','true');
			jQuery("#btn1").hide();
			jQuery("#btn2").show();
            jQuery( "#msgemail" ).html(result); 			
           }
          
		   console.log(result);
        });
    });    
});
</script> 