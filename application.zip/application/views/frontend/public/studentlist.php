<script> 
 function cnfdel(id){
		var url="<?php echo base_url().'delete-student/';?>";
	   if (confirm("Are you sure want to delete this student?")) {
       window.location.href = url+"/"+id;
		}
    return false;
 }
 </script>
	<section class="bannerSec subBann innerPage">		
		<div class="">
			<div class="container">
				<div class="innerBox">
					<h1>Student List</h1>										
				</div>				
			</div>
		</div>
	</section>
		
	<section class="rosterBox">
		<div class="container">
			<div class="row">
				<div class="col-lg-8 col-md-8 col-sm-6 col">
					<!--<h2>Student List</h2>	-->
					
				</div>
				<div class="col-lg-4 col-md-4 col-sm-6 col text-right">					
					<div class="dropdown">
					  <button class="btn dropdown-toggle droDbox" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
						Import students
					  </button>
					  <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
						<a class="classRoom" href="#"><i class="fa fa-users"></i>Import from Google Classroom <i class="fa fa-angle-right"></i></a>
						<p>Don't have a Google Classroom account? You can always add students by entering their first and last names.</p>
						</div>
					</div>
				</div>				
			</div>
			<div class="row mt-4">
				
				<div class="col-lg-12 rostForm">
					<!--<p>Click in any row to edit student information. To add more students, click <b>Add students</b> in the footer of your roster.</p>-->
					<?php 
						if($this->session->flashdata('msgdelete') != null && $this->session->flashdata('msgdelete') != "")
							{ 
							?>
							<div class="row">
								<div class="col-md-12">
									<div class="alert" role="alert">
									<?php echo $this->session->flashdata('msgdelete');?>
									</div>
								</div>
							</div>
							<?php 
							} else if($this->session->flashdata('msgadd') != null && $this->session->flashdata('msgadd') != "")
							{ 
							?>
							<div class="row">
								<div class="col-md-12">
									<div class="alert" role="alert">
									<?php echo $this->session->flashdata('msgadd');?>
									</div>
								</div>
							</div>
							<?php 
							} 
						?>	
					<div class="table-responsive-md">
						<table class="table table-bordered">
							<thead>
                                            <tr>
												<th>#</th>
											   <th>Student Name</th>
                                                <th>Class</th>                                       
                                                <th>Action</th>
                                            </tr>
                    </thead>
                    <tbody>
         			
         			<?php 
										$i = 1;
										if($stdn_list){
										foreach($stdn_list as $stdn_lst){
											?>
         			<tr>
         				<td><?php echo $i;?></td>
         				<td><?php echo $stdn_lst->first_name;?></td>
         				 <td><?php
                          if(!empty($stdn_lst->class_name)){						 
						 if($stdn_lst->class_name==1){
							echo "Kindergarten"; 
						 }
						 else{
							echo "Year ".($stdn_lst->class_name - 1); 
						  }
						  }else{}
						 ?></td>
         				 <td>
                                                    <a href="javascript:void(0)" onclick="cnfdel(<?php echo $stdn_lst->user_id;?>)"><i class="fa fa-trash"></i></a>
													<a href="<?php echo base_url().'edit-student/'.$stdn_lst->user_id;?>"><i class="fa fa-edit"></i></a>
													
                       </td>
         			</tr>
         			<?php $i++;}}else{?>
											
											  <tr>
												<td colspan="5">No record found</td>
                                              
                                            </tr>
											
										<?php } ?>
							</tbody>
							<tfoot>
								<tr>
									<td colspan="7">
										<span>You're using 1 out of 90 student accounts.</span>
										<span class="float-right studentAdd">
										 <?php if($this->session->userdata('user_type')=='7'){?>
										 <a href="<?=base_url('add-user');?>"><i class="fa fa-plus-circle"></i>Add Children</a>
										 <?php
										 }
										 ?>
										
										 <?php if($this->session->userdata('user_type')=='8'){?>
											<a href="<?=base_url('add-user');?>"><i class="fa fa-plus-circle"></i>Add students</a>
											<?php
										 }
										 ?>
										</span>
									</td>
									
								</tr>
							</tfoot>
						</table>
					</div>
				</div>
			</div>
		</div>
	</section>

	
