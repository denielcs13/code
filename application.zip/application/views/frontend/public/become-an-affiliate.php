<?php 
if($this->session->userdata('user_id')!='')
{

	include(APPPATH.'/views/frontend/private/header.php');
	
}
else
{
	include('header.php');
}	
?>

<section id="title-inner" style="background-image:url(<?= base_url('assets/images/affilate.jpg')?>);">
<div id="large-header">   
<canvas id="demo-canvas"></canvas>
<div class="container">
<div class="text-tit">
 <div class="bb"></div>
<span class="lefttop-icon"></span>
<h1>
<span>Become an Affiliate</span>
</h1>
<span class="rightbotm-icon"></span>
</div>



</div></div>

</section>

 <!-- Page Content inner -->
 
 <section class="about_content content-text">


 
 
 <div class="container">
  
 <div class="row">
 <div class="affiliate-sec">
 <div class="row">
 <div class="col-xs-12 col-sm-6 col-md-4 col-lg-4">
 <div class="btns-affiliate"><a href="#">Have available markets</a></div>
 </div>
 <div class="col-xs-12 col-sm-6 col-md-4 col-lg-4">
 <div class="btns-affiliate"><a href="#" class="orange">Why own a TheUniversityofMaths franchise?</a></div>
 </div>
 <div class="col-xs-12 col-sm-6 col-md-4 col-lg-4">
 <div class="btns-affiliate"><a href="#" class="blue">Apply for your franchise</a></div>
 </div>
 </div>
</div>
 
 <div class="space-75">
 <p>Our individualised programmes help children to develop calculation skills for confidence in the classroom and in everyday life.</p>
 <p>We see our students growing into sound, capable people, who in turn are able to make significant contributions to society.</p>
 <p>We are seeking like-minded people who believe in each and every child's potential. Owning your own The University of Maths Education Centre is a wonderful opportunity to nurture children to learn with confidence to realise their goals and dreams in the future.</p>
 
 <p>Franchisees have also been considered special members of their local community for their contribution to children's education and long-term development. As a TheUniversityofMaths franchisee, you will have the opportunity to build an exciting and worthwhile business that contributes to your local community. The role of running a centre also includes enough flexibility to fit in with your family and lifestyle needs. You will become part of a team with a worldwide network of associates all working towards developing "life skills" in children around the world.</p>
 

<p>Please contact us at <a href="mailto:partners@theuniversityofmaths.com"></a></p>

<strong>In total we need 3 emails account.</strong>

<ul>
<li>ask@theuniversityofmaths.com</li>
<li>hr@theuniversityofmaths.com</li>
<li>partners@theuniversityofmaths.com</li>
</ul>
 </div>

 </div>
 </div>
 </section>
 
 
 
 <section class="mission space-75">
   <div class="container">
   <div class="content-text space-left-right50">
   <h3 class="text-center">Your Investment</h3>
   <p>Before you embark on any new business venture it's important to develop a solid business plan to help you estimate your potential revenues and expenses. In the table below we outline the standard costs associated with owning a Kumon Franchise. Once you review the information, please give us a call at 1-855-586-6687 or email us and we'll be glad to help.</p>
    
   </div>
   </div>
   
   </section>
   
   
 <section class="about_content content-text space-75">
 
 <div class="container">
<div class="become-affiliate">
<h4>COSTS DUE AT SIGNING OF TRAINING AGREEMENT</h4>
<table class="table table-striped table-light">
  <thead>
    <tr>
      <th scope="col">Type of Expenditure</th>
      <th scope="col">Amount</th>
      <th scope="col">Method of Payment</th>
      <th scope="col">Payment Made To</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th scope="row">Training Agreement Deposit Fee<br />
      <a href="#" class="btn_td">See Notes</a></th>
      <td>$500</td>
      <td>Lump sum</td>
      <td>Kumon</td>
    </tr>
    
    
    
    
    
  </tbody>
</table>
</div>


<div class="become-affiliate">
<h4>COSTS DUE AT TIME OF INSTRUCTOR DEVELOPMENT PROGRAM</h4>
<table class="table table-striped table-light">
  <thead>
    <tr>
      <th scope="col">Type of Expenditure</th>
      <th scope="col">Amount</th>
      <th scope="col">Method of Payment</th>
      <th scope="col">Payment Made To</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th scope="row">Expenses while Training<br />
      <a href="#" class="btn_td">See Notes</a></th>
      <td>Instructor Development Program $4,860–$8,520</td>
      <td>As arranged</td>
      <td>Airlines, hotels, restaurants, etc.</td> 
    </tr>

  </tbody>
</table>
</div>


<div class="become-affiliate">
<h4>COSTS DUE AT SIGNING OF FRANCHISE AGREEMENT</h4>
<table class="table table-striped table-light">
  <thead>
    <tr>
      <th scope="col">Type of Expenditure</th>
      <th scope="col">Amount</th>
      <th scope="col">Method of Payment</th>
      <th scope="col">Payment Made To</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th scope="row">Initial Franchise Fee<br />
      <a href="#" class="btn_td">See Notes</a></th>
      <td>$1,000 less the $500 Deposit Fee if you are obtaining your first Kumon Center Franchise.</td>
      <td>Lump Sum</td>
      <td>Kumon</td> 
    </tr>
    
    
    <tr>
      <th scope="row">Initial Purchase of Materials<br />
      <a href="#" class="btn_td">See Notes</a></th>
      <td>$1,000</td>
      <td>Lump Sum</td>
      <td>Kumon</td> 
    </tr>

  </tbody>
</table>
</div>

<div class="become-affiliate">
<h4>COST DUE BEFORE OPENING</h4>
<table class="table table-striped table-light">
  <thead>
    <tr>
      <th scope="col">Type of Expenditure</th>
      <th scope="col">Amount</th>
      <th scope="col">Method of Payment</th>
      <th scope="col">Payment Made To</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th scope="row">Architect design<br />
      <a href="#" class="btn_td">See Notes</a></th>
      <td>$0–$9,500</td>
      <td>As Arranged</td>
      <td>Architect</td> 
    </tr>  
    <tr>
      <th scope="row">Architect design<br />
      <a href="#" class="btn_td">See Notes</a></th>
      <td>$0–$9,500</td>
      <td>As Arranged</td>
      <td>Architect</td> 
    </tr>
    <tr>
      <th scope="row">Architect design<br />
      <a href="#" class="btn_td">See Notes</a></th>
      <td>$0–$9,500</td>
      <td>As Arranged</td>
      <td>Architect</td> 
    </tr>
    <tr>
      <th scope="row">Architect design<br />
      <a href="#" class="btn_td">See Notes</a></th>
      <td>$0–$9,500</td>
      <td>As Arranged</td>
      <td>Architect</td> 
    </tr>
    <tr>
      <th scope="row">Architect design<br />
      <a href="#" class="btn_td">See Notes</a></th>
      <td>$0–$9,500</td>
      <td>As Arranged</td>
      <td>Architect</td> 
    </tr>
    <tr>
      <th scope="row">Architect design<br />
      <a href="#" class="btn_td">See Notes</a></th>
      <td>$0–$9,500</td>
      <td>As Arranged</td>
      <td>Architect</td> 
    </tr>
    
    
    

  </tbody>
</table>
</div>


<div class="become-affiliate">
<h4>COSTS DUE AS REQUIRED BY LANDLORD</h4>
<table class="table table-striped table-light">
  <thead>
    <tr>
      <th scope="col">Type of Expenditure</th>
      <th scope="col">Amount</th>
      <th scope="col">Method of Payment</th>
      <th scope="col">Payment Made To</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th scope="row">Architect design<br />
      <a href="#" class="btn_td">See Notes</a></th>
      <td>$0–$9,500</td>
      <td>As Arranged</td>
      <td>Architect</td> 
    </tr>  
    <tr>
      <th scope="row">Architect design<br />
      <a href="#" class="btn_td">See Notes</a></th>
      <td>$0–$9,500</td>
      <td>As Arranged</td>
      <td>Architect</td> 
    </tr>
    <tr>
      <th scope="row">Architect design<br />
      <a href="#" class="btn_td">See Notes</a></th>
      <td>$0–$9,500</td>
      <td>As Arranged</td>
      <td>Architect</td> 
    </tr>
    <tr>
      <th scope="row">Architect design<br />
      <a href="#" class="btn_td">See Notes</a></th>
      <td>$0–$9,500</td>
      <td>As Arranged</td>
      <td>Architect</td> 
    </tr>
    <tr>
      <th scope="row">Architect design<br />
      <a href="#" class="btn_td">See Notes</a></th>
      <td>$0–$9,500</td>
      <td>As Arranged</td>
      <td>Architect</td> 
    </tr>
    <tr>
      <th scope="row">Architect design<br />
      <a href="#" class="btn_td">See Notes</a></th>
      <td>$0–$9,500</td>
      <td>As Arranged</td>
      <td>Architect</td> 
    </tr>
    
    
    

  </tbody>
</table>
</div>


<div class="become-affiliate">
<h4>COSTS DUE 90 DAYS AFTER OPENING</h4>
<table class="table table-striped table-light">
  <thead>
    <tr>
      <th scope="col">Type of Expenditure</th>
      <th scope="col">Amount</th>
      <th scope="col">Method of Payment</th>
      <th scope="col">Payment Made To</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th scope="row">Architect design<br />
      <a href="#" class="btn_td">See Notes</a></th>
      <td>$0–$9,500</td>
      <td>As Arranged</td>
      <td>Architect</td> 
    </tr>  

    
    
    

  </tbody>
</table>
</div>

<div class="become-affiliate">
<h4>COSTS DUE AS ARRANGED</h4>
<table class="table table-striped table-light">
  <thead>
    <tr>
      <th scope="col">Type of Expenditure</th>
      <th scope="col">Amount</th>
      <th scope="col">Method of Payment</th>
      <th scope="col">Payment Made To</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th scope="row">Architect design<br />
      <a href="#" class="btn_td">See Notes</a></th>
      <td>$0–$9,500</td>
      <td>As Arranged</td>
      <td>Architect</td> 
    </tr>
    <tr>
      <th scope="row">Architect design<br />
      <a href="#" class="btn_td">See Notes</a></th>
      <td>$0–$9,500</td>
      <td>As Arranged</td>
      <td>Architect</td> 
    </tr>  

  </tbody>
</table>
</div>



 </div>
 
 
 </section>
 
 
 <section class="mission space-35">
   <div class="container">
   <div class="content-text space-left-right50 text-center">
   <h3 class="text-center">Total</h3>
   <p>$69,583 – $148,965</p>
   <a href="#" class="orange_btn">See Notes</a>
    
   </div>
   </div>
   
   </section>
   
   
   <section class="about_content content-text leagel-sec space-75">


 
 
 <div class="container">
  
 <div class="row">
<h5>Legal Disclaimer</h5>
 <p>This information is not intended as an offer to sell or the solicitation of an offer to buy a franchise. We offer franchises solely by means of our Franchise Disclosure Document. The United States Federal Trade Commission and certain states have laws governing the offer and sale of franchises. We will not offer you a franchise unless and until we have complied with all applicable legal requirements in your jurisdiction.</p>

 </div>
 </div>
 </section>
 
  
    
 <!-- Page Content End -->
<?php 
if($this->session->userdata('user_id')!='')
{
	include(APPPATH.'/views/frontend/private/footer.php');
}
else
{
	include('footer.php');
}	
?>