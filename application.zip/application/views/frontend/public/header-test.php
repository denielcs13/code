
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<link rel="shortcut icon" href="<?= base_url('assets/images/favicon.png')?>" />

<link href="<?= base_url('assets/images/60x60.png')?>" rel="apple-touch-icon" />
<link href="<?= base_url('assets/images/76x76.png')?>" rel="apple-touch-icon" sizes="76x76" />
<link href="<?= base_url('assets/images/120x120.png')?>" rel="apple-touch-icon" sizes="120x120" />
<link href="<?= base_url('assets/images/152x152.png')?>" rel="apple-touch-icon" sizes="152x152" />

<meta name="description" content="">
<meta name="author" content="">
<title>The University Of Education </title>

<!-- Bootstrap core CSS -->
<link href="<?= base_url('assets/css/bootstrap.min.css')?>" rel="stylesheet">
<link href="<?= base_url('assets/css/font-awesome.min.css')?>" rel="stylesheet" />
<link href="<?= base_url('assets/css/font-awesome.css')?>" rel="stylesheet" />
<link href="<?= base_url('assets/css/animate.css')?>" rel="stylesheet" />
<link href="<?= base_url('assets/css/404.css')?>" rel="stylesheet" />
<link href="<?= base_url('assets/css/title.css')?>" rel="stylesheet" /> 
<link href="<?= base_url('assets/css/owl.carousel.min.css')?>" rel="stylesheet" />
<link href="<?= base_url('assets/css/owl.carousel.css')?>" rel="stylesheet" />
<script src="https://cdnjs.cloudflare.com/ajax/libs/modernizr/2.6.2/modernizr.min.js"></script>
<script src="<?= base_url('assets/js/wow.min.js')?>"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
<script src='<?= base_url('assets/js/unispeech.js')?>'></script>
<!-- Custom styles for this template -->
<link href="<?= base_url('assets/style19-06-19.css')?>" rel="stylesheet">
</head>

<body>
	<header class="header fadeInDown" >
		<div class="container">
			<div class="row">
				<div class="col-xs-12 col-sm-4 col-md-2 col-lg-2 logo-sect">
					<div class="logo text">
						<a href="index.php"><img src="<?= base_url('assets/images/logo.png')?>"></a>
					</div>
				</div>
				<div class="col-xs-12 col-sm-8 col-md-10 col-lg-10 text-right">
					<div class="btnButton">
						<ul>
							<li class="hoveMenu">
								<a href="#">Courses</a>
								<ul class="hoMenu">
									<li><a href="<?=base_url('math')?>">Maths</a></li>
									<li><a href="<?=base_url('english')?>">English</a></li>	
									<li><a href="<?=base_url('chinese')?>">Chinese</a></li>	
									<li><a href="<?=base_url('chemistry')?>">Chemistry</a></li>	
									<li><a href="<?=base_url('physics')?>">Physics</a></li>	
									<li><a href="<?=base_url('biology')?>">Biology</a></li>	
									<li><a href="<?=base_url('spanish')?>">Spanish</a></li>									
								</ul>
							</li>
							<li>
								<a href="#">Country</a>
							</li>
							<li>
								<a href="#">Login</a>
							</li>
							<li>
								<a href="#" class="btnBox">Sign Up For Free</a>
							</li>
						</ul>
					</div>
				</div>
			</div>
		</div>
	</header>
	
