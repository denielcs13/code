<?php 
if($this->session->userdata('user_id')!='')
{

	include(APPPATH.'/views/frontend/private/header.php');
	
}
else
{
	include('header.php');
}	
?>
<section id="title-inner" style="background-image:url(<?= base_url('assets/images/parents.jpg')?>);">
<div id="large-header">   
<canvas id="demo-canvas"></canvas>
<div class="container">
<div class="text-tit">
 <div class="bb"></div>
<span class="lefttop-icon"></span>
<h1>
<span>Parents</span>
</h1>
<span class="rightbotm-icon"></span>
</div>



</div></div>





</section>

 <!-- Page Content inner -->
 
 <section class="about_content content-text space-75">
 <div class="container">
 <div class="row">
 
 <div class="col-xs-12 col-sm-12 col-md-7 col-lg-7">
<p>We believe parents play a big role in their child’s success. Parents should regularly check in with their child’s progress by accessing their progress report and analysis, and also to understand the content their child has learned during the study period.</p>
<p>As parents ourselves, we understand how busy life can be and we often feel that we don’t have the time and energy to follow up with our child’s study plan and development. This is why we have developed weekly, monthly and yearly analysis reports of your child’s learning progress, which consists of the following key information, to assist you:-</p>
<ul>
<li>Topics the child has learned over the study period.</li>
<li>Date, time, number of attempts, scores, grades and tutors’ recommendations of the child’s classroom and homework performances.</li>
<li>Detailed analysis (including peer group analysis) of each topic and sub-topic, e.g. standard deviation, mean, highest and lowest scores.</li>
</ul>

<p>We highly recommend parents to sit down and discuss the analysis reports with their child, so that both parties can communicate and plan for the child's future study development. We are also welcome parents to come and talk to us about how we can support your child’s educational needs.</p>
 </div>
 
 <div class="col-xs-12 col-sm-12 col-md-5 col-lg-5">
 <div class="img-hvr"><img  src="<?= base_url('assets/images/parents-content.jpg')?>" alt="" title="" /></div> 
 </div>
 
 
 
 
 </div>
 </div>
 </section>
 
 
 <section class="white-sec space-75">
   <div class="container">

   <div class="content-text">
<div class="row">
<div class="col-xs-12 col-sm-6 col-md-3 col-lg-3">
<div class="trainers_box">
<div class="icon-circle">
<img  src="<?= base_url('assets/images/kids-trdined.png')?>" alt="" />
</div>
<h3>3,000+</h3>
<h4>Kids Trained</h4>

</div>
</div>
<div class="col-xs-12 col-sm-6 col-md-3 col-lg-3">
<div class="trainers_box">
<div class="icon-circle">
<img  src="<?= base_url('assets/images/qualified-trainers.png')?>" alt="" />
</div>
<h3>410+</h3>
<h4>Qualified Trainers</h4>

</div>
</div>
<div class="col-xs-12 col-sm-6 col-md-3 col-lg-3">
<div class="trainers_box">
<div class="icon-circle">
<img  src="<?= base_url('assets/images/skills.png')?>" alt="" />
</div>
<h3>190+</h3>
<h4>Skills</h4>

</div>
</div>
<div class="col-xs-12 col-sm-6 col-md-3 col-lg-3">
<div class="trainers_box">
<div class="icon-circle">
<img  src="<?= base_url('assets/images/global-accreditations.png')?>" alt="" />
</div>
<h3>120+</h3>
<h4>Global Accreditations</h4>

</div>
</div>
</div>

</div>
</div>
   </section>
 
 
   
   
   
   
   
   
    
 <!-- Page Content End -->
<?php 
if($this->session->userdata('user_id')!='')
{
	include(APPPATH.'/views/frontend/private/footer.php');
}
else
{
	include('footer.php');
}	
?>