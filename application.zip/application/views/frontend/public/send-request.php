		<section class="bannerSec subBann innerPage">
		<div class="">
		<div class="container">
		<div class="innerBox">					<h1>Institute</h1>														</div>							</div>
		</div>	
		</section>
		<section class="sinUpBox">
		<div class="container">
		<?php        if($this->session->flashdata('msg'))        {?>
		<div id="msg" style="border: 1px solid;height: 34px;box-shadow: aquamarine;box-shadow: 0px 0px 0px 1px black;">            
		<?PHP            echo "<span> ".$this->session->flashdata('msg')."</span>";                 ?>
		</div> 
		<?PHP }?>			
		<div class="row">				
		<!--Left Box-->				
		<div class="col-lg-12">	
		<!--Form Box-->					
		<div id="students" class="sibord"  style="display:block;">					<form  method="post" action="">		
		<div class="row">
		<div class="col-lg-4 col-md-4 col-sm-12">
		<div class="form-group row">
		<label class="col-sm-12 text-left control-label col-form-label">Institute List*</label>
		<div class="col-sm-12">	
		<select class="form-control custom-select" name="institute" id="class_type">
		<option value="">Select</option>											<?php
		$i = 1;                    
		if($inst_lst){ 
		foreach($inst_lst as $inst_ls){ 
		?>    
		<option value="<?=$inst_ls->user_id;?>"><?=$inst_ls->inst_name;?></option>    <?php $i++;
		}}else{?>                                                                     <option value="">No data find</option>
		<?php } ?>										
		</select>
		<span class="danger-error"><?=form_error('institute')?></span></div>
		</div>
		</div>	
		<div class="col-lg-12 col-md-12 col-sm-12 text-right">
		<button type="submit" name="submit" class="btnBox btForm">Add</button>		</div>
		</div><!--row end-->						
		</form>					
		</div>							
		</div><!--row end-->
		</div>
		</section>