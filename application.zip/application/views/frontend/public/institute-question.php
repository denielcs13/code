<div id="carouselExampleControls" class="carousel slide" data-ride="carousel">
 
  

 <!-- Page Content -->
   <!-- Page Content -->
   <section id="maths_practise" class="space-75">
    <div class="container">
    <div class="col-md-12 col-xs-12 col-lg-12 col-sm-12">
      <!-- Page Heading -->
      <h1 class="text-center dis-inline">Practise - Kindergarten to Year 13</h1>

      <div class="row">
	  <?php 
										$i = 1;
										if($ques_lst){
										foreach($ques_lst as $ques_ls){
											
											?>
         			
         			<?php $i++;}}else{?>
											
											 No record found
											
										<?php } ?>
        <div class="col-lg-4 col-sm-6">
          <div class="card math-box cyan_bg wow fadeInUp  time2 animated">
            <div class="content_main">
				<div class="content_img" style="background-image: url(https://www.theuniversityofmaths.com/assets/images/Kindergarten.jpg)">
				</div>
				<div class="content_links">
					<ul>
						<li><a href="<?=base_url('math_inst/kindergarten')?>" class="btn-mn btn-3 btn-3e mts">Maths</a></li>
						<li><a href="<?=base_url('english_inst/kindergarten')?>" class="btn-mn btn-3 btn-3e eng">English</a></li>
						<li><a href="#" class="btn-mn btn-3 btn-3e chi">Chinese</a></li>
					</ul>
				</div>
			</div>            
            <div class="math-content">
				<p>Kindergarten</p>
            </div>
          </div>
        </div>
        
        <div class="col-lg-4 col-sm-6">
          <div class="card math-box wow fadeInUp  time4 animated animation_started">
           <div class="content_main">
					<div class="content_img" style="background-image:url(https://www.theuniversityofmaths.com/assets/images/year-1.jpg)">
						<!--<img class="math-img-top" src="https://www.theuniversityofmaths.com/assets/images/year-1.jpg" alt="">-->
					</div>
					<div class="content_links">
						<ul>
							<li><a href="<?=base_url('math_inst/year-1')?>" class="btn-mn btn-3 btn-3e mts">Maths</a></li>
							<li><a href="<?=base_url('english_inst/year-1')?>" class="btn-mn btn-3 btn-3e eng">English</a></li>
							<li><a href="#" class="btn-mn btn-3 btn-3e chi">Chinese</a></li>			
						</ul>
					</div>
			</div>
			<div class="math-content">
				<p>YEAR 1</p>
            </div>
          </div>
        </div>
        
        <div class="col-lg-4 col-sm-6">
          <div class="card math-box maroon_bg  wow fadeInUp  time6 animated animation_started">
           
				<div class="content_main">
					<div class="content_img" style="background-image:url(https://www.theuniversityofmaths.com/assets/images/year-2.jpg)">
						<!--<img class="math-img-top"src="https://www.theuniversityofmaths.com/assets/images/year-2.jpg" alt="">-->
					</div>
					<div class="content_links">
						<ul>
							<li><a href="<?=base_url('math_inst/year-2')?>" class="btn-mn btn-3 btn-3e mts">Maths</a></li>
							<li><a href="<?=base_url('english_inst/year-2')?>" class="btn-mn btn-3 btn-3e eng">English</a></li>
							<li><a href="#" class="btn-mn btn-3 btn-3e chi">Chinese</a></li>			
						</ul>
					</div>
				</div>
			
            <div class="math-content">
            <p>YEAR 2 </p>
            </div>
          </div>
        </div>
        
           <div class="col-lg-4 col-sm-6">
          <div class="card math-box maroon_bg wow fadeInUp  time8 animated animation_started">
           <div class="content_main">
			<div class="content_img" style="background-image:url(https://www.theuniversityofmaths.com/assets/images/year-3.jpg)">
				<!--<img class="math-img-top" src="https://www.theuniversityofmaths.com/assets/images/year-3.jpg" alt="">-->
			</div>
			<div class="content_links">
						<ul>
							<li><a href="<?=base_url('math_inst/year-3')?>" class="btn-mn btn-3 btn-3e mts">Maths</a></li>
							<li><a href="<?=base_url('english_inst/year-3')?>" class="btn-mn btn-3 btn-3e eng">English</a></li>
							<li><a href="#" class="btn-mn btn-3 btn-3e chi">Chinese</a></li>			
						</ul>
					</div>
           </div>
           
            <div class="math-content">
            <p>YEAR 3 </p>
            </div>
          </div>
        </div>
        
        <div class="col-lg-4 col-sm-6">
          <div class="card math-box cyan_bg wow fadeInUp  time10 animated animation_started">
            
			<div class="content_main">
				<div class="content_img" style="background-image:url(https://www.theuniversityofmaths.com/assets/images/year-4.jpg)">
				
				</div>
				<div class="content_links">
						<ul>
							<li><a href="<?=base_url('math_inst/year-4')?>" class="btn-mn btn-3 btn-3e mts">Maths</a></li>
							<li><a href="<?=base_url('english_inst/year-4')?>" class="btn-mn btn-3 btn-3e eng">English</a></li>
							<li><a href="#" class="btn-mn btn-3 btn-3e chi">Chinese</a></li>			
						</ul>
					</div>
				</div>
            <div class="math-content">
            <p>YEAR 4</p>
            </div>
          </div>
        </div>
        
        <div class="col-lg-4 col-sm-6">
          <div class="card math-box  wow fadeInUp  time12 animated animation_started">
            
			<div class="content_main">
			<div class="content_img" style="background-image:url(https://www.theuniversityofmaths.com/assets/images/year-5.jpg)">
			<!--<img class="math-img-top" src="https://www.theuniversityofmaths.com/assets/images/year-5.jpg" alt="")>-->
			</div>
            <div class="content_links">
						<ul>
							<li><a href="<?=base_url('math_inst/year-5')?>" class="btn-mn btn-3 btn-3e mts">Maths</a></li>
							<li><a href="<?=base_url('english_inst/year-5')?>" class="btn-mn btn-3 btn-3e eng">English</a></li>
							<li><a href="#" class="btn-mn btn-3 btn-3e chi">Chinese</a></li>			
						</ul>
					</div>
            </div>
            <div class="math-content">
            <p>YEAR 5 </p>
            </div>
          </div>
        </div>
        
           <div class="col-lg-4 col-sm-6">
			<div class="card math-box wow fadeInUp  time14 animated animation_started">
            
			<div class="content_main">
			<div class="content_img" style="background-image:url(https://www.theuniversityofmaths.com/assets/images/year-6.jpg">
			<!--<img class="math-img-top" src="https://www.theuniversityofmaths.com/assets/images/year-6.jpg" alt="">-->
			</div>
           <div class="content_links">
						<ul>
							<li><a href="<?=base_url('math_inst/year-6')?>" class="btn-mn btn-3 btn-3e mts">Maths</a></li>
							<li><a href="<?=base_url('english_inst/year-6')?>" class="btn-mn btn-3 btn-3e eng">English</a></li>
							<li><a href="#" class="btn-mn btn-3 btn-3e chi">Chinese</a></li>			
						</ul>
			</div>
            </div>
            
            <div class="math-content">
            <p>YEAR 6</p>
            </div>
          </div>
        </div>
        
        <div class="col-lg-4 col-sm-6">
          <div class="card math-box maroon_bg wow fadeInUp  time14 animated animation_started">
           
			<div class="content_main">
			<div class="content_img" style="background-image:url(https://www.theuniversityofmaths.com/assets/images/year-7.jpg)">
			<!--<img class="math-img-top" src="https://www.theuniversityofmaths.com/assets/images/year-7.jpg" alt="">-->
			</div>
			<div class="content_links">
						<ul>
							<li><a href="<?=base_url('math_inst/year-7')?>" class="btn-mn btn-3 btn-3e mts">Maths</a></li>
							<li><a href="<?=base_url('english_inst/year-7')?>" class="btn-mn btn-3 btn-3e eng">English</a></li>
							<li><a href="#" class="btn-mn btn-3 btn-3e chi">Chinese</a></li>			
						</ul>
					</div></div>
            
            <div class="math-content">
            <p>YEAR 7 </p>
            </div>
          </div>
        </div>
        
        <div class="col-lg-4 col-sm-6">
          <div class="card math-box cyan_bg wow fadeInUp  time16 animated animation_started">
           
			<div class="content_main">
			<div class="content_img" style="background-image:url(https://www.theuniversityofmaths.com/assets/images/year-8.jpg)">
			<!--<img class="math-img-top" src="https://www.theuniversityofmaths.com/assets/images/year-8.jpg" alt="">-->
			</div>
            <div class="content_links">
						<ul>
							<li><a href="<?=base_url('math_inst/year-8')?>" class="btn-mn btn-3 btn-3e mts">Maths</a></li>
							<li><a href="<?=base_url('english_inst/year-8')?>" class="btn-mn btn-3 btn-3e eng">English</a></li>
							<li><a href="#" class="btn-mn btn-3 btn-3e chi">Chinese</a></li>			
						</ul>
					</div>
            </div>
            <div class="math-content">
            <p>YEAR 8</p>
            </div>
          </div>
        </div>
        
           <div class="col-lg-4 col-sm-6">
          <div class="card math-box cyan_bg wow fadeInUp  time18 animated animation_started">
           
			<div class="content_main">
			<div class="content_img" style="background-image:url(https://www.theuniversityofmaths.com/assets/images/year-9.jpg)">
			<!--<img class="math-img-top" src="https://www.theuniversityofmaths.com/assets/images/year-9.jpg" alt="">-->
			</div>
            <div class="content_links">
						<ul>
							<li><a href="<?=base_url('math_inst/year-9')?>" class="btn-mn btn-3 btn-3e mts">Maths</a></li>
							<li><a href="<?=base_url('english_inst/year-9')?>" class="btn-mn btn-3 btn-3e eng">English</a></li>
							<li><a href="#" class="btn-mn btn-3 btn-3e chi">Chinese</a></li>			
						</ul>
					</div>
					</div>
					
            
            <div class="math-content">
            <p>YEAR 9 </p>
            </div>
          </div>
        </div>
        
        <div class="col-lg-4 col-sm-6">
          <div class="card math-box wow fadeInUp  time20 animated animation_started">
          
			<div class="content_main">
			<div class="content_img" style="background-image:url(https://www.theuniversityofmaths.com/assets/images/year-10.jpg)">
			<!--<img class="math-img-top" src="https://www.theuniversityofmaths.com/assets/images/year-10.jpg" alt="">-->
			</div>
            <div class="content_links">
						<ul>
							<li><a href="<?=base_url('math_inst/year-10')?>" class="btn-mn btn-3 btn-3e mts">Maths</a></li>
							<li><a href="<?=base_url('english_inst/year-10')?>" class="btn-mn btn-3 btn-3e eng">English</a></li>
							<li><a href="#" class="btn-mn btn-3 btn-3e chi">Chinese</a></li>			
						</ul>
					</div></div>
           
            <div class="math-content">
            <p>YEAR 10</p>
            </div>
          </div>
        </div>
        
        <div class="col-lg-4 col-sm-6">
          <div class="card math-box maroon_bg wow fadeInUp  time22 animated animation_started">
           
			<div class="content_main">
			<div class="content_img" style="background-image:url(https://www.theuniversityofmaths.com/assets/images/year-11.jpg)">
			<!--<img class="math-img-top" src="https://www.theuniversityofmaths.com/assets/images/year-11.jpg" alt="">-->
			</div>
           <div class="content_links">
						<ul>
							<li><a href="<?=base_url('math_inst/year-11')?>" class="btn-mn btn-3 btn-3e mts">Maths</a></li>
							<li><a href="<?=base_url('english_inst/year-11')?>" class="btn-mn btn-3 btn-3e eng">English</a></li>
							<li><a href="#" class="btn-mn btn-3 btn-3e chi">Chinese</a></li>			
						</ul>
					</div></div>
            <div class="math-content">
            <p>YEAR 11 </p>
            </div>
          </div>
        </div>
        
           <div class="col-lg-4 col-sm-6">
          <div class="card math-box maroon_bg wow fadeInUp  time24 animated animation_started">
           
			<div class="content_main">
			<div class="content_img" style="background-image:url(https://www.theuniversityofmaths.com/assets/images/year-12.jpg)">
			<!--<img class="math-img-top" src="" alt="">-->
			</div>
            <div class="content_links">
						<ul>
							<li><a href="<?=base_url('math_inst/year-12')?>" class="btn-mn btn-3 btn-3e mts">Maths</a></li>
							<li><a href="<?=base_url('english_inst/year-12')?>" class="btn-mn btn-3 btn-3e eng">English</a></li>
							<li><a href="#" class="btn-mn btn-3 btn-3e chi">Chinese</a></li>			
						</ul>
					</div></div>
           
            <div class="math-content">
            <p>YEAR 12 </p>
            </div>
          </div>
        </div>
        
        <div class="col-lg-4 col-sm-6">
          <div class="card math-box wow cyan_bg fadeInUp  time26 animated animation_started">
            
			<div class="content_main">
			<div class="content_img" style="background-image:url(https://www.theuniversityofmaths.com/assets/images/year-13.jpg)">
				<!--<img class="math-img-top" src="https://www.theuniversityofmaths.com/assets/images/year-13.jpg" alt="">-->
            </div>
			<div class="content_links">
						<ul>
							<li><a href="<?=base_url('math_inst/year-13')?>" class="btn-mn btn-3 btn-3e mts">Maths</a></li>
							<li><a href="<?=base_url('english_inst/year-13')?>" class="btn-mn btn-3 btn-3e eng">English</a></li>
							<li><a href="#" class="btn-mn btn-3 btn-3e chi">Chinese</a></li>			
						</ul>
					</div></div>
            
            <div class="math-content">
            <p>YEAR 13</p>
            </div>
          </div>
        </div>
         
        <div class="col-xs-12 col-sm-12 col-md-6 col-lg-4">
          <div class="card math-box yellow-bg">
            
            <p>We are using Mathematics Intelligence Systems to teach and monitor our student learning process.</p>
          </div>
        </div>
       </div>
      <!-- /.row -->
    </div>
    </div>
    </section>
  <!-- Page Content End -->
