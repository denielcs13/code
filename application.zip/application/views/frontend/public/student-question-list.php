<section id="title-inner" style="background-image:url(<?= base_url('assets/images/profile.jpg')?>);">
<div id="large-header">   
<canvas id="demo-canvas"></canvas>
<div class="container">
<div class="text-tit">
 <div class="bb"></div>
<span class="lefttop-icon"></span>
<h1>
<span>Student Question</span>
</h1>
<span class="rightbotm-icon"></span>
</div>

</div></div>

</section>

<section class="about_content content-text syllabus-page space-75 profile">
   <div class="container">           
         <div class="row">            		 
         	<div class="col-md-12">
         		<table class="table table-bordered nowrap display">         			
         			<thead>
                                            <tr>
											   <th>#</th>
											   <th>Question Name</th>                                                
                                            </tr>
                    </thead>
                    <tbody>
         			
         			<?php 
										$i = 1;
										if($ques_lst){
										foreach($ques_lst as $ques_ls){
											
											?>
         			<tr>
         				<td><?php echo $i;?></td>        				
         				<td><a href="<?php 
						 if($ques_ls->year_id==1){
							$clstype="kindergarten"; 
						 }
						 else{
							$clstype="year-".($ques_ls->year_id - 1); 
						 }
						echo base_url($ques_ls->class_type.'/'.$clstype.'/').$ques_ls->skill_slug;?>"><?php echo $ques_ls->skill_name;?></a></td>         				
         			</tr>
         			<?php $i++;}}else{?>
											
											  <tr>
												<td colspan="5">No record found</td>
                                              
                                            </tr>
											
										<?php } ?>
				</tbody>						
         		</table>
         	</div>
         </div>
      
   </div>
</section>