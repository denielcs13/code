<section id="title-inner" style="background-image:url(<?= base_url('assets/images/profile.jpg')?>);">
<div id="large-header">   
<canvas id="demo-canvas"></canvas>
<div class="container">
<div class="text-tit">
 <div class="bb"></div>
<span class="lefttop-icon"></span>
<h1>
<span>Welcome to Dashboard</span>
</h1>
<span class="rightbotm-icon"></span>
</div>

</div></div>

</section>
<section class="about_content content-text syllabus-page space-75 profile">
   <div class="container">
   <div class="row">
  <div class="col-md-12">   
   <?php

        if($this->session->flashdata('msg'))
        {?>
            <div id="msg" >
            <?PHP
            echo "<span> ".$this->session->flashdata('msg')."</span>";
       
          ?></div> <?PHP } else if($this->session->flashdata('msgappr'))
        {?>
            <div id="msg" >
            <?PHP
            echo "<span> ".$this->session->flashdata('msgappr')."</span>";
       
          ?></div> <?PHP } else if($this->session->flashdata('msgrm'))
        {?>
            <div id="msg" >
            <?PHP
            echo "<span> ".$this->session->flashdata('msgrm')."</span>";
       
          ?></div> <?PHP }else if($this->session->flashdata('msgrme'))
        {?>
            <div id="msg">
            <?PHP
            echo "<span> ".$this->session->flashdata('msgrme')."</span>";
       
          ?></div> <?PHP } else if($this->session->flashdata('msgsnd'))
        {?>
            <div id="msg">
            <?PHP
            echo "<span> ".$this->session->flashdata('msgsnd')."</span>";
       
          ?></div> <?PHP } else if($this->session->flashdata('msgsyl'))
        {?>
            <div id="msg">
            <?PHP
            echo "<span> ".$this->session->flashdata('msgsyl')."</span>";
       
          ?></div> <?PHP }?>
		  </div>
		  </div>
		  <div class="row">
		  <div class="col-md-12">
		  
		  <span class="mecBox" style="float: left;">
          <a href="<?=base_url('math');?>" name="add_stud"  class="btn-mn btn-3 btn-3e mts"> Math</a>
          <a href="<?=base_url('english');?>" name="add_stud"  class="btn-mn btn-3 btn-3e mts">English</a>
		  <a href="#" name="add_stud"  class="btn-mn btn-3 btn-3e mts">Chinees</a>
		  <a href="<?=base_url('score');?>" name="test_stud"  class="btn-mn btn-3 btn-3e mts">Test Score</a>
           </span>
		  </div>
		  </div>
          <div class="row">
            <?php if($this->session->userdata('user_type')=='7'){?>
             <div class="col-sm-12">
            <span class="mecBox" style="float: right;">
          <a href="<?=base_url('student-list');?>" name="add_stud"  class="btn-mn btn-3 btn-3e mts"> Children List</a>
          <a href="<?=base_url('add-user');?>" name="add_stud"  class="btn-mn btn-3 btn-3e mts">Add Children</a>
           </span>
        
             </div>
          <?php } ?>
		  
		  <?php if($this->session->userdata('user_type')=='8'){?>
             <div class="col-sm-12">
            <span class="mecBox" style="">
          <a href="<?=base_url('student-list');?>" name="add_stud"  class="btn-mn btn-3 btn-3e mts"> Student List</a>
          <a href="<?=base_url('add-user');?>" name="add_stud"  class="btn-mn btn-3 btn-3e mts">Add Student</a>
		  <a href="<?=base_url('approve-student');?>" name="aprove_stud"  class="btn-mn btn-3 btn-3e mts">Approve Student</a>
		   <a href="<?=base_url('add-syllabus');?>" name="aprove_stud"  class="btn-mn btn-3 btn-3e mts">Add Syllabus</a>
		   <a href="<?=base_url('institute-syllabus-list');?>" name="aprove_stud"  class="btn-mn btn-3 btn-3e mts">Syllabus List</a>
           </span>
        
             </div>
          <?php } ?>
		  
		  <?php 
		  if($this->session->userdata('user_type')=='6' && $this->session->userdata('parent_id')=='0'){?>
             <div class="col-sm-12">
            <span class="mecBox" style="">
          <a href="<?=base_url('send-add-request');?>" name="add_stud"  class="btn-mn btn-3 btn-3e mts"> Send Add Request</a>
          
           </span>        
             </div>
          <?php } ?>
		  
		  <?php 
		  if($this->session->userdata('user_type')=='6' && $this->session->userdata('parent_id')!='0'){?>
             <div class="col-sm-12">
            <span class="mecBox" style="">
          <a href="<?=base_url('student-question-list');?>" name="add_stud"  class="btn-mn btn-3 btn-3e mts"> My Syllabus</a>
          
           </span>        
             </div>
          <?php } ?>
		  
		  <div class="col-sm-12">
            <span class="mecBox" style="">
          <a href="<?=base_url('profile-update');?>" name="add_stud"  class="btn-mn btn-3 btn-3e mts"> Profile</a>
          
           </span>        
             </div>
			   <div class="col-sm-12">
            <span class="mecBox" style="">
               <a href="<?=base_url('change-password');?>" name="add_stud"  class="btn-mn btn-3 btn-3e mts"> Change password</a>
          
           </span>        
             </div>
		  
          </div>
         <div class="row">
		 </div>
      
   </div>
</section>