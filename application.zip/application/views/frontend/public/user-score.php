<section id="title-inner" style="background-image:url(<?= base_url('assets/images/profile.jpg')?>);">
<div id="large-header">   
<canvas id="demo-canvas"></canvas>
<div class="container">
<div class="text-tit">
 <div class="bb"></div>
<span class="lefttop-icon"></span>
<h1>
<span>Test Score</span>
</h1>
<span class="rightbotm-icon"></span>
</div>

</div></div>

</section>

<section class="about_content content-text syllabus-page space-75 profile">
   <div class="container">          
         <div class="row">		 
         	<div class="col-md-12">
         		<table class="table table-bordered nowrap display">         			
         			<thead>
                                            <tr>
                                               <th>Class Name</th>												
											   <th>Total Question attemp</th>
											   <th>Total Correct Question</th>
											   <th>Total Wrong Question</th>
											   <th>Percentage</th>                                              
                                            </tr>
                    </thead>
                    <tbody>
         			
         			<?php 
         			 error_reporting(0);
							//var_dump($score_dtl);die;
										$i = 1;
										$crt=0;
										$wrg=0;

										if($score_dtl){
										foreach($score_dtl as $score_dt){
											if($score_dt->wrg_ans!=0){
												$wrg=+$wrg;

												$wrg++;

											}
											if($score_dt->wrg_ans==0){
												$crt=+$crt;

												$crt++;

											}
											if($score_dt->ques_class==1)
											{
												$cls="Kindergarten";
											}
											
                                          
											?>
         			
         			<?php $i++;
         		}
         			 //echo $crt.'<br>'.$wrg;

         		}else{?>
											
											  <tr>
												<td colspan="5">No record found</td>
                                              
                                            </tr>
											
										<?php } ?>
				<tr>
					    <td><?php echo $cls;?></td>
         				<td><?php echo ($crt+$wrg);?></td>        				
         				<td><?php echo $crt;?></td> 
         				<td><?php echo $wrg;?></td>
         				<td><?php echo number_format(($crt/($crt+$wrg))*100,2);?></td>        				
         			</tr>						


				</tbody>						
         		</table>
         	</div>
         </div>
      
   </div>
</section>