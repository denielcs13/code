<?php 
if($this->session->userdata('user_id')!='')
{

	include(APPPATH.'/views/frontend/private/header.php');
	
}
else
{
	include('header.php');
}	
?>
 <!-- Page Content inner -->
 
 <section class="about_content content-text space-75 page_404"> 
 <div class="container">
 <div class="row">
 
 <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
 
<div class="text-center">
<div class="globe">
    <div class="bird">
        <div class="body">
        <div class="eye left"></div>
        <div class="eye right"></div>
        <div class="beak"><div></div></div>
        <div class="feet"></div>
        <div class="wire"></div>
        </div>
        <div class="hills"></div>
        <div class="cloud"></div>
        <div class="cloud small"></div>
    </div>
</div>

<h2>404</h2> 
<span class="text-this">This is somewhat embarrassing, isn't it?</span> 
 </div>
 

 </div>
 
 
 
 
 </div>
 </div>
 </section>
 
 
   
   
   
   
   
   
    
 <!-- Page Content End -->
<?php 
if($this->session->userdata('user_id')!='')
{
	include(APPPATH.'/views/frontend/private/footer.php');
}
else
{
	include('footer.php');
}	
?>