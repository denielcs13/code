<section id="title-inner" style="background-image:url(<?= base_url('assets/images/profile.jpg')?>);">
<div id="large-header">   
<canvas id="demo-canvas"></canvas>
<div class="container">
<div class="text-tit">
 <div class="bb"></div>
<span class="lefttop-icon"></span>
<h1>
<span>Syllabus List</span>
</h1>
<span class="rightbotm-icon"></span>
</div>

</div></div>

</section>
<script> 
 function cnfdel(id){
		var url="<?php echo base_url().'delete-inst-syllabus/';?>";
	   if (confirm("Are you sure want to delete this student?")) {
       window.location.href = url+"/"+id;
		}
    return false;
 }
 </script>
<section class="about_content content-text syllabus-page space-75 profile">
   <div class="container"> 
          <?php 
						if($this->session->flashdata('msgdelinst') != null && $this->session->flashdata('msgdelinst') != "")
							{ 
							?>
							<div class="row">
								<div class="col-md-12">									
									<?php echo $this->session->flashdata('msgdelinst');?>
								</div>
							</div>
							<?php 
							} else if($this->session->flashdata('msgadd') != null && $this->session->flashdata('msgadd') != "")
							{ 
							?>
							<div class="row">
								<div class="col-md-12">
									<div class="alert" role="alert">
									<?php echo $this->session->flashdata('msgadd');?>
									</div>
								</div>
							</div>
							<?php 
							} 
						?>
         		  <div class="row">		          	<div class="col-md-12">			   <span class="mecBox" style="float: right;">			    			      <a href="<?=base_url('add-syllabus');?>" name="add_stud"  class="btn-mn btn-3 btn-3e mts">Add Syllabus</a>				 			   </span></div></div>			 <div class="row">		 
         	<div class="col-md-12">
         		<table class="table table-bordered nowrap display">         			
         			<thead>
                                            <tr>
												<th>#</th>
											    <th>Skill Name</th>
                                                <th>Class</th> 
                                                <th>Type</th>
                                                <th>Syllabus Name</th>
												<th>Action</th>
                                            </tr>
                    </thead>
                    <tbody>
         			
         			<?php 
										$i = 1;
										if($syl_lst){
										foreach($syl_lst as $syl_ls){
											?>
         			<tr>
         				<td><?php echo $i;?></td>
         				<td><?php echo $syl_ls->skill_name;?></td>
         				 <td><?php 
						 if($syl_ls->year_id=='1'){
						 echo "Kindergarten";
						 }else {
							echo "Year ".($syl_ls->year_id - 1); 
						 }
						 ?></td>
						 <td><?php echo ucfirst($syl_ls->class_type);?></td>
						 <td><?php echo $syl_ls->syllb_name;?></td>
         				 <td>
                                                    <a href="javascript:void(0)" onclick="cnfdel(<?php echo $syl_ls->s_id;?>)"><button type="button" class="btn btn-sm btn-icon btn-pure btn-outline delete-row-btn redColor" data-toggle="tooltip" data-original-title="Delete" style="color:#668fc9;">Delete</button></a>
													<!--<a href="<?//php echo base_url().'edit-student/'.$syl_ls->s_id;?>"><button type="button" class="btn btn-sm btn-icon btn-pure btn-outline delete-row-btn royal-blue" data-toggle="tooltip" data-original-title="Edit" style="color:#668fc9;">Edit</button></a>-->
													
                       </td>
         			</tr>
         			<?php $i++;}}else{?>
											
											  <tr>
												<td colspan="5">No record found</td>
                                              
                                            </tr>
											
										<?php } ?>
				</tbody>						
         		</table>
         	</div>
         </div>
      
   </div>
</section>