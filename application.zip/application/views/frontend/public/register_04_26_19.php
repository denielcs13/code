
<div class="login-page signup-page">
  <div class="container">
    <div class="row">
      <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 space-75">
        <div class="row res-space-0">
          <div class="col-md-2"></div>
          <div class="col-xs-12 col-sm-12 col-md-12 col-lg-8 shadow-box">
            <div class="bg-form">
              <div class="row">
                <div class="col-xs-12 col-md-6 p-left15 mobile-none">
                  <div class="login-bg">
                    <div class="text-content">
                      <h2><br />
                       </h2>
                      <p></p>
                    </div>
                  </div>
                </div>
                <div class="col-xs-12 col-md-6">
                  <div class="form-section">
                    <h1>Membership</h1>
                    <form class="cmxform" id="signupForm" method="post" action="">
                      <div class="row">
                        <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
						<?php if (validation_errors()){ ?>
										
												<div class="alert alert-danger" role="alert">
													<?= validation_errors() ?>
												</div>
										
						<?php }
							elseif($this->session->flashdata('msg') != null && $this->session->flashdata('msg') != "")
								{ 
								?>
								<div class="alert alert-danger" role="alert">
										<?php echo $this->session->flashdata('msg');?>
								</div>
											
							<?php }	?>
                          <div id="msgemail"></div>
                          <p class="error">Student’s Email is required.</p>
                          <div class="input-field">
                            <input type="text" name="reg_email" id="reg_email" value="" placeholder="Student’s Email " />
                            
                          </div>
                          <div class="row">
                            <div class="col-lg-6">
                              <div class="input-field">
                                <input type="text" name="reg_fname" id="reg_email" placeholder="Student’s First Name" value=""/>
                              </div>
                            </div>
                            <div class="col-lg-6">
                              <div class="input-field">
                                <input type="text" name="reg_lname" id="reg_email" placeholder="Student’s Last Name" value="" />
                              </div>
                            </div>
                          </div>
                          
                          <!--<div class="input-field">
                            <input type="text" name="reg_mobile" placeholder="Phone" />
                          </div>-->
                          <button disabled="" class="btn-mn btn-3 btn-3e button-org">Sign Up</button>
                        </div>
                      </div>
                    </form>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="col-md-2"></div>
        </div>
      </div>
    </div>
  </div>
</div>

<!-- Page Content End -->


<?php /*?><script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script><?php */?>
<script type="text/javascript">

jQuery(document).ready(function(){

    jQuery('#reg_email').blur(function(){
	var email=$('#reg_email').val();
    jQuery.post('<?=base_url('useremailcheck1');?>',{email:email},function(result){
           if(result=="<span style='color:green'>You can register with us.</span>")
           {
            jQuery('.button-org').removeAttr('disabled');
            jQuery( "#msgemail" ).html(result);
           }else{
            jQuery('.button-org').prop('disabled','true');
            jQuery( "#msgemail" ).html(result);
           }
          
		   console.log(result);
        });
    });    
});
</script> 


