<section id="title-inner" style="background-image:url(<?= base_url('assets/images/profile.jpg')?>);">
<div id="large-header">   
<canvas id="demo-canvas"></canvas>
<div class="container">
<div class="text-tit">
 <div class="bb"></div>
<span class="lefttop-icon"></span>
<h1>
<span>Add Syllabus</span>
</h1>
<span class="rightbotm-icon"></span>
</div>

</div></div>

</section>
<section class="about_content content-text syllabus-page space-75 profile">
   <div class="container">
   <?php

        if($this->session->flashdata('msg'))
        {?>
            <div id="msg" style="border: 1px solid;height: 34px;box-shadow: aquamarine;box-shadow: 0px 0px 0px 1px black;">
            <?PHP
            echo "<span> ".$this->session->flashdata('msg')."</span>";
       
          ?></div> <?PHP }?>
          
   <form  method="post" action="">
      <div class="row">         
		 <div class="col-sm-12 col-lg-6">
            <div class="form-group row">
               <label for="fname2" class="col-sm-3 text-left control-label col-form-label">Syllabus name</label> <div class="col-sm-9">                			   
                <input type="text" class="form-control" name="syllb_name" id="syllb_name"  placeholder="Please Enter Syllabus Name">
                <span class="danger-error"><?=form_error('syllb_name')?></span>				
               </div>
			   
            </div>
         </div>
         <div class="col-sm-12 col-lg-6">
            <div class="form-group row">
               <label for="fname2" class="col-sm-3 text-left control-label col-form-label">Class type</label>                    
               <div class="col-sm-9">                			   
                <select class="form-control custom-select" data-placeholder="Select Class" name="class_type" id="class_type" tabindex="1">
				 <option value="">Select</option>
                 <option value="math">Math</option>
                 <option value="english">English</option>
                 <option value="">Chinees</option>				 
                  </select>                                   
               </div>
            </div>
         </div>
		 
         <div class="col-sm-12 col-lg-6">
            <div class="form-group row">
               <label for="fname2" class="col-sm-3 text-left control-label col-form-label">Class Name</label>                    
               <div id="div_cls_type" class="col-sm-9">                			   
                <select class="form-control custom-select" data-placeholder="Select Class" name="class_name" id="class_role" tabindex="1">
				 <option value="">Select</option>			
                               
                                <?php  
                    $i = 1;
                    if($year_dtl){
                    foreach($year_dtl as $year_dt){
                      ?>
                      <option value="<?=$year_dt->class_id;?>"><?=$year_dt->class_name;?></option>
                      <?php $i++;}}else{?>                      
                       
                        <option value="">No data find</option>                  
                      
                    <?php } ?>

                     </select>
                     					 
                                   
               <span class="danger-error"><?=form_error('class_name')?></span>
               </div>
            </div>
         </div>
		 <div class="col-sm-12 col-lg-6">
            <div class="form-group row">
               <label for="fname2" class="col-sm-3 text-left control-label col-form-label">Topic Name</label>
               <form action="" method="POST">			   
               <div class="col-sm-9" id="subclass_div">					   
               <input type="text" class="form-control" name="t_name" id="t_name"  placeholder="Please Enter Topic Name" onkeyup="ajaxSearch();">			   
               <span class="danger-error"><?=form_error('t_name')?></span>
			   
                <div id="suggestions">
				  	 <div id="autoSuggestionsList"></div>
					 <button type="submit" name="submit" class="btn-mn btn-3 btn-3e button-org subBox">Add</button>
				 </div>
                </div>
				</form>
			   
            </div>
         </div>    
         
         <!--div class="col-sm-12 col-lg-12">
            <div class="card-body">
               <div class="form-group m-b-0 text-right">						
               <button type="submit" class="btn-mn btn-3 btn-3e button-org subBox">Add</button>	</div>
            </div>
         </div-->
      </div>
      </form>
   </div>
</section>
<script type="text/javascript">

jQuery(document).ready(function(){
	
    //05-02-19
    $(document).on('change','#class_type',function(){
            var cls_type = $("option:selected", this).text();
			var c_type = $("#class_type").val();
                        
			$('#div_cls_type').append('<input type="hidden" name="cls_type1" id="type_id1" value="'+c_type+'">');
           //$('#div_cls_type').val(c_type);
		   });   

   //05-02-19
    $(document).on('change','#class_role',function(){
            var cls_name = $("option:selected", this).text();
			var t_name = $("#t_name").val();
            var cls_id = $("#class_role").val();
            var ctype_id1 = $("#type_id1").val(); 			
            			
			$('#subclass_div').append('<input type="hidden" name="cls_id" id="cls_id1" value="'+cls_id+'"><input type="hidden" name="clstype_id" id="clstype_id1" value="'+ctype_id1+'">');
           });   
});


function ajaxSearch()
{   var cls_id = $("#cls_id1").val();
    var cls_id_type = $("#clstype_id1").val();    	
    var input_data = $('#t_name').val();
	//console.log(cls_id_type);  

    if (input_data.length === 0)
    {
        $('#suggestions').hide();
    }
    else
    {

        var post_data = {
            'search_data': input_data,
            'id':cls_id,
			'cls_type':cls_id_type
            };

        $.ajax({
            type: "POST",
            url: "<?php echo base_url('classnamecheck'); ?>",
            data: post_data,
            success: function (data) {
                // return success
                if (data.length > 0) {
                    $('#suggestions').show();
                    $('#autoSuggestionsList').addClass('auto_list');
                    $('#autoSuggestionsList').html(data);
                }
            }
         });

     }
 }	
</script>
<style>
input[type=text] {
    width: 200px;
    padding: 5px;
    margin: 5px 0;
    box-sizing: border-box;
}

#autoSuggestionsList > li {
    background: none repeat scroll 0 0 #F3F3F3;
    border-bottom: 1px solid #E3E3E3;
    list-style: none outside none;
    padding: 3px 15px 3px 15px;
    text-align: left;
}


#autoSuggestionsList > li a { color: #800000; 
width: 90%;
display: inline-block;
}

.auto_list {
    border: 1px solid #E3E3E3;
    border-radius: 5px 5px 5px 5px;   
    width: 100%;

}
.auto_list li input[type="checkbox"]{
	
	float: right;
    vertical-align: middle;
    display: inline-block;
    margin: 7px;
}
.subBox{
	float:right;
	margin-top:10px;
}
</style>