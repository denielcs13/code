<?php 
if($this->session->userdata('user_id')!='')
{

	include(APPPATH.'/views/frontend/private/header.php');
	
}
else
{
	include('header.php');
}	
?>

<?php  $img=ucfirst($year_dtl->class_slug.'_bg.jpg');?>
<section id="title-inner" style="background-image:url(<?= base_url('assets/images/'.$img)?>);">
<div id="large-header">   
<canvas id="demo-canvas"></canvas>
<div class="container">
<div class="text-tit">
 <div class="bb"></div>
<span class="lefttop-icon"></span>
<h1>
<span><?php echo $year_dtl->class_name;?></span>
</h1>
<span class="rightbotm-icon"></span>
</div>



</div></div>





</section>

 <!-- Page Content inner -->
 
 
 <section class="about_content content-text syllabus-page kg_wtht_login space-75">
 <div class="container">
 <div class="row">
<!-- Bootstrap Tabs -->
	
	<div class="tab-content">
	<div class="row">
	<?php 
      if($SylList1 != null && $SylList1 != ""){
			global $order_arr;
			$tid=0;$wid=0;
									?>
        <div class="col-xs-12 col-sm-12 col-md-6 col-lg-6">
        
		
		
														
			
			<h2 class="blue-title">Term 1</h2>
			
			
<div class="row">
<?php foreach($SylList1 as $result){
	$term= $this->main_model->get_detail('master_terms','term_id',$result->term_id);
	$skl_dtl= $this->main_model->get_detail('master_skill','skill_id',$result->skill_id);
	$query=$this->db->query('select * from syllabus_week_subskill where subskill_id IN (select skill_id from master_skill where skill_parent="'.$result->skill_id.'")'); 
	?>
<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
<div class="syllabus-sec">
<h3><?php echo $order_arr[$result->skill_order].'. '.$skl_dtl->skill_name;?></h3>
<div class="row">



</div>
</div>




</div>

<?PHP } ?>




</div>
 </div>
<?PHP } ?>        
        
        
        <?php 
      if($SylList2 != null && $SylList2 != ""){
			global $order_arr;
			$tid=0;$wid=0;
									?>
        <div class="col-xs-12 col-sm-12 col-md-6 col-lg-6">
        
		
		
														
			
			<h2 class="green-title">Term 2</h2>
			
			
<div class="row">
<?php foreach($SylList2 as $result){
	$term= $this->main_model->get_detail('master_terms','term_id',$result->term_id);
	$skl_dtl= $this->main_model->get_detail('master_skill','skill_id',$result->skill_id);
	$query=$this->db->query('select * from syllabus_week_subskill where subskill_id IN (select skill_id from master_skill where skill_parent="'.$result->skill_id.'")'); 
	?>
<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
<div class="syllabus-sec">
<h3><?php echo $order_arr[$result->skill_order].'. '.$skl_dtl->skill_name;?></h3>

</div>




</div>

<?PHP } ?>




</div>
 </div>
<?PHP } ?>        
        
     
  <?php 
      if($SylList3 != null && $SylList3 != ""){
			global $order_arr;
			$tid=0;$wid=0;
									?>
        <div class="col-xs-12 col-sm-12 col-md-6 col-lg-6">
        
		
		
														
			
			<h2  class="cyan-title">Term 3</h2>
			
			
<div class="row">
<?php foreach($SylList3 as $result){
	$term= $this->main_model->get_detail('master_terms','term_id',$result->term_id);
	$skl_dtl= $this->main_model->get_detail('master_skill','skill_id',$result->skill_id);
	$query=$this->db->query('select * from syllabus_week_subskill where subskill_id IN (select skill_id from master_skill where skill_parent="'.$result->skill_id.'")'); 
	?>
<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
<div class="syllabus-sec">
<h3><?php echo $order_arr[$result->skill_order].'. '.$skl_dtl->skill_name;?></h3>
<div class="row">








</div>
</div>




</div>

<?PHP } ?>




</div>
 </div>
<?PHP } ?>        
        
         
<?php 
      if($SylList4 != null && $SylList4 != ""){
			global $order_arr;
			$tid=0;$wid=0;
									?>
        <div class="col-xs-12 col-sm-12 col-md-6 col-lg-6">
        
		
		
														
			
			<h2 class="red-title">Term 4</h2>
			
			
<div class="row">
<?php foreach($SylList4 as $result){
	$term= $this->main_model->get_detail('master_terms','term_id',$result->term_id);
	$skl_dtl= $this->main_model->get_detail('master_skill','skill_id',$result->skill_id);
	$query=$this->db->query('select * from syllabus_week_subskill where subskill_id IN (select skill_id from master_skill where skill_parent="'.$result->skill_id.'")'); 
	?>
<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
<div class="syllabus-sec">
<h3><?php echo $order_arr[$result->skill_order].'. '.$skl_dtl->skill_name;?></h3>
<div class="row">






</div>
</div>




</div>

<?PHP } ?>




</div>
 </div> 
<?PHP } ?>        
        
     
	</div>
</div>
 </div>
 </div>
 </section>
 
 
 


   
   
   
   
    
 <!-- Page Content End -->
<?php 
if($this->session->userdata('user_id')!='')
{
	include(APPPATH.'/views/frontend/private/footer.php');
}
else
{
	include('footer.php');
}	
?>