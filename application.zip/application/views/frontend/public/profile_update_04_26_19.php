<section id="title-inner" style="background-image:url(<?= base_url('assets/images/profile.jpg')?>);">
<div id="large-header">   
<canvas id="demo-canvas"></canvas>
<div class="container">
<div class="text-tit">
 <div class="bb"></div>
<span class="lefttop-icon"></span>
<h1>
<span>Profile</span>
</h1>
<span class="rightbotm-icon"></span>
</div>

</div></div>

</section>
<section class="about_content content-text syllabus-page space-75 profile">
   <div class="container">
   <?php

        if($this->session->flashdata('msg'))
        {?>
            <div id="msg" style="border: 1px solid;height: 34px;box-shadow: aquamarine;box-shadow: 0px 0px 0px 1px black;">
            <?PHP
            echo "<span> ".$this->session->flashdata('msg')."</span>";
       
          ?></div> <?PHP }?>
   <form action="" method="post" enctype="multipart/form-data">
      <div class="row">
      
         <div class="col-sm-12 col-lg-6">
            <div class="form-group row">
               <label for="fname2" class="col-sm-3 text-left control-label col-form-label">First Name</label>					
               <div class="col-sm-9">					   
               <input type="text" class="form-control" name="f_name" value="<?=($user->first_name)?$user->first_name:set_value('f_name')?>" placeholder="First Name">
               <span class="danger-error"><?=form_error('f_name')?></span>					
               </div>
            </div>
         </div>
         <div class="col-sm-12 col-lg-6">
            <div class="form-group row">
               <label for="fname2" class="col-sm-3 text-left control-label col-form-label">Last Name</label>                    
               <div class="col-sm-9">                        
               <input type="text" name="last_name" value="<?=($user->last_name)?$user->last_name:set_value('last_name')?>" class="form-control" placeholder="Last Name">                    
               <span class="danger-error"><?=form_error('last_name')?></span>
               </div>
            </div>
         </div>
         <div class="col-sm-12 col-lg-6">
            <div class="form-group row">
               <label for="fname2" class="col-sm-3 text-left control-label col-form-label">Date of Birth</label>                    
               <div class="col-sm-9">                        
               <input type="date" name="dob" value="<?=($user->dob)?$user->dob:set_value('dob')?>" class="form-control" placeholder="Date of Birth">                    
               <span class="danger-error"><?=form_error('dob')?></span>
               </div>
            </div>
         </div>
         <div class="col-sm-12 col-lg-6">
            <div class="form-group row">
               <label for="fname2" class="col-sm-3 text-left control-label col-form-label">Phone</label>                    
               <div class="col-sm-9">                        
               <input type="text" name="phone" value="<?=($user->phone)?$user->phone:set_value('phone')?>" class="form-control" placeholder="Phone">                    
               <span class="danger-error"><?=form_error('phone')?></span>
               </div>
            </div>
         </div>
         <div class="col-sm-12 col-lg-6">
            <div class="form-group row">
               <label for="fname2" class="col-sm-3 text-left control-label col-form-label">Address</label>                    
               <div class="col-sm-9">                        
               <input type="text" name="address" value="<?=($user->address)?$user->address:set_value('address')?>" class="form-control" placeholder="Address">                    
               <span class="danger-error"><?=form_error('address')?></span>
               </div>
            </div>
         </div>
         <div class="col-sm-12 col-lg-6">
            <div class="form-group row">
               <label for="fname2" class="col-sm-3 text-left control-label col-form-label">Email</label>                    
               <div class="col-sm-9">                        
               <input type="text" readonly="" name="email" value="<?=($user->email)?$user->email:set_value('email')?>" class="form-control" placeholder="Email">                    
               <span class="danger-error"><?=form_error('email')?></span>
               </div>
            </div>
         </div>
         <div class="col-sm-12 col-lg-6">
            <div class="form-group row">
               <label for="nname" class="col-sm-3 text-left control-label col-form-label">Country</label>                    
               <div class="col-sm-9">
                  <select class="form-control custom-select" data-placeholder="Select Country" name="Country" tabindex="1">
                     <option value="" >Select Country</option>
                     <option value="Category 2">India</option>
                     <option value="Category 3">Usa</option>
                  </select>
               <span class="danger-error"><?=form_error('Country')?></span>
               </div>
            </div>
         </div>
         <div class="col-sm-12 col-lg-6">
            <div class="form-group row">
               <label for="fname2" class="col-sm-3 text-left control-label col-form-label">City</label>                    
               <div class="col-sm-9">                        
               <input type="text" name="city" value="<?=($user->city)?$user->city:set_value('city')?>" class="form-control" placeholder="City">                    
              <span class="danger-error"><?=form_error('city')?></span>
               </div>
            </div>
         </div>
         <div class="col-sm-12 col-lg-6">
            <div class="form-group row">
               <label for="nname" class="col-sm-3 text-left control-label col-form-label">State</label>                    
               <div class="col-sm-9">
                  <select class="form-control custom-select" name="state" data-placeholder="Select State" tabindex="1">
                     <option value=""  >Select State</option>
                     <option value="Category 2">India</option>
                     <option value="Category 3">Usa</option>
                  </select>
               <span class="danger-error"><?=form_error('state')?></span>
               </div>
            </div>
         </div>
         <div class="col-sm-12 col-lg-6">
            <div class="form-group row">
               <label for="fname2" class="col-sm-3 text-left control-label col-form-label">Zip Code</label>                    
               <div class="col-sm-9">                        
               <input type="text" name="zip" value="<?=($user->zipcode)?$user->zipcode:set_value('zip')?>" class="form-control" placeholder="zip">                    
               <span class="danger-error"><?=form_error('zip')?></span>
               </div>
            </div>
         </div>
         <div class="col-sm-12 col-lg-6">
            <div class="form-group row">
               <label for="fname2" class="col-sm-3 text-left control-label col-form-label">Select Image</label>                    
               <div class="col-sm-9">                        
               <input type="file"  required="" name="file">                  
               <span class="danger-error"><?=form_error('file')?></span>
               </div>
            </div>
         </div>
         <div class="col-sm-12 col-lg-12">
            <div class="card-body">
               <div class="form-group m-b-0 text-right">						
               <button type="submit" class="btn-mn btn-3 btn-3e button-org subBox">Submit</button>					</div>
            </div>
         </div>
      </div>
      </form>
   </div>
</section>