<?php 
if($this->session->userdata('user_id')!='')
{

	include(APPPATH.'/views/frontend/private/header.php');
	
}
else
{
	include('header.php');
}	
?>
<section id="title-inner" style="background-image:url(<?= base_url('assets/images/media-&-events.jpg')?>);">
<div id="large-header">   
<canvas id="demo-canvas"></canvas>
<div class="container">
<div class="text-tit">
 <div class="bb"></div>
<span class="lefttop-icon"></span>
<h1>
<span>Media & Events</span>
</h1>
<span class="rightbotm-icon"></span>
</div>



</div></div>

</section>

 <!-- Page Content inner -->
 
 
 <section class="about_content content-text event-page space-75">
 <div class="container">
 <div class="event-box">
 
 <div class="event_media">
 <div class="row">
 <div class="col-xs-12 col-sm-12 col-md-6 col-lg-6">
 <a href="single-post/1"><img  src="<?= base_url('assets/images/event.jpg')?>" alt="" /></a>
 </div>
 
  <div class="col-xs-12 col-sm-12 col-md-6 col-lg-6">


										<span class="date">AUGUST 02, 2018</span>
										<h4><a href="single-post/1">6 Reasons Why Singapore Math
Might Just Be the Better Way</a></h4>
										<p>When the ambiguous high school math problem went viral in April, complete with a handful of seemingly arbitrary answers, it sent many older Americans into a tailspin of</p>
										<a href="single-post/1" class="btn-mn btn-3 btn-3e button-org">Read More</a>
 </div>
 
 </div>
 
 </div>
 
 <div class="event_media">
 <div class="row align-right">

 
<div class="col-xs-12 col-sm-12 col-md-6 col-lg-6"> 


										<span class="date">JULY 24, 2018</span>
										<h4><a href="single-post/2">India's impressive concept about nothing</a></h4>
										<p>The invention of zero was a hugely signi cant mathematical development, one that is fundamental to calculus, which made physics, engineering and much of modern technology possible.</p>
										<a href="single-post/2"class="btn-mn btn-3 btn-3e button-org">Read More</a>
 </div>
 
 <div class="col-xs-12 col-sm-12 col-md-6 col-lg-6 order-first order-lg-6 order-md-6">
 <a href="single-post/2"><img  src="<?= base_url('assets/images/event.jpg')?>" alt="" /></a>
 </div>
  
 </div>
 
 </div>
 
 <div class="event_media">
 <div class="row">
 <div class="col-xs-12 col-sm-12 col-md-6 col-lg-6">
 <a href="single-post/3"><img  src="<?= base_url('assets/images/event.jpg')?>" alt="" /></a>
 </div>
 
  <div class="col-xs-12 col-sm-12 col-md-6 col-lg-6">


										<span class="date">JULY 13, 2018</span>
										<h4><a href="single-post/3">Children in Singapore excel at math because parents care</a></h4>
										<p>After spending close to 40 years in the math education game as a secondary teacher,
mathematics consultant and teacher educator</p>
										<a href="single-post/3" class="btn-mn btn-3 btn-3e button-org"class="btn-mn btn-3 btn-3e button-org">Read More</a>
 </div>
 
 </div>
 
 </div>
 
 <div class="event_media">
 <div class="row align-right">

  <div class="col-xs-12 col-sm-12 col-md-6 col-lg-6">


										<span class="date">JUNE 05, 2018</span>
										<h4><a href="single-post/4">Why is Singapore Math so popular overseas?</a></h4>
										<p>What is Singapore Math and why is it so popular in other countries? Is it true that this method makes math easily understood by kids</p>
										<a href="single-post/4"class="btn-mn btn-3 btn-3e button-org">Read More</a>
 </div>
 
 <div class="col-xs-12 col-sm-12 col-md-6 col-lg-6 order-first order-lg-6 order-md-6">
<a href="single-post/4"> <img  src="<?= base_url('assets/images/event.jpg')?>" alt="" /></a>
 </div>
 
 </div>
 
 </div>

  <div class="event_media">
 <div class="row">
 <div class="col-xs-12 col-sm-12 col-md-6 col-lg-6">
 <a href="single-post/5"><img  src="<?= base_url('assets/images/event.jpg')?>" alt="" /></a>
 </div>
 
  <div class="col-xs-12 col-sm-12 col-md-6 col-lg-6">

										<span class="date">JULY 13, 2018</span>
										<h4><a href="single-post/5">Singapore Math Is Popular Among
Educators Worldwide. Why?</a></h4>
										<p>Singapore Math has gone beyond helping Singaporean students excel in the classroom
to becoming a commercial product used widely around the world.</p>
										<a href="single-post/5"class="btn-mn btn-3 btn-3e button-org">Read More</a>
 </div>
 
 </div>
 
 </div>
 
 <div class="event_media">
 <div class="row align-right">

  <div class="col-xs-12 col-sm-12 col-md-6 col-lg-6">


										<span class="date">JUNE 05, 2018</span>
										<h4><a href="single-post/6">Singapore Math Pros and Cons</a></h4>
										<p>The Singapore Math method marked a change in the way math was taught in many
American classrooms.</p>
										<a href="single-post/6"class="btn-mn btn-3 btn-3e button-org">Read More</a>
 </div>
 
 <div class="col-xs-12 col-sm-12 col-md-6 col-lg-6 order-first order-lg-6 order-md-6">
<a href="single-post/6"> <img  src="<?= base_url('assets/images/event.jpg')?>" alt="" /></a>
 </div>
 
 </div>
 
 </div>
 
 
   <div class="event_media">
 <div class="row">
 <div class="col-xs-12 col-sm-12 col-md-6 col-lg-6">
 <a href="single-post/7"><img  src="<?= base_url('assets/images/event.jpg')?>" alt="" /></a>
 </div>
 
  <div class="col-xs-12 col-sm-12 col-md-6 col-lg-6">


										<span class="date">JULY 13, 2018</span>
										<h4><a href="single-post/7">Singapore maths inspires UK educators</a></h4>
										<p>The "mastery" method, as Singapore's approach is called in Britain, introduces core concepts gradually. Ideas are broken down into small steps, using real-life objects such as cubes to illustrate a point,</p>
										<a href="single-post/7"class="btn-mn btn-3 btn-3e button-org">Read More</a>
 </div>
 
 </div>
 
 </div>
 
 <div class="event_media">
 <div class="row align-right">

  <div class="col-xs-12 col-sm-12 col-md-6 col-lg-6">


										<span class="date">JUNE 05, 2018</span>
										<h4><a href="single-post/8">Singapore maths: How a radical new way of teaching
equips UK pupils to tackle a tougher curriculum</a></h4>
										<p>The system, known as 'maths mastery', relies on teaching fewer subjects, but in far greater
depth</p>
										<a href="single-post/8"class="btn-mn btn-3 btn-3e button-org">Read More</a>
 </div>
 
 <div class="col-xs-12 col-sm-12 col-md-6 col-lg-6 order-first order-lg-6 order-md-6">
<a href="single-post/8"> <img  src="<?= base_url('assets/images/event.jpg')?>" alt="" /></a>
 </div>
 
 </div>
 
 </div>
 
 
 
    <div class="event_media">
 <div class="row">
 <div class="col-xs-12 col-sm-12 col-md-6 col-lg-6">
 <a href="single-post/9"><img  src="<?= base_url('assets/images/event.jpg')?>" alt="" /></a>
 </div>
 
  <div class="col-xs-12 col-sm-12 col-md-6 col-lg-6">


										<span class="date">JULY 13, 2018</span>
										<h4><a href="single-post/9">Singapore students top global ranking in maths and science</a></h4>
										<p>The study assessed Primary 4 and Secondary 2 pupils in 64 education systems. It found that students in Singapore had a strong mastery in both subjects, and were able to apply their knowledge and conceptual understanding to solve problems.</p>
										<a href="single-post/9"class="btn-mn btn-3 btn-3e button-org">Read More</a>
 </div>
 
 </div>
 
 </div>
 
 <div class="event_media">
 <div class="row align-right">

  <div class="col-xs-12 col-sm-12 col-md-6 col-lg-6">


										<span class="date">JUNE 05, 2018</span>
										<h4><a href="single-post/10">Why are Singaporeans so good at Math?</a></h4>
										<p>As a local student majoring in mathematics, my experience is an emphatic no.
In my opinion, it is a mistake to view performances</p>
										<a href="single-post/10"class="btn-mn btn-3 btn-3e button-org">Read More</a>
 </div>
 
 <div class="col-xs-12 col-sm-12 col-md-6 col-lg-6 order-first order-lg-6 order-md-6">
<a href="single-post/10"> <img  src="<?= base_url('assets/images/event.jpg')?>" alt="" /></a>
 </div>
 
 </div>
 
 </div>
 
 
 
 <div class="event_media">
 <div class="row">
 <div class="col-xs-12 col-sm-12 col-md-6 col-lg-6">
 <a href="single-post/11"><img  src="<?= base_url('assets/images/event.jpg')?>" alt="" /></a>
 </div>
 
  <div class="col-xs-12 col-sm-12 col-md-6 col-lg-6">


										<span class="date">JULY 13, 2018</span>
										<h4><a href="single-post/11">Why Do Singapore Students Surpass the Rest of the
World in Math and Science?</a></h4>
										<p>The latest results from the Trends in International Mathematics and Science Study (TIMSS)--an international assessment of 60 participating countries--have been released to prove</p>
										<a href="single-post/11"class="btn-mn btn-3 btn-3e button-org">Read More</a>
 </div>
 
 </div>
 
 </div>
 
 <div class="event_media">
 <div class="row align-right">

  <div class="col-xs-12 col-sm-12 col-md-6 col-lg-6">


										<span class="date">JUNE 05, 2018</span>
										<h4><a href="single-post/12">Why Singapore's kids are so good at maths</a></h4>
										<p>Sie Yu Chuah smiles when asked how his parents would react to a low test score. "My parents
are not that strict but they have high expectations</p>
										<a href="single-post/12"class="btn-mn btn-3 btn-3e button-org">Read More</a>
 </div>
 
 <div class="col-xs-12 col-sm-12 col-md-6 col-lg-6 order-first order-lg-6 order-md-6">
<a href="single-post/12"><img  src="<?= base_url('assets/images/event.jpg')?>" alt="" /></a>
 </div>
 
 </div>
 
 </div>
 
 <div class="row">
 <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
 <ul class="pagination float-right">
 <li><a href="#">1</a></li>
 <li><a href="#">2</a></li>
 <li><a href="#">3</a></li>
 <li><a href="#">4</a></li>
 <li><a href="#">5</a></li>
 <li><a href="#">Next</a></li>
 </ul>
 </div>
 </div>

 
 </div></div> 
 </section>
 
 
   
   
   
   
   
   
    
 <!-- Page Content End -->
<?php 
if($this->session->userdata('user_id')!='')
{
	include(APPPATH.'/views/frontend/private/footer.php');
}
else
{
	include('footer.php');
}	
?>