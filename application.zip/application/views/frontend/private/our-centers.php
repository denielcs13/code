<?php 
if($this->session->userdata('user_id')!='')
{

	include(APPPATH.'/views/frontend/private/header.php');
	
}
else
{
	include('header.php');
}	
?>

<section id="title-inner" style="background-image:url(<?= base_url('assets/images/admission.jpg')?>);">
<div id="large-header">   
<canvas id="demo-canvas"></canvas>
<div class="container">
<div class="text-tit">
 <div class="bb"></div>
<span class="lefttop-icon"></span>
<h1>
<span>Our Centers</span>
</h1>
<span class="rightbotm-icon"></span>
</div>

</div></div>

</section>

 <!-- Page Content inner -->
 
 <section class="about_content content-text faq-page our-center-page space-75">
 <div class="container">
 <div class="row">
 
 <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">

<!--Accordion wrapper-->

	<div class="row">
		<?php
		if(!empty($center_list)){
			foreach($center_list as $center){
		?>
		<div class="col-md-6 col-sm-12">
			<!-- CONTACT INFO -->
            <div class="box-center">
			<div class="wow fadeInUp contact-info" data-wow-delay="0.4s">
				 <div class="section-title">
					  <h2> <?php echo (isset($center->center_name) && !empty($center->center_name)) ? $center->center_name : 'N/A'; ?></h2>
					  <p><i class="fa fa-map-marker"></i> <?php echo (isset($center->center_address) && !empty($center->center_name)) ? $center->center_address : 'N/A'; ?></p>
				 </div>
				 
				 <p><i class="fa fa-flag" aria-hidden="true"></i> City: <?php echo (isset($center->center_city) && !empty($center->center_city)) ? $center->center_city : 'N/A'; ?></p>
				 
				 <p><i class="fa fa-phone"></i> Phone:  <?php echo (isset($center->center_phone) && !empty($center->center_phone)) ? $center->center_phone : 'N/A'; ?></p>
			</div>
            </div>
	   </div>
		<?php
			}
		}
		?>
	</div>
 
 
 </div>
 
 
 
 
 </div>
 </div>
 </section>
 
 
   
   
   
   
   
   
    
 <!-- Page Content End -->
<?php 
if($this->session->userdata('user_id')!='')
{
	include(APPPATH.'/views/frontend/private/footer.php');
}
else
{
	include('footer.php');
}	
?>