

<section class="about_content content-text space-75 space-top-0">
  <br>
 <br>
 <div class="container">
 <center><h1>Monthly Analysis Report<br/>
 - <?php echo date('M Y',strtotime($month));?> -
 </h1></center>
 <?php
 	$sql_chkcexam=$this->db->query("select * from student_classexcerise where   year_id='".$year_id."' and user_id='".$user_id."' 
	and exam_status='pass' and MONTH(exam_date)='".$mymonth."' ");
	$num_chkcexm=$sql_chkcexam->num_rows();
	
	$sql_hexam=$this->db->query("select * from student_homeworktest where   year_id='".$year_id."' and user_id='".$user_id."' 
	and exam_status='pass' and MONTH(exam_date)='".$mymonth."' ");
	$num_chkhexm=$sql_hexam->num_rows();
	if($num_chkcexm > 0 || $num_chkhexm > 0)
	{
 /* if($exam_details)
 {
	 foreach($exam_details as $rowexam)
	 { */
		    
$first_day_this_month = date('01 M Y',strtotime($month)); // hard-coded '01' for first day
$last_day_this_month  = date('t M Y',strtotime($month)); 
	 
 ?>
 <div class="row">

  <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
   <div class="row">
   <div class="col-md-6 col-sm-6">
    <table class="table table-striped table-light">
	<tr>
	<td>Student ID</td>
	<td><strong><?php echo  $student_details->user_id;?></strong></td>
	</tr>
	<tr>
	<td>First Name</td>
	<td><strong><?php echo $student_details->first_name;?></strong></td>
	</tr>
	<tr>
	<td>Last Name</td>
	<td><strong><?php echo $student_details->last_name;?></strong></td>
	</tr>
	<tr>
	<td>Reporting Period</td>
	<td colspan="3"><strong><?php echo $first_day_this_month;?> to  <?php echo $last_day_this_month;?> (Term <?php echo $term_id;?>)</strong></td>
	</tr>
	</table>
   </div>
     <div class="col-md-6 col-sm-6">
	 <table class="table table-striped table-light">
	<tr>
	<td>Date</td>
	<td><strong><?php echo $first_day_this_month;?></strong></td>
	</tr>
	<tr>
	<td>Year</td>
	<td><strong><?php 
	if($student_details->year_id==1)
	{
	echo 'kindergarten';
	}
	else	
	{
		echo $year_name;
	}
	?></strong></td>
	</tr>
	<tr>
	<td>Date  of  Birth</td>
	<td><strong><?php 
	if(!empty($student_details->dob) && $student_details->dob != '0000-00-00')
	{	
		echo date("d M Y", strtotime($student_details->dob));
		
	}
	
	?></strong></td>
	</tr>
	
	
	</table>
   </div>
  
</div>
 </div>
 
 </div>
<?php


	 /* }
} */
?> 
 </div>
 
 <div  class="container" style="background-color: #fecc98;height: 35px">
 	<div  style="padding-top: 5px; "><b style="font-size: 20px">Subject Attempted</b></div>

 </div>
	
	<div><?php //echo get_grade();?></div>
 </div>
 
 <!-- For Term 1 --- -->
 <?php
	

	//if(!empty($classroomtest_details)){
 		?>

 

  <div class="container">
 <div class="row" style="margin-top: 25px;margin-bottom: 25px;">

  <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
   <div class="row">
   <div class="col-md-12 col-sm-12">
    <table class="table table-striped table-light">
 <?php
  global $order_arr;
/*  echo '<pre>';
 var_dump($SylList1);
 echo '</pre>';  */
 $main_week="";
 $mainskill="";
 $unikskill="";
	$unikweek="";
 
	 foreach($SylList1 as $result){
		  
		 $sql_syllab=$this->db->query("select * from master_syllabus where skill_id = '".$result->skill_id."' and class_id='".$year_id."' and term_id='1'"); 
		 $row_syllab=$sql_syllab->row();		
		
		$sql_pskill=$this->db->query("select * from master_skill where skill_id = '".$result->skill_id."' ");
		$skl_dtl=$sql_pskill->row();			 
		$mainskill=$result->skill_id;	
		$main_week=$result->week_id;
		 if($mainskill!=$unikskill)
		 {
			$sql_subskill=$this->db->query("select * from master_skill where skill_id = '".$result->subskill_id."' ");
			$subskl_dtl=$sql_subskill->row(); 	
?>
	<tr><td> <h3 style="color: #6eb72f;font-size: 20px;"><?php echo $order_arr[$row_syllab->skill_order].'. '.$skl_dtl->skill_name;?></h3></td></tr>
	 <?php }
	 if($main_week!=$unikweek)
	 {
		$myweek="select * from master_weeks where week_id = '".$result->week_id."' ";
		$sql_week=$this->db->query($myweek); 
		$week_dtl=$sql_week->row();
		
		$sql_goal=$this->db->query("select * from master_goal where term_id = '".$row_syllab->term_id."' and year_id='".$year_id."' and week_id='".$result->week_id."'  ");
		$goal=$sql_goal->row(); 
	 ?>
	 <tr><td><strong><?php echo $goal->goal_name;?></strong> <br/><h4 style="color:blue;font-weight:bold;" ><?php echo $week_dtl->week_name;?></h4></td></tr>
	 <?php
	 }
	 ?>
	 <tr ><td><h4 ><strong><?php echo $order_arr[$row_syllab->skill_order].'.'.$result->subskill_order;?></strong> <?php echo  $this->db->where('skill_id',$result->subskill_id)->get('master_skill')->row()->skill_name;?></h4>
	 <br/>
	 
	 <?php

	$sql_classexam=$this->db->query("select * from student_classexcerise where skill_id = '".$result->subskill_id."' and 
	year_id='".$year_id."' and user_id='".$user_id."' 
	and exam_status='pass' and MONTH(exam_date)='".$mymonth."' ");
	$num_classexm=$sql_classexam->num_rows();
	if($num_classexm > 0)
	{
		?>
		<h3>Classroom</h3>
		<table class="table">
 		<thead>
 			<tr>
 				<th style="border-bottom: 1px solid #1a1b1d;">Attempts</th>
 				<th style="border-bottom: 1px solid #1a1b1d;">Date</th>
 				<th style="border-bottom: 1px solid #1a1b1d;">Duration</th>
 				<th style="border-bottom: 1px solid #1a1b1d;">Total Questions</th>
 				<th style="border-bottom: 1px solid #1a1b1d;">Score</th>
 				<th style="border-bottom: 1px solid #1a1b1d;">Percentage (%)</th>
 			</tr>
 		</thead>
		<tbody>
		<?php
		$count=1;
		$row_classexm=$sql_classexam->result();
		$calc=array();
		foreach($row_classexm as $classexam)
		{
			$user_id = $classexam->user_id;
					$exam_id = $classexam->exam_id;
					$result_class = $this->main_model->get_selected_details('student_classexcerise_history',$columns = array('COUNT(hid) as total_question','SUM(CASE WHEN answer_status = "true" THEN 1 ELSE 0 END) AS correct_answer','(SUM(CASE WHEN answer_status = "true" THEN 1 ELSE 0 END) *100/COUNT(hid)) as score_percent'),$where = array('user_id'=>$user_id,'exam_id'=>$exam_id),$records="single",$obj=true);
 				
			$calper=round($result_class->score_percent);
			?>
			<tr>
 					<td><?php echo $count; ?></td>
 					<td><?php echo date('d M Y', strtotime($classexam->exam_date));?></td>
 					<td><?php echo date('h:m', strtotime($classexam->exam_date));?></td>
 					<td><?php echo $result_class->total_question;?></td>
 					
 					<td><?php echo $result_class->correct_answer;?></td>
 					<td><?php echo round($result_class->score_percent);
						
					?>%</td>
 				</tr>
			<?php
				array_push($calc, array('per'=>$calper,'totalright'=>$result_class->correct_answer,'totalquestion'->$result_class->total_question,'date'=>$classexam->exam_date));
			$count++;
		}
		?>
			<tbody>
			</table>
		<?php
		
	
	}
	
	?>
	<!----Homework excerise----->
	 <?php
	
	$sql_homeexam=$this->db->query("select * from student_homeworktest where skill_id = '".$result->subskill_id."' and year_id='".$year_id."' and user_id='".$user_id."' 
	and exam_status='pass' and MONTH(exam_date)='".DATE('m')."' ");
	$num_homeexm=$sql_homeexam->num_rows();
	if($num_homeexm > 0)
	{
		?>
		<br/>
		<h3>Home Work</h3>
		<table class="table">
 		<thead>
 			<tr>
 				<th style="border-bottom: 1px solid #1a1b1d;">Attempts</th>
 				<th style="border-bottom: 1px solid #1a1b1d;">Date</th>
 				<th style="border-bottom: 1px solid #1a1b1d;">Duration</th>
 				<th style="border-bottom: 1px solid #1a1b1d;">Total Questions</th>
 				<th style="border-bottom: 1px solid #1a1b1d;">Score</th>
 				<th style="border-bottom: 1px solid #1a1b1d;">Percentage (%)</th>
 			</tr>
 		</thead>
		<tbody>
		<?php
		$count1=1;
		$row_homeexm=$sql_homeexam->result();
		foreach($row_homeexm as $homwexam)
		{
			$user_id1 = $homwexam->user_id;
			$exam_id1 = $homwexam->exam_id;
			$result_home = $this->main_model->get_selected_details('student_home_history',$columns = array('COUNT(hid) as total_question','SUM(CASE WHEN answer_status = "true" THEN 1 ELSE 0 END) AS correct_answer','(SUM(CASE WHEN answer_status = "true" THEN 1 ELSE 0 END) *100/COUNT(hid)) as score_percent'),$where = array('user_id'=>$user_id1,'exam_id'=>$exam_id1),$records="single",$obj=true);
 			$calper1=round($result_home->score_percent);	
			
			?>
			<tr>
 					<td><?php echo $count1; ?></td>
 					<td><?php echo date('d M Y', strtotime($homwexam->exam_date));?></td>
 					<td><?php echo date('h:m', strtotime($homwexam->exam_date));?></td>
 					<td><?php echo $result_home->total_question;?></td>
 					
 					<td><?php echo $result_home->correct_answer;?></td>
 					<td><?php echo round($result_home->score_percent); ?>%</td>
 				</tr>
			<?php
			array_push($calc, array('per'=>$calper1,'totalright'=>$result_home->correct_answer,'totalquestion'->$result_home->total_question,'date'=>$homwexam->exam_date));
			$count1++;
		}
		?>
			<tbody>
			</table>
		<?php
		
	
	}
	
	?>
	<!----End homework excerise---->
	<?php
	if($calc)
	{
		?>
	 	<b><u><span>Analysis (using most recent data) </span></u></b>
 	<div>
 		<table >
 		<thead>
 			<tr>
 				<th style="border-bottom: 1px solid #1a1b1d; width: 150px;">Lowest Score</th>
 				<th style="border-bottom: 1px solid #1a1b1d;width: 150px;">Percentage(%)</th>
 				<th style="border-bottom: 1px solid #1a1b1d;width: 100px;">Date</th>
 				
 			</tr>
 		</thead>
 		<tr>
 		<td style="width: 150px;"><?=$calc[get_min($calc)]['totalright']?>	</td>
 				<td style="width: 150px;"><?= round($calc[get_min($calc)]['per'])?>%</td>
 				<td style="width: 100px;"><?=date('d M y',strtotime($calc[get_min($calc)]['date'])) ?></td>
 			</tr>
 		<tbody>
 			
 		</tbody>
 	</table>
 	</div>
 		<br>
 		<div>
 		<table >
 		<thead>
 			<tr>
 				<th style="border-bottom: 1px solid #1a1b1d; width: 150px;">Highest Score</th>
 				<th style="border-bottom: 1px solid #1a1b1d;width: 150px;">Percentage(%)</th>
 				<th style="border-bottom: 1px solid #1a1b1d;width: 100px;">Date</th>
 				
 			</tr>
 		</thead>
 		
		<?php
			 
		?>	
		
		<tr>
 		<td style="width: 150px;"><?=$calc[getmax($calc)]['totalright']?>	</td>
 				<td style="width: 150px;"><?= round($calc[getmax($calc)]['per'])?>%</td>
 				<td style="width: 100px;"><?=date('d M y',strtotime($calc[getmax($calc)]['date'])) ?></td>
 			</tr>
 			
 			
 		<tbody>
 			
 		</tbody>
 	</table>
 	</div>
 		<br>
 		<div>
 		<table >
 		<thead>
 			<tr>
 				<th style="border-bottom: 1px solid #1a1b1d; width: 150px;">Mean Score</th>
 				<th style="border-bottom: 1px solid #1a1b1d;width: 150px;">Median Score</th>
 				<th style="border-bottom: 1px solid #1a1b1d;width: 100px;">Mode Score</th>
 				
 			</tr>
 		</thead>
 		<?PHP 
 		?>
 		<td style="width: 150px;"><?= round(mean($calc)); ?>%</td>
 				<td style="width: 150px;"><?=round( median($calc),2);?>%</td>
 				<td style="width: 100px;"><?= round($calc[getmax($calc)]['per'])?>%</td>
 		<tbody>
 			
 		</tbody>
 	</table>
 	</div>
 		<br>
 <span><b>Grade (Highest  <?php echo $calc[getmax($calc)]['per'];?>%) </b></span>
 	<?php
	$star_p=$calc[getmax($calc)]['per'];
	echo get_grade($star_p);
	
 	?>
	<br>
 <span><b>Remarks:  <?php $highgrade=$calc[getmax($calc)]['per'];?> </b></span>
 <?php
 if($highgrade < 50)
 {
	 echo '<p>Has difficulty learning and applying new skills. </p>';
	 
 }
 else if($highgrade > 49 && $highgrade < 80)
 {
	 echo '<p>With assistance from others, is able to learn apply new skills. </p>';
	 
 }
 else if($highgrade > 79 && $highgrade < 90)
 {
	 echo '<p>Quick learner, and able to learn and apply new skills with minimal assistance from others. </p>';
	 
 }
 else if($highgrade > 89 && $highgrade < 99)
 {
	 echo '<p>Quick learner, and able to learn and apply new skills with minimal assistance from others. </p>';
	 
 }
  else if($highgrade > 99 )
 {
	 echo '<p>Extremely quick learner, with excellent ability to learn and apply new skills with minimal assistance from others.  </p>';
	 
 }
 }
	?>
	 </td></tr>
	 <?php
	$unikskill=$mainskill;
	$unikweek=$main_week;
	 $calc='';
	 }
	
 ?>
 </table>
 </div>
  </div>
   </div>
    </div>
    
	<?php
	}
	else
	{
		echo '<br/><br/><p class="error" align="center">No report found this month.<br/>
		<a href="'.base_url().'all-month-report"><strong>Go Back</strong></a></p>';
	}
		?>
	  </div>
 </section>

 
 
 
 
 
 
 <?php


	
function getMax( $array )
{
    $max = 0;
    foreach( $array as $k => $v )
    {
        $max = max( array( $max, $v['per'] ) );
        
    }
    foreach ($array as $key => $val) 
    {
       if ($val['per'] === $max) 
       {

           	 $abc=$key;
       }
   }
    return $abc;
} 

  
    //echo min($min);

function get_min($array)
{
	$min = array();
    foreach( $array as $k => $v )
    {
    	array_push($min,$v['per']);
    }
  foreach($min as $k => $v )
    {
    	if($v==min($min))
    	{
    		
    		return $k;	
    	}
    	
    }
}
   
   
function mean($array)
{
	$total=0;
    foreach( $array as $k => $v )
		    {
		        $total=$total+$v['per'];
		         $total.'<br>';
		    }
	 $mean=round($total)/count($array);
	 return $mean;
}
   


function median($array) {

	$arr=array();
	foreach ($array as $key => $value) {
		array_push($arr, $value['per']);
	}

    $count = count($arr);
    $middleval = floor(($count-1)/2); 
    if($count % 2) 
    { 
        $median = $arr[$middleval];
    } 
    else
    { 
        $low = $arr[$middleval];
        $high = $arr[$middleval+1];
        $median = (($low+$high)/2);
    }
    return $median;
}
  

function mode($array)
{
	$arr=array();
	foreach ($array as $key => $value) 
	{
	array_push($arr, intval(round($value['per'])));
	}
	

$values = array_count_values($arr);

if($values)
{

$popular = array_slice(array_keys($values), 0, 1, true);
}

return $popular;
}

 	function get_grade($star_p){
	
 	
	if(1>=$star_p||$star_p<=49)
 	{
 		$star=1;
 	}elseif (50>=$star_p||$star_p<=79) {
 		$star=2;
 	}elseif (80>=$star_p||$star_p<=89) {
 		$star=3;
 	}elseif (90>=$star_p||$star_p<=99) {
 		$star=4;
 	}else{
 		$star=5;
 	}
 	$html.= '<div class="col-md-3">';
    for($i=0;$i<$star;$i++)
    {
    	$html.='<img style="height: 61px" src="'.base_url('assets/star/img.png').'">';
    }
$html.= '</div>';

return $html;

	}
	
   ?>