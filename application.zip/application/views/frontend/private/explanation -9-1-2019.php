<?php include('header.php'); ?>
<?php
    /*Just for your server-side code*/
    header('Content-Type: text/html; charset=ISO-8859-1');
?>
<section id="title-inner" style="background-image:url(<?= base_url('assets/images/Kindergarten_bg.jpg')?>);">
<div id="large-header">   
<canvas id="demo-canvas"></canvas>
<div class="container">
<div class="text-tit">
 <div class="bb"></div>
<span class="lefttop-icon"></span>
<h1>
<span><?php echo $year_dtl->class_name; ?></span>
</h1>
<span class="rightbotm-icon"></span>
</div>



</div></div>





</section>

 <!-- Page Content inner -->
 
 
<section class="about_content content-text syllabus-page space-75 explanation">
<div class="container">



<div class="tab-content">
	<div class="row">										
<div class="col-xs-12 col-sm-9 col-md-9 col-lg-9">
<form method="post" action="">	
		
		<h1>Sorry, incorrect...</h1>
		<h3>The correct answer is:</h3>
		
		<?php 
		
		if($ques_dtl != null && $ques_dtl != ""){
		
		 
			if($ques_dtl->ques_type==4){?>
				<h3><?php echo $correct_ans->ans_name;?></h3>
			
				<div style="border:1px solid #ccc; padding:30px;"> <h3>Explanation</h3>
				<?php
					echo $ques_dtl->ques_name; 
					echo '<br>';
					$imgs=$this->main_model->getall('ques_img','ques_id',$ques_dtl->ques_id);

					foreach($imgs as $img){

					echo '<img src="/assets/uploads/ans/'.$img->img.'"/>';
					}
					echo '<br>';
					$answers=$this->questions_model->get_answers($ques_dtl->ques_id);
					foreach($answers as $answer){
						
					echo '<a id ="a1" class="explan-btn">'.$answer->ans_name.'</a>&nbsp;&nbsp;&nbsp;';
					}



					echo '<h4 class="space10">You answered: </h4>';
					echo '<h3>'.$yourans->ans_name.'</h3>';
					echo '</div>';
			}
			elseif($ques_dtl->ques_type==5)
			{?>
			<img src="/assets/uploads/ans/<?php echo $correct_ans->ans_name;?>"/>
				
		
			<div style="border:1px solid #ccc; padding:30px;"> <h3>Explanation</h3>
			<?php
				echo $ques_dtl->ques_name;
				echo '<br>';
				
				echo '<br>';
				$answers=$this->questions_model->get_answers($ques_dtl->ques_id);
				foreach($answers as $answer){
					
				echo '<img src="/assets/uploads/ans/'.$answer->ans_name.'"/>&nbsp;';
				}



				echo '<h4 class="space10">You answered: </h4>';
				echo '<img src="/assets/uploads/ans/'.$yourans->ans_name.'"/>';
				echo '</div>';
			}
			elseif($ques_dtl->ques_type==6)
			{?>
			<h3><?php echo $correct_ans->ans_name;?></h3>
		
			<div style="border:1px solid #ccc; padding:30px;"> <h3>Explanation</h3>
			<?php
				echo $ques_dtl->ques_name;
				echo '<br>';
				
				$imgs=$this->main_model->getall('ques_img','ques_id',$ques_dtl->ques_id);
				foreach($imgs as $img){
					for($i=0;$i<$img->repeat;$i++){
					echo '<img src="/assets/uploads/ans/'.$img->img.'"/>';
					}
					echo '<br>';
				}
				$answers=$this->questions_model->get_answers($ques_dtl->ques_id);
				foreach($answers as $answer){
					
				echo $answer->ans_name.'&nbsp;&nbsp;&nbsp;';
				}



				echo '<h4 class="space10">You answered: </h4>'; 
				echo '<h3>'.$yourans->ans_name.'</h3>';
				echo '</div>';
				
			}
			elseif($ques_dtl->ques_type==26)
			{?>
			<h3><?php echo $correct_ans->ans_name;?></h3>
		
			<div style="border:1px solid #ccc; padding:30px;"> <h3>Explanation</h3>
			<?php
				$QuesDecoded = base64_decode($ques_dtl->ques_name); 
					 $QuesDecoded;
				echo '<br>';
				
				$imgs=$this->main_model->getall('ques_img','ques_id',$ques_dtl->ques_id);
				foreach($imgs as $img){
					for($i=0;$i<$img->repeat;$i++){
					echo '<img src="/assets/uploads/ans/'.$img->img.'"/>';
					}
					echo '<br>';
				}
				$answers=$this->questions_model->get_answers($ques_dtl->ques_id);
				foreach($answers as $answer){
					
				echo $answer->ans_name.'&nbsp;&nbsp;&nbsp;';
				}



				echo '<h4 class="space10">You answered: </h4>'; 
				echo '<h3>'.$yourans->ans_name.'</h3>';
				echo '</div>';
				
			}
			
			}
			else
			{ ?>
			  No Question found
			<?php } ?>
			
			
			<a href="" class="got_it">Got it</a>
			</form>
			</div>
		
    
			

<div class="col-xs-12 col-sm-3 col-md-3 col-lg-3">
<h2>Sidebar</h2>
</div>
</div>
</div>




</div> 

 </section>
 

 <script>
  $("#a1").click(function(event) {
    this.removeAttribute("href");            
    anchorClicked("a1");
  });
 </script>
    
 <!-- Page Content End -->
<?php include('footer.php'); ?>