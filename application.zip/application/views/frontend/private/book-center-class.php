<?php include('header.php'); ?>
	<script type='text/javascript' src='<?= base_url('assets/js/formjquery.min.js')?>'></script>
<link rel="stylesheet" href="http://code.jquery.com/ui/1.11.0/themes/smoothness/jquery-ui.css">
<script src="//ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
<style>
		#contact label{
			display: inline-block;
			width: 100px;
			text-align: right;
		}
		#contact_submit{
			padding-left: 100px;
		}
		#contact div{
			margin-top: 1em;
		}
		textarea{
			vertical-align: top;
			height: 5em;
		}
			
		.error{
			display: none;
			margin-left: 10px;
		}		
		
		.error_show{
			color: red;
			margin-left: 10px;
		}
		
		input.invalid, textarea.invalid{
			border: 2px solid red;
		}
		
		input.valid, textarea.valid{
			border: 2px solid green;
		}
		
		.tablinkpay li {

    float: left;
    background-image: none !important;

}
	</style>
	 <script>
	 
		jQuery(document).ready(function() {
			<!-- Real-time Validation -->
				<!--Name can't be blank-->
				jQuery('#contact_fname').on('input', function() {
					var input=$(this);
					var is_name=input.val();
					if(is_name){input.removeClass("invalid").addClass("valid");}
					else{input.removeClass("valid").addClass("invalid");}
				});
				jQuery('#contact_lname').on('input', function() {
					var input=$(this);
					var is_name=input.val();
					if(is_name){input.removeClass("invalid").addClass("valid");}
					else{input.removeClass("valid").addClass("invalid");}
				});
				
				<!--Email must be an email -->
				jQuery('#contact_email').on('input', function() {
					var input=$(this);
					var re = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$/;
					var is_email=re.test(input.val());
					if(is_email){input.removeClass("invalid").addClass("valid");}
					else{input.removeClass("valid").addClass("invalid");}
				});
				
				jQuery('#contact_phone').on('input', function() {
					var input=$(this);
					 var data=$('#contact_phone').val();  
     if(phone_validate(data)) 
     { 
      // $('.error_Msg').hide();  // hides error msg if validation is true
	   input.removeClass("valid").addClass("invalid");
     } 
     else 
     { 
      
	  input.removeClass("invalid").addClass("valid");
       event.preventDefault(); 
     } 
					
				});
				
				jQuery('#contact_datepicker1').on('input', function() {
					var input=$(this);
					var is_name=input.val();
					if(is_name){input.removeClass("invalid").addClass("valid");}
					else{input.removeClass("valid").addClass("invalid");}
				});
				
		
			<!-- After Form Submitted Validation-->
			jQuery("#contact_submit button").click(function(event){
				var form_data=$("#contact").serializeArray();
				var error_free=true;
				for (var input in form_data){
					var element=$("#contact_"+form_data[input]['name']);
					if(form_data[input]['name']=='fname' || form_data[input]['name']=='lname' || form_data[input]['name']='email' || form_data[input]['name']='phone'  || form_data[input]['name']='datepicker');
					{
					var valid=element.hasClass("valid");
					var error_element=$("span", element.parent());
					if (!valid){error_element.removeClass("error").addClass("error_show"); error_free=false;}
					else{error_element.removeClass("error_show").addClass("error");}
					}
					
				}
				if (!error_free){
					event.preventDefault(); 
				}
				else{
					alert('No errors: Form will be submitted');
				}
			});
			
			
			
		});
	</script>
<section id="title-inner" class="bgcolor-text">
<canvas id="demo-canvas"></canvas>
<div class="container">
<div class="text-tit">
<h1>
<span>Book Your Class</span>
</h1>
</div>

</div>
</section>

<!-- Page Content inner -->
<div class="about_content login-page forgot-password change-password book-center-class-page content-text space-75">

<div class="container">
<div class="row">


<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
<div class="row">
<div class="col-xs-12 col-sm-12 col-md-3 col-lg-3"></div>
<div class="col-xs-12 col-sm-12 col-md-6 col-lg-6">
<div class="form-section">
<form class="cmxform" id="contact" method="post" action="">
<?php
if($checkord < 1)
{
	?>
<div class="row">
<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
<div class="tablinkpay">
<ul >
<li><strong>Fill Details</strong></li>
<li>Parents Details</li>
<li>Pay Now</li>

</ul>
</div>
</div>
</div>
<?php
}
?>

<div class="row">
<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">

<h3>You are registering for<?php echo $elg_yearname;?></h3>
<p>Please fill the details to Join the Class</p>




<div class="row">
<?php if (validation_errors()) : ?>
											<div class="col-lg-12">
												<div class="alert alert-danger" role="alert">
													<?= validation_errors() ?>
												</div>
											</div>
											<?php endif; ?>
<div class="col-lg-12">
<div class="input-field">
<label>First Name</label>
<span class="input input--hoshi">
					<input type="text" name="first_name" value="<?php echo $userinfo->first_name;?>" placeholder="First Name" id="contact_fname" />
					<span class="error">This field is required</span>
				</span>
</div>
<div class="input-field">
<label>Last Name</label>
<span class="input input--hoshi">
					<input type="text" name="last_name" value="<?php echo $userinfo->last_name;?>" placeholder="Last Name" id="contact_lname" />
				</span>
</div>
<div class="input-field">
<label>Email</label>
<span class="input input--hoshi">
					<input type="text" name="email" value="<?php echo $userinfo->email;?>" placeholder="Email" id="contact_email" />
					<span class="error">A valid email address is required</span>
				</span>
</div>
<div class="input-field">
<label>Phone</label>
<span class="input input--hoshi">
					<input type="text" name="phone" id="contact_phone" value="<?php echo $userinfo->phone;?>" placeholder="Phone" />
				</span>
</div>
<div class="input-field">
<label>D.O.B*</label>
<span class="input input--hoshi">
<?php
if($userinfo->dob!='')
{
	$dobdate=explode('-',$userinfo->dob);
	$datedob=$dobdate[2].'/'.$dobdate[1].'/'.$dobdate[0];
}
else
{
	$datedob='';
}
?>
					<input type="text" name="dob" value="<?php echo $datedob;?>" placeholder="D.O.B (dd/MM/yyyy)" id="contact_datepicker1" class="date-format"  />
				<span class="error" id="dateerror" style="display: none">Invalid Date. Only dd/MM/yyyy format allowed.</span>
				
				</span>
</div>
<div class="input-field">
<label>Address</label>
<span class="input input--hoshi">
					<input type="text" name="address" value="<?php echo $userinfo->address;?>" placeholder="Address" />
				</span>
<span class="input input--hoshi">
					<input type="text" name="city" value="<?php echo $userinfo->city;?>" placeholder="City" />
				</span>				
<span class="input input--hoshi">
					<input type="text" name="state" value="<?php echo $userinfo->state;?>" placeholder="State" />
				</span>		
<span class="input input--hoshi">
					<input type="text" name="zipcode" value="<?php echo $userinfo->zipcode;?>" placeholder="Zip Code" />
				</span>						
				</div>

</div>

</div>





<input type="hidden" name="elg_yearid" value="<?php echo $elg_yearid;?>" />
<div id="contact_submit" class="text-center">
<button class="btn-mn btn-3 btn-3e button-org"  id="booknow">Book Now</button>
</div>




</div>


</div>
</form>
</div>

</div>
<div class="col-xs-12 col-sm-12 col-md-3 col-lg-3"></div>
</div>
</div>

</div>
</div>

</div>

 <!-- Page Content End -->
 <?php include('footer.php'); ?>

	
 <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>

<script type="text/javascript">
jQuery(document).ready(function(){

    jQuery('#regcenter').change(function(){
		
      var center_id=$('#regcenter').val();
	  //alert(center_id);
            jQuery.ajax({
                type : 'POST',
                url : '<?php echo BASE_URL.'ajaxcall/checkcenter_seats';?>',
                data : {center_id:center_id,year_id:<?php echo $elg_yearid;?>}
				,	
        success: function(result){
           // alert(result);
		   if(result > 0)
		   { 
			//jQuery( "#seatshow" ).html('<p style="color:green;font-weight:bold;">Avaliable seats is '+result+'</p>');
			jQuery( "#seatshow" ).html('<p style="color:green;font-weight:bold;">Seats available when registering.</p>');
			 jQuery( "#booknow" ).show();
		   }
		   else
		   {
			   jQuery( "#seatshow" ).html('<p style="color:red;font-weight:bold;">No seat Avaliable in this center please choice another center!.</p>');
			    jQuery( "#booknow" ).hide();
			  
		   }
		   // jQuery("#seatshow").val(result);
        }


    });
    });    
});


</script>
<!--
<script src="http://code.jquery.com/jquery-1.10.2.js"></script>
<script src="http://code.jquery.com/ui/1.11.0/jquery-ui.js"></script>
<script>
jQuery(document).ready(function() {
// Datepicker Popups calender to Choose date.
jQuery(function() {
jQuery("#contact_datepicker").datepicker();
<?php
if($datedob!='')
{
	?>
jQuery('#contact_datepicker').val('');
<?php
}
?>
// Pass the user selected date format.
jQuery("#format").change(function() {

jQuery("#contact_datepicker").datepicker("option", "dateFormat", $(this).val());
});
});
});
</script>
-->
    <script type="text/javascript">
        var isShift = false;
        var seperator = "/";
        window.onload = function () {
            //Reference the Table.
            var tblForm = document.getElementById("contact");

            //Reference all INPUT elements in the Table.
            var inputs = document.getElementsByTagName("input");

            //Loop through all INPUT elements.
           // for (var i = 0; i < inputs.length; i++) {
                //Check whether the INPUT element is TextBox.
               // if (inputs[i].type == "text") {
                    //Check whether Date Format Validation is required.
                    if (inputs[4].className.indexOf("date-format") != 1) {
                        
                        //Set Max Length.
                        inputs[4].setAttribute("maxlength", 10);

                        //Only allow Numeric Keys.
                        inputs[4].onkeydown = function (e) {
                            return IsNumeric(this, e.keyCode);
                        };

                        //Validate Date as User types.
                        inputs[4].onkeyup = function (e) {
                            ValidateDateFormat(this, e.keyCode);
                        };
                    }
               // }
            //}
        };

        function IsNumeric(input, keyCode) {
            if (keyCode == 16) {
                isShift = true;
            }
            //Allow only Numeric Keys.
            if (((keyCode >= 48 && keyCode <= 57) || keyCode == 8 || keyCode <= 37 || keyCode <= 39 || (keyCode >= 96 && keyCode <= 105)) && isShift == false) {
                if ((input.value.length == 2 || input.value.length == 5) && keyCode != 8) {
                    input.value += seperator;
                }

                return true;
            }
            else {
                return false;
            }
        };

        function ValidateDateFormat(input, keyCode) {
            var dateString = input.value;
            if (keyCode == 16) {
                isShift = false;
            }
            var regex = /(((0|1)[0-9]|2[0-9]|3[0-1])\/(0[1-9]|1[0-2])\/((19|20)\d\d))$/;

            //Check whether valid dd/MM/yyyy Date Format.
            if (regex.test(dateString) || dateString.length == 0) {
                //ShowHideError(input, "none");
				document.getElementById('dateerror').style.display = 'none';
            } else {
                //ShowHideError(input, "block");
				document.getElementById('dateerror').style.display = 'block';
            }
        };

        function ShowHideError(textbox, display) {
           // var row = textbox.parentNode.parentNode;
            var errorMsg = getElementsById("getElementById").value;
            if (errorMsg != null) {
                errorMsg.style.display = display;
            }
        };
    </script>

