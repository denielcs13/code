<?php error_reporting(E_ALL);
ini_set('display_errors','0');?>
<?php include('header.php'); ?>

<section id="title-inner" class="bgcolor-text">
<canvas id="demo-canvas"></canvas>
<div class="container">
<div class="text-tit">
<h1>
<span>This Week Classroom Exercise</span>
</h1>
</div>

</div>
</section>
<!-- Page Content inner -->

<?php /*?><div class="tabs-login">
<div class="container">
<div class="row">
<ul class="links-menu">
<li><a href="notice-board">Notice Board</a></li>
<li><a href="this-week-classroom-exercise" class="active">This Week Classroom Exercise</a></li>
<li><a href="homework-exercise">Homework Exercise</a></li>
<li><a href="year-1-syllabus"><?php echo $year_name;?> - Syllabus</a></li>
<li><a href="analysis-report">Analysis Report</a></li>
<li><a href="booking-payment">Booking & Payment</a></li>
<li><a href="certificate-award">Certificate & Award</a></li>
<li><a href="changepassword">Change Password</a></li>
<li><a href="<?php echo  base_url().lcfirst($year_slug);?>/exam"><?php echo $year_name;?> - Exam</a></a></li>
</ul>

</div>
</div>

</div><?php */?>
 <?php
 global $order_arr;
 


 ?>
 <section class="about_content content-text space-75">
 <div class="container">
 <div class="row">
 
 <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
    <?php
	 $query_ord=$this->db->query("select plan_id,order_date,order_week from orders where userid = '".$this->session->userdata('user_id')."'  and order_status='active' and pay_status='confirm' order by orderid desc"); 
				$num_ord= $query_ord->num_rows();
				if($num_ord > 0)
				{
   //if($planactive=='yes')
   //{
?>	
   <div class="tab-content">
    <?php 
      if($SylList1 != null && $SylList1 != ""){
			global $order_arr;
			$tid=0;$wid=0;
									?>
        <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
          <h2 class="blue-title">Term 1</h2>
          <div class="row">
            <?php 
			$userweek=1;
			$aveageweek=0;
			/* echo '<pre>';
			var_dump($SylList1);
			echo '</pre>'; */
			$countweek=1;
			
			foreach($SylList1 as $result){
			
	$term= $this->main_model->get_detail('master_terms','term_id',$result->term_id);
	$skl_dtl= $this->main_model->get_detail('master_skill','skill_id',$result->skill_id);
	$query=$this->db->query('select * from syllabus_week_subskill where skill_id = "'.$result->skill_id.'" and week_id = "'.$userweek.'"'); 
	 $ct2= $query->num_rows();
	$comp2=0;
	if($countweek==1)
	{
			//echo 'select * from syllabus_week_subskill where skill_id = "'.$result->skill_id.'" and week_id = "'.$userweek.'"';
		?>
            <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
              <div class="syllabus-sec">
                <h3><?php echo $order_arr[$result->skill_order].'. '.$skl_dtl->skill_name;?></h3>
                <div class="row">
                  <?php 

	foreach($query->result() as $ress){
	
	$subskl_dtl= $this->main_model->get_detail('master_skill','skill_id',$ress->subskill_id);
	$comp2++;
	?>
    <?php if($wid!=$ress->week_id || $comp2==1){
	
	$query1=$this->db->query('select count(*) as "ct" from syllabus_week_subskill where week_id="'.$userweek.'" and term_id="'.$ress->term_id.'" and year_id="'.$ress->year_id.'"');
	$res1=$query1->row();
	$ct= $res1->ct;
	
	$comp=0;

	$week_dtl= $this->main_model->get_detail('master_weeks','week_id',$ress->week_id);
	$this->db->select('*'); 
	$this->db->from('master_goal');
	$this->db->where('term_id',$result->term_id);
	$this->db->where('year_id',$result->class_id);
	$this->db->where('week_id',$ress->week_id);
	$goal= $this->db->get()->row();
	$color_class=explode(',' ,$ress->week_id);
	$color_class=$color_class[0];
	$aveageweek ++;
	/*---get Week Notes detail-------*/
	$query_notes=$this->db->query('select notes_file from master_weeknotes where week_id="'.$ress->week_id.'" and term_id="'.$ress->term_id.'" and year_id="'.$ress->year_id.'"');
	$row_notes=$query_notes->row();
	/*----end of week notes details-----*/
	?>
                  <div class="col-xs-12 col-sm-12 col-md-4 col-lg-4">
                    <div class="box-syllabus">
                      <div class="text-content">
                        <ul>
                          <li>
                            <div class="row">
                              <div class="col-xs-8 col-sm-8 col-md-6 col-lg-8 col-8"><strong><?php echo $goal->goal_name;?></strong></div>
                              <div class="col-xs-4 col-sm-4 col-md-6 col-lg-4 col-4">
                                <h4 class="cyan_bg color-<?php echo $color_class;?>"><?php echo $week_dtl->week_name;?>
								</h4> 
                              </div>
                            </div>
                          </li>
                          <?php } $comp++; ?>
                        					
						 <a href="<?php echo base_url().'classroom-exercise/'.$subskl_dtl->skill_slug;?>">
                          <li><strong><?php echo $order_arr[$result->skill_order].'.'.$ress->subskill_order;?></strong> <?php echo $subskl_dtl->skill_name;?></li>
                          </a>
						  
							
                          <?php if(($ct==$comp) || ($ct2==$comp2)){?>
                        </ul>
                      </div>
                    </div>
                  </div>
                  <?php } $wid=$ress->week_id;?>
                  <?php } ?>
                </div>
              </div>
            </div>
            <?PHP 
			}
			$countweek++;
			} ?>
          </div>
        </div>
        <?PHP } ?>
   </div>
   <?php
   } 
   else
   { 
	if($nobuyplan=='1')
	{	
	 
	   echo '<p style="color:red;">Please make payment of current week.</p><p><a href="'.BASE_URL.'membership-plan" style="font-weight:bold;">Pay Now</p><br/>';
	}
	else
	{
		echo '<p style="color:red;">Your Plan has been expired,please make payment of current week.</p>
		<p><a href="'.BASE_URL.'membership-plan" style="font-weight:bold;">Pay Now</p><br/>
		';
	}
   }
   ?>
 <!--
 <div class="table-responsive">
 <table class="table table-striped table-light">
  <thead>
    <tr>
      <th scope="col">Study Week No</th>
      <th scope="col">Topic</th>
      <th scope="col">Subject Exercises</th>
      <th scope="col">Classroom Score</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th scope="row"># <?php echo $week_id;?>. (<?php echo $yearstart. ' - '. $currentdate;?>)</th>
      <td><?php
	  if($yeargoal)
	  {
		 
			  echo $yeargoal->goal_name;
		  
		  
	  }
	  
	  ?></td>
      <td>  <ul>
	  <?php
	$sorder=1;
	  $query=$this->db->query("select * from syllabus_week_subskill where week_id='".$week_id."' and term_id='".$term_id."' and year_id='".$year_id."' order by subskill_order asc"); 
	  foreach($query->result() as $ress){
		  $subskl_dtl= $this->main_model->get_detail('master_skill','skill_id',$ress->subskill_id);
	  ?>
	  <a href="<?php echo base_url().strtolower($year_slug).'/'.$subskl_dtl->skill_slug;?>"><li><strong><?php //echo $order_arr[$sorder].'.'.$sorder;?></strong> <?php echo $subskl_dtl->skill_name;?></li></a>
	  <?php
	  $sorder++;
	  }
	  ?>
	  </ul>
	
</td>
      <td></td>
    </tr>
    
    
  </tbody>
</table>
</div>

-->
 
 </div>
 
 
 
 
 </div>
 </div>
 </section>
 
 
   
   
   
   
   
   
    
 <!-- Page Content End -->
<?php include('footer.php'); ?>