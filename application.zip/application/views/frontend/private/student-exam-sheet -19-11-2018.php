<?php include('header.php'); ?>

<!-- Page Content inner -->
<!--
<div class="tabs-login">
<div class="container">
<div class="row">
<ul class="links-menu">
<li><a href="notice-board">Notice Board</a></li>
<li><a href="this-week-classroom-exercise">This Week Classroom Exercise</a></li>
<li><a href="homework-exercise" >Homework Exercise</a></li>
<li><a href="year-1-syllabus"><?php echo $year_name;?> - Syllabus</a></li>
<li><a href="analysis-report">Analysis Report</a></li>
<li><a href="booking-payment">Booking & Payment</a></li>
<li><a href="certificate-award">Certificate & Award</a></li> 
<li><a href="changepassword">Change Password</a></li>
<li><a href="<?php echo  base_url().lcfirst($year_slug);?>/exam"><?php echo $year_name;?> - Exam</a></a></li>
<li><a href="<?php echo  base_url();?>student-exam-grade" class="active">Students Grade</a></a></li>
</ul>

</div>
</div>

</div>
 -->

 
 <section class="about_content content-text space-75 space-top-0">
 <div class="container">
 <h1>Students Exam Sheet</h1>
 <?php
 if($exam_details)
 {
	 foreach($exam_details as $rowexam)
	 {
		    $user_query=$this->db->query("select user_id,first_name,last_name from user_details where user_id='".$rowexam->user_id."' "); 
			$result_user=$user_query->row();
	 
	 
 ?>
 <div class="row">

  <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
   <div class="row">
   <div class="col-md-6 col-sm-6">
    <table class="table table-striped table-light">
	<tr>
	<td><strong>Student ID</strong></td>
	<td><?php echo $rowexam->user_id;?></td>
	</tr>
	<tr>
	<td><strong>First Name</strong></td>
	<td><?php echo $result_user->first_name;?></td>
	</tr>
	<tr>
	<td><strong>Last Name</strong></td>
	<td><?php echo $result_user->last_name;?></td>
	</tr>
	<tr>
	<td><strong>Reporting Period</strong></td>
	<td>Term <?php echo $rowexam->term_id;?></td>
	</tr>
	</table>
   </div>
     <div class="col-md-6 col-sm-6">
	 <table class="table table-striped table-light">
	<tr>
	<td><strong>Date</strong></td>
	<td><?php echo $rowexam->exam_date;?></td>
	</tr>
	<tr>
	<td><strong>Year</strong></td>
	<td><?php 
	if($rowexam->year_id==1)
	{
	echo 'kindergarten';
	}
	else	
	{
		echo $rowexam->year_id;
	}
	?></td>
	</tr>
	<tr>
	<td><strong>Total Gade</strong></td>
	<td><?php 
	 $examhquery=$this->db->query("select count(*) as totalquestion from sexam_history where exam_id='".$rowexam->exam_id."' "); 
		   $ehistoryrow=$examhquery->row();
		   $totalquestion=$ehistoryrow->totalquestion;
		   $queryrightcount="select count(*) as totalright from sexam_history where exam_id='".$rowexam->exam_id."' and answer_status='true'  ";
		  
		   $examhquery1=$this->db->query($queryrightcount); 
		   $exrightquestion=$examhquery1->row();
		   // var_dump($resultexam);
		    $totalright=$exrightquestion->totalright;
			$calper=($totalright/$totalquestion)*100;
	 echo $totalright.'/'.$totalquestion.' ('.number_format($calper).'%)';
	?></td>
	</tr>
	
	</table>
   </div>
  
</div>
 </div>
 
 </div>
<?php
 $sheet_query=$this->db->query("select * from sexam_history where exam_id='".$rowexam->exam_id."' "); 
$result_sheet=$sheet_query->result();
if($result_sheet)
{
?>
<strong>Questions Sheet</strong>
 <div class="row">
  <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
  <table class="table table-striped table-light">
  <thead>
    <tr>
	<th scope="col">Skill</th>
      <th scope="col">Question</th>
	  
      <th scope="col">Answer</th>     
      <!--<th scope="col">Status</th>-->
	
	   
    </tr>
  </thead>
  <tbody>
  </tbody>
  <?php
  foreach($result_sheet as $rowsheet)
  {
	   $question_query=$this->db->query("select ques.ques_name,skill.skill_name from manage_question_".$rowexam->year_id." ques left join master_skill skill on
		skill.skill_id=ques.ques_subskillid where ques.ques_id='".$rowsheet->question_id."' "); 
	   $result_ques=$question_query->row();
	  ?>
  <tr>
   <td><?php echo $result_ques->skill_name;?></td>
  <td><?php echo $result_ques->ques_name;?></td>
  
    <td>
	<?php
	if($rowsheet->answer_status=='true')
	{
		echo 'Correct';
	}
	else
	{
		echo 'Wrong';
	}
	?>
	</td>
  </tr>
  <?php
  }
  ?>
  </table>
  </div>
  </div>
 <?php
}
	 }
}
?> 
 </div>
 </section>
 
 
   
   
   
   
   
   
    
 <!-- Page Content End -->
<?php include('footer.php'); ?>