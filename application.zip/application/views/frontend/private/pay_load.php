<?php include('header.php');
ini_set('max_execution_time', 300);
 ?>

<!-- Page Content inner -->
<section id="title-inner" class="bgcolor-text">
<canvas id="demo-canvas"></canvas>
<div class="container">
<div class="text-tit">
<h1>
<span>Order History</span>
</h1>
</div>

</div>
</section>

<?php /*?><div class="tabs-login">
<div class="container">
<div class="row">
<ul class="links-menu">
<li><a href="my-notice-board" class="active">Notice Board</a></li>

<li><a href="<?php echo  base_url();?>this-week-classroom-exercise">This Week Classroom Exercise</a></li>
<li><a href="<?php echo  base_url();?>homework-exercise">Homework Exercise</a></li>
<li><a href="/<?php echo lcfirst($year_slug);?>"><?php echo $year_name;?> - Syllabus</a></li>
<li><a href="analysis-report">Analysis Report</a></li>
<li><a href="booking-payment">Booking & Payment</a></li>
<li><a href="certificate-award">Certificate & Award</a></li>
<li><a href="<?php echo  base_url().lcfirst($year_slug);?>/exam"><?php echo $year_name;?> - Exam</a></li>
<!--<li><a href="<?php echo  base_url();?>student-exam-grade">Students Grade</a></li>-->
</ul>

</div>
</div>

</div><?php */?>
 <?php
 $today=strtotime(date("Y-m-d H:i:s"));
 ?>
 <section class="about_content content-text space-75">
 <div class="container">
 <div class="row"><br/>
 <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
<div id="myloader" style="display:none;"><img src="<?= base_url('assets/images/2.gif')?>" /></div>
 	<?php  echo '<div class="table-wrap">
	<div class="table-responsive">
	  <table class="table table-hover table-bordered mb-0">

		<tbody>
			<tr>
		<td colspan="8">We are updating.... Please wait.</td>
	</tr>';?>
		<?php 
		$i=1;
		while($i>0){
		$this->db->select('*'); 
		$this->db->from('orders');
		$this->db->where('userid',$this->session->userdata('user_id'));
		$this->db->order_by('order_date', 'DESC');
		$orderlist=$this->db->get()->row();
		
		if($orderlist != null && $orderlist != ""){		
		  
			if($orderlist->pay_status=='confirm'){
				$i=0;
				$this->session->set_userdata('loginyear',$orderlist->year_id);
			}

		
		}
		}
		redirect(base_url().'booking-payment');
		
			?>
	
		
		<?php  echo '</tbody>
		</table>
		<br/>
		

	 </div>
 </div>';?>
 
 
 
 
 </div>
 </div>
 </section>
 
 
   
   
   
   
   
   
    
 <!-- Page Content End -->
<?php include('footer.php'); ?>
 <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
 <script type="text/javascript">
 var n = localStorage.getItem('on_load_counter');
    if (n === null) {
        n = 0;
    }
    n++;
    localStorage.setItem("on_load_counter", n);
	 var np = localStorage.getItem('on_load_counter');
	if(np< 3)
	{
		$(document).ready(function(){    
			//Check if the current URL contains '#'
		
			if(document.URL.indexOf("#")==-1){
				// Set the URL to whatever it was plus "#".
				 $('#myloader').show();
				url = document.URL+"#";
				location = "#";

				//Reload the page
				location.reload(true);
			}
			else
			{
				 $('#myloader').show();
				location.reload(true);
			}
			
			
		});
	}
	if(np==3)
	{
		$('#myloader').hide();
	}
</script>