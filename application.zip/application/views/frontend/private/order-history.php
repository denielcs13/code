<?php include('header.php'); ?>

<!-- Page Content inner -->
<section id="title-inner" class="bgcolor-text">
<canvas id="demo-canvas"></canvas>
<div class="container">
<div class="text-tit"> 
<h1>
<span>Order History</span>
</h1>
</div>

</div>
</section>

<?php /*?><div class="tabs-login">
<div class="container">
<div class="row">
<ul class="links-menu">
<li><a href="my-notice-board" class="active">Notice Board</a></li>

<li><a href="<?php echo  base_url();?>this-week-classroom-exercise">This Week Classroom Exercise</a></li>
<li><a href="<?php echo  base_url();?>homework-exercise">Homework Exercise</a></li>
<li><a href="/<?php echo lcfirst($year_slug);?>"><?php echo $year_name;?> - Syllabus</a></li>
<li><a href="analysis-report">Analysis Report</a></li>
<li><a href="booking-payment">Booking & Payment</a></li>
<li><a href="certificate-award">Certificate & Award</a></li>
<li><a href="<?php echo  base_url().lcfirst($year_slug);?>/exam"><?php echo $year_name;?> - Exam</a></li>
<!--<li><a href="<?php echo  base_url();?>student-exam-grade">Students Grade</a></li>-->
</ul>

</div>
</div>

</div><?php */?>
 <?php 
 $today=strtotime(date("Y-m-d H:i:s"));
 ?>
 <section class="about_content content-text space-75">
 <div class="container">
 <div class="row"><br/>
 <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
<div id="myloader" style="display:none;"><img src="<?= base_url('assets/images/2.gif')?>" /></div>
 	<div class="table-wrap">
	<div class="table-responsive">
	  <table class="table table-hover table-bordered mb-0">
		<thead>
		  <tr>
			<th>Order ID</th>
			<th>Year</th>
			<th>Center</th>			
			<th>Plan</th>
			<th>Amount</th>
			<th>Status</th>
			<th>Payment Status</th>
			<th>Tansation ID</th>
			<th>Date</th>			
			<th class="text-nowrap">View</th>
		  </tr>
		</thead>
		<tbody>
		<?php 
		$expirydate="";
		$orddb="";
		if($orderlist != null && $orderlist != ""){		
		  foreach($orderlist as $result)
		  {
			$plan_name=$this->plan_model->GetPlanName($result->plan_id);
			/*----expired order plan------*/
			$expirydate=strtotime("+".$result->order_totalweek." week", strtotime($result->order_date));
			if($today > $expirydate)
			{
				$orddb=array('order_status'=>'expired');				
				$this->order_model->Update_Order($orddb,$result->orderid);
			}
			/*----end of expired order plan------*/	
		?>
		<tr>
		<td><?php echo $result->orderid;?></td>
		<td><?php echo $this->classes_model->GetClassName($result->year_id);?></td>
		<td><?php echo $this->center_model->GetDepartmeantName($result->center_id);?></td>
		<td><?php echo $plan_name;?></td>
		<td>$<?php echo number_format($result->amount);?></td>
		<td><?php echo ucfirst($result->order_status);?></td>
		<td><?php echo ucfirst($result->pay_status);?></td>
		<td><?php echo $result->trans_id;?></td>
		<td><?php echo date('m/d/Y',strtotime($result->order_date));?></td>
		<td><a href="<?php echo  base_url();?>order-invoice/<?php echo $result->orderid;?> ">Invoice</a>
		
		</td>
		</tr>
		<?php
		  }
		}
		else
		{
			?>
		<tr>
		<td colspan="8">No Order available!</td>
</tr>
<?php
		}
?>		
		</tbody>
		</table>
		<br/>
		<center><a href="<?php echo  base_url();?>membership-plan"><button class="btn-mn btn-3 btn-3e button-org">Buy Plan</button></a></center>
</div>
	 </div>
 </div>
 
 
 
 
 </div>
 </div>
 </section>
 
 
   
   
   
   
   
   
    
 <!-- Page Content End -->
<?php include('footer.php'); ?>
 <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
 <script type="text/javascript">
 var n = localStorage.getItem('on_load_counter');
    if (n === null) {
        n = 0;
    }
    n++;
    localStorage.setItem("on_load_counter", n);
	 var np = localStorage.getItem('on_load_counter');
	if(np< 3)
	{
		$(document).ready(function(){    
			//Check if the current URL contains '#'
		
			if(document.URL.indexOf("#")==-1){
				// Set the URL to whatever it was plus "#".
				 $('#myloader').show();
				url = document.URL+"#";
				location = "#";

				//Reload the page
				location.reload(true);
			}
			else
			{
				 $('#myloader').show();
				location.reload(true);
			}
			
			
		});
	}
	if(np==3)
	{
		$('#myloader').hide();
	}
</script>