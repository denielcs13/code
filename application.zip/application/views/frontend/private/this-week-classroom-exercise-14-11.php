<?php include('header.php'); ?>

<section id="title-inner" class="bgcolor-text">
<canvas id="demo-canvas"></canvas>
<div class="container">
<div class="text-tit">
<h1>
<span>This Week Classroom Exercise</span>
</h1>
</div>

</div>
</section>
<!-- Page Content inner -->

<?php /*?><div class="tabs-login">
<div class="container">
<div class="row">
<ul class="links-menu">
<li><a href="notice-board">Notice Board</a></li>
<li><a href="this-week-classroom-exercise" class="active">This Week Classroom Exercise</a></li>
<li><a href="homework-exercise">Homework Exercise</a></li>
<li><a href="year-1-syllabus"><?php echo $year_name;?> - Syllabus</a></li>
<li><a href="analysis-report">Analysis Report</a></li>
<li><a href="booking-payment">Booking & Payment</a></li>
<li><a href="certificate-award">Certificate & Award</a></li>
<li><a href="changepassword">Change Password</a></li>
<li><a href="<?php echo  base_url().lcfirst($year_slug);?>/exam"><?php echo $year_name;?> - Exam</a></a></li>
</ul>

</div>
</div>

</div><?php */?>
 <?php
 global $order_arr;

 ?>
 <section class="about_content content-text space-75">
 <div class="container">
 <div class="row">
 
 <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
 
 <div class="table-responsive">
 <table class="table table-striped table-light">
  <thead>
    <tr>
      <th scope="col">Study Week No</th>
      <th scope="col">Topic</th>
      <th scope="col">Subject Exercises</th>
      <th scope="col">Classroom Score</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th scope="row"># <?php echo $week_id;?>. (<?php echo $yearstart. ' - '. $currentdate;?>)</th>
      <td><?php
	  if($yeargoal)
	  {
		 
			  echo $yeargoal->goal_name;
		  
		  
	  }
	  
	  ?></td>
      <td>  <ul>
	  <?php
	$sorder=1;
	  $query=$this->db->query("select * from syllabus_week_subskill where week_id='".$week_id."' and term_id='".$term_id."' and year_id='".$year_id."' order by subskill_order asc"); 
	  foreach($query->result() as $ress){
		  $subskl_dtl= $this->main_model->get_detail('master_skill','skill_id',$ress->subskill_id);
	  ?>
	  <a href="<?php echo base_url().strtolower($year_slug).'/'.$subskl_dtl->skill_slug;?>"><li><strong><?php //echo $order_arr[$sorder].'.'.$sorder;?></strong> <?php echo $subskl_dtl->skill_name;?></li></a>
	  <?php
	  $sorder++;
	  }
	  ?>
	  </ul>
	
</td>
      <td></td>
    </tr>
    
    
  </tbody>
</table>
</div>
 
 </div>
 
 
 
 
 </div>
 </div>
 </section>
 
 
   
   
   
   
   
   
    
 <!-- Page Content End -->
<?php include('footer.php'); ?>