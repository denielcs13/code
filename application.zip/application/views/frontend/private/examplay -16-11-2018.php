<?php include('header.php'); ?>
<?php
    /*Just for your server-side code*/
    header('Content-Type: text/html; charset=ISO-8859-1');
?>


<section id="title-inner" class="bgcolor-text">
<canvas id="demo-canvas"></canvas>
<div class="container">
<div class="text-tit">
<h1>
<span><?php echo $year_dtl->class_name;?> - Exam</span>
</h1>
</div>

</div>
</section>

 <!-- Page Content inner -->
 
 
 <section class="about_content content-text syllabus-page space-75">
 <div class="container">
 <div class="row">
<!-- Bootstrap Tabs -->
	
	<div class="tab-content">
											

		<?php if(isset($correct) && $correct==1){	?>
		<div id="infor">
		<h3> Fantastic</h3>
		</div>
		<?php }	?>
											
		<form  name="myForm"  method="post" action="" onsubmit="return validateForm()">	
			
			
			<?php 

			if($Questionlist != null && $Questionlist != "")
			{
				
			  foreach($Questionlist as $result){
			
				$query_ques=$this->db->query("select * from manage_question_".$year_id." where ques_id='".$result->question_id."' ");
				$ques_result=$query_ques->row();
				if($ques_result->ques_type==1){  
					
					echo $ques_result->ques_name;
					echo '<br>';
					
				
					$answers=$this->questions_model->get_answers($ques_result->ques_id);
					foreach($answers as $answer){
						
					echo '<a id ="a1" href="javascript:alert(default functionality)"  style="height: 77px; width: 77px; line-height: 77px; font-size: 50px;background-color: #1fb2e4;color:#FFF" ><input name="answerid" value="'.$answer->ans_id.'" name="rb" type="radio" id="rb1" style="height: 77px; width: 77px; line-height: 77px; font-size: 50px;background-color: #1fb2e4;color:#FFF">'.$answer->ans_name.'</a>&nbsp;&nbsp;&nbsp;';
					}
					
				
				}
				elseif($ques_result->ques_type==3){ 
					
					echo $ques_result->ques_name;
					echo '<br>';
					$imgs=$this->main_model->getall('ques_img','ques_id',$ques_result->ques_id);

					
					echo '<br>';
					$answers=$this->questions_model->get_answers($ques_result->ques_id);
					foreach($answers as $answer){
						
					echo '<a id ="a1" href="javascript:alert(default functionality)"  style="height: 77px; width: 77px; line-height: 77px; font-size: 50px;background-color: #1fb2e4;color:#FFF" ><input name="answerid" value="'.$answer->ans_id.'" name="rb" type="radio" id="rb1" style="height: 77px; width: 77px; line-height: 77px; font-size: 50px;background-color: #1fb2e4;color:#FFF">'.$answer->ans_name.'</a>&nbsp;&nbsp;&nbsp;';
					}
					
				
				}
				elseif($ques_result->ques_type==4){ 
					
					echo $ques_result->ques_name;
					echo '<br>';
					$imgs=$this->main_model->getall('ques_img','ques_id',$ques_result->ques_id);

					foreach($imgs as $img){

					echo '<img src="/assets/uploads/ans/'.$img->img.'"/>';
					}
					echo '<br>';
					$answers=$this->questions_model->get_answers($ques_result->ques_id);
					foreach($answers as $answer){
						
					echo '<a id ="a1" href="javascript:alert(default functionality)"  style="height: 77px; width: 77px; line-height: 77px; font-size: 50px;background-color: #1fb2e4;color:#FFF" ><input name="answerid" value="'.$answer->ans_id.'" name="rb" type="radio" id="rb1" style="height: 77px; width: 77px; line-height: 77px; font-size: 50px;background-color: #1fb2e4;color:#FFF">'.$answer->ans_name.'</a>&nbsp;&nbsp;&nbsp;';
					}
					
				
				}
				elseif($ques_result->ques_type==5)
				{
					echo $ques_result->ques_name;
					echo '<br>';
					$imgs=$this->main_model->getall('ques_img','ques_id',$ques_result->ques_id);

				
					echo '<br>';
					
					$answers=$this->questions_model->get_answers($ques_result->ques_id);
					foreach($answers as $answer){
					
					if($answer->has_image==1){
						
					
						
					echo '<label class="anslabel"><input name="answerid" value="'.$answer->ans_id.'" name="rb" type="radio" id="rb1"><img src="/assets/uploads/ans/'.$answer->ans_name.'"/></label>&nbsp;&nbsp;&nbsp;';
					}
						
					}
					
				}
				elseif($ques_result->ques_type==6)
				{
					echo $ques_result->ques_name;
					echo '<br>';
					$imgs=$this->main_model->getall('ques_img','ques_id',$ques_result->ques_id);
					foreach($imgs as $img){
					for($i=0;$i<$img->repeat;$i++){
					echo '<img src="/assets/uploads/ans/'.$img->img.'"/>';
					}
					echo '<br>';
					}
				
					echo '<br>';
					
					$answers=$this->questions_model->get_answers($ques_result->ques_id);
					foreach($answers as $answer){
					
					echo '<label class="anslabel"><input name="answerid" value="'.$answer->ans_id.'" name="rb" type="radio" id="rb1"><div>'.$answer->ans_name.'</div></label>&nbsp;&nbsp;&nbsp;';
						
					}
					
				}
				
				elseif($ques_result->ques_type==25){ 
					
					echo $ques_result->ques_name;
					echo '<br>';
					$imgs=$this->main_model->getall('ques_img','ques_id',$ques_result->ques_id);

					
					echo '<br>';
					$answers=$this->questions_model->get_answers($ques_result->ques_id);
					foreach($answers as $answer){
						
					echo '<a id ="a1" href="javascript:alert(default functionality)"  style="height: 77px; width: 77px; line-height: 77px; font-size: 50px;background-color: #1fb2e4;color:#FFF" ><input name="answerid" value="'.$answer->ans_id.'" name="rb" type="radio" id="rb1" style="height: 77px; width: 77px; line-height: 77px; font-size: 50px;background-color: #1fb2e4;color:#FFF">'.$answer->ans_name.'</a>&nbsp;&nbsp;&nbsp;';
					}
					
				
				}
				
				elseif($ques_result->ques_type==26)
				{
					$QuesDecoded = base64_decode($ques_result->ques_name); 
					echo $QuesDecoded;
					echo '<br>';
					
				
				}
				}
				?>
				<div>
					<input type="hidden" name="questionid" value="<?php echo $ques_result->ques_id;?>"/>
					<input type="hidden" name="action" value="submitanswer"/>	
					<input type="hidden" name="ques_type" value="<?php echo $ques_result->ques_type;?>"/>
					<input type="hidden" name="year_id" value="<?php echo $year_id;?>"/>
					<input type="hidden" name="term_id" value="<?php echo $term_id;?>"/>
					<input type="submit" name="submit" value="Submit">
				</div>
				<?php }
				else
				{ ?>
				  No Question found
				<?php } ?>
				
				
		</form>

</div>

 </div>
 </div>
 </section>
 <style>
 .anslabel > input{ /* HIDE RADIO */
  visibility: hidden; /* Makes input not-clickable */
  position: absolute; /* Remove input from document flow */
}
.anslabel > input + img{ /* IMAGE STYLES */
  cursor:pointer;
  border:2px solid transparent;
  border-radius:10px;
  padding:0px;
}
.anslabel > input:checked + img{ /* (RADIO CHECKED) IMAGE STYLES */
  border:2px solid #1278a6;
   padding:0px;
}

.anslabel > input + div{ /* IMAGE STYLES */
  cursor:pointer;
  border:2px solid #00a7dc;
  border-radius:10px;
  padding:10px;
}
.anslabel > input:checked + div{ /* (RADIO CHECKED) IMAGE STYLES */
  border:2px solid #1278a6;
   padding:10px;
}
 </style>
 
 <script>
  $("#a1").click(function(event) {
    this.removeAttribute("href");            
    anchorClicked("a1");
  });
  
  $( document ).ready(function() {
    $("#infor").delay(3000).fadeOut("slow");
});

function validateForm() {
    var x = document.forms["myForm"]["answerid"].value;
	
    if (x == "") {
        var r = confirm("You did not complete the question.Are you sure you want to submit?!");
		if (r == true) {
			return true;
		} else {
			return false;
		}
    }
}
 </script>


   
   
   
   
    
 <!-- Page Content End -->
<?php include('footer.php'); ?>