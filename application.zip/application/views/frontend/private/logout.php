<?php 
if($this->session->userdata('user_id')!='')
{

	include(APPPATH.'/views/frontend/private/header.php');
	
}
else
{
		include(APPPATH.'/views/frontend/public/header.php');
}	
?>


 <!-- Page Content inner -->



<div class="login-page logout-page">
  <div class="container">
    <div class="row">
      <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 space-75">
        <div class="row res-space-0">
          <div class="col-md-2"></div>
          <div class="col-xs-12 col-sm-12 col-md-12 col-lg-8 shadow-box">
            <div class="bg-form">
              <div class="row">
                <div class="col-xs-12 col-md-6 p-left15 mobile-none">
                  <div class="login-bg">
                    <div class="text-content">
                      <h2>Thankyou and see you again</h2><br>
                      <p>You have successfully logged out.</p>
                    </div>
                  </div>
                </div>
                <div class="col-xs-12 col-md-6">
                  <div class="form-section">
                    <h1>Thanks For Stopping by us</h1>

<h2>Follow us</h2>
<ul class="social">
<li><a href="https://www.facebook.com/" class="fb" target="_blank"><i class="fa fa-facebook" aria-hidden="true"></i></a></li>
<li><a href="https://www.linkedin.com/uas/login" class="link" target="_blank"><i class="fa fa-linkedin" aria-hidden="true"></i></a></li>
<li><a href="https://www.instagram.com/accounts/login/?hl=en" class="insta" target="_blank"><i class="fa fa-instagram" aria-hidden="true"></i></a></li>
<li><a href="https://web.whatsapp.com/#" class="whatsapp" style="background: #00e676;border-color: #a67356;" target="_blank"><i class="fa fa-whatsapp" aria-hidden="true"></i></a></li>
<li><a href="https://web.wechat.com/" class="whatsapp" style="background: ##00d20f;border-color: #a67356;" target="_blank"><i class="fa fa-wechat"></i></a></li>
</ul>
                    
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="col-md-2"></div>
        </div>
      </div>
    </div>
  </div>
</div>
 
    
 <!-- Page Content End -->
<?php 
if($this->session->userdata('user_id')!='')
{

	include(APPPATH.'/views/frontend/private/footer.php');
	
}
else
{
		include(APPPATH.'/views/frontend/public/footer.php');
}	
?>

