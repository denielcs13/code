 
<footer class="private-footer">
<div class="container">
<div class="row">

<div class="col-xs-12 col-sm-12 col-md-12 col-lg-5">
<div class="rightbar">

<div class="row space_bottom_23 color_text botttom_link">



<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
<h5>Follow Us</h5>
<ul class="social">
<li><a href="https://www.facebook.com/" class="fb" target="_blank"><i class="fa fa-facebook" aria-hidden="true"></i></a></li>
<li><a href="https://twitter.com/" class="tw" target="_blank"><i class="fa fa-twitter" aria-hidden="true"></i></a></li>
<li><a href="https://plus.google.com/discover" class="gplus" target="_blank"><i class="fa fa-google-plus" aria-hidden="true"></i></a></li>
<li><a href="https://www.youtube.com/" class="yt" target="_blank"><i class="fa fa-youtube" aria-hidden="true"></i></a></li>

<li><a href="https://www.instagram.com/accounts/login/?hl=en" class="insta" target="_blank"><i class="fa fa-instagram" aria-hidden="true"></i></a></li>
<li><a href="https://www.linkedin.com/uas/login" class="link" target="_blank"><i class="fa fa-linkedin" aria-hidden="true"></i></a></li>
<li><a href="https://www.pinterest.com/" class="pin" target="_blank"><i class="fa fa-pinterest" aria-hidden="true"></i></a></li>
</ul>

</div>

<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
<div class="counter">
 Questions answered  <h3><?php echo get_counter();?></h3>
</div>

</div>


</div>
</div>

</div>

</div>
   
<div class="copy_right">
<p class="text-left">© 2018 - <?php echo date('Y');?> The University Of English. All Rights Reserved.</p>
</div>
</div>

</footer>
<script>
$('document').ready(function(){
$('.boxText').children('input').attr('maxlength','1');
})
</script>
<a id="back2Top" title="Back to top" href="#">&#10148;</a>
 
<!-- Bootstrap core JavaScript --> 
<script src="<?= base_url('assets/js/jquery.min.js')?>"></script> 
<script src="<?= base_url('assets/js/bootstrap.bundle.min.js')?>"></script> 
<script src="<?= base_url('assets/js/main.js')?>"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1/jquery.min.js"></script>
<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
<script src="<?= base_url('assets/js/jquery.slicknav.js')?>"></script>
<script src="<?= base_url('assets/js/demo-2.js')?>"></script>

<script src="<?= base_url('assets/js/owl.carousel.js')?>"></script>
<script src="<?= base_url('assets/js/owl.carousel.min.js')?>"></script> 

<script>
            $(document).ready(function() {
              var owl = $('.owl-carousel');
              owl.owlCarousel({
				items: 1,
                margin: 10,
                nav: true,
                loop: true,
				 autoplay: true,
                responsive: {
                  0: {
                    items: 1
                  },
                  600: {
                    items: 2
                  },
                  1000: {
                    items: 3
                  }
                }
              })
            })
          </script> 
		 
</body>
</html>