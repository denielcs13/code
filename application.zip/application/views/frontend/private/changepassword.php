<?php include('header.php'); ?>

<!-- Page Content inner -->

<section id="title-inner" class="bgcolor-text">
<canvas id="demo-canvas"></canvas>
<div class="container">
<div class="text-tit">
<h1>
<span>Change Password</span>
</h1>
</div>

</div>
</section>

 
 <section class="about_content login-page forgot-password change-password content-text space-75">
 <div class="container">
 <div class="row">
 <div class="col-xs-12 col-sm-12 col-md-3 col-lg-3"></div> 
 
 <div class="col-xs-12 col-sm-12 col-md-12 col-lg-6">
 <div class="form-section"><form class="cmxform" id="signupForm" method="post" action="">
<div class="row">
<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
<p class="error">Username is required.</p>
<?php
if($success!="")
{
	?>
<p class="successfully-msg"><?php echo $success;?></p>
<?php
}
?>	
<?php if (validation_errors()) : ?>
											<div class="col-md-12">
												<div class="alert alert-danger" role="alert">
													<?= validation_errors() ?>
												</div>
											</div>
											<?php endif; ?>
										<?php if ($error!=''){ ?>
											<div class="col-md-12">
												<div class="alert alert-danger" role="alert">
													<?= $error ?>
												</div>
											</div>
										<?php } ?>

<div class="input-field">
					<input type="password" name="currentpassword" id="currentpassword" value="" placeholder="Current Password" />
	
           
</div>
<div class="input-field">
					<input type="password" name="password" id="password" value="" placeholder="New Password" />
	
           
</div>

<div class="input-field">
<input type="password" name="cpassword" id="cpassword" value="" placeholder="Confirm Password" />
</div>
<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 text-center"><button class="btn-mn btn-3 btn-3e button-org">Update</button></div>





</div>


</div>
</form></div>
 
 </div>
 
 <div class="col-xs-12 col-sm-12 col-md-3 col-lg-3"></div>
 
 
 
 
 </div>
 </div>
 </section>
 
 
   
   
   
   
   
   
    
 <!-- Page Content End -->
<?php include('footer.php'); ?>