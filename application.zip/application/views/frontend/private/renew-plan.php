<?php //include('header.php'); ?>

<!--<section id="title-inner" style="background-image:url(<?= base_url('assets/images/contact-bg.jpg')?>);">
<div id="large-header">   
<canvas id="demo-canvas"></canvas>
<div class="container">
<div class="text-tit">
 <div class="bb"></div>
<span class="lefttop-icon"></span>
<h1>
<span>Membership-Plans</span>
</h1>
<span class="rightbotm-icon"></span>
</div>

</div></div>

</section>-->

<!-- Page Content inner -->
<link href="<?= base_url('assets/style.css')?>" rel="stylesheet">

<div class="signup-page">

<div class="container">
<div class="row">


<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 space-75">

<div class="row" style="text-align:center;">
<br/></br/>
<h2 class="ref-paynow-size">Please do not refresh or back button for payment processing<h2>

<form name="paypal" action="https://www.sandbox.paypal.com/cgi-bin/webscr" method="post" target="_top">
<input type="hidden" name="cmd" value="_xclick">
<input type="hidden" name="business" value="testing80-facilitator@iwesh.com">
<input type='hidden' name='item_name' value='<?php echo $plandetail->plan_name;?>'>
	<input type='hidden' name='item_number' value='<?php echo $orderid;?>'>
	<input type='hidden' name='quantity' value='1'>
	<input type='hidden' name='amount' value='<?php echo $totalamount;?>'>	
	<input type='hidden' name='currency_code' value='USD'>
	<input type='hidden' name='notify_url' value='https://theuniversityofenglish.com/renew-notified'>
	<input type='hidden' name='cancel_return' value='https://theuniversityofenglish.com/pay-cancel'>
	<input type='hidden' name='return' value='https://theuniversityofenglish.com/pay-load'>
<input type="image" src="https://www.sandbox.paypal.com/en_US/i/btn/btn_paynowCC_LG.gif" border="0" name="submit" alt="PayPal - The safer, easier way to pay online!">
<img alt="" border="0" src="https://www.sandbox.paypal.com/en_US/i/scr/pixel.gif" width="1" height="1">
</form>


</div>
</div>

</div>
</div>

</div>

 <!-- Page Content End -->
 <?php //include('footer.php'); ?>
 <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>

<script type="text/javascript">
window.onload = function(){
  document.forms['paypal'].submit();
}
</script>
