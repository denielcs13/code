<?php include('header.php'); ?>

<section id="title-inner" class="bgcolor-text">
<canvas id="demo-canvas"></canvas>
<div class="container">
<div class="text-tit">
<h1>
<span>Homework Exercise</span>
</h1>
</div>

</div>
</section>

<!-- Page Content inner -->

 <section class="about_content content-text space-75">
 <div class="container">
 <div class="row">
 
 <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
 
 <div class="table-responsive">
 <table class="table table-striped table-light">
  <thead>
    <tr>
      <th scope="col">Study Week No.</th>
      <th scope="col">Topic</th>
      <th scope="col">Subject Exercises</th>
      <th scope="col">Homework Score</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th scope="row"># <?php echo $week_id;?>. (<?php echo $yearstart. ' - '. $currentdate;?>)</th>
      <td><?php
	  if($yeargoal)
	  {
		 
			  echo $yeargoal->goal_name;
		  
		  
	  }
	  
	  ?></td>
      <td>  <ul>
	  <?php
	$sorder=1;
	  $query=$this->db->query("select * from syllabus_week_subskill where week_id='".$week_id."' and term_id='".$term_id."' and year_id='".$year_id."' order by subskill_order asc"); 
	  foreach($query->result() as $ress){
		  $subskl_dtl= $this->main_model->get_detail('master_skill','skill_id',$ress->subskill_id);
	  ?>
	  <a href="<?php echo base_url().strtolower($year_slug).'/'.$subskl_dtl->skill_slug;?>"><li><strong><?php //echo $order_arr[$sorder].'.'.$sorder;?></strong> <?php echo $subskl_dtl->skill_name;?></li></a>
	  <?php
	  $sorder++;
	  }
	  ?>
	  </ul>
	
</td>
      <td>
	  <ul>
	  <?php
	  $userid=$this->session->userdata('user_id');
	  $loginyear=$this->session->userdata('loginyear');
	  $totalquestion="";
	  $totalright="";
	  $examhquery="";
	  $examhquery1="";
	  $examquery=$this->db->query("select * from student_exam where year_id='".$loginyear."' and user_id='".$userid."' and exam_status='pass' order by term_id asc"); 
	  foreach($examquery->result() as $resultexam){
		  echo '<li><p><strong>Term-'.$resultexam->term_id.' Results</strong></p>';
		   $examhquery=$this->db->query("select count(*) as totalquestion from sexam_history where exam_id='".$resultexam->exam_id."' "); 
		   $ehistoryrow=$examhquery->row();
		   $totalquestion=$ehistoryrow->totalquestion;
		   $queryrightcount="select count(*) as totalright from sexam_history where exam_id='".$resultexam->exam_id."' and answer_status='true'  ";
		  
		   $examhquery1=$this->db->query($queryrightcount); 
		   $exrightquestion=$examhquery1->row();
		  // var_dump($resultexam);
		    $totalright=$exrightquestion->totalright;
		  echo '<p>'.$totalright.'/'.$totalquestion;
		  echo '</li>';
	  }
		  ?>
		  
		  
	  </ul>
	  </td>
    </tr>
    
 <?php
if($week_id > 1)
{
	$preweek=$week_id-1;
	$prevdate=date('m/d/Y',strtotime ( '-1 week' , strtotime ( $currentdate ) ));
	?>	
<tr>
      <th scope="row"># <?php echo $preweek;?>. (<?php echo $yearstart. ' - '. $prevdate;?>)</th>
      <td><?php
	  if($yeargoal2)
	  {
		 
			  echo $yeargoal2->goal_name;
		  
		  
	  }
	  
	  ?></td>
      <td>  <ul>
	  <?php
	$sorder1=1;
	
	  $query1=$this->db->query("select * from syllabus_week_subskill where week_id='".$preweek."' and term_id='".$term_id."' and year_id='".$year_id."' order by subskill_order asc"); 
	  foreach($query1->result() as $ress1){
		  $subskl_dtl2= $this->main_model->get_detail('master_skill','skill_id',$ress1->subskill_id);
	  ?>
	  <a href="<?php echo base_url().strtolower($year_slug).'/'.$subskl_dtl2->skill_slug;?>"><li><strong><?php //echo $order_arr[$sorder].'.'.$sorder;?></strong> <?php echo $subskl_dtl2->skill_name;?></li></a>
	  <?php
	  $sorder1++;
	  }
	  ?>
	  </ul>
	
</td>
      <td></td>
    </tr>
  <?php
}
?>  
    
  </tbody>
</table>
 </div>

 <p>Every week has at least 2 repeat exercises from the previous done exercises in the syllabus.  Always have records of each exercise, i.e. when was it done, 
the score, the time it take, how questions answered, etc…</p>
 </div>
 
 
 
 
 </div>
 </div>
 </section>
 
 
   
   
   
   
   
   
    
 <!-- Page Content End -->
<?php include('footer.php'); ?>