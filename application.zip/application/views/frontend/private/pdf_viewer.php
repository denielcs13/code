<?php

	 $file =$pdf_path;
	 $fp = fopen($pdf_path,'rb');

header('Content-type: application/pdf');
header('Content-Disposition: inline; filename="'.$file_name.'"');
header('Content-Transfer-Encoding: binary');
header('Content-Length: ' . filesize($file));
header('Accept-Ranges: bytes');

   fpassthru($fp);
		
		?>