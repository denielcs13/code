<?php include('header.php'); ?>
<?php
    /*Just for your server-side code*/
    header('Content-Type: text/html; charset=ISO-8859-1');
?>

<section id="title-inner" class="bgcolor-text">
<canvas id="demo-canvas"></canvas>
<div class="container">
<div class="text-tit">
<h1>
<span><?php echo $year_dtl->class_name;?> - Assessment Test</span>
</h1>
</div>

</div>
</section>

 <!-- Page Content inner -->
 
 
 <section class="about_content content-text syllabus-page space-75">
 <div class="container">
 <div class="row" >
<!-- Bootstrap Tabs -->
	
	<div class="tab-content assessmentplay-content">

<?php
if($err_reload=='1')
{?>
<div id="infor">
<h3 style="color:red;"> Your page reload ,please give test again.</h3>
</div>
<?php
}
?>

		<?php if(isset($timeover) && $timeover==1){	?>
		<div id="infor">
		<?php
			if(isset($completed) && $completed!=1){
				?>
			<h3 style="color:red;"> Your Assessment Test Time is Over.</h3>
			<?php
			}
			?>
		</div>
		<?php
		}
		?>
		<?php
		if(isset($completed) && $completed==1){
			//if(isset($timeover) && $timeover!=1){
			$examhquery=$this->db->query("select count(*) as totalquestion from sasstest_history where exam_id='".$exam_id."' "); 
		   $ehistoryrow=$examhquery->row();
		   $totalquestion=$ehistoryrow->totalquestion;
		   $queryrightcount="select count(*) as totalright from sasstest_history where exam_id='".$exam_id."' and answer_status='true'  ";
		  
		   $examhquery1=$this->db->query($queryrightcount); 
		   $exrightquestion=$examhquery1->row();
		   // var_dump($resultexam);
		    $totalright=$exrightquestion->totalright;
			$calper=($totalright/$totalquestion)*100;
			$ass_marks=number_format($calper);	
			if($year_id==1)
			{
				if($ass_marks >99)
				{
					$promote_year=$year_id+1;
					$congtext='Excelent';
				}
				else
				{
					$promote_year=$year_id;
					$congtext='Congratulations';
				}
			}
			else if($year_id==2)
			{
				if($ass_marks < 80)
				{
					$promote_year=$year_id-1;
					$congtext='Congratulations';
				}
				else if($ass_marks >= 80 && $ass_marks <= 99)
				{
					$promote_year=$year_id;
					$congtext='Congratulations';
				}
				
				else if($ass_marks >99)
				{
					$promote_year=$year_id+1;
					$congtext='Excelent';
				}
				
			}
			else if($year_id==3)
			{
				if($ass_marks <= 49)
				{
					$promote_year=$year_id-2;
					$congtext='Congratulations';
				}
				else if($ass_marks >= 50 && $ass_marks <= 79)
				{
					$promote_year=$year_id-1;
					$congtext='Congratulations';
				}
				else if($ass_marks >= 80 && $ass_marks <= 99)
				{
					$promote_year=$year_id;
					$congtext='Congratulations';
				}
				
				else if($ass_marks >99)
				{
					$promote_year=$year_id+1;
					$congtext='Excelent';
				}
			}
			else if($year_id==4)
			{
				if($ass_marks <= 49)
				{
					$promote_year=$year_id-2;
					$congtext='Congratulations';
				}
				else if($ass_marks >= 50 && $ass_marks <= 79)
				{
					$promote_year=$year_id-1;
					$congtext='Congratulations';
				}
				else if($ass_marks >= 80 && $ass_marks <= 99)
				{
					$promote_year=$year_id;
					$congtext='Congratulations';
				}
				
				else if($ass_marks >99)
				{
					$promote_year=$year_id+1;
					$congtext='Excelent';
				}
			}
			else if($year_id==5)
			{
				if($ass_marks <= 49)
				{
					$promote_year=$year_id-2;
					$congtext='Congratulations';
				}
				else if($ass_marks >= 50 && $ass_marks <= 79)
				{
					$promote_year=$year_id-1;
					$congtext='Congratulations';
				}
				else if($ass_marks >= 80 && $ass_marks <= 99)
				{
					$promote_year=$year_id;
					$congtext='Congratulations';
				}
				
				else if($ass_marks >99)
				{
					$promote_year=$year_id+1;
					$congtext='Excelent';
				}
			}
			else if($year_id==6)
			{
				if($ass_marks <= 49)
				{
					$promote_year=$year_id-2;
					$congtext='Congratulations';
				}
				else if($ass_marks >= 50 && $ass_marks <= 79)
				{
					$promote_year=$year_id-1;
					$congtext='Congratulations';
				}
				else if($ass_marks >= 80 && $ass_marks <= 99)
				{
					$promote_year=$year_id;
					$congtext='Congratulations';
				}
				
				else if($ass_marks >99)
				{
					$promote_year=$year_id+1;
					$congtext='Excelent';
				}
			}
			else if($year_id==7)
			{
				if($ass_marks <= 49)
				{
					$promote_year=$year_id-2;
					$congtext='Congratulations';
				}
				else if($ass_marks >= 50 && $ass_marks <= 79)
				{
					$promote_year=$year_id-1;
					$congtext='Congratulations';
				}
				else if($ass_marks >= 80 && $ass_marks <= 99)
				{
					$promote_year=$year_id;
					$congtext='Congratulations';
				}
				
				else if($ass_marks >99)
				{
					$promote_year=$year_id+1;
					$congtext='Excelent';
				}
			}
			else if($year_id==8)
			{
				if($ass_marks <= 49)
				{
					$promote_year=$year_id-2;
					$congtext='Congratulations';
				}
				else if($ass_marks >= 50 && $ass_marks <= 79)
				{
					$promote_year=$year_id-1;
					$congtext='Congratulations';
				}
				else if($ass_marks >= 80 && $ass_marks <= 99)
				{
					$promote_year=$year_id;
					$congtext='Congratulations';
				}
				
				else if($ass_marks >99)
				{
					$promote_year=$year_id+1;
					$congtext='Excelent';
				}
			}
			else if($year_id==9)
			{
				if($ass_marks <= 49)
				{
					$promote_year=$year_id-2;
					$congtext='Congratulations';
				}
				else if($ass_marks >= 50 && $ass_marks <= 79)
				{
					$promote_year=$year_id-1;
					$congtext='Congratulations';
				}
				else if($ass_marks >= 80 && $ass_marks <= 99)
				{
					$promote_year=$year_id;
					$congtext='Congratulations';
				}
				
				else if($ass_marks >99)
				{
					$promote_year=$year_id+1;
					$congtext='Excelent';
				}
			}
			else if($year_id==10)
			{
				if($ass_marks <= 49)
				{
					$promote_year=$year_id-2;
					$congtext='Congratulations';
				}
				else if($ass_marks >= 50 && $ass_marks <= 79)
				{
					$promote_year=$year_id-1;
					$congtext='Congratulations';
				}
				else if($ass_marks >= 80 && $ass_marks <= 99)
				{
					$promote_year=$year_id;
					$congtext='Congratulations';
				}
				
				else if($ass_marks >99)
				{
					$promote_year=$year_id+1;
					$congtext='Excelent';
				}
			}
			else if($year_id==11)
			{
				if($ass_marks <= 49)
				{
					$promote_year=$year_id-2;
					$congtext='Congratulations';
				}
				else if($ass_marks >= 50 && $ass_marks <= 79)
				{
					$promote_year=$year_id-1;
					$congtext='Congratulations';
				}
				else if($ass_marks >= 80 && $ass_marks <= 99)
				{
					$promote_year=$year_id;
					$congtext='Congratulations';
				}
				
				else if($ass_marks >99)
				{
					$promote_year=$year_id+1;
					$congtext='Excelent';
				}
			}
			else if($year_id==12)
			{
				if($ass_marks <= 49)
				{
					$promote_year=$year_id-2;
					$congtext='Congratulations';
				}
				else if($ass_marks >= 50 && $ass_marks <= 79)
				{
					$promote_year=$year_id-1;
					$congtext='Congratulations';
				}
				else if($ass_marks >= 80 && $ass_marks <= 99)
				{
					$promote_year=$year_id;
					$congtext='Congratulations';
				}
				
				else if($ass_marks >99)
				{
					$promote_year=$year_id+1;
					$congtext='Excelent';
				}
			}
			else if($year_id==13)
			{
				if($ass_marks <= 49)
				{
					$promote_year=$year_id-2;
					$congtext='Congratulations';
				}
				else if($ass_marks >= 50 && $ass_marks <= 79)
				{
					$promote_year=$year_id-1;
					$congtext='Congratulations';
				}
				else if($ass_marks >= 80 && $ass_marks <= 100)
				{
					$promote_year=$year_id;
					$congtext='Excelent';
				}
				
				
			}
				
			?>
			<h3><?php echo $congtext;?> you are eligible to take admission in <?php echo $this->classes_model->GetClassName($promote_year);?> </h3>
			<p>Total Questions: <?php echo $totalquestion;?></p>
			<p>Scores: <?php echo $totalright.'/'.$totalquestion;?></p>
			<p>Percentage(%): <?php echo number_format($calper);?>%</p>
			<?php
			if($promote_year!="" && $promote_year!=null)
			{
				$query_ques=$this->db->query("select * from student_promoted  where exam_id='".$exam_id."' ");
				$ques_result=$query_ques->num_rows();
				if($ques_result > 0)
				{
				}
				else
				{
						$createdate1=date("Y-m-d H:i:s");
						$prom_data=array(
							
							'user_id'=>$this->session->userdata('user_id'),
							'exam_id'=>$exam_id,
							'reg_year'=>$year_id,
							'promote_year'=>$promote_year,
							'pay_status'=>'pending',
							'promote_date'=>$createdate1
							);
						$proid=$this->exam_model->Save_Promoted_Assessment($prom_data);	
				}
			}
			?>
			<p><a href="<?php echo BASE_URL.'book-center-class/'.$promote_year;?>" class="btn-mn btn-3 btn-3e button-org aat-btn">Join the class</a><p>
			<?php
			//}
		}
		?>
											
		<form  name="myForm" id="assemment"  method="post" action="" >	
			<?php
			if($completed !=1){
				?>
			<div style="float:right;" id="timer"><p id="showtimer" style="font-weight:bold: color:green;"></p></div>
			<?php
			}
			?>

<script>
// Set the date we're counting down to
var d1 = new Date (),
    d2 = new Date ( d1 );
d2.setMinutes ( d1.getMinutes() + 30 );

var countDownDate = d2.getTime();

// Update the count down every 1 second
var x = setInterval(function() {

  // Get todays date and time
  var now = new Date().getTime();

  // Find the distance between now and the count down date
  var distance = countDownDate - now;

  // Time calculations for days, hours, minutes and seconds
  var days = Math.floor(distance / (1000 * 60 * 60 * 24));
  var hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
  var minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
  var seconds = Math.floor((distance % (1000 * 60)) / 1000);

  // Display the result in the element with id="demo"
/*  document.getElementById("demo").innerHTML = days + "d " + hours + "h "
  + minutes + "m " + seconds + "s ";*/
    document.getElementById("showtimer").innerHTML = hours + "H: "  + minutes + "m: " + seconds + "s ";

  // If the count down is finished, write some text
  if (distance < 0) {
    clearInterval(x);
    document.getElementById("showtimer").innerHTML = "Time is Over!";
  }
}, 1000);
</script>
			<div id="question_list">
			
			<?php 

			if($Questionlist != null && $Questionlist != "")
			{
				
			  foreach($Questionlist as $result)
			  {
			
				$query_ques=$this->db->query("select * from manage_question_".$result->ass_year_id." where ques_id='".$result->ass_question."' ");
				$ques_result=$query_ques->row();
				/*echo '<pre>';
				var_dump($ques_result);
				echo '</pre>';
				*/
				$ques_type=explode(',',$ques_result->ques_type);
				
					if(in_array(1,$ques_type)){  
					if(in_array(26,$ques_type))
					{
					$QuesDecoded = base64_decode($ques_result->ques_name); 
					echo $QuesDecoded;
					}else{
					echo '<p>'.$ques_result->ques_name.'</p>';
					}
					echo '<br>';
					
				
					$answers=$this->questions_model->get_answers1($result->ass_year_id,$ques_result->ques_id);
					
					
					foreach($answers as $answer){
					
					if($answer->has_image==1){
					echo '<a id ="a1" class="quiz-btn" href="javascript:alert(default functionality)"><input name="answerid" value="'.$answer->ans_id.'" name="rb" type="radio" id="rb1"><label><img src="'.$answer->ans_name.'" /></label></a>&nbsp;&nbsp;&nbsp;';	
					
					}
					else{
					echo '<a id ="a1" class="quiz-btn" href="javascript:alert(default functionality)"><input name="answerid" value="'.$answer->ans_id.'" name="rb" type="radio" id="rb1"><label>'.$answer->ans_name.'</label></a>&nbsp;&nbsp;&nbsp;';
					}
					
					}
					
				}
				elseif(in_array(3,$ques_type)){ 
					
					echo $ques_result->ques_name;
					echo '<br>';
					$imgs=$this->main_model->getall('ques_img','ques_id',$ques_result->ques_id);

					echo '<br>';
					$answers=$this->questions_model->get_answers1($result->ass_year_id,$ques_result->ques_id);
					foreach($answers as $answer){
						
					echo '<a id="a1" class="quiz-btn" href="javascript:alert(default functionality)"><input name="answerid" value="'.$answer->ans_id.'" name="rb" type="radio" id="rb1"><label>'.$answer->ans_name.'</label></a>&nbsp;&nbsp;&nbsp;';
					}
					
				
				}
				elseif(in_array(4,$ques_type)){ 
					
					echo $ques_result->ques_name;
					echo '<br>';
					$imgs=$this->main_model->getall('ques_img','ques_id',$ques_result->ques_id);

					foreach($imgs as $img){

					echo '<img src="/assets/uploads/ans/'.$img->img.'"/>';
					}
					echo '<br>';
					$answers=$this->questions_model->get_answers1($result->ass_year_id,$ques_result->ques_id);
					foreach($answers as $answer){
						
					echo '<a id ="a1" class="quiz-btn" href="javascript:alert(default functionality)"><input name="answerid" value="'.$answer->ans_id.'" name="rb" type="radio" id="rb1"><label>'.$answer->ans_name.'</label></a>&nbsp;&nbsp;&nbsp;';
					}
					
				
				}
					elseif(in_array(5,$ques_type))
						{
					echo $ques_result->ques_name;
					echo '<br>';
					$imgs=$this->main_model->getall('ques_img','ques_id',$ques_result->ques_id);

				
					echo '<br>';
					
					$answers=$this->questions_model->get_answers1($result->ass_year_id,$ques_result->ques_id);
					foreach($answers as $answer){
					
					if($answer->has_image==1){
						
					
						
					echo '<label class="anslabel"><input name="answerid" value="'.$answer->ans_id.'" name="rb" type="radio" id="rb1"><img src="/assets/uploads/ans/'.$answer->ans_name.'"/></label>&nbsp;&nbsp;&nbsp;';
					}
						
					}
					
				}
					elseif(in_array(6,$ques_type))
						{
					echo $ques_result->ques_name;
					echo '<br>';
					$imgs=$this->main_model->getall('ques_img','ques_id',$ques_result->ques_id);
					foreach($imgs as $img){
					for($i=0;$i<$img->repeat;$i++){
					echo '<img src="/assets/uploads/ans/'.$img->img.'"/>';
					}
					echo '<br>';
					}
				
					echo '<br>';
					
					$answers=$this->questions_model->get_answers1($result->ass_year_id,$ques_result->ques_id);
					foreach($answers as $answer){
					
					echo '<label class="anslabel"><input name="answerid" value="'.$answer->ans_id.'" name="rb" type="radio" id="rb1"><div>'.$answer->ans_name.'</div></label>&nbsp;&nbsp;&nbsp;';
						
					}
					
				}
				
				elseif(in_array(25,$ques_type)){ 
					
					echo $ques_result->ques_name;
					echo '<br>';
					$imgs=$this->main_model->getall('ques_img','ques_id',$ques_result->ques_id);

					
					echo '<br>';
					$answers=$this->questions_model->get_answers1($result->ass_year_id,$ques_result->ques_id);
					foreach($answers as $answer){
						
					echo '<a id ="a1" class="quiz-btn" href="javascript:alert(default functionality)"><input name="answerid" value="'.$answer->ans_id.'" name="rb" type="radio" id="rb1"><label>'.$answer->ans_name.'</label></a>&nbsp;&nbsp;&nbsp;';
					}
					
				
				}
				
					elseif(in_array(22,$ques_type)){ 

					if(in_array(26,$ques_type)){
						$QuesDecoded = base64_decode($ques_result->ques_name); 
						}
						else{$QuesDecoded =$ques_result->ques_name; }
						echo $QuesDecoded;
					$imgs=$this->main_model->getall('ques_img','ques_id',$ques_result->ques_id);

					
					echo '<br>';
					$answers=$this->questions_model->get_answers1($result->ass_year_id,$ques_result->ques_id);
					foreach($answers as $answer){
						
					echo '<a id ="a1" class="quiz-btn" href="javascript:alert(default functionality)"><input name="answerid" value="'.$answer->ans_id.'" name="rb" type="radio" id="rb1"><label>'.$answer->ans_name.'</label></a>&nbsp;&nbsp;&nbsp;';
					}
					
				
				}
				
				elseif(in_array(26,$ques_type)){ 
					$QuesDecoded = base64_decode($ques_result->ques_name); 
					echo $QuesDecoded;
					echo '<br>';
					$answers=$this->questions_model->get_answers1($result->ass_year_id,$ques_result->ques_id);
					foreach($answers as $answer){
						echo $answer->ans_name;
				
					}
					
				
				}
				else
				{
						echo '<p>'.$ques_result->ques_name.'</p>';
						echo '<br>';
						$answers=$this->questions_model->get_answers1($result->ass_year_id,$ques_result->ques_id);
						foreach($answers as $answer){

						echo $answer->ans_name;
						}
				}
				?>
				<input type="hidden" name="ass_year_id" value="<?php echo $result->ass_year_id;?>"/>
				<?php
				
				}
				?>
				<div>
					<input type="hidden" name="questionid" value="<?php echo $ques_result->ques_id;?>"/>
					<input type="hidden" name="action" value="submitanswer"/>	
					<input type="hidden" name="ques_type" value="<?php echo $ques_result->ques_type;?>"/>
					<input type="hidden" name="ques_class" value="<?php echo $ques_result->ques_class;?>"/>
					<input type="hidden" name="year_id" value="<?php echo $year_id;?>"/>
					</div></div>	
				<input type="submit" name="submit" value="Submit" id="btnassemment">
				
				<?php }
				else
				{
if(isset($completed) && $completed!=1){
			?>
				  No Question found
				<?php 
}
				} ?>
				
			
		</form>

</div>

 </div>
 </div>
 </section>
 <style>
 .anslabel > input{ /* HIDE RADIO */
  visibility: hidden; /* Makes input not-clickable */
  position: absolute; /* Remove input from document flow */
}
.anslabel > input + img{ /* IMAGE STYLES */
  cursor:pointer;
  border:2px solid transparent;
  border-radius:10px;
  padding:0px;
}
.anslabel > input:checked + img{ /* (RADIO CHECKED) IMAGE STYLES */
  border:2px solid #1278a6;
   padding:0px;
}

.anslabel > input + div{ /* IMAGE STYLES */
  cursor:pointer;
  border:2px solid #00a7dc;
  border-radius:10px;
  padding:10px;
}
.anslabel > input:checked + div{ /* (RADIO CHECKED) IMAGE STYLES */
  border:2px solid #1278a6;
   padding:10px;
}
 </style>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script>  
 <script>

 $('#btnassemment').click(function(event) {
       form = $("#assemment").serialize();

     $.ajax({
       type: "POST",
       url: "<?php echo site_url('ajaxcall/ajax_assessment'); ?>",
       data: form,

       success: function(data){
          // alert('Successful!'); //Unterminated String literal fixed
		    $('#question_list').html(data);
       }

     });
     event.preventDefault();
     return false;  //stop the actual form post !important!

  });
</script>
 
 <script>
  $("#a1").click(function(event) {
    this.removeAttribute("href");            
    anchorClicked("a1");
  });
  
  $( document ).ready(function() {
    $("#infor").delay(3000).fadeOut("slow");
});

function validateForm() {
    var x = document.forms["myForm"]["answerid"].value;
	
    if (x == "") {
        var r = confirm("You did not complete the question.Are you sure you want to submit?!");
		if (r == true) {
			return true;
		} else {
			return false;
		}
    }
}
 </script>


   
   
   
   
    
 <!-- Page Content End -->
<?php include('footer.php'); ?>