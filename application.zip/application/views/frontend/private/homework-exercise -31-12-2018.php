<?php include('header.php'); ?>

<section id="title-inner" class="bgcolor-text">
<canvas id="demo-canvas"></canvas>
<div class="container">
<div class="text-tit">
<h1>
<span>Homework Exercise</span>
</h1>
</div>

</div>
</section>

<!-- Page Content inner -->

 <section class="about_content content-text page-homework-exercise space-75">
 <div class="container">
 <div class="row">
 
 <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
   <?php
  
   $query_ord=$this->db->query("select plan_id,order_date,order_week from orders where userid = '".$this->session->userdata('user_id')."'  and order_status='active' and pay_status='confirm' order by orderid desc"); 
				$num_ord= $query_ord->num_rows();
				if($num_ord > 0){

$query_ordweek=$this->db->query("select ordweek_weekid from order_weeks where ordweek_userid = '".$this->session->userdata('user_id')."'  
	 and ordweek_yearid='".$year_id."' and ordweek_termid='".$term_id."' 
	 and ordweek_weekid in (".$weeklist.") and ordweek_paystatus='confirm' "); 
	 $num_ordweek= $query_ordweek->num_rows();
		$userweeklist=array();
		if($num_ordweek > 0)
		{
			$resultweeks=$query_ordweek->result();
			
			foreach($resultweeks as $weeknumber)
			{
				array_push($userweeklist,$weeknumber->ordweek_weekid);
			}
		}
		
				
   //if($planactive=='yes')
   //{
?>	   
   <div class="tab-content">
    <?php 
      if($SylList1 != null && $SylList1 != ""){
			global $order_arr;
			$tid=0;$wid=0;
									?>
        <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
          <h2 class="blue-title">Term <?php echo $term_id;?></h2>
          <div class="row">
            <?php 
			$aveageweek=0;
			$userweek=$userweek;
			   /*  echo '<pre>';
			var_dump($SylList1);
			echo '</pre>';   */
			$countweek=1;
			foreach($SylList1 as $result){
		$sql_term=$this->db->query("select * from master_terms where term_id = '".$term_id."' "); 
	$term=$sql_term->row();
	
	$sql_dt1=$this->db->query("select * from master_skill where skill_id = '".$result->skill_id."' "); 
	$skl_dtl=$sql_dt1->row();
	
	$sql_syllab=$this->db->query("select * from master_syllabus where skill_id = '".$result->skill_id."' and class_id='".$year_id."' and term_id='".$term_id."'"); 
	$row_syllab=$sql_syllab->row();
	
	$query=$this->db->query('select * from syllabus_week_subskill where skill_id = "'.$result->skill_id.'" and week_id in ('.$weeklist.')'); 
	 $ct2= $query->num_rows();
	$comp2=0;
if($countweek< 3 && $ct2 > 0)
{
	
if(in_array($result->week_id,$userweeklist))
{
	
	?>
            <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
              <div class="syllabus-sec">
                <h3><?php echo $order_arr[$row_syllab->skill_order].'. '.$skl_dtl->skill_name;?></h3>
                <div class="row">
                  <?php 

foreach($query->result() as $ress){
	
	$subskl_dtl= $this->main_model->get_detail('master_skill','skill_id',$ress->subskill_id);
	$comp2++;
	?>
                  <?php if($wid!=$ress->week_id || $comp2==1){
	
	$query1=$this->db->query('select count(*) as "ct" from syllabus_week_subskill where week_id="'.$userweek.'" and term_id="'.$ress->term_id.'" and year_id="'.$ress->year_id.'"');
	$res1=$query1->row();
	$ct= $res1->ct;
	
	$comp=0;

	$week_dtl= $this->main_model->get_detail('master_weeks','week_id',$ress->week_id);
	$sql_goal=$this->db->query('select * from master_goal where week_id="'.$ress->week_id.'" and term_id="'.$term_id.'" and year_id="'.$year_id.'"');
	$goal= $sql_goal->row();
	$color_class=explode(',' ,$ress->week_id);
	$color_class=$color_class[0];
	$aveageweek ++;

	?>
                  <div class="col-xs-12 col-sm-12 col-md-4 col-lg-4">
                    <div class="box-syllabus">
                      <div class="text-content">
                        <ul>
                          <li>
                            <div class="row">
                              <div class="col-xs-8 col-sm-8 col-md-6 col-lg-8 col-8"><strong><?php echo $goal->goal_name;?></strong></div>
                              <div class="col-xs-4 col-sm-4 col-md-6 col-lg-4 col-4">
                                <h4 class="cyan_bg color-<?php echo $color_class;?>"><?php echo $week_dtl->week_name;?>
								<?php
								if($row_notes->notes_file!='')
								{
									echo '  <a href="'.base_url('assets/uploads/notes/'.$row_notes->notes_file).'">Notes</a>';
								}
								?></h4> 
                              </div>
                            </div>
                          </li>
                          <?php } $comp++; ?>
                     <a href="<?php echo base_url().'homework/'.$subskl_dtl->skill_slug;?>">
                   <li><strong><?php echo $order_arr[$row_syllab->skill_order].'.'.$ress->subskill_order;?></strong> <?php echo $subskl_dtl->skill_name;?></li>
                          </a>
                          <?php if(($ct==$comp) || ($ct2==$comp2)){?>
                        </ul>
                      </div>
                    </div>
                  </div>
                  <?php } $wid=$ress->week_id;?>
                  <?php } ?>
                </div>
              </div>
            </div>
            <?PHP 
}
			}
			$countweek++;
			} ?>
          </div>
        </div>
        <?PHP } 
   
   ?>
   </div>
   <?php
   } 
   else
   { 
	if($nobuyplan=='1')
	{	
	 
	   echo 'Please make payment of current week.';
	}
	else
	{
		echo '<p style="color:red;">Your Plan has been expired,please make payment of current week.</p>
		<p><a href="'.BASE_URL.'membership-plan" style="font-weight:bold;">Pay Now</p><br/>
		';
	}
   }
   ?>
 <!--<div class="table-responsive">
 <table class="table table-striped table-light">
  <thead>
    <tr>
      <th scope="col">Study Week No.</th>
      <th scope="col">Topic</th>
      <th scope="col">Subject Exercises</th>
      <th scope="col">Homework Score</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th scope="row"># <?php echo $week_id;?>. (<?php echo $yearstart. ' - '. $currentdate;?>)</th>
      <td><?php
	  if($yeargoal)
	  {
		 
			  echo $yeargoal->goal_name;
		  
		  
	  }
	  
	  ?></td>
      <td>  <ul>
	  <?php
	$sorder=1;
	  $query=$this->db->query("select * from syllabus_week_subskill where week_id='".$week_id."' and term_id='".$term_id."' and year_id='".$year_id."' order by subskill_order asc"); 
	  foreach($query->result() as $ress){
		  $subskl_dtl= $this->main_model->get_detail('master_skill','skill_id',$ress->subskill_id);
	  ?>
	  <a href="<?php echo base_url().strtolower($year_slug).'/'.$subskl_dtl->skill_slug;?>"><li><strong><?php //echo $order_arr[$sorder].'.'.$sorder;?></strong> <?php echo $subskl_dtl->skill_name;?></li></a>
	  <?php
	  $sorder++;
	  }
	  ?>
	  </ul>
	
</td>
      <td>
	  <ul>
	  <?php
	  $userid=$this->session->userdata('user_id');
	  $loginyear=$this->session->userdata('loginyear');
	  $totalquestion="";
	  $totalright="";
	  $examhquery="";
	  $examhquery1="";
	  $examquery=$this->db->query("select * from student_exam where year_id='".$loginyear."' and user_id='".$userid."' and exam_status='pass' order by term_id asc"); 
	  foreach($examquery->result() as $resultexam){
		  echo '<li><p><strong>Term-'.$resultexam->term_id.' Results</strong></p>';
		   $examhquery=$this->db->query("select count(*) as totalquestion from sexam_history where exam_id='".$resultexam->exam_id."' "); 
		   $ehistoryrow=$examhquery->row();
		   $totalquestion=$ehistoryrow->totalquestion;
		   $queryrightcount="select count(*) as totalright from sexam_history where exam_id='".$resultexam->exam_id."' and answer_status='true'  ";
		  
		   $examhquery1=$this->db->query($queryrightcount); 
		   $exrightquestion=$examhquery1->row();
		  // var_dump($resultexam);
		    $totalright=$exrightquestion->totalright;
		  echo '<p>'.$totalright.'/'.$totalquestion;
		  echo '</li>';
	  }
		  ?>
		  
		  
	  </ul>
	  </td>
    </tr>
    
 <?php
if($week_id > 1)
{
	$preweek=$week_id-1;
	$prevdate=date('m/d/Y',strtotime ( '-1 week' , strtotime ( $currentdate ) ));
	?>	
<tr>
      <th scope="row"># <?php echo $preweek;?>. (<?php echo $yearstart. ' - '. $prevdate;?>)</th>
      <td><?php
	  if($yeargoal2)
	  {
		 
			  echo $yeargoal2->goal_name;
		  
		  
	  }
	  
	  ?></td>
      <td>  <ul>
	  <?php
	$sorder1=1;
	
	  $query1=$this->db->query("select * from syllabus_week_subskill where week_id='".$preweek."' and term_id='".$term_id."' and year_id='".$year_id."' order by subskill_order asc"); 
	  foreach($query1->result() as $ress1){
		  $subskl_dtl2= $this->main_model->get_detail('master_skill','skill_id',$ress1->subskill_id);
	  ?>
	  <a href="<?php echo base_url().strtolower($year_slug).'/'.$subskl_dtl2->skill_slug;?>"><li><strong><?php //echo $order_arr[$sorder].'.'.$sorder;?></strong> <?php echo $subskl_dtl2->skill_name;?></li></a>
	  <?php
	  $sorder1++;
	  }
	  ?>
	  </ul>
	
</td>
      <td></td>
    </tr>
  <?php
}
?>  
    
  </tbody>
</table>
 </div>-->


 </div>
 
 
 
 
 </div>
 </div>
 </section>
 
 
   
   
   
   
   
   
    
 <!-- Page Content End -->
<?php include('footer.php'); ?>