<?php include('header.php'); ?>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.2/jquery.min.js"></script>

<section id="title-inner" class="bgcolor-text">
<canvas id="demo-canvas"></canvas>
<div class="container">
<div class="text-tit">
<h1>
<span>Choose Week</span>
</h1>
</div>

</div>
</section>


<!-- Page Content inner -->
<div  class="about_content login-page forgot-password change-password membership-plan content-text space-75">

<div class="container">
<?php
if($class_schedule==0){

?>
<div class="row">
<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">


No Class Schedule



</div>
</div>
<?php
}else{
?>
<div class="row">

<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12"> 



<?php if ($error!=''){ ?>
											<div class="col-md-12">
												<div class="alert alert-danger" role="alert">
													<?= $error ?>
												</div>
											</div>
										<?php } ?>
										 <?php 
						if($this->session->flashdata('success_msg') != null && $this->session->flashdata('success_msg') != "")
								{ 
								?>
								
									<div class="col-md-12">
										<div style="margin-top:18px;" class="alert alert-danger " >
											<?php echo $this->session->flashdata('success_msg');?>
										</div>
									</div>
								
								<?php 
							} 
							?>	
<?php
if($planlist)
{
	$userid=$this->session->userdata('user_id');
	
	foreach($planlist as $rowplan)
	{
		if($rowplan->planid==1)
		{
			 if($num_chkord > 0)
			  {
				  $actionpage='renew-payment';
			  }
			  else
			  {
				  $actionpage='paynow';
			  }
?>	
<?= form_open(base_url().$actionpage,array('name'=>'cmxform','id'=>'signupForm','method'=>'post')) ?>	



	<div class="box-syllabus box-week-charge">
	<div class="text-content">

	  <h2><?php echo $rowplan->plan_name;?> Charge $<?php echo number_format($rowplan->plan_price);?></h2>

	 
	  
	  <!-- <li>
	  <?php
	  if($num_chkord > 0)
	  {
		  
?>
<a href="<?php echo  base_url();?>renew-payment/<?php echo $rowplan->planid;?>/<?php echo $payyear;?>" class="button">Buy Now</a>
<?php
	  }
else
{
?>	
	  <a href="<?php echo  base_url();?>paynow/<?php echo $rowplan->planid;?>/<?php echo $payyear;?>" class="button">Buy Now</a>
	  <?php
}
?>
	  <li> -->

	  <input type="hidden" name="planid" value="<?php echo $rowplan->planid;?>" />
	  <?php
	  $term_1_week=1;
	  $term_2_week=1;
	  $term_3_week=1;
	  $term_4_week=1;
	   if($userweek>10)
	   {
		   if($userweek>20)
			{
			if($userweek>30)
			{
			$limit=3;
			$term_4_week=$userweek-30;
			$first_term=4;
			}
			else{
				$limit=2;
				$term_3_week=$userweek-20;
				$first_term=3;
			}
			}
			else{
				$limit=1;
				$term_2_week=$userweek-10;
				$first_term=2;
			}
			}
		else{
			$limit=0;
			$term_1_week=$userweek-0;
			$first_term=1;
		}
		   
	   
	   $sql_terms=$this->db->query("select * from master_terms order by term_id limit ".$limit.",4"); 
	   $row_terms=$sql_terms->result();
	   foreach($row_terms as $termrow)
	   { 
		
		 ?>
	  	<div class="text-content"> 
		<h3><label class="switch"><input type="checkbox" id="select_all<?php echo $termrow->term_id;?>" name="term_id[]" value="<?php echo $termrow->term_id;?>" /><span class="slider round"></span></label>Term <?php echo $termrow->term_id;?> </h3>
		
		 <div class="row">
		 <?php
		 if($termrow->term_id==1){
			 $start_week=$term_1_week;
		 }
		 elseif($termrow->term_id==2){
			 $start_week=$term_2_week;
		 } 
		 elseif($termrow->term_id==3){
			 $start_week=$term_3_week;
		 } 
		 elseif($termrow->term_id==4){
			 $start_week=$term_4_week;
		 }
		 
		
		 for($week=$start_week;$week<=10;$week++)
		 {
			$query_ordweek=$this->db->query("select * from order_weeks  where ordweek_userid='".$userid."' 
				and ordweek_paystatus='confirm' and  ordweek_yearid='".$payyear."' 
				and  ordweek_termid='".$termrow->term_id."' and  ordweek_weekid='".$week."'");
			$num_ordweek=$query_ordweek->num_rows();
			
			if($num_ordweek > 0)
			{
				$rowweek=$query_ordweek->row();
			?>
		 <div class="col-xs-2 col-sm-2 col-md-2 col-lg-2 col-2" style="padding: 12px;
    margin: 15px;
    border: 1px solid #eee;">
		  <label class="switch"><span class=""><img src="<?= base_url('assets/images/planactive.png')?>" /></span></label> Week <?php echo $week;?> 
		  </div>
		  <?php
				}
				else
				{
					?>
		<div class="col-xs-2 col-sm-2 col-md-2 col-lg-2 col-2" style="padding: 12px;
    margin: 15px;
    border: 1px solid #eee;">
		   <label class="switch"><input class="checkbox<?php echo $termrow->term_id;?> week_chk" type="checkbox" name="week_id[<?php echo $termrow->term_id;?>][]" value="<?php echo $week;?>" /><span class="slider round"></span></label> Week <?php echo $week;?> 
		  </div>			
				<?php
				}	
		 }
		 ?>
		</div>
		
		</div>
		<script type="text/javascript">
$(document).ready(function(){
    $('#select_all<?php echo $termrow->term_id;?>').on('click',function(){
        if(this.checked){
            $('.checkbox<?php echo $termrow->term_id;?>').each(function(){
                this.checked = true;
            });
        }else{
             $('.checkbox<?php echo $termrow->term_id;?>').each(function(){
                this.checked = false;
            });
        }
    });
    
    $('.checkbox<?php echo $termrow->term_id;?>').on('click',function(){
        if($('.checkbox<?php echo $termrow->term_id;?>:checked').length == $('.checkbox<?php echo $termrow->term_id;?>').length){
            $('#select_all<?php echo $termrow->term_id;?>').prop('checked',true);
        }else{
            $('#select_all<?php echo $termrow->term_id;?>').prop('checked',false);
        }
    });
});
</script>
	<?php
	   }
?>	   
	</div>
	<input type="hidden" name="payyear" value="<?php echo $payyear;?>" />

	<div class="col-lg-12">
	<div class="input-field">
<label>Select Center</label>
<span class="input input--hoshi">
					<select name="reg_center" id="regcenter" >
                    <option value="">Select Center</option>
                    
                    <?php
					if($center_list)
					{
						foreach($center_list as $locations)
						{
							echo '<option value="'.$locations->center_id.'">'.$locations->center_city.'</option>';
						}
					}
					?>
                    </select>
				</span>
</div>

<div class="input-field">
<label>Select Day</label>
<span class="input input--hoshi">
<div id="select_day_cntr">

</div>

</span>
</div>

<div class="input-field">
<label>Select Time</label>
<span class="input input--hoshi">
<div id="select_day_time_cntr">

</div>

</span>
</div>


<div id="dayavailability"></div>
<div id="room_avail_cntr" style="color:green;font-weight:bold;"></div>
<div id="seatshow">


</div>
</div>
	
	
	
<div class="text-center"><button class="btn-mn btn-3 btn-3e button-org" style="display:none"  id="booknow">Enroll Now</button></div>
	</div>

</form>

<?php
		}
	}
}
?>

</div>

</div>
<?php
}
?>

</div>
</div>

 <!-- Page Content End -->
 <?php include('footer.php'); ?> 
 
 <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>

<script type="text/javascript">
jQuery(document).ready(function(){
	jQuery('#regcenter').change(function(){
		
	var week_id_term1=$('.checkbox1:checkbox:checked');
	var week_id_term2=$('.checkbox2:checkbox:checked');
	var week_id_term3=$('.checkbox3:checkbox:checked');
	var week_id_term4=$('.checkbox4:checkbox:checked');
	
	var arr = [];
	
	$(week_id_term1).each(function () {
		arr.push([1, $(this).val()]);
	});
	
	$(week_id_term2).each(function () {
		arr.push([2, $(this).val()]);
	});
	$(week_id_term3).each(function () {
		arr.push([3, $(this).val()]);
	});
	$(week_id_term4).each(function () {
		arr.push([4, $(this).val()]);
	});
	
	console.log(arr);
	if(arr.length>0){
	
		 
	 
      var center_id=$('#regcenter').val();
	       jQuery.ajax({
                type : 'POST',
                url : '<?php echo BASE_URL.'ajaxcall/checkcenter_day';?>',
                data : {center_id:center_id,week_term:arr,year_id:<?php echo $payyear;?>,userweek:<?php echo $userweek;?>,first_term:<?php echo $first_term;?>}
				,	
        success: function(result){
		   if(result!="") 
		   { 
				jQuery( "#select_day_cntr" ).html(result);
				 jQuery( "#select_day_time_cntr" ).html('');
			   jQuery( "#room_avail_cntr" ).html('');
			   jQuery( "#dayavailability" ).html('');
			   jQuery( "#booknow" ).hide('');
			}
		   else
		   {
			   jQuery( "#select_day_cntr" ).html('');
			   jQuery( "#select_day_time_cntr" ).html('');
			   jQuery( "#room_avail_cntr" ).html('');
			   jQuery( "#booknow" ).hide('');
			   jQuery( "#dayavailability" ).html('<p style="color:red;font-weight:bold;">No class schedule for this center please choice another center!.</p>');
			    		  
		   }
		   
        }


    });
	}
	else{ alert("Please select week")}
    });    

	
	  jQuery('#regcenter1').change(function(){
		
      var center_id=$('#regcenter').val();
	  //alert(center_id);
            jQuery.ajax({
                type : 'POST',
                url : '<?php echo BASE_URL.'ajaxcall/checkcenter_seats';?>',
                data : {center_id:center_id,year_id:<?php echo $payyear;?>}
				,	
        success: function(result){
		   if(result > 1) 
		   { 
			//jQuery( "#seatshow" ).html('<p style="color:green;font-weight:bold;">Avaliable seats is '+result+'</p>');
			jQuery( "#seatshow" ).html('<p style="color:green;font-weight:bold;">Seat is available</p>');
			 jQuery( "#booknow" ).show();
		   }
		   else if(result ==1){
			  jQuery( "#seatshow" ).html('<p style="color:green;font-weight:bold;">Limited seats available</p>');
			 jQuery( "#booknow" ).show();
		   }
		   else
		   {
			   jQuery( "#seatshow" ).html('<p style="color:red;font-weight:bold;">No seat Avaliable in this center please choice another center!.</p>');
			    jQuery( "#booknow" ).hide();
			  
		   }
		   // jQuery("#seatshow").val(result);
        }


    });
    });    

	
	
	
	
	});

</script>

<script type="text/javascript">
jQuery(document).ready(function(){

    jQuery('#reg_year').change(function(){
		
      var yearid=$('#reg_year').val();
            jQuery.ajax({
                type : 'POST',
                url : '<?php echo BASE_URL.'ajaxcall/yearsprice';?>',
                data : {yearid:yearid}
				,	
        success: function(result){
           // alert(result);
           jQuery( "#priceshow" ).html('Price $'+result);
		    jQuery("#yearprice").val(result);
        }


    });
    });    
});

</script>
