<?php
    /*Just for your server-side code*/
    header('Content-Type: text/html; charset=ISO-8859-1');
?>
<!-- Bootstrap core CSS -->
<link href="<?= base_url('assets/css/bootstrap.min.css')?>" rel="stylesheet">
<link href="<?= base_url('assets/css/font-awesome.min.css')?>" rel="stylesheet" />
<link href="<?= base_url('assets/css/font-awesome.css')?>" rel="stylesheet" />
<link href="<?= base_url('assets/css/animate.css')?>" rel="stylesheet" />
<link href="<?= base_url('assets/css/404.css')?>" rel="stylesheet" />
<link href="<?= base_url('assets/css/title.css')?>" rel="stylesheet" />
<link href="<?= base_url('assets/css/owl.carousel.min.css')?>" rel="stylesheet" />
<link href="<?= base_url('assets/css/owl.carousel.css')?>" rel="stylesheet" />
<script src="http://cdnjs.cloudflare.com/ajax/libs/modernizr/2.6.2/modernizr.min.js"></script>
<script src="<?= base_url('assets/js/wow.min.js')?>"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
<script src="<?php echo base_url().'assets/ckeditor2/ckeditor.js';?>"></script>
<!-- Custom styles for this template -->
<link href="<?= base_url('assets/style.css')?>" rel="stylesheet">
<?php  $img=ucfirst($year_dtl->class_slug.'_bg.jpg');?>
 

<section id="title-inner" class="bgcolor-text">
<canvas id="demo-canvas"></canvas>
<div class="container">
<div class="text-tit">
<h1>
<span>Class Room Exercise of <?php echo $subskill; ?></span>
</h1>
</div>

</div>
</section>

 <!-- Page Content inner -->
     <?php
					$sql_total_attempt=$this->db->query("select count(exam_id) as totalexam from  student_classexcerise  where user_id='".$this->session->userdata('user_id')."' and skill_id='".$skill_id."' 
							and year_id='".$year_id."'  ");
					$row_total_attempt=$sql_total_attempt->row();
				$total_attempt_exam=$row_total_attempt->totalexam;
				
				$sqlattques=$this->db->query("select count(hid) as totalattentquestion from student_classexcerise_history  where user_id='".$this->session->userdata('user_id')."' and skill_id='".$skill_id."' 
							and year_id='".$year_id."' and exam_id='".$lastexam."'  ");
				$row_attendq=$sqlattques->row();
				$totalattent=$row_attendq->totalattentquestion;
				
				$queryrightcount="select count(*) as totalright from student_classexcerise_history where user_id='".$this->session->userdata('user_id')."' and skill_id='".$skill_id."' 
					and year_id='".$year_id."'  and answer_status='true'  and exam_id='".$lastexam."'   ";
	
				$examhquery1=$this->db->query($queryrightcount); 
				$exrightquestion=$examhquery1->row();		 
				$totalright=$exrightquestion->totalright;
				if($totalattent){	
				$calper=($totalright/$totalattent)*100;
				}
				else{$calper='';}
				$textper_marks=number_format($calper);
						?>
 
 <section class="about_content content-text syllabus-page space-75 space-top-0 page-answer">
 <div class="container">
 <div class="row">
<!-- Bootstrap Tabs -->
	<div class="col-xs-12 col-sm-12 col-md-9 col-lg-9">
    <div class="tab-content space-top-75"> 
											

		<?php if(isset($correct) && $correct==1){	?>
		<div id="infor">
		<h3>Fantastic</h3>
		</div>
		<?php }	?>
											
		<form  name="myForm" id="myForm"  method="post" action="" onsubmit="return validateForm()">	
			
			
			<?php 
			if($ctest_completed!='1' && $total_attempt_exam < 5)
			{	
			if($Questionlist != null && $Questionlist != ""){
			?>
			<div id="question_list">
<?php			
					
					  foreach($Questionlist as $result){
						
						echo get_question($year_dtl->class_id,$result->ques_id);
						}
						?>	
					
			</div>
			
			<button  class="btn-mn btn-3 btn-3e button-org" id="btntestexam">Submit</button>
				
				<?php }
				else
				{ ?>
				  No Question found
				<?php }

			}
			else
			{
				if($textper_marks < 80)
				{
					//$testfail='<br><p style="color:red;">Your score is less than 80% so your exercise not valid.Please attempt exercise again to <a href="'.BASE_URL.'homework/'.$subskill.'?reh=1"><strong>Click Here</strong></a></p>';
				}
				else
				{
					$testfail='';
				}
				
			
				echo '<p>Your class exercise has been completed.</p>';
				echo $testfail;
				if($total_attempt_exam < 6)
				{
					echo '<p style="font-weight:bold;"><a href="'.BASE_URL.'classroom-exercise/'.$subskill.'?again=1">Attempt This Exercise Again</a></p>';
				}
				else
				{
					echo '<br><p style="color:red;">Your exercise limit has been over!.<p>';
				}
				?> <br><br>
					<a href="<?=BASE_URL.'classroom-exercise'?>" class="btn" style="background: #ed9c0f;height: 61px;width: 150px;color: white;font-size: 30px;">Back</a>
			<?php }				?>
				
				
		</form>

</div></div>
<?php

if($this->session->userdata('testagain')=='1' && $lastexam_status!='pending')
{
	$totalattent=0;
	$textper_marks=0;
}
else
{
	$totalattent=$totalattent;
	$textper_marks=$textper_marks;
}
?>
    <div class="col-xs-12 col-sm-12 col-md-3 col-lg-3">
    <div class="sidebar-play">
    <h3 class="org">Questions<br />answered</h3>
    <div class="number" id="textexamtotal"><?php echo $totalright.'/'.$totalattent;?></div>
   <!-- <h3>Time<br />elapsed</h3>
   
        <div class="timeing">
   <ul id="showtimer">	 </ul>

 </div>-->

   
    
    <h3 class="green">Smart<br />
    Score</h3>
    <div class="number" id="testexampersent"><?php echo $textper_marks;?>%</div>
    </div>
    </div>

 </div>
 </div>
 </section>
 <style>
 .anslabel > input{ /* HIDE RADIO */
  visibility: hidden; /* Makes input not-clickable */
  position: absolute; /* Remove input from document flow */
}
.anslabel > input + img{ /* IMAGE STYLES */
  cursor:pointer;
  border:2px solid transparent;
  border-radius:10px;
  padding:0px;
}
.anslabel > input:checked + img{ /* (RADIO CHECKED) IMAGE STYLES */
  border:2px solid #1278a6;
   padding:0px;
}

.anslabel > input + div{ /* IMAGE STYLES */
  cursor:pointer;
  border:2px solid #00a7dc;
  border-radius:10px;
  padding:10px;
}
.anslabel > input:checked + div{ /* (RADIO CHECKED) IMAGE STYLES */
  border:2px solid #1278a6;
   padding:10px;
}
 </style>
 
 <script>
  $("#a1").click(function(event) {
    this.removeAttribute("href");            
    anchorClicked("a1");
  });
  
  $( document ).ready(function() {
    $("#infor").delay(3000).fadeOut("slow");
});

function validateForm() {
    var x = document.forms["myForm"]["answerid"].value;
	
    if (x == "") {
        var r = confirm("You did not complete the question.Are you sure you want to submit?!");
		if (r == true) {
			return true;
		} else {
			return false;
		}
    }
}
 </script>

    
 <!-- Page Content End -->

<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script>  
 <script>

 $('#btntestexam').click(function(event) {
	 form = $("#myForm").serialize(); 
 if($('input[name="ques_type"]').val()){   
for (instance in CKEDITOR.instances) {
        CKEDITOR.instances[instance].updateElement();
    }
	
		// form = new FormData(this);

	var ques_type=$('input[name="ques_type"]').val();
	ques_type = "["+ques_type+"]";
	parsedText = JSON.parse(ques_type)

	if(parsedText[0]=='1'){
		var x = document.forms["myForm"]["answerid"].value;
		if (x==""){
		   return false;
		}
	}
	else if(parsedText[0]=='22'){
		var val = [];
		$("input[name='answerid[]']:checked").each( function (i) {
          val[i] = $(this).val();
        });
		if(val==""){
			return false;
		}
		
	}	
	else if(parsedText[0]=='26' || parsedText[0]=='32'){
		var x = document.forms["myForm"]["input1"].value;
		if (x==""){
		   return false;
		}
		
	  var atr = $("input[name='input1']").attr('type');
	  if(atr=='checkbox'){
		 var val = [];
		$("input[type='checkbox']:checked").each( function (i) {
          val[i] = $(this).val();
        });
		if(val==""){
			return false;
		}
	  }
	}
 }

     $.ajax({
       type: "POST",
       url: "<?php echo site_url('ajaxcall/ajax_classexcercise'); ?>",
       data: form,

       success: function(data){
          // alert('Successful!'); //Unterminated String literal fixed
		    $('#question_list').html(data);
       }

     });
     event.preventDefault();
     return false;  //stop the actual form post !important!

  });
</script>

<!-- Bootstrap core JavaScript --> 
<script src="<?= base_url('assets/js/jquery.min.js')?>"></script> 
<script src="<?= base_url('assets/js/bootstrap.bundle.min.js')?>"></script> 
<script src="<?= base_url('assets/js/main.js')?>"></script>
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1/jquery.min.js"></script>
<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
<script src="<?= base_url('assets/js/jquery.slicknav.js')?>"></script>
<script src="<?= base_url('assets/js/demo-2.js')?>"></script>

<script src="<?= base_url('assets/js/owl.carousel.js')?>"></script>
<script src="<?= base_url('assets/js/owl.carousel.min.js')?>"></script> 