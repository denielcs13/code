<?php include('header.php'); ?>
<?php
    /*Just for your server-side code*/
    header('Content-Type: text/html; charset=ISO-8859-1');
?>
<section id="title-inner" style="background-image:url(<?= base_url('assets/images/Kindergarten_bg.jpg')?>);">
<div id="large-header">   
<canvas id="demo-canvas"></canvas>
<div class="container">
<div class="text-tit">
 <div class="bb"></div>
<span class="lefttop-icon"></span>
<h1>
<span><?php echo $year_dtl->class_name; ?></span>
</h1>
<span class="rightbotm-icon"></span>
</div>



</div></div>





</section>

 <!-- Page Content inner -->
 
 
 <section class="about_content content-text syllabus-page space-75 explanation">
 <div class="container">
 <div class="row">
<!-- Bootstrap Tabs -->
	
<div class="tab-content">
			<?php if(isset($showtimer) && $showtimer!=''){
//echo '<h3>'.$showtimer.'</h3>';				
			}
			?>
											
	<form method="post" action="">	
		
		<h1>Sorry, incorrect...</h1>
		<h3>The correct answer is:</h3>
		<?php if(isset($timeover) && $timeover==1){	?>
		<div id="infor">
			<h3 style="color:red;"> Your Assessment Test Time is Over.</h3>
		</div>
		<?php
		}
		?>
		
		
		<?php
		if(isset($completed) && $completed==1){
			//if(isset($timeover) && $timeover!=1){
				$examhquery=$this->db->query("select count(*) as totalquestion from sasstest_history where exam_id='".$exam_id."' "); 
		   $ehistoryrow=$examhquery->row();
		   $totalquestion=$ehistoryrow->totalquestion;
		   $queryrightcount="select count(*) as totalright from sasstest_history where exam_id='".$exam_id."' and answer_status='true'  ";
		  
		   $examhquery1=$this->db->query($queryrightcount); 
		   $exrightquestion=$examhquery1->row();
		   // var_dump($resultexam);
		    $totalright=$exrightquestion->totalright;
			$calper=($totalright/$totalquestion)*100;
if($year_id==1)
			{
				if($ass_marks >99)
				{
					$promote_year=$year_id+1;
					$congtext='Excelent';
				}
				else
				{
					$promote_year=$year_id;
					$congtext='Congratulations';
				}
			}
			else if($year_id==2)
			{
				if($ass_marks < 80)
				{
					$promote_year=$year_id-1;
					$congtext='Congratulations';
				}
				else if($ass_marks >= 80 && $ass_marks <= 99)
				{
					$promote_year=$year_id;
					$congtext='Congratulations';
				}
				
				else if($ass_marks >99)
				{
					$promote_year=$year_id+1;
					$congtext='Excelent';
				}
				
			}
			else if($year_id==3)
			{
				if($ass_marks <= 49)
				{
					$promote_year=$year_id-2;
					$congtext='Congratulations';
				}
				else if($ass_marks >= 50 && $ass_marks <= 79)
				{
					$promote_year=$year_id-1;
					$congtext='Congratulations';
				}
				else if($ass_marks >= 80 && $ass_marks <= 99)
				{
					$promote_year=$year_id;
					$congtext='Congratulations';
				}
				
				else if($ass_marks >99)
				{
					$promote_year=$year_id+1;
					$congtext='Excelent';
				}
			}
			else if($year_id==4)
			{
				if($ass_marks <= 49)
				{
					$promote_year=$year_id-2;
					$congtext='Congratulations';
				}
				else if($ass_marks >= 50 && $ass_marks <= 79)
				{
					$promote_year=$year_id-1;
					$congtext='Congratulations';
				}
				else if($ass_marks >= 80 && $ass_marks <= 99)
				{
					$promote_year=$year_id;
					$congtext='Congratulations';
				}
				
				else if($ass_marks >99)
				{
					$promote_year=$year_id+1;
					$congtext='Excelent';
				}
			}
			else if($year_id==5)
			{
				if($ass_marks <= 49)
				{
					$promote_year=$year_id-2;
					$congtext='Congratulations';
				}
				else if($ass_marks >= 50 && $ass_marks <= 79)
				{
					$promote_year=$year_id-1;
					$congtext='Congratulations';
				}
				else if($ass_marks >= 80 && $ass_marks <= 99)
				{
					$promote_year=$year_id;
					$congtext='Congratulations';
				}
				
				else if($ass_marks >99)
				{
					$promote_year=$year_id+1;
					$congtext='Excelent';
				}
			}
			else if($year_id==6)
			{
				if($ass_marks <= 49)
				{
					$promote_year=$year_id-2;
					$congtext='Congratulations';
				}
				else if($ass_marks >= 50 && $ass_marks <= 79)
				{
					$promote_year=$year_id-1;
					$congtext='Congratulations';
				}
				else if($ass_marks >= 80 && $ass_marks <= 99)
				{
					$promote_year=$year_id;
					$congtext='Congratulations';
				}
				
				else if($ass_marks >99)
				{
					$promote_year=$year_id+1;
					$congtext='Excelent';
				}
			}
			else if($year_id==7)
			{
				if($ass_marks <= 49)
				{
					$promote_year=$year_id-2;
					$congtext='Congratulations';
				}
				else if($ass_marks >= 50 && $ass_marks <= 79)
				{
					$promote_year=$year_id-1;
					$congtext='Congratulations';
				}
				else if($ass_marks >= 80 && $ass_marks <= 99)
				{
					$promote_year=$year_id;
					$congtext='Congratulations';
				}
				
				else if($ass_marks >99)
				{
					$promote_year=$year_id+1;
					$congtext='Excelent';
				}
			}
			else if($year_id==8)
			{
				if($ass_marks <= 49)
				{
					$promote_year=$year_id-2;
					$congtext='Congratulations';
				}
				else if($ass_marks >= 50 && $ass_marks <= 79)
				{
					$promote_year=$year_id-1;
					$congtext='Congratulations';
				}
				else if($ass_marks >= 80 && $ass_marks <= 99)
				{
					$promote_year=$year_id;
					$congtext='Congratulations';
				}
				
				else if($ass_marks >99)
				{
					$promote_year=$year_id+1;
					$congtext='Excelent';
				}
			}
			else if($year_id==9)
			{
				if($ass_marks <= 49)
				{
					$promote_year=$year_id-2;
					$congtext='Congratulations';
				}
				else if($ass_marks >= 50 && $ass_marks <= 79)
				{
					$promote_year=$year_id-1;
					$congtext='Congratulations';
				}
				else if($ass_marks >= 80 && $ass_marks <= 99)
				{
					$promote_year=$year_id;
					$congtext='Congratulations';
				}
				
				else if($ass_marks >99)
				{
					$promote_year=$year_id+1;
					$congtext='Excelent';
				}
			}
			else if($year_id==10)
			{
				if($ass_marks <= 49)
				{
					$promote_year=$year_id-2;
					$congtext='Congratulations';
				}
				else if($ass_marks >= 50 && $ass_marks <= 79)
				{
					$promote_year=$year_id-1;
					$congtext='Congratulations';
				}
				else if($ass_marks >= 80 && $ass_marks <= 99)
				{
					$promote_year=$year_id;
					$congtext='Congratulations';
				}
				
				else if($ass_marks >99)
				{
					$promote_year=$year_id+1;
					$congtext='Excelent';
				}
			}
			else if($year_id==11)
			{
				if($ass_marks <= 49)
				{
					$promote_year=$year_id-2;
					$congtext='Congratulations';
				}
				else if($ass_marks >= 50 && $ass_marks <= 79)
				{
					$promote_year=$year_id-1;
					$congtext='Congratulations';
				}
				else if($ass_marks >= 80 && $ass_marks <= 99)
				{
					$promote_year=$year_id;
					$congtext='Congratulations';
				}
				
				else if($ass_marks >99)
				{
					$promote_year=$year_id+1;
					$congtext='Excelent';
				}
			}
			else if($year_id==12)
			{
				if($ass_marks <= 49)
				{
					$promote_year=$year_id-2;
					$congtext='Congratulations';
				}
				else if($ass_marks >= 50 && $ass_marks <= 79)
				{
					$promote_year=$year_id-1;
					$congtext='Congratulations';
				}
				else if($ass_marks >= 80 && $ass_marks <= 99)
				{
					$promote_year=$year_id;
					$congtext='Congratulations';
				}
				
				else if($ass_marks >99)
				{
					$promote_year=$year_id+1;
					$congtext='Excelent';
				}
			}
			else if($year_id==13)
			{
				if($ass_marks <= 49)
				{
					$promote_year=$year_id-2;
					$congtext='Congratulations';
				}
				else if($ass_marks >= 50 && $ass_marks <= 79)
				{
					$promote_year=$year_id-1;
					$congtext='Congratulations';
				}
				else if($ass_marks >= 80 && $ass_marks <= 100)
				{
					$promote_year=$year_id;
					$congtext='Excelent';
				}
				
				
			}			
				
			?>
			<h3><?php echo $congtext;?>  you are eligible to take admission in <?php echo $this->classes_model->GetClassName($promote_year);?> </h3>
			<p>Total Questions: <?php echo $totalquestion;?></p>
			<p>Scores: <?php echo $totalright.'/'.$totalquestion;?></p>
			<p>Percentage(%): <?php echo number_format($calper);?>%</p>
			<?php
			if($promote_year!="" && $promote_year!=null)
			{
				$query_ques=$this->db->query("select * from student_promoted  where exam_id='".$exam_id."' ");
				$ques_result=$query_ques->num_rows();
				if($ques_result > 0)
				{
				}
				else
				{
						$createdate1=date("Y-m-d H:i:s");
						$prom_data=array(
							
							'user_id'=>$this->session->userdata('user_id'),
							'exam_id'=>$exam_id,
							'reg_year'=>$year_id,
							'promote_year'=>$promote_year,
							'pay_status'=>'pending',
							'promote_date'=>$createdate1
							);
						$proid=$this->exam_model->Save_Promoted_Assessment($prom_data);	
				}
			}
			?>
						<p><a href="<?php echo BASE_URL.'book-center-class/'.$promote_year;?>">Book Class</a><p>
			<?php
			//}
		}

		
		if($ques_dtl != null && $ques_dtl != ""){
		
		 
			if($ques_dtl->ques_type==4){?>
				<h3><?php echo $correct_ans->ans_name;?></h3>
			
				<div style="border:1px solid #ccc; padding:30px;"> <h3>Explanation</h3>
				<?php
					echo $ques_dtl->ques_name; 
					echo '<br>';
					$imgs=$this->main_model->getall('ques_img','ques_id',$ques_dtl->ques_id);

					foreach($imgs as $img){

					echo '<img src="/assets/uploads/ans/'.$img->img.'"/>';
					}
					echo '<br>';
					$answers=$this->questions_model->get_answers($ques_dtl->ques_id);
					foreach($answers as $answer){
						
					echo '<a id ="a1" class="explan-btn">'.$answer->ans_name.'</a>&nbsp;&nbsp;&nbsp;';
					}



					echo '<h4 class="space10">You answered: </h4>';
					echo '<h3>'.$yourans->ans_name.'</h3>';
			}
			elseif($ques_dtl->ques_type==5)
			{?>
			<img src="/assets/uploads/ans/<?php echo $correct_ans->ans_name;?>"/>
				
		
			<div style="border:1px solid #ccc; padding:30px;"> <h3>Explanation</h3>
			<?php
				echo $ques_dtl->ques_name;
				echo '<br>';
				
				echo '<br>';
				$answers=$this->questions_model->get_answers($ques_dtl->ques_id);
				foreach($answers as $answer){
					
				echo '<img src="/assets/uploads/ans/'.$answer->ans_name.'"/>&nbsp;';
				}



				echo '<h4 class="space10">You answered: </h4>';
				echo '<img src="/assets/uploads/ans/'.$yourans->ans_name.'"/>';
				
			}
			elseif($ques_dtl->ques_type==6)
			{?>
			<h3><?php echo $correct_ans->ans_name;?></h3>
		
			<div style="border:1px solid #ccc; padding:30px;"> <h3>Explanation</h3>
			<?php
				echo $ques_dtl->ques_name;
				echo '<br>';
				
				$imgs=$this->main_model->getall('ques_img','ques_id',$ques_dtl->ques_id);
				foreach($imgs as $img){
					for($i=0;$i<$img->repeat;$i++){
					echo '<img src="/assets/uploads/ans/'.$img->img.'"/>';
					}
					echo '<br>';
				}
				$answers=$this->questions_model->get_answers($ques_dtl->ques_id);
				foreach($answers as $answer){
					
				echo $answer->ans_name.'&nbsp;&nbsp;&nbsp;';
				}



				echo '<h4 class="space10">You answered: </h4>'; 
				echo '<h3>'.$yourans->ans_name.'</h3>';
				
			}
			
			
			}
			else
			{ ?>
			  No Question found
			<?php } ?>
			
			
			
			</div>
		
			
		<a href="" class="got_it">Got it</a>
			
			</form>

</div>

</div>

</div>
 </section>
 

 <script>
  $("#a1").click(function(event) {
    this.removeAttribute("href");            
    anchorClicked("a1");
  });
 </script>
    
 <!-- Page Content End -->
<?php include('footer.php'); ?>