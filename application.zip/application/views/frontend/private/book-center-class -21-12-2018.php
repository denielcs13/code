<?php include('header.php'); ?>
	<script type='text/javascript' src='<?= base_url('assets/js/formjquery.min.js')?>'></script>
<link rel="stylesheet" href="http://code.jquery.com/ui/1.11.0/themes/smoothness/jquery-ui.css">

<style>
		#contact label{
			display: inline-block;
			width: 100px;
			text-align: right;
		}
		#contact_submit{
			padding-left: 100px;
		}
		#contact div{
			margin-top: 1em;
		}
		textarea{
			vertical-align: top;
			height: 5em;
		}
			
		.error{
			display: none;
			margin-left: 10px;
		}		
		
		.error_show{
			color: red;
			margin-left: 10px;
		}
		
		input.invalid, textarea.invalid{
			border: 2px solid red;
		}
		
		input.valid, textarea.valid{
			border: 2px solid green;
		}
	</style>
	 <script>
		jQuery(document).ready(function() {
			<!-- Real-time Validation -->
				<!--Name can't be blank-->
				jQuery('#contact_fname').on('input', function() {
					var input=$(this);
					var is_name=input.val();
					if(is_name){input.removeClass("invalid").addClass("valid");}
					else{input.removeClass("valid").addClass("invalid");}
				});
				jQuery('#contact_lname').on('input', function() {
					var input=$(this);
					var is_name=input.val();
					if(is_name){input.removeClass("invalid").addClass("valid");}
					else{input.removeClass("valid").addClass("invalid");}
				});
				
				<!--Email must be an email -->
				jQuery('#contact_email').on('input', function() {
					var input=$(this);
					var re = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$/;
					var is_email=re.test(input.val());
					if(is_email){input.removeClass("invalid").addClass("valid");}
					else{input.removeClass("valid").addClass("invalid");}
				});
				
				jQuery('#contact_datepicker').on('input', function() {
					var input=$(this);
					var is_name=input.val();
					if(is_name){input.removeClass("invalid").addClass("valid");}
					else{input.removeClass("valid").addClass("invalid");}
				});
				
		
			<!-- After Form Submitted Validation-->
			jQuery("#contact_submit button").click(function(event){
				var form_data=$("#contact").serializeArray();
				var error_free=true;
				for (var input in form_data){
					var element=$("#contact_"+form_data[input]['name']);
					if(form_data[input]['name']=='fname' || form_data[input]['name']=='lname' || form_data[input]['name']='email'  || form_data[input]['name']='datepicker');
					{
					var valid=element.hasClass("valid");
					var error_element=$("span", element.parent());
					if (!valid){error_element.removeClass("error").addClass("error_show"); error_free=false;}
					else{error_element.removeClass("error_show").addClass("error");}
					}
					
				}
				if (!error_free){
					event.preventDefault(); 
				}
				else{
					alert('No errors: Form will be submitted');
				}
			});
			
			
			
		});
	</script>
<section id="title-inner" class="bgcolor-text">
<canvas id="demo-canvas"></canvas>
<div class="container">
<div class="text-tit">
<h1>
<span>Book Your Class</span>
</h1>
</div>

</div>
</section>

<!-- Page Content inner -->
<div class="about_content login-page forgot-password change-password book-center-class-page content-text space-75">

<div class="container">
<div class="row">


<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
<div class="row">
<div class="col-xs-12 col-sm-12 col-md-3 col-lg-3"></div>
<div class="col-xs-12 col-sm-12 col-md-6 col-lg-6">
<div class="form-section">
<form class="cmxform" id="contact" method="post" action="">
<div class="row">
<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">

<h3>Your Eligible Year : <?php echo $elg_yearname;?></h3>




<div class="row">
<?php if (validation_errors()) : ?>
											<div class="col-lg-12">
												<div class="alert alert-danger" role="alert">
													<?= validation_errors() ?>
												</div>
											</div>
											<?php endif; ?>
<div class="col-lg-12">
<div class="input-field">
<label>First Name</label>
<span class="input input--hoshi">
					<input type="text" name="first_name" value="<?php echo $userinfo->first_name;?>" placeholder="First Name" id="contact_fname" />
					<span class="error">This field is required</span>
				</span>
</div>
<div class="input-field">
<label>Last Name</label>
<span class="input input--hoshi">
					<input type="text" name="last_name" value="<?php echo $userinfo->last_name;?>" placeholder="Last Name" id="contact_lname" />
				</span>
</div>
<div class="input-field">
<label>Email</label>
<span class="input input--hoshi">
					<input type="text" name="email" value="<?php echo $userinfo->email;?>" placeholder="Email" id="contact_email" />
					<span class="error">A valid email address is required</span>
				</span>
</div>
<div class="input-field">
<label>Phone</label>
<span class="input input--hoshi">
					<input type="text" name="phone" value="<?php echo $userinfo->phone;?>" placeholder="Phone" />
				</span>
</div>
<div class="input-field">
<label>D.O.B*</label>
<span class="input input--hoshi">
<?php
if($userinfo->dob!='')
{
	$dobdate=explode('-',$userinfo->dob);
	$datedob=$dobdate[1].'/'.$dobdate[2].'/'.$dobdate[0];
}
else
{
	$datedob=date('m/d/Y');
}
?>
					<input type="text" name="dob" value="<?php echo $datedob;?>" placeholder="D.O.B" id="contact_datepicker"  autocomplete="off" />
				<span class="error">This field is required</span>
				</span>
</div>
<div class="input-field">
<label>Address</label>
<span class="input input--hoshi">
					<input type="text" name="address" value="<?php echo $userinfo->address;?>" placeholder="Address" />
				</span>
</div>

<div class="input-field">
<label>Select Center</label>
<span class="input input--hoshi">
					<select name="reg_center" id="regcenter" >
                    <option value="">Select Center</option>
                    
                    <?php
					if($center_list)
					{
						foreach($center_list as $locations)
						{
							echo '<option value="'.$locations->center_id.'">'.$locations->center_city.'</option>';
						}
					}
					?>
                    </select>
				</span>
</div>
<div id="seatshow"></div>
</div>

</div>





<input type="hidden" name="elg_yearid" value="<?php echo $elg_yearid;?>" />
<div id="contact_submit" class="text-center">
<button class="btn-mn btn-3 btn-3e button-org" style="display:none;" id="booknow">Book Now</button>
</div>




</div>


</div>
</form>
</div>

</div>
<div class="col-xs-12 col-sm-12 col-md-3 col-lg-3"></div>
</div>
</div>

</div>
</div>

</div>

 <!-- Page Content End -->
 <?php include('footer.php'); ?>

	
 <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>

<script type="text/javascript">
jQuery(document).ready(function(){

    jQuery('#regcenter').change(function(){
		
      var center_id=$('#regcenter').val();
	  //alert(center_id);
            jQuery.ajax({
                type : 'POST',
                url : '<?php echo BASE_URL.'ajaxcall/checkcenter_seats';?>',
                data : {center_id:center_id,year_id:<?php echo $elg_yearid;?>}
				,	
        success: function(result){
           // alert(result);
		   if(result > 0)
		   { 
			//jQuery( "#seatshow" ).html('<p style="color:green;font-weight:bold;">Avaliable seats is '+result+'</p>');
			jQuery( "#seatshow" ).html('<p style="color:green;font-weight:bold;">Seats available when registering.</p>');
			 jQuery( "#booknow" ).show();
		   }
		   else
		   {
			   jQuery( "#seatshow" ).html('<p style="color:red;font-weight:bold;">No seat Avaliable in this center please choice another center!.</p>');
			    jQuery( "#booknow" ).hide();
			  
		   }
		   // jQuery("#seatshow").val(result);
        }


    });
    });    
});

</script>
<script src="http://code.jquery.com/jquery-1.10.2.js"></script>
<script src="http://code.jquery.com/ui/1.11.0/jquery-ui.js"></script>
<script>
jQuery(document).ready(function() {
// Datepicker Popups calender to Choose date.
jQuery(function() {
jQuery("#contact_datepicker").datepicker();
<?php
if($datedob!='')
{
	?>
jQuery('#contact_datepicker').val('');
<?php
}
?>
// Pass the user selected date format.
jQuery("#format").change(function() {

jQuery("#contact_datepicker").datepicker("option", "dateFormat", $(this).val());
});
});
});
</script>
