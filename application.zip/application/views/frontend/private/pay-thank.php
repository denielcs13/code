<?php include('header.php'); ?>

<section id="title-inner" style="background-image:url(<?= base_url('assets/images/contact-bg.jpg')?>);">
<div id="large-header">   
<canvas id="demo-canvas"></canvas>
<div class="container">
<div class="text-tit">
 <div class="bb"></div>
<span class="lefttop-icon"></span>
<h1>
<span>Membership-Plans</span>
</h1>
<span class="rightbotm-icon"></span>
</div>

</div></div>

</section>

<!-- Page Content inner -->
<div class="login-page signup-page">

<div class="container">
<div class="row">


<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 space-75">

<div class="row">

<p>Thank for paypament<p>
<?php
//$query_chkpro=$this->db->query("select * from student_promoted  where user_id='532' and pay_status='pending' order by  pid desc ");
	//$num_chkpro=$query_chkpro->num_rows();
	//echo $num_chkpro;
	?><br/>
<div id="myloader" style="display:none;"><img src="<?= base_url('assets/images/2.gif')?>" /></div>

</div>
</div>

</div>
</div>

</div>

 <!-- Page Content End -->
 <?php include('footer.php'); ?>
 <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
 <?php
$pageload = $this->session->userdata('pageload');
						$pageload++;
$this->session->set_userdata('pageload', $pageload);


?>	
 <script type="text/javascript">
 var n = localStorage.getItem('on_load_counter');
    if (n === null) {
        n = 0;
    }
    n++;
    localStorage.setItem("on_load_counter", n);
	 var np = localStorage.getItem('on_load_counter');
	if(np< 3)
	{
		$(document).ready(function(){    
			//Check if the current URL contains '#'
		
			if(document.URL.indexOf("#")==-1){
				// Set the URL to whatever it was plus "#".
				 $('#myloader').show();
				url = document.URL+"#";
				location = "#";

				//Reload the page
				location.reload(true);
			}
			else
			{
				 $('#myloader').show();
				location.reload(true);
			}
			
			
		});
	}
	if(np==3)
	{
		$('#myloader').hide();
	}
</script>
<?php

?>

