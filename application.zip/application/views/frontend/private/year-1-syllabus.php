<?php include('header.php'); ?>

<!-- Page Content inner -->

<div class="tabs-login">
<div class="container">
<div class="row">
<ul class="links-menu">
<li><a href="notice-board">Notice Board</a></li>
<li><a href="this-week-classroom-exercise">This Week Classroom Exercise</a></li>
<li><a href="homework-exercise">Homework Exercise</a></li>
<li><a href="year-1-syllabus" class="active">Year 1 - Syllabus</a></li>
<li><a href="analysis-report">Analysis Report</a></li>
<li><a href="booking-payment">Booking & Payment</a></li>
<li><a href="certificate-award">Certificate & Award</a></li> 

</ul>

</div>
</div>

</div>
 
 <section class="about_content content-text space-75 space-top-0">
 <div class="container">
 <div class="row">
 
 <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
 
 
 <table class="table table-striped table-light">
  <thead>
    <tr>
      <th scope="col">Study Week No.</th>
      <th scope="col">Topic</th>
      <th scope="col">Subject Exercises</th>
      <th scope="col">Classroom Score</th>
      <th scope="col">Homework Score</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th scope="row"># 1.  (31/JAN/18 - 05/JAN/19)</th>
      <td>A. Numbers & Counting Up To 3</td>
      <td>A1. Learn to count 3<br />
      A2. Count to 3<br />
A3. Count using stickers - up to 3
</td>
      <td>20/20&nbsp;&nbsp; 100%</td>
      
      <td>20/20&nbsp;&nbsp; 100%</td>
    </tr>
    
    
    <tr>
      <th scope="row"># 2. (07/JAN/18 - 12/JAN/18)</th>
      <td>A. Numbers & Counting Up To 3</td>
      <td>A4. Count on ten frames – up to 3<br />
      A5. Represent numbers – up to 3<br />
A6. Ordinal numbers – up to third
</td>
      <td></td>
      
      <td></td>
    </tr>
    
    
  </tbody>
</table>
 
 </div>
 
 
 
 
 </div>
 </div>
 </section>
 
 <!-- Page Content End -->
<?php include('footer.php'); ?>