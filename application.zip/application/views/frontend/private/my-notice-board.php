<?php include('header.php'); ?>

<!-- Page Content inner -->
<section id="title-inner" class="bgcolor-text">
<canvas id="demo-canvas"></canvas>
<div class="container">
<div class="text-tit">
<h1>
<span>Dashboard</span>
</h1>
</div>

</div>
</section>

 
 <section class="about_content content-text page-dashboard space-75">
 <div class="container">
 <div class="row">
 
 <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12" >

   <?php
  if($this->session->userdata('user_type')=='3')
	{?>
	 <h2 align="center">You have Successfully registered as a tutor with us for 
	 <?php 
	 
	 $years=explode(',',$this->session->userdata('loginyear'));
			
		?>

		<?php foreach($years as $year){
			
			$year_dtl=$this->main_model->get_detail('master_class','class_id',$year);
			$years[]=$year_dtl->class_name;
			
			}
			
			echo implode(', ',$years);
			?>
	 </h2>
 <p align="center">Please visit your  registered year's pages.</p>

		
	<?php }
	else{
   
   
   
   $whr="userid='".$this->session->userdata('user_id')."' and pay_status='confirm'";
   $order_row=$this->main_model->get_where_row('orders',$whr);
														
													
   
 if(!$order_row)
 {?>
 <h2 align="center">You have Successfully registered for <?php echo $year_name;?> to learn english.  </h2>
 <p align="center">Please Book Now to join the classes.</p>
<p align="center"> <a href="<?php echo BASE_URL.'book-center-class/'.$this->session->userdata('loginyear');?>" class="btn-mn btn-3 btn-3e  button-org aat-btn"><strong>Book Now</strong></a></p>
 <?php
 }
 else
 {
 ?>

 <h3 class="text-center">
 <?php
 if($this->session->userdata('lastlogedin')!='')
 {?>
 Last login : <?php echo $this->session->userdata('lastlogedin');?>
 <?php 
 } else { ?>
 This is your First Login
 <?php } ?>
 </h3>

  <div class="row">
<div class="col-xs-12 col-sm-6 col-md-4 col-lg-3">
<div class="box-show">
<a href="">
<img src="<?php echo base_url();?>assets/images/year.png" alt="" />
<span>Your <?php echo $year_name;?></span></a>
</div> 
</div>
<div class="col-xs-12 col-sm-6 col-md-4 col-lg-3">
<div class="box-show">
<a href="<?php echo base_url();?><?php echo lcfirst($year_slug);?>">
<img src="<?php echo base_url();?>assets/images/syllabus.png" alt="" />
<span>Syllabus</span></a>
</div>
</div>
<div class="col-xs-12 col-sm-6 col-md-4 col-lg-3">
<div class="box-show">

<a href="<?php echo base_url();?>classroom-exercise">
<img src="<?php echo base_url();?>assets/images/classroom.png" alt="" />
<span>Classroom Exercise</span></a>
</div>
</div>
<div class="col-xs-12 col-sm-6 col-md-4 col-lg-3">
<div class="box-show">
<a href="<?php echo base_url();?>homework">
<img src="<?php echo base_url();?>assets/images/homework.png" alt="" />
<span>Home Work</span></a>
</div>
</div>

<div class="col-xs-12 col-sm-6 col-md-4 col-lg-3">
<div class="box-show">
<a href="<?php echo base_url();?>analysis-report">
<img src="<?php echo base_url();?>assets/images/analysis-report.png" alt="" />
<span>Analysis Report</span></a>
</div>
</div>
<div class="col-xs-12 col-sm-6 col-md-4 col-lg-3">
<div class="box-show">
<a href="<?php echo base_url();?>certificate-award">
<img src="<?php echo base_url();?>assets/images/certificate.png" alt="" />
<span>Certificate</span></a>
</div>
</div>
<div class="col-xs-12 col-sm-6 col-md-4 col-lg-3">
<div class="box-show">
<a href="<?php echo base_url();?>exam">
<img src="<?php echo base_url();?>assets/images/exam.png" alt="" />
<span>Exam Details</span></a>
</div>
</div>
<div class="col-xs-12 col-sm-6 col-md-4 col-lg-3">
<div class="box-show">
<a href="">
<img src="<?php echo base_url();?>assets/images/university.png" alt="" /> 
<span>University Comments</span></a>
</div>
</div> 

</div>
 <?php
 }
 ?>
<?php } ?>


 
 </div>
 
 
 
 
 </div>
 </div>
 </section>
 
 
   
   
   
   
   
   
    
 <!-- Page Content End -->
<?php include('footer.php'); ?>