<?php include('header.php'); ?>
<style type="text/css">
	.table-bordered td, .table-bordered th{
		border: 1px solid #bac7ce
	}

</style>
<section class="about_content content-text space-75 space-top-0">
 <section class="about_content content-text space-75 space-top-0">
  <br>
 <br>
 <div class="container">
 <h1>Students Exam Sheet</h1>

<div class="contener">	
<?php
 $exam_id=$this->uri->segment(2);?>
<div class="row">

  <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
   <div class="row">
  
	 
  
</div>
 </div>
 
 </div>
<?php
$data=array('attempt'=>$exam_id,'user_id'=>$this->session->userdata('user_id'));
$sheet_query=$this->db->where($data)->get('sexam_history'); 
$result_sheet=$sheet_query->result();

if($result_sheet!='hidequestion')
{
?>
<strong>Questions Sheet</strong>
 <div class="row">
  <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
  <table class="table table-bordered">
  <thead>
    <tr>
	<th scope="col">Skill</th>
      <th scope="col">Question</th>
	  
      <th scope="col">Answer</th>     
      <!--<th scope="col">Status</th>-->
	
	   
    </tr>
  </thead>
  <tbody>
  </tbody>
  <?php
  
  foreach($result_sheet as $rowsheet)

  {

	   $question_query=$this->db->query("select ques.ques_name,skill.skill_name,ques.ques_type from manage_question_".$rowsheet->year_id." ques left join master_skill skill on
		skill.skill_id=ques.ques_subskillid where ques.ques_id='".$rowsheet->question_id."' "); 
	   $result_ques=$question_query->row();
	  ?>
  <tr>
   <td><?php echo $result_ques->skill_name;?></td>
  <td><?php echo base64_decode($result_ques->ques_name);?></td>
  
    <td>
	<?php
	if($rowsheet->answer_status=='true')
	{
		echo 'Correct';
	}
	else
	{
		echo 'Wrong';
	}
	?>
	</td>
  </tr>
  <?php
  }
  ?>
  </table>
  </div>
  </div>
 <?php
}

?>
</div>
</section>
<?php include('footer.php'); ?>