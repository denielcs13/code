<?php include('header.php'); ?>

<!-- Page Content inner -->
<section id="title-inner" class="bgcolor-text">
<canvas id="demo-canvas"></canvas>
<div class="container">
<div class="text-tit">
<h1>
<span>Dashboard</span>
</h1>
</div>

</div>
</section>

 
 <section class="about_content content-text analysis-report space-75">
 <div class="container">
 <div class="row">
 

<div class="col-xs-12 col-sm-4 col-md-4 col-lg-4">
<a href="<?php echo base_url().'all-weeks-report';?>" class="btn-mn btn-3 btn-3e ans-btn">Weekly Report</a>
</div>
<div class="col-xs-12 col-sm-4 col-md-4 col-lg-4">
<a href="<?php echo base_url().'all-month-report';?>" class="btn-mn btn-3 btn-3e ans-btn">Monthly Report</a>
</div>

<div class="col-xs-12 col-sm-4 col-md-4 col-lg-4">
<a href="<?php echo base_url().'yearly-report';?>" class="btn-mn btn-3 btn-3e ans-btn">Yearly Report</a>
</div>


 
 
 
 
 </div>
 </div>
 </section>
 
 
   
   
   
   
   
   
    
 <!-- Page Content End -->
<?php include('footer.php'); ?>