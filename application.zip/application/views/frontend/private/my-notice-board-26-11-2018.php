<?php include('header.php'); ?>

<!-- Page Content inner -->
<section id="title-inner" class="bgcolor-text">
<canvas id="demo-canvas"></canvas>
<div class="container">
<div class="text-tit">
<h1>
<span>Dashboard</span>
</h1>
</div>

</div>
</section>

 
 <section class="about_content content-text space-75">
 <div class="container">
 <div class="row">
 
 <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12" >

   <?php
  if($this->session->userdata('user_type')=='3')
	{?>
	 <h2 align="center">You have Successfully registered as a tutor with us for 
	 <?php 
	 
	 $years=explode(',',$this->session->userdata('loginyear'));
			
		?>

		<?php foreach($years as $year){
			
			$year_dtl=$this->main_model->get_detail('master_class','class_id',$year);
			$years[]=$year_dtl->class_name;
			
			}
			
			echo implode(', ',$years);
			?>
	 </h2>
 <p align="center">Please visit your  registered year's pages.</p>

		
	<?php }
	else{
   
 if($aatcount==0)
 {?>
 <h2 align="center">You have Successfully registered with us for  <?php echo $year_name;?></h2>
 <p align="center">Please give AAT to join the classes.</p>
<p align="center"> <a href="<?php echo BASE_URL.$year_slug.'/assessment';?>" class="btn-mn btn-3 btn-3e  button-org aat-btn"><strong>Start AAT</strong></a></p>
 <?php
 }
 else
 {
 ?>
  <ul>
 <li>Last login : <?php echo $this->session->userdata('lastlogedin');?> </li>
 <li>Quiz for kids and for parents</li>
 <li>Coming Up Class Date and Time (Reminder)</li>
 <li>This week classroom exercise and Homework exercise</li>
 <li>How many more weeks arrive to the Semester Test</li>
 <li>What needs to be done in order to achieve Certificate and Award</li>
  </ul>
 <?php
 }
 ?>
<?php } ?>
 
 </div>
 
 
 
 
 </div>
 </div>
 </section>
 
 
   
   
   
   
   
   
    
 <!-- Page Content End -->
<?php include('footer.php'); ?>