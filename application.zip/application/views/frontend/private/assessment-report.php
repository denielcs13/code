<?php include('header.php'); ?>

<!-- Page Content inner -->
<section id="title-inner" class="bgcolor-text">
<canvas id="demo-canvas"></canvas>
<div class="container">
<div class="text-tit">
<h1>
<span>AAT Report</span>
</h1>
</div>

</div>
</section>

<div class="tabs-login">
<div class="container">
<!--<div class="row">
<ul class="links-menu">
<li><a href="<?php echo  base_url();?>dashboard" class="active">Notice Board</a></li>

<li><a href="<?php echo  base_url();?>classroom-exercise">This Week Classroom Exercise</a></li>
<li><a href="<?php echo  base_url();?>homework">Homework Exercise</a></li>
<li><a href="/<?php echo lcfirst($year_slug);?>"><?php echo $year_name;?> - Syllabus</a></li>
<li><a href="analysis-report">Analysis Report</a></li>
<li><a href="booking-payment">Booking & Payment</a></li>
<li><a href="certificate-award">Certificate & Award</a></li>
<li><a href="<?php echo  base_url().lcfirst($year_slug);?>/exam"><?php echo $year_name;?> - Exam</a></li>

</ul>

</div>-->
</div>

</div>
 
 <section class="about_content content-text space-75 space-top-0">
 <div class="container">
 <h1>AAT Report</h1>

 <div class="row">


<?php
if($asstestlist)
{
	?>
<div class="table-responsive">
  <table class="table table-striped table-light">
  <thead>
    <tr>
	<th scope="col">AAT Year</th>      
	 <th scope="col">Date</th>
      <th scope="col">Total Question</th>     
      <th scope="col">Scores</th>
	  <th scope="col">Percentage(%)</th>
	  <th scope="col">Promoted year</th>
	   
    </tr>
  </thead>
  <tbody>
    <?php
	 $totalquestion="";
	  $totalright="";
	  $calper="";
	foreach($asstestlist as $userexamrow)
	{
		//var_dump($userexamrow);
		 $examhquery=$this->db->query("select count(*) as totalquestion from sasstest_history where exam_id='".$userexamrow->exam_id."' "); 
		   $ehistoryrow=$examhquery->row();
		   $totalquestion=$ehistoryrow->totalquestion;
		   $queryrightcount="select count(*) as totalright from sasstest_history where exam_id='".$userexamrow->exam_id."' and answer_status='true'  ";
		  
		   $examhquery1=$this->db->query($queryrightcount); 
		   $exrightquestion=$examhquery1->row();
		   // var_dump($resultexam);
		    $totalright=$exrightquestion->totalright;
			$calper=($totalright/$totalquestion)*100;
			
		?>
	<tr>
	<td><?php if($userexamrow->year_id=='1') { echo 'Kindergarten';} else { echo 'Year '.$userexamrow->year_id;}?> </td>
	
	<td><?php echo date('m/d/Y',strtotime($userexamrow->exam_date));?></td>
	<td><?php echo $totalquestion;?></td>
	<td><?php echo $totalright.'/'.$totalquestion;?></td>
	<td><?php echo number_format($calper);?>%</td>
	<td><?php if($userexamrow->assyear_id=='1') { echo 'Kindergarten';} else { echo 'Year '.$userexamrow->assyear_id;}?></td>
	</tr>
   <?php
	}
	?>
    
  </tbody>
</table>
</div>
<?php
}
?>
 </div>
 

  
 </div>
 </section>
 
 
   
   
   
   
   
   
    
 <!-- Page Content End -->
<?php include('footer.php'); ?>