<?php include('header.php'); ?>

<!-- Page Content inner -->

<div class="tabs-login">
<div class="container">
<div class="row">
<ul class="links-menu">
<li><a href="notice-board">Notice Board</a></li>
<li><a href="this-week-classroom-exercise">This Week Classroom Exercise</a></li>
<li><a href="homework-exercise">Homework Exercise</a></li>
<li><a href="year-1-syllabus">Year 1 - Syllabus</a></li>
<li><a href="analysis-report">Analysis Report</a></li>
<li><a href="booking-payment">Booking & Payment</a></li>
<li><a href="certificate-award" class="active">Certificate & Award</a></li>

</ul>

</div>
</div>

</div>
 
 <section class="about_content content-text space-75 space-top-0">
 <div class="container">
 <div class="row">
 
 <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
 <strong>Grading system</strong>
<ul>
<li>1%-49% is 1 star achievement level</li>
<li>50%-79% is 2 stars achievement level</li>
<li>80% is 3 stars achievement level</li>
<li>90% is 4 stars achievement level</li>
<li>100% is 5 stars achievement level – Master level</li>
</ul>


<p>The record system will only show the highest grading system achieved.  If click down each to topic
User can view each and every time the attempts on the exercise the scores, date & time, number
Of questions done, an analysis report on this topic. Each exercise has maximum 20 questions each time attempt.</p>

<p>Every end of semester will have a Semester Milestone Achievement Test (label by 1st SMAT, 2nd SMAT, 3rd SMAT and 4th SMAT). Each SMAT will take 30mins.
If all 4 SMAT or Year SMAT (call it YSMAT) stars total 20 – Master level for that year, if total YQMAT total 10-19 stars – Honors Graduate and 0-9 stars – Graduate</p>

<p>Award for parents.  If student graduated with Master level, parent will be given 20% discount award for next year tuition fee. If student graduated with Honors Graduate level parent will be given 10% discount award for next year tuition fee.</p>

<p>At the end of each month and also end of each semester the system will send reminder through email/text to student and/or parents to check their report and analysis summary.</p>

 
 </div>
 
 
 
 
 </div>
 </div>
 </section>
 
 
   
   
   
   
   
   
    
 <!-- Page Content End -->
<?php include('footer.php'); ?>