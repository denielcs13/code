<?php include('header.php'); ?>
<?php  $img=ucfirst($year_dtl->class_slug.'_bg.jpg');?>
<?php
if($this->session->userdata('loginyear')!="")
{
	if($year_id!=$this->session->userdata('loginyear'))
	{
		redirect(base_url().'dashboard');
		exit;
	}
}
?>
<section id="title-inner" style="background-image:url(<?= base_url('assets/images/'.$img)?>);">
  <div id="large-header">
    <canvas id="demo-canvas"></canvas>
    <div class="container">
      <div class="text-tit">
        <div class="bb"></div>
        <span class="lefttop-icon"></span>
        <h1> <span><?php echo $year_dtl->class_name;?></span> </h1>
        <span class="rightbotm-icon"></span> </div>
    </div>
  </div>
</section>


<!-- Page Content inner -->

<section class="about_content content-text syllabus-page space-75">
  <div class="container">
    <div class="row"> 
      <!-- Bootstrap Tabs -->
      <?php
	  /*----Student Current year Active Weeks with Current Date-----*/
	  	$query_cweek=$this->db->query("select promote_date from student_promoted where user_id = '".$this->session->userdata('user_id')."' and promote_year = '".$year_id."' and pay_status='confirm'"); 
		$row_cweek= $query_cweek->row();
	 $registerdate=$row_cweek->promote_date;
		
		 $startDate = strtotime($registerdate);
		
		 $endDate =strtotime(date("Y-m-d H:i:s"));
		
		$today_time = date('Y-m-d',strtotime($endDate));
		
		$expire_time = date('Y-m-d',strtotime($startDate));
		
		if ($expire_time == $today_time) {
			 $user_currentweek=1;
			
		}
		else
		{	
			
			if($this->session->userdata('user_id')!='1'){
				
			// $interval = $startDate->diff($endDate);
			  $interval = 1;
			 $user_currentweek=(int)(($interval->days) / 7);
			}
		}
		
		
		/*----End Student Current year Active Weeks with Current Date-----*/
		/*----Student Current year Active Weeks with Order Paymemt-----*/
		$query_ord=$this->db->query("select plan_id,order_date,order_week from orders where userid = '".$this->session->userdata('user_id')."' and year_id = '".$year_id."' and order_status='active' and pay_status='confirm' order by orderid desc"); 
		$num_ord= $query_ord->num_rows();
		if($num_ord > 0)
		{	
			$row_ord= $query_ord->row();
			/*$query_plan=$this->db->query("select plan_week from master_plan where planid = '".$row_ord->plan_id."'"); 
			$row_plan= $query_plan->row();
			
			$order_week=$row_plan->plan_week;*/
			$order_week=$row_ord->order_week;
			
		}
		else
		{
			$order_week=0;
		}
		
		/*----End of Student Current year Active Weeks with Order Paymemt-----*/
		
		
	 ?>
      <div class="tab-content">
        <?php 
      if($SylList1 != null && $SylList1 != ""){
			global $order_arr;
			$tid=0;$wid=0;
									?>
        <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
          <h2 class="blue-title">Term 1</h2>
          <div class="row">
            <?php 
			$aveageweek=0;
			foreach($SylList1 as $result){
	$term= $this->main_model->get_detail('master_terms','term_id',$result->term_id);
	$skl_dtl= $this->main_model->get_detail('master_skill','skill_id',$result->skill_id);
	$query=$this->db->query('select * from syllabus_week_subskill where skill_id = "'.$result->skill_id.'"'); 
	 $ct2= $query->num_rows();
	$comp2=0;

	?>
            <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
              <div class="syllabus-sec">
                <h3><?php echo $order_arr[$result->skill_order].'. '.$skl_dtl->skill_name;?></h3>
                <div class="row">
                  <?php 

foreach($query->result() as $ress){
	
	$subskl_dtl= $this->main_model->get_detail('master_skill','skill_id',$ress->subskill_id);
	$comp2++;
	?>
                  <?php if($wid!=$ress->week_id || $comp2==1){
	
	$query1=$this->db->query('select count(*) as "ct" from syllabus_week_subskill where week_id="'.$ress->week_id.'" and term_id="'.$ress->term_id.'" and year_id="'.$ress->year_id.'"');
	$res1=$query1->row();
	$ct= $res1->ct;
	
	$comp=0;

	$week_dtl= $this->main_model->get_detail('master_weeks','week_id',$ress->week_id);
	$this->db->select('*'); 
	$this->db->from('master_goal');
	$this->db->where('term_id',$result->term_id);
	$this->db->where('year_id',$result->class_id);
	$this->db->where('week_id',$ress->week_id);
	$goal= $this->db->get()->row();
	$color_class=explode(',' ,$ress->week_id);
	$color_class=$color_class[0];
	$aveageweek ++;
	/*---get Week Notes detail-------*/
	$query_notes=$this->db->query('select notes_file from master_weeknotes where week_id="'.$ress->week_id.'" and term_id="'.$ress->term_id.'" and year_id="'.$ress->year_id.'"');
	$row_notes=$query_notes->row();
	/*----end of week notes details-----*/
	?>
                  <div class="col-xs-12 col-sm-12 col-md-4 col-lg-4">
                    <div class="box-syllabus">
                      <div class="text-content">
                        <ul>
                          <li>
                            <div class="row">
                              <div class="col-xs-8 col-sm-8 col-md-6 col-lg-8 col-8"><strong><?php echo $goal->goal_name;?></strong></div>
                              <div class="col-xs-4 col-sm-4 col-md-6 col-lg-4 col-4">
                                <h4 class="cyan_bg color-<?php echo $color_class;?>"><?php echo $week_dtl->week_name;?>
								<?php
								if($row_notes->notes_file!='')
								{
									echo '  <a href="'.base_url('assets/uploads/notes/'.$row_notes->notes_file).'">Notes</a>';
								}
								?></h4> 
                              </div>
                            </div>
                          </li>
                          <?php } $comp++; ?>
                        <?php
						if($aveageweek <= $user_currentweek && $aveageweek <= $order_week)
						{
?>							
						 <a href="<?php echo base_url().strtolower($year_dtl->class_slug).'/'.$subskl_dtl->skill_slug;?>">
                          <li><strong><?php echo $order_arr[$result->skill_order].'.'.$ress->subskill_order;?></strong> <?php echo $subskl_dtl->skill_name;?></li>
                          </a>
						  <?php
						}
						elseif($this->session->userdata('user_id')=='1')
						{
?>							
						 <a href="<?php echo base_url().strtolower($year_dtl->class_slug).'/'.$subskl_dtl->skill_slug;?>">
                          <li><strong><?php echo $order_arr[$result->skill_order].'.'.$ress->subskill_order;?></strong> <?php echo $subskl_dtl->skill_name;?></li>
                          </a>
						  <?php
						}
						else
						{?>
					
                          <li><strong><?php echo $order_arr[$result->skill_order].'.'.$ress->subskill_order;?></strong> <?php echo $subskl_dtl->skill_name;?></li>
                          
					<?php
						}
						?>
							
                          <?php if(($ct==$comp) || ($ct2==$comp2)){?>
                        </ul>
                      </div>
                    </div>
                  </div>
                  <?php } $wid=$ress->week_id;?>
                  <?php } ?>
                </div>
              </div>
            </div>
            <?PHP } ?>
          </div>
        </div>
        <?PHP } ?>
        <?php 
      if($SylList2 != null && $SylList2 != ""){
			global $order_arr;
			$tid=0;$wid=0;
									?>
        <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
          <h2  class="green-title">Term 2</h2>
          <div class="row">
            <?php foreach($SylList2 as $result){
	$term= $this->main_model->get_detail('master_terms','term_id',$result->term_id);
	$skl_dtl= $this->main_model->get_detail('master_skill','skill_id',$result->skill_id);
	$query=$this->db->query('select * from syllabus_week_subskill where skill_id = "'.$result->skill_id.'"'); 
	 $ct2= $query->num_rows();
	$comp2=0;

	?>
            <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
              <div class="syllabus-sec">
                <h3><?php echo $order_arr[$result->skill_order].'. '.$skl_dtl->skill_name;?></h3>
                <div class="row">
                  <?php 

foreach($query->result() as $ress){
	
	$subskl_dtl= $this->main_model->get_detail('master_skill','skill_id',$ress->subskill_id);
	$comp2++;
	?>
                  <?php if($wid!=$ress->week_id || $comp2==1){
	
	$query1=$this->db->query('select count(*) as "ct" from syllabus_week_subskill where week_id="'.$ress->week_id.'" and term_id="'.$ress->term_id.'" and year_id="'.$ress->year_id.'"');
	$res1=$query1->row();
	$ct= $res1->ct;
	
	$comp=0;

	$week_dtl= $this->main_model->get_detail('master_weeks','week_id',$ress->week_id);
	$this->db->select('*'); 
	$this->db->from('master_goal');
	$this->db->where('term_id',$result->term_id);
	$this->db->where('year_id',$result->class_id);
	$this->db->where('week_id',$ress->week_id);
	$goal= $this->db->get()->row();
	$color_class=explode(',' ,$ress->week_id);
	$color_class=$color_class[0];
	$aveageweek ++;
		/*---get Week Notes detail-------*/
	$query_notes=$this->db->query('select notes_file from master_weeknotes where week_id="'.$ress->week_id.'" and term_id="'.$ress->term_id.'" and year_id="'.$ress->year_id.'"');
	$row_notes=$query_notes->row();
	/*----end of week notes details-----*/
	?>
                  <div class="col-xs-12 col-sm-12 col-md-4 col-lg-4">
                    <div class="box-syllabus ">
                      <div class="text-content">
                        <ul>
                          <li>
                            <div class="row">
                              <div class="col-xs-8 col-sm-8 col-md-6 col-lg-8 col-8"><strong><?php echo $goal->goal_name;?></strong></div>
                              <div class="col-xs-4 col-sm-4 col-md-6 col-lg-4 col-4">
                                <h4 class="cyan_bg color-<?php echo $color_class;?>"><?php echo $week_dtl->week_name;?>
								<?php
								if($row_notes->notes_file!='')
								{
									echo '  <a href="'.base_url('assets/uploads/notes/'.$row_notes->notes_file).'">Notes</a>';
								}
								?>
								</h4>
                              </div>
                            </div>
                          </li>
                          <?php } $comp++; ?>
						  <?php 
						if($aveageweek <= $user_currentweek && $aveageweek <= $order_week)
						{
							?>
                          <a href="<?php echo base_url().strtolower($year_dtl->class_slug).'/'.$subskl_dtl->skill_slug;?>">
                          <li><strong><?php echo $order_arr[$result->skill_order].'.'.$ress->subskill_order;?></strong> <?php echo $subskl_dtl->skill_name;?></li>
                          </a>
						  <?php
						}
						elseif($this->session->userdata('user_id')=='1')
						{
?>							
						 <a href="<?php echo base_url().strtolower($year_dtl->class_slug).'/'.$subskl_dtl->skill_slug;?>">
                          <li><strong><?php echo $order_arr[$result->skill_order].'.'.$ress->subskill_order;?></strong> <?php echo $subskl_dtl->skill_name;?></li>
                          </a>
						  <?php
						}
						else
						{
							?>
						 
                          <li><strong><?php echo $order_arr[$result->skill_order].'.'.$ress->subskill_order;?></strong> <?php echo $subskl_dtl->skill_name;?></li>
                          
						<?php
						}
?>						
                          <?php if(($ct==$comp) || ($ct2==$comp2)){?>
                        </ul>
                      </div>
                    </div>
                  </div>
                  <?php } $wid=$ress->week_id;?>
                  <?php } ?>
                </div>
              </div>
            </div>
            <?PHP } ?>
          </div>
        </div>
        <?PHP } ?>
        <?php 
      if($SylList3 != null && $SylList3 != ""){
			global $order_arr;
			$tid=0;$wid=0;
									?>
        <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
          <h2 class="cyan-title">Term 3</h2>
          <div class="row">
            <?php foreach($SylList3 as $result){
	$term= $this->main_model->get_detail('master_terms','term_id',$result->term_id);
	$skl_dtl= $this->main_model->get_detail('master_skill','skill_id',$result->skill_id);
	$query=$this->db->query('select * from syllabus_week_subskill where skill_id = "'.$result->skill_id.'"'); 
	 $ct2= $query->num_rows();
	$comp2=0;

	?>
            <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
              <div class="syllabus-sec">
                <h3><?php echo $order_arr[$result->skill_order].'. '.$skl_dtl->skill_name;?></h3>
                <div class="row">
                  <?php 

foreach($query->result() as $ress){
	
	$subskl_dtl= $this->main_model->get_detail('master_skill','skill_id',$ress->subskill_id);
	$comp2++;
	?>
                  <?php if($wid!=$ress->week_id || $comp2==1){
	
	$query1=$this->db->query('select count(*) as "ct" from syllabus_week_subskill where week_id="'.$ress->week_id.'" and term_id="'.$ress->term_id.'" and year_id="'.$ress->year_id.'"');
	$res1=$query1->row();
	$ct= $res1->ct;
	
	$comp=0;

	$week_dtl= $this->main_model->get_detail('master_weeks','week_id',$ress->week_id);
	$this->db->select('*'); 
	$this->db->from('master_goal');
	$this->db->where('term_id',$result->term_id);
	$this->db->where('year_id',$result->class_id);
	$this->db->where('week_id',$ress->week_id);
	$goal= $this->db->get()->row();
	$color_class=explode(',' ,$ress->week_id);
	$color_class=$color_class[0];
	$aveageweek++;
		/*---get Week Notes detail-------*/
	$query_notes=$this->db->query('select notes_file from master_weeknotes where week_id="'.$ress->week_id.'" and term_id="'.$ress->term_id.'" and year_id="'.$ress->year_id.'"');
	$row_notes=$query_notes->row();
	/*----end of week notes details-----*/
	
	?>
                  <div class="col-xs-12 col-sm-12 col-md-4 col-lg-4">
                    <div class="box-syllabus">
                      <div class="text-content">
                        <ul>
                          <li>
                            <div class="row">
                              <div class="col-xs-8 col-sm-8 col-md-6 col-lg-8 col-8"><strong><?php echo $goal->goal_name;?></strong></div>
                              <div class="col-xs-4 col-sm-4 col-md-6 col-lg-4 col-4">
                                <h4 class="cyan_bg color-<?php echo $color_class;?>"><?php echo $week_dtl->week_name;?>
								<?php
								if($row_notes->notes_file!='')
								{
									echo '  <a href="'.base_url('assets/uploads/notes/'.$row_notes->notes_file).'">Notes</a>';
								}
								?>
								</h4>
                              </div>
                            </div>
                          </li>
                          <?php } $comp++; ?>
						 <?php
						 if($aveageweek <= $user_currentweek && $aveageweek <= $order_week)
						{
							?>
							
                          <a href="<?php echo base_url().strtolower($year_dtl->class_slug).'/'.$subskl_dtl->skill_slug;?>">
                          <li><strong><?php echo $order_arr[$result->skill_order].'.'.$ress->subskill_order;?></strong> <?php echo $subskl_dtl->skill_name;?></li>
                          </a>
						  <?php
						}
						elseif($this->session->userdata('user_id')=='1')
						{
						?>							
						 <a href="<?php echo base_url().strtolower($year_dtl->class_slug).'/'.$subskl_dtl->skill_slug;?>">
                          <li><strong><?php echo $order_arr[$result->skill_order].'.'.$ress->subskill_order;?></strong> <?php echo $subskl_dtl->skill_name;?></li>
                          </a>
						  <?php
						}
						else
						{
						?>
						<li><strong><?php echo $order_arr[$result->skill_order].'.'.$ress->subskill_order;?></strong> <?php echo $subskl_dtl->skill_name;?></li>
						<?php
						}
						?>
                          <?php if(($ct==$comp) || ($ct2==$comp2)){?>
                        </ul>
                      </div>
                    </div>
                  </div>
                  <?php } $wid=$ress->week_id;?>
                  <?php } ?>
                </div>
              </div>
            </div>
            <?PHP } ?>
          </div>
        </div>
        <?PHP } ?>
		
		
		   <?php 
      if($SylList4 != null && $SylList4 != ""){
			global $order_arr;
			$tid=0;$wid=0;
									?>
        <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
          <h2 class="red-title">Term 4</h2>
          <div class="row">
            <?php foreach($SylList4 as $result){
	$term= $this->main_model->get_detail('master_terms','term_id',$result->term_id);
	$skl_dtl= $this->main_model->get_detail('master_skill','skill_id',$result->skill_id);
	$query=$this->db->query('select * from syllabus_week_subskill where skill_id = "'.$result->skill_id.'"'); 
	 $ct2= $query->num_rows();
	$comp2=0;

	?>
            <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
              <div class="syllabus-sec">
                <h3><?php echo $order_arr[$result->skill_order].'. '.$skl_dtl->skill_name;?></h3>
                <div class="row">
                  <?php 

foreach($query->result() as $ress){ 
	
	$subskl_dtl= $this->main_model->get_detail('master_skill','skill_id',$ress->subskill_id);
	$comp2++;
	?>
                  <?php if($wid!=$ress->week_id || $comp2==1){
	
	$query1=$this->db->query('select count(*) as "ct" from syllabus_week_subskill where week_id="'.$ress->week_id.'" and term_id="'.$ress->term_id.'" and year_id="'.$ress->year_id.'"');
	$res1=$query1->row();
	$ct= $res1->ct;
	
	$comp=0;

	$week_dtl= $this->main_model->get_detail('master_weeks','week_id',$ress->week_id);
	$this->db->select('*'); 
	$this->db->from('master_goal');
	$this->db->where('term_id',$result->term_id);
	$this->db->where('year_id',$result->class_id);
	$this->db->where('week_id',$ress->week_id);
	$goal= $this->db->get()->row();
	$color_class=explode(',' ,$ress->week_id);
	$color_class=$color_class[0];
	$aveageweek++;
		/*---get Week Notes detail-------*/
	$query_notes=$this->db->query('select notes_file from master_weeknotes where week_id="'.$ress->week_id.'" and term_id="'.$ress->term_id.'" and year_id="'.$ress->year_id.'"');
	$row_notes=$query_notes->row();
	/*----end of week notes details-----*/
	?>
                  <div class="col-xs-12 col-sm-12 col-md-4 col-lg-4">
                    <div class="box-syllabus ">
                      <div class="text-content">
                        <ul>
                          <li>
                            <div class="row">
                              <div class="col-xs-8 col-sm-8 col-md-6 col-lg-8 col-8"><strong><?php echo $goal->goal_name;?></strong></div>
                              <div class="col-xs-4 col-sm-4 col-md-6 col-lg-4 col-4">
                                <h4 class="cyan_bg color-<?php echo $color_class;?>"><?php echo $week_dtl->week_name;?>
								<?php
								if($row_notes->notes_file!='')
								{
									echo '  <a href="'.base_url('assets/uploads/notes/'.$row_notes->notes_file).'">Notes</a>';
								}
								?>
								</h4>
                              </div>
                            </div>
                          </li>
                          <?php } $comp++; ?>
						   <?php
						 if($aveageweek <= $user_currentweek && $aveageweek <= $order_week)
						{
							?>
                          <a href="<?php echo base_url().strtolower($year_dtl->class_slug).'/'.$subskl_dtl->skill_slug;?>">
                          <li><strong><?php echo $order_arr[$result->skill_order].'.'.$ress->subskill_order;?></strong> <?php echo $subskl_dtl->skill_name;?></li>
                          </a>
						  <?php
						}
						elseif($this->session->userdata('user_id')=='1')
						{
						?>							
						<a href="<?php echo base_url().strtolower($year_dtl->class_slug).'/'.$subskl_dtl->skill_slug;?>">
                          <li><strong><?php echo $order_arr[$result->skill_order].'.'.$ress->subskill_order;?></strong> <?php echo $subskl_dtl->skill_name;?></li>
                          </a>
						  <?php
						}
						else
						{
							?>
						 <li><strong><?php echo $order_arr[$result->skill_order].'.'.$ress->subskill_order;?></strong> <?php echo $subskl_dtl->skill_name;?></li>	
						<?php
						}
?>						
                          <?php if(($ct==$comp) || ($ct2==$comp2)){?>
                        </ul>
                      </div>
                    </div>
                  </div>
                  <?php } $wid=$ress->week_id;?>
                  <?php } ?>
                </div>
              </div>
            </div>
            <?PHP } ?>
          </div>
        </div>
        <?PHP } ?>
      
      </div>
    </div>
  </div>
</section>
<?php include('footer.php'); ?>
