<?php include('header.php'); ?>

<section id="title-inner" style="background-image:url(<?= base_url('assets/images/contact-bg.jpg')?>);">
<div id="large-header">   
<canvas id="demo-canvas"></canvas>
<div class="container">
<div class="text-tit">
 <div class="bb"></div>
<span class="lefttop-icon"></span>
<h1>
<span>Membership-Plans</span>
</h1>
<span class="rightbotm-icon"></span>
</div>

</div></div>

</section>

<!-- Page Content inner -->
<div  class="about_content login-page forgot-password change-password content-text space-75">

<div class="container">
<div class="row">


<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">

<div class="row">
<?php
if($planlist)
{
	$userid=$this->session->userdata('user_id');
	
	
	$query_chkpro=$this->db->query("select * from student_promoted  where user_id='".$userid."' and pay_status='pending' order by  pid desc ");
	$num_chkpro=$query_chkpro->num_rows();
	if($num_chkpro > 0)
	{
		$yearchk=$query_chkpro->row();
		$payyear=$yearchk->promote_year;
	}
	else
	{
			$query_chkpro=$this->db->query("select promote_year from student_promoted  where user_id='".$userid."'  ");
			$yearchk=$query_chkpro->row();
			$payyear=$yearchk->promote_year;
	}
	
	$query_chkord=$this->db->query("select * from orders  where userid='".$userid."' and pay_status='confirm' and order_status='active' and year_id='".$payyear."' order by  orderid desc ");
	$num_chkord=$query_chkord->num_rows();
	foreach($planlist as $rowplan)
	{
?>	
	<div class="col-xs-12 col-sm-12 col-md-6 col-lg-6"> 
	<div class="box-syllabus">
	<div class="text-content">
	  <ul>
	  <li>
	  <h2><?php echo $rowplan->plan_name;?></h2>
	  </li>
	  <li>
	  $<?php echo number_format($rowplan->plan_price);?>
	  </li>
	  
	  <li>
	  <?php
	  if($num_chkord > 0)
	  {
?>
<a href="<?php echo  base_url();?>renew-payment/<?php echo $rowplan->planid;?>/<?php echo $payyear;?>" class="button">Buy Now</a>
<?php
	  }
else
{
?>	
	  <a href="<?php echo  base_url();?>paynow/<?php echo $rowplan->planid;?>/<?php echo $payyear;?>" class="button">Buy Now</a>
	  <?php
}
?>
	  <li>
	  </ul>
	</div>
	</div>
	</div>


<?php
	}
}
?>

</div>
</div>

</div>
</div>

</div>

 <!-- Page Content End -->
 <?php include('footer.php'); ?>
 <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>

<script type="text/javascript">
jQuery(document).ready(function(){

    jQuery('#reg_year').change(function(){
		
      var yearid=$('#reg_year').val();
            jQuery.ajax({
                type : 'POST',
                url : '<?php echo BASE_URL.'ajaxcall/yearsprice';?>',
                data : {yearid:yearid}
				,	
        success: function(result){
           // alert(result);
           jQuery( "#priceshow" ).html('Price $'+result);
		    jQuery("#yearprice").val(result);
        }


    });
    });    
});

</script>
