<section class="bannerSec subBann innerPage">		
		<div class="">
			<div class="container">
				<div class="innerBox quest">
					<h1><?php echo $year_dtl->class_name; ?></h1>										
				</div>
				<div class="bannRightBox innerBrBox">
					<ul class="tabBoxPagi text-right">
						<li>
							<span><a href="#">SKILLS</a></span> /
							<span class="tbActive">QUESTION</span>
						</li>
					</ul>
				</div>				
			</div>
		</div>
	</section>
		
	<section class="quesBox">
		<div class="container">
			<div class="row">
				<!--queston Box-->
				<div class="col-lg-10 col-md-9">
					<div class="quesBoxL">
						<?php if(isset($correct) && $correct==1){	?>
		<div id="infor">
		<h3>Fantastic</h3>
		</div>
		<?php }	?>
											
		<form  name="myForm" id="myForm"  method="post" action="" onsubmit="return validateForm()" >	
			
			
			<?php 

			if($Questionlist != null && $Questionlist != ""){
			?>
			<div id="question_list">
			<?php	
            		
				foreach($Questionlist as $result){
				    
					echo get_question($obj,$year_dtl->class_id,$result->ques_id);
				}
				?>
			
				</div>
		
				<button  class="btn-mn btn-3 btn-3e button-org"  id="btntestexam">Submit</button>
				
				<?php }
				else
				{ ?>
				  No Question found
				<?php } ?>
				
				
		</form>
					</div>
				</div>	
				<!--timing summary Box-->
				
				<div class="col-lg-2 col-md-3">
					<div class="summaryBox quesStates">
						<ul>
							<li>
								<h4>Questions answered</h4>
								<div class="questCount" id="textexamtotal">
									<h2>1</h2>
								</div>
							</li>
							<li class="timeElBox">
								<h4>Time elapsed</h4>
								<div class="questCount">
									<table class="timer" align="center">
										<tbody>
											<tr class="cd100">
												<td class="hours">00</td>
												<td class="minutes">00</td>
												<td class="seconds">37</td>
											</tr>									  
											<tr class="box-label">
												<th>hr</th>
												<th>min</th>
												<th>sec</th>
											</tr>
										</tbody>
									</table>
									     <!--  <div class="timeing">
   <ul id="showtimer">	 </ul>

 </div>-->
									
								</div>
							</li>
							<li class="scoreBox">
								<h4>SmartScore<span>out of 100 ?</span></h4>

								<div class="questCount">
									 <div class="number" id="testexampersent">0</div>
								</div>
							</li>
							
						</ul>
					</div>
				</div>
			</div>
			
			
			
		</div>
	</section>
	<style>
 .anslabel > input{ /* HIDE RADIO */
  visibility: hidden; /* Makes input not-clickable */
  position: absolute; /* Remove input from document flow */
}
.anslabel > input + img{ /* IMAGE STYLES */
  cursor:pointer;
  border:2px solid transparent;
  border-radius:10px;
  padding:0px;
}
.anslabel > input:checked + img{ /* (RADIO CHECKED) IMAGE STYLES */
  border:2px solid #1278a6;
   padding:0px;
}

.anslabel > input + div{ /* IMAGE STYLES */
  cursor:pointer;
  border:2px solid #00a7dc;
  border-radius:10px;
  padding:10px;
}
.anslabel > input:checked + div{ /* (RADIO CHECKED) IMAGE STYLES */
  border:2px solid #1278a6;
   padding:10px;
}
 </style>
 
 <script>
  $("#a1").click(function(event) {
    this.removeAttribute("href");            
    anchorClicked("a1");
  });
  
  $( document ).ready(function() {
    $("#infor").delay(1000).fadeOut("slow");
});

function validateForm() {
    var x = document.forms["myForm"]["answerid"].value;
	
    if (x == "") {
        var r = confirm("You did not complete the question.Are you sure you want to submit?!");
		if (r == true) {
			return true;
		} else {
			return false;
		}
    }
}
 </script>

    
 <!-- Page Content End -->
<?php //include('footer.php'); ?>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script>  
 <script>

 $('#btntestexam').click(function(event) {
    /* for (instance in CKEDITOR.instances) {
        CKEDITOR.instances[instance].updateElement();
    } */
	 form = $("#myForm").serialize();
     console.log(form);
		// form = new FormData(this);

	var ques_type=$('input[name="ques_type"]').val();
	ques_type = "["+ques_type+"]";
	parsedText = JSON.parse(ques_type)

	if(parsedText[0]=='1'){
		var x = document.forms["myForm"]["answerid"].value;
		if (x==""){
		   return false;
		}
	}
	else if(parsedText[0]=='22'){
		var val = [];
		$("input[name='answerid[]']:checked").each( function (i) {
          val[i] = $(this).val();
        });
		if(val==""){
			return false;
		}
		
	}	
	else if(parsedText[0]=='26' || parsedText[0]=='32'){
		var x = document.forms["myForm"]["input1"].value;
		if (x==""){
		   return false;
		}
		
	  var atr = $("input[name='input1']").attr('type');
	  if(atr=='checkbox'){
		 var val = [];
		//$("input[type='checkbox']:checked").each( function (i) {
			$("input[type='radio']:checked").each( function (i) {
          val[i] = $(this).val();
        });
		if(val==""){
			return false;
		}
	  }
	}	
     $.ajax({
       type: "POST",
       url: "<?php echo site_url('ajaxcall/ajax_testexam/'.$this->uri->segment(1)); ?>",
       data: form,	  

       success: function(data){
         
		    $('#question_list').html(data);
       }

     });
     event.preventDefault();
     return false;  //stop the actual form post !important!

  });
</script>
<script>
/*// Set the date we're counting down to
var d1 = new Date (),
    d2 = new Date ( d1 );
d2.setMinutes ( d1.getMinutes() + 30 );

var countDownDate = d2.getTime();

// Update the count down every 1 second
var x = setInterval(function() {

  // Get todays date and time
  var now = new Date().getTime();

  // Find the distance between now and the count down date
  var distance = countDownDate - now;

  // Time calculations for days, hours, minutes and seconds
  var days = Math.floor(distance / (1000 * 60 * 60 * 24));
  var hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
  var minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
  var seconds = Math.floor((distance % (1000 * 60)) / 1000);

  // Display the result in the element with id="demo"
/*  document.getElementById("demo").innerHTML = days + "d " + hours + "h "
  + minutes + "m " + seconds + "s ";*/
    //document.getElementById("showtimer").innerHTML = hours + "H: "  + minutes + "m: " + seconds + "s ";
    document.getElementById("showtimer").innerHTML = '<li><input type="text" placeholder="'+hours+'" /><label>hr</label></li><li><input type="text" placeholder="'+minutes+'" /><label>min</label></li><li><input type="text" placeholder="'+seconds+'" /><label>sec</label></li>';
  /*/ If the count down is finished, write some text
  if (distance < 0) {
    clearInterval(x);
    document.getElementById("showtimer").innerHTML = "Time is Over!";
  }
}, 1000);*/


var h1 = document.getElementsByTagName('h1')[0],
    start = document.getElementById('start'),
    stop = document.getElementById('stop'),
    clear = document.getElementById('clear'),
    seconds = 0, minutes = 0, hours = 0,
    t;

function add() {
    seconds++;
    if (seconds >= 60) {
        seconds = 0;
        minutes++;
        if (minutes >= 60) {
            minutes = 0;
            hours++;
        }
    }
    
    //h1.textContent = (hours ? (hours > 9 ? hours : "0" + hours) : "00") + ":" + (minutes ? (minutes > 9 ? minutes : "0" + minutes) : "00") + ":" + (seconds > 9 ? seconds : "0" + seconds);
document.getElementById("showtimer").innerHTML = '<li><input type="text" placeholder="'+hours+'" /><label>hr</label></li><li><input type="text" placeholder="'+minutes+'" /><label>min</label></li><li><input type="text" placeholder="'+seconds+'" /><label>sec</label></li>';
    timer();
}
function timer() {
    t = setTimeout(add, 1000);
}
timer();


/* Start button */
start.onclick = timer;
</script>
 <script>
       
        CKEDITOR.replace( 'question_name1', {
            height: 10,
			
            filebrowserUploadUrl: '<?php echo BASE_URL_ADMIN."questions/upload/".$year?>',
			  toolbarCanCollapse : true,                  

              allowedContent: true, 
			  toolbar: [            
            ['ckeditor_wiris_formulaEditor', 'ckeditor_wiris_formulaEditorChemistry', 'ckeditor_wiris_CAS']
        ],
		
            
        } );
    </script>
