<?php include('header.php'); ?>

<!-- Page Content inner -->


<section class="about_content content-text space-75 space-top-0">
  <br>
 <br>
 <div class="container">
 <h1>Students Exam Sheet</h1>
 <?php
 if($exam_details)
 {
	 foreach($exam_details as $rowexam)
	 {
		    $user_query=$this->db->query("select user_id,first_name,last_name,dob from user_details where user_id='".$rowexam->user_id."' "); 
			$result_user=$user_query->row();
	 
	 
 ?>
 <div class="row">

  <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
   <div class="row">
   <div class="col-md-6 col-sm-6">
    <table class="table table-striped table-light">
	<tr>
	<td><strong>Student ID</strong></td>
	<td><?php echo $rowexam->user_id;?></td>
	</tr>
	<tr>
	<td><strong>First Name</strong></td>
	<td><?php echo $result_user->first_name;?></td>
	</tr>
	<tr>
	<td><strong>Last Name</strong></td>
	<td><?php echo $result_user->last_name;?></td>
	</tr>
	<tr>
	<td><strong>Reporting Period</strong></td>
	<td>Term <?php echo $rowexam->term_id;?></td>
	</tr>
	</table>
   </div>
     <div class="col-md-6 col-sm-6">
	 <table class="table table-striped table-light">
	<tr>
	<td><strong>Date</strong></td>
	<td><?php if($rowexam->exam_date!="")
	{	
		echo date("d M Y", strtotime($rowexam->exam_date));
		
	}?></td>
	</tr>
	<tr>
	<td><strong>Year</strong></td>
	<td><?php 
	if($rowexam->year_id==1)
	{
	echo 'kindergarten';
	}
	else	
	{
		echo $rowexam->year_id;
	}
	?></td>
	</tr>
	<tr>
	<td><strong>Date  of  Birth</strong></td>
	<td><?php 
	if($result_user->dob!="")
	{	
		echo date("d M Y", strtotime($result_user->dob));
		
	}
	
	?></td>
	</tr>
	<tr>
	<td><strong>Total Gade</strong></td>
	<td><?php 
	 $examhquery=$this->db->query("select count(*) as totalquestion from sexam_history where exam_id='".$rowexam->exam_id."' "); 
		   $ehistoryrow=$examhquery->row();
		   $totalquestion=$ehistoryrow->totalquestion;
		   $queryrightcount="select count(*) as totalright from sexam_history where exam_id='".$rowexam->exam_id."' and answer_status='true'  ";
		  
		   $examhquery1=$this->db->query($queryrightcount); 
		   $exrightquestion=$examhquery1->row();
		   // var_dump($resultexam);
		    $totalright=$exrightquestion->totalright;
			$calper=($totalright/$totalquestion)*100;
	 echo $totalright.'/'.$totalquestion.' ('.number_format($calper).'%)';
	?></td>
	</tr>
	
	</table>
   </div>
  
</div>
 </div>
 
 </div>
<?php


	 }
}
?> 
 </div>
  <div  class="container" style="background-color: #fecc98;height: 35px">
 	<div  style="padding-top: 5px; "><b style="font-size: 20px">Summary</b></div>

 </div>
 <div class="container">
 	<div style="margin-top: 25px;margin-bottom: 25px;"><b><span style="color: #6eb72f;font-size: 20px;" >Total number of stars for 4 semester milestone assessment test is 18.</span></b></div>
 </div>
 <div  class="container" style="background-color: #ffff99;height: 35px">
 	<div  style="padding-top: 5px; "><b style="font-size: 25px">Term <?=$rowexam->term_id;?>:<span style="color: #6eb72f; font-family: initial ;
    font-size: 25px" >   Semester Milestone test</span></b></div>

 </div>
 <div class="container">
 	
 	<table class="table">
 		<thead>
 			<tr>
 				<th style="border-bottom: 1px solid #1a1b1d;">Attempts</th>
 				<th style="border-bottom: 1px solid #1a1b1d;">Date</th>
 				<th style="border-bottom: 1px solid #1a1b1d;">Time</th>
 				<th style="border-bottom: 1px solid #1a1b1d;">Total Questions</th>
 				<th style="border-bottom: 1px solid #1a1b1d;">Score</th>
 				<th style="border-bottom: 1px solid #1a1b1d;">Percentage (%)</th>
 			</tr>
 		</thead>
 		<?php
 		 $data=array('user_id'=>$this->session->userdata('user_id'));
 		 $query1=$this->db->where($data)->limit(5)->get('student_exam');
 		
 	
 		?>
 		<tbody>
 			<?php
 			$i=1;
 				$calc=array();
 				foreach ($query1->result() as $value) 
 				{
 					$data=array('user_id'=>$this->session->userdata('user_id'),'attempt'=>$value->attempt);
		 			$abc=$this->db->where($data)->get('sexam_history');
 				?>
 					<tr>
 					<td><?=$value->attempt?></td>
 					<td><?=date("d M Y", strtotime($value->exam_date));?></td>
 					<td><?=date("i:s", strtotime($value->duration));?></td>
 					<td><?=($abc->num_rows());?></td>
 					<?php 
 						$data=array('user_id'=>$this->session->userdata('user_id'),'attempt'=>$value->attempt,'answer_status'=>'true');
 					?>
 					<td><?= $totalright=$this->db->where($data)->get('sexam_history')->num_rows().'/'.$totalquestion=$abc->num_rows();?></td>
 					<?PHP 
							$calper=($totalright/$totalquestion)*100;
							?>
 					<td><?=number_format($calper).'% <pre>'; ?></td>
 				</tr>
 				<?php 
 				
 					array_push($calc, array('per'=>$calper,'totalright'=>$totalright,'totalquestion'->$totalquestion,'date'=>$value->exam_date));
 				$i++; 
 			}
 			?>
 		</tbody>
 	</table>
 	
 	<b><u><span>Analysis (using most recent data) </span></u></b>
 	<div>
 		<table >
 		<thead>
 			<tr>
 				<th style="border-bottom: 1px solid #1a1b1d; width: 150px;">Lowest Score</th>
 				<th style="border-bottom: 1px solid #1a1b1d;width: 150px;">Percentage(%)</th>
 				<th style="border-bottom: 1px solid #1a1b1d;width: 100px;">Date</th>
 				
 			</tr>
 		</thead>
 		<tr>
 		<td style="width: 150px;"><?=$calc[get_min($calc)]['totalright']?>	</td>
 				<td style="width: 150px;"><?= round($calc[get_min($calc)]['per'])?>%</td>
 				<td style="width: 100px;"><?=date('d M y',strtotime($calc[get_min($calc)]['date'])) ?></td>
 			</tr>
 		<tbody>
 			
 		</tbody>
 	</table>
 	</div>
 		<br>
 		<div>
 		<table >
 		<thead>
 			<tr>
 				<th style="border-bottom: 1px solid #1a1b1d; width: 150px;">Highest Score</th>
 				<th style="border-bottom: 1px solid #1a1b1d;width: 150px;">Percentage(%)</th>
 				<th style="border-bottom: 1px solid #1a1b1d;width: 100px;">Date</th>
 				
 			</tr>
 		</thead>
 		
		<?php
			 
		?>	
		
		<tr>
 		<td style="width: 150px;"><?=$calc[getmax($calc)]['totalright']?>	</td>
 				<td style="width: 150px;"><?= round($calc[getmax($calc)]['per'])?>%</td>
 				<td style="width: 100px;"><?=date('d M y',strtotime($calc[getmax($calc)]['date'])) ?></td>
 			</tr>
 			
 			
 		<tbody>
 			
 		</tbody>
 	</table>
 	</div>
 		<br>
 		<div>
 		<table >
 		<thead>
 			<tr>
 				<th style="border-bottom: 1px solid #1a1b1d; width: 150px;">Mean Score</th>
 				<th style="border-bottom: 1px solid #1a1b1d;width: 150px;">Median Score</th>
 				<th style="border-bottom: 1px solid #1a1b1d;width: 100px;">Mode Score</th>
 				
 			</tr>
 		</thead>
 		<?PHP 
 		?>
 		<td style="width: 150px;"><?= round(mean($calc)); ?>%</td>
 				<td style="width: 150px;"><?=round( median($calc),2);?>%</td>
 				<td style="width: 100px;"><?=Mode($calc)[0]?>%</td>
 		<tbody>
 			
 		</tbody>
 	</table>
 	</div>
 		<br>
 <span><b>Grade (Highest  <?php echo $calc[getmax($calc)]['per'];?>%) </b></span>
 	<?php
 	$star_p=$calc[getmax($calc)]['per'];
 	if(1>=$star_p||$star_p<=49)
 	{
 		$star=1;
 	}elseif (50>=$star_p||$star_p<=79) {
 		$star=2;
 	}elseif (80>=$star_p||$star_p<=89) {
 		$star=3;
 	}elseif (90>=$star_p||$star_p<=99) {
 		$star=4;
 	}else{
 		$star=5;
 	}
 	echo '<p>';
    for($i=0;$i<$star;$i++)
    {
    	echo '<img style="height: 61px" src="'.base_url('assets/star/img.png').'">';
    }
echo '</p>';
 	?>
 </div>
 </section>
<?php


	
function getMax( $array )
{
    $max = 0;
    foreach( $array as $k => $v )
    {
        $max = max( array( $max, $v['per'] ) );
        
    }
    foreach ($array as $key => $val) 
    {
       if ($val['per'] === $max) 
       {

           	 $abc=$key;
       }
   }
    return $abc;
} 

  
    //echo min($min);

function get_min($array)
{
	$min = array();
    foreach( $array as $k => $v )
    {
    	array_push($min,$v['per']);
    }
  foreach($min as $k => $v )
    {
    	if($v==min($min))
    	{
    		
    		return $k;	
    	}
    	
    }
}
   
   
function mean($array)
{
	$total=0;
    foreach( $array as $k => $v )
		    {
		        $total=$total+$v['per'];
		         $total.'<br>';
		    }
	 $mean=round($total)/count($array);
	 return $mean;
}
   


function median($array) {

	$arr=array();
	foreach ($array as $key => $value) {
		array_push($arr, $value['per']);
	}

    $count = count($arr);
    $middleval = floor(($count-1)/2); 
    if($count % 2) 
    { 
        $median = $arr[$middleval];
    } 
    else
    { 
        $low = $arr[$middleval];
        $high = $arr[$middleval+1];
        $median = (($low+$high)/2);
    }
    return $median;
}
  

function mode($array)
{
	$arr=array();
	foreach ($array as $key => $value) 
	{
	array_push($arr, intval(round($value['per'])));
	}
	

$values = array_count_values($arr);

if($values)
{

$popular = array_slice(array_keys($values), 0, 1, true);
}

return $popular;
}



   ?>
    
 <!-- Page Content End -->
<?php include('footer.php'); ?>