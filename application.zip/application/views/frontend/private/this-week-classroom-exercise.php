<?php error_reporting(E_ALL);
ini_set('display_errors','0');?>
<?php include('header.php'); ?>

<section id="title-inner" class="bgcolor-text">
<canvas id="demo-canvas"></canvas>
<div class="container">
<div class="text-tit">
<h1>
<span>This Week Classroom Exercise</span>
</h1>
</div>

</div>
</section>
<!-- Page Content inner -->

<?php
 global $order_arr;
 


 ?>
 <section class="about_content content-text page-classroom-exercise space-75">
 <div class="container">
 <div class="row">
 
 <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
    <?php
	
	
	
   $query_ord=$this->db->query("select plan_id,order_date,order_week from orders where userid = '".$this->session->userdata('user_id')."'  and order_status='active' and pay_status='confirm' order by orderid desc"); 
	$num_ord= $query_ord->num_rows();
	if($num_ord > 0){
	 $query_ordweek=$this->db->query("select * from order_weeks where ordweek_userid = '".$this->session->userdata('user_id')."'  
	 and ordweek_yearid='".$year_id."' and ordweek_termid='".$term_id."' 
	 and ordweek_weekid='".$userweek."' and ordweek_paystatus='confirm' "); 
	 $num_ordweek= $query_ordweek->num_rows();			
	 if($num_ordweek > 0) 
				{
					
					
			$query_chk_cls_schdl=$this->db->query("select s.*,cb.week_id,cb.class_schdl_date from seat_allotment_info s INNER JOIN classroom_booking cb ON s.classroom_booking_id=cb.id where s.user_id='".$this->session->userdata('user_id')."' and  cb.week_id='".$userweek."' and  cb.term_id='".$term_id."'");

			$num_cls_schdl=$query_chk_cls_schdl->num_rows();
			if($num_cls_schdl > 0)
			{
			$row_cls_schdl=$query_chk_cls_schdl->row();	
			$row_cls_schdl_dtl=	$this->main_model->get_detail('class_schedule','id',$row_cls_schdl->class_schdl_id);
			if($row_cls_schdl_dtl->day==date('w')){

			$row_cls_schdl_time=$this->main_model->get_detail('weekday_time','id',$row_cls_schdl_dtl->time);
			$current_time=date('H:i:s');
			if(($row_cls_schdl_time->class_time!="") && (strtotime($row_cls_schdl_time->class_time)<=strtotime($current_time))) {
   
?>	
   <div class="tab-content">
    <?php 
      if($SylList1 != null && $SylList1 != ""){
			global $order_arr;
			$tid=0;$wid=0;
									?>
        <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
          <h2 class="blue-title">Term <?php echo $term_id;?></h2>
          <div class="row">
            <?php 
			
			$userweek=$userweek;
			$aveageweek=0;
			/*  echo '<pre>';
			var_dump($SylList1);
			echo '</pre>';  */
			$countweek=1;
			
			foreach($SylList1 as $result){
			
	
	$sql_term=$this->db->query("select * from master_terms where term_id = '".$term_id."' "); 
	$term=$sql_term->row();
	
	$sql_dt1=$this->db->query("select * from master_skill where skill_id = '".$result->skill_id."' "); 
	$skl_dtl=$sql_dt1->row();
	
	$sql_syllab=$this->db->query("select * from master_syllabus where skill_id = '".$result->skill_id."' and class_id='".$year_id."' and term_id='".$term_id."'"); 
	$row_syllab=$sql_syllab->row();
	
	$query=$this->db->query('select * from syllabus_week_subskill where skill_id = "'.$result->skill_id.'" and week_id = "'.$userweek.'"'); 
	 $ct2= $query->num_rows();
	$comp2=0;
	if($countweek==1)
	{
			//echo 'select * from syllabus_week_subskill where skill_id = "'.$result->skill_id.'" and week_id = "'.$userweek.'"';
		?>
            <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
              <div class="syllabus-sec">
                <h3><?php echo $order_arr[$row_syllab->skill_order].'. '.$skl_dtl->skill_name;?></h3>
                <div class="row">
                  <?php 

	foreach($query->result() as $ress){
	
	$subskl_dtl= $this->main_model->get_detail('master_skill','skill_id',$ress->subskill_id);
	$comp2++;
	?>
    <?php if($wid!=$ress->week_id || $comp2==1){
	
	$query1=$this->db->query('select count(*) as "ct" from syllabus_week_subskill where week_id="'.$userweek.'" and term_id="'.$ress->term_id.'" and year_id="'.$ress->year_id.'"');
	$res1=$query1->row();
	$ct= $res1->ct;
	
	$comp=0;

	$week_dtl= $this->main_model->get_detail('master_weeks','week_id',$ress->week_id);
	$sql_goal=$this->db->query('select * from master_goal where week_id="'.$userweek.'" and term_id="'.$term_id.'" and year_id="'.$year_id.'"');
	$goal= $sql_goal->row();
	$color_class=explode(',' ,$ress->week_id);
	$color_class=$color_class[0];
	$aveageweek ++;
	
	?>
                  <div class="col-xs-12 col-sm-12 col-md-4 col-lg-4">
                    <div class="box-syllabus">
                      <div class="text-content">
                        <ul>
                          <li>
                            <div class="row">
                              <div class="col-xs-8 col-sm-8 col-md-6 col-lg-8 col-8"><strong><?php echo $goal->goal_name;?></strong></div>
                              <div class="col-xs-4 col-sm-4 col-md-6 col-lg-4 col-4">
                                <h4 class="cyan_bg color-<?php echo $color_class;?>"><?php echo $week_dtl->week_name;?>
								</h4> 
                              </div>
                            </div>
                          </li>
                          <?php } $comp++; ?>
                        					
						 <?php
							
							$sqlchk_examlast=$this->db->query("select exam_id,exam_status from student_classexcerise  where user_id='".$this->session->userdata('user_id')."' and skill_id='".$subskl_dtl->skill_id."' 
							and year_id='".$year_id."'  order by exam_id desc ");
							$row_chkexam_id=$sqlchk_examlast->row();
							$lastexam_id=$row_chkexam_id->exam_id;
							$data['lastexam']=$lastexam_id;
							$lastexam_status=$row_chkexam_id->exam_status;
							
							if($lastexam_status=="pass")
							{
							?>				
								 <a href="<?php echo base_url().'classroom-exercise/'.$subskl_dtl->skill_slug;?>" target="_blank">
								  <li style="color:#b7aaaa;"><strong style="color:#b7aaaa;"><?php echo $order_arr[$row_syllab->skill_order].'.'.$ress->subskill_order;?></strong> <?php echo $subskl_dtl->skill_name;?><img style="width: 20px;" src="<?='/assets/star/g1.ico'?>"></li>
								  </a>
							<?php }else{ ?>
									<a href="<?php echo base_url().'classroom-exercise/'.$subskl_dtl->skill_slug;?>" target="_blank">
								  <li><strong><?php echo $order_arr[$row_syllab->skill_order].'.'.$ress->subskill_order;?></strong> <?php echo $subskl_dtl->skill_name;?></li>
								  </a>
							<?php }?>
						  
							
                          <?php if(($ct==$comp) || ($ct2==$comp2)){?>
                        </ul>
                      </div>
                    </div>
                  </div>
                  <?php } $wid=$ress->week_id;?>
                  <?php } ?>
                </div>
              </div>
            </div>
            <?PHP 
			}
			$countweek++;
			} ?>
          </div>
        </div>
        <?PHP } ?>
   </div>
   <?php 
   }else{
			
			$class_date_time = date('Y-m-d h:i A',strtotime($row_cls_schdl->class_schdl_date));
			
			echo 'Your class will start at '.$class_date_time;
		}
		}
		else{
		
			$class_date_time = date('Y-m-d h:i A',strtotime($row_cls_schdl->class_schdl_date));
			
			echo 'Your class will start at '.$class_date_time;	
			
		}
		}
		else{
			
			
			$query_chk_cls_schdl=$this->db->query("select s.*,cb.id,cb.week_id,cb.class_schdl_date from seat_allotment_info s INNER JOIN classroom_booking cb ON s.classroom_booking_id=cb.id where s.user_id='".$this->session->userdata('user_id')."' and cb.class_schdl_date>CURDATE() order by cb.class_schdl_date asc LIMIT 1");
			$num_cls_schdl=$query_chk_cls_schdl->num_rows();
			if($num_cls_schdl > 0)
			{
				$row_cls_schdl=$query_chk_cls_schdl->row();	
				$class_date_time = date('Y-m-d h:i A',strtotime($row_cls_schdl->class_schdl_date));
			
			echo 'Your class will start at '.$class_date_time;	
		
			}
			else{
				echo "You don't have any class in future";	
			}
		}
   } 
   else
   { 
	if($nobuyplan=='1')
	{	
	 
	   echo '<p style="color:red;">Please make payment of current week.</p><p><a href="'.BASE_URL.'membership-plan" style="font-weight:bold;">Pay Now</p><br/>';
	}
	else
	{
		echo '<p style="color:red;">Your Plan has been expired,please make payment of current week.</p>
		<p><a href="'.BASE_URL.'membership-plan" style="font-weight:bold;">Pay Now</p><br/>
		';
	}
   }
   
   } 
   else
   { 
	if($nobuyplan=='1')
	{	
	 
	   echo '<p style="color:red;">Please make payment of current week.</p><p><a href="'.BASE_URL.'membership-plan" style="font-weight:bold;">Pay Now</p><br/>';
	}
	else
	{
		echo '<p style="color:red;">Your Plan has been expired,please make payment of current week.</p>
		<p><a href="'.BASE_URL.'membership-plan" style="font-weight:bold;">Pay Now</p><br/>
		';
	}
   }
   ?>
 
 
 </div>
 
 
 
 
 </div>
 </div>
 </section>
 
 
   
   
   
   
   
   
    
 <!-- Page Content End -->
<?php include('footer.php'); ?>