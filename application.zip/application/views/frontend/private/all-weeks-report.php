<?php include('header.php'); ?>

<!-- Page Content inner -->
<section id="title-inner" class="bgcolor-text">
<canvas id="demo-canvas"></canvas>
<div class="container">
<div class="text-tit">
<h1>
<span>All Weeks Report</span>
</h1>
</div>

</div>
</section>

 
 <section class="about_content content-text analysis-report space-75">
 <div class="container">
 <div class="row">
 
<?php
function week_between_two_dates($date1, $date2)
{
    $first = DateTime::createFromFormat('m/d/Y', $date1);
    $second = DateTime::createFromFormat('m/d/Y', $date2);
    if($date1 > $date2) return week_between_two_dates($date2, $date1);
    return floor($first->diff($second)->days/7);
}

$dt1 = $termdate;
$dt2 = date('m/d/Y');
$calweek= week_between_two_dates($dt1, $dt2);
if($calweek > 0)
{
$days="";
$days1="";	
for($i=1; $i <= $calweek;$i++)
{
$days=7*$i;
$days1=$days+1;
$nextdate=date('Y-m-d',strtotime("+".$days." day", strtotime($dt1)));
$sqlcmonth=$this->db->query("select exam_id as creportmonth from student_classexcerise  where 
				user_id='".$this->session->userdata('user_id')."' and year_id='".$year_id."' and exam_status='pass' 
				and (`exam_date` >=  '".$dbdate."'
      AND `exam_date`  <  '".$dbdate."' + INTERVAL ".$days1." DAY)");
$num_cmonth=$sqlcmonth->num_rows();

$sqlhmonth=$this->db->query("select exam_id as hreportmonth from student_homeworktest  where 
				user_id='".$this->session->userdata('user_id')."' and year_id='".$year_id."' and exam_status='pass' 
				 and (`exam_date` >=  '2018-11-12'
      AND `exam_date`  <  '2018-11-12' + INTERVAL ".$days1." DAY)");
$num_hmonth=$sqlhmonth->num_rows();

if($num_cmonth > 0 || $num_hmonth > 0)
{

?>

<div class="col-xs-12 col-sm-4 col-md-4 col-lg-4">
<a href="<?php echo base_url().'weekly-report/'.$i;?>" class="btn-mn btn-3 btn-3e ans-btn"><?php echo 'Week'.$i;?></a>
</div>

<?php
		}
}
	
}
else
{
echo '<br/><br/><p class="error" align="center">No report found .<br/>
		<a href="'.base_url().'analysis-report"><strong>Go Back</strong></a></p>';	
}


?>


 
 
 
 
 </div>
 </div>
 </section>
 
 
   
   
   
   
   
   
    
 <!-- Page Content End -->
<?php include('footer.php'); ?>