<?php include('header.php'); ?>
<?php
    /*Just for your server-side code*/
  
?>
<?php  $img=ucfirst($year_dtl->class_slug.'_bg.jpg');?>


<section id="title-inner" class="bgcolor-text">
<canvas id="demo-canvas"></canvas>
<div class="container">
<div class="text-tit">
<h1>
<span>Class Room Exercise of <?php echo $subskill; ?></span>
</h1>
</div>

</div>
</section>

 <!-- Page Content inner -->
     <?php
					$sql_total_attempt=$this->db->query("select count(exam_id) as totalexam from  student_classexcerise  where user_id='".$this->session->userdata('user_id')."' and skill_id='".$skill_id."' 
							and year_id='".$year_id."'  ");
					$row_total_attempt=$sql_total_attempt->row();
					$total_attempt_exam=$row_total_attempt->totalexam;
				
				$sqlattques=$this->db->query("select count(hid) as totalattentquestion from student_classexcerise_history  where user_id='".$this->session->userdata('user_id')."' and skill_id='".$skill_id."' 
							and year_id='".$year_id."' and exam_id='".$lastexam."'  ");
				$row_attendq=$sqlattques->row();
				$totalattent=$row_attendq->totalattentquestion;
				
				$queryrightcount="select count(*) as totalright from student_classexcerise_history where user_id='".$this->session->userdata('user_id')."' and skill_id='".$skill_id."' 
					and year_id='".$year_id."'  and answer_status='true'  and exam_id='".$lastexam."'   ";
	
				$examhquery1=$this->db->query($queryrightcount); 
				$exrightquestion=$examhquery1->row();		 
				$totalright=$exrightquestion->totalright;					
				$calper=($totalright/20)*100;
				$textper_marks=number_format($calper);
						?>
 
 <section class="about_content content-text syllabus-page space-75 space-top-0 page-answer">
 <div class="container">
 <div class="row">
<!-- Bootstrap Tabs -->
	<div class="col-xs-12 col-sm-12 col-md-9 col-lg-9">
    <div class="tab-content space-top-75"> 
											

		<?php if(isset($correct) && $correct==1){	?>
		<div id="infor">
		<h3>Fantastic</h3>
		</div>
		<?php }	?>
											
		<form  name="myForm" id="testexmfrm"  method="post" action="" onsubmit="return validateForm()">	
			
			
			<?php 
			if($ctest_completed!='1' && $total_attempt_exam < 5)
			{	
			if($Questionlist != null && $Questionlist != ""){
			?>
			<div id="question_list">
<?php			
			  foreach($Questionlist as $result){
			
				  $result->ques_subskillid;
				// echo $result->ques_type;
				 $ques_type=explode(',',$result->ques_type);
				
				if(in_array(1,$ques_type)){  
					if(in_array(26,$ques_type))
					{
					$QuesDecoded = base64_decode($result->ques_name); 
					echo $QuesDecoded;
					}else{
					echo '<p>'.$result->ques_name.'</p>';
					}
					echo '<br>';
					
				
					$answers=$this->questions_model->get_answers($result->ques_id);
					foreach($answers as $answer){
					
					if($answer->has_image==1){
					echo '<a id ="a1" class="quiz-btn" href="javascript:alert(default functionality)"><input name="answerid" value="'.$answer->ans_id.'" name="rb" type="radio" id="rb1"><label><img src="'.$answer->ans_name.'" /></label></a>&nbsp;&nbsp;&nbsp;';	
					
					}
					else{
					echo '<a id ="a1" class="quiz-btn" href="javascript:alert(default functionality)"><input name="answerid" value="'.$answer->ans_id.'" name="rb" type="radio" id="rb1"><label>'.$answer->ans_name.'</label></a>&nbsp;&nbsp;&nbsp;';
					}
					
					}
					
				
				}
				elseif(in_array(3,$ques_type)){ 
					
					echo '<p>'.$result->ques_name.'</p>';
					echo '<br>';
					$imgs=$this->main_model->getall('ques_img','ques_id',$result->ques_id);

					$answers=$this->questions_model->get_answers($result->ques_id);
					foreach($answers as $answer){
						
					echo '<a id ="a1" class="quiz-btn" href="javascript:alert(default functionality)"><input name="answerid" value="'.$answer->ans_id.'" name="rb" type="radio" id="rb1"><label>'.$answer->ans_name.'</label></a>&nbsp;&nbsp;&nbsp;';
					}
					
				
				}
				elseif(in_array(4,$ques_type)){ 
					
					echo '<p>'.$result->ques_name.'</p>';
					echo '<br>';
					$imgs=$this->main_model->getall('ques_img','ques_id',$result->ques_id);

					foreach($imgs as $img){

					echo '<img src="http://dev.theuniversityofmaths.com/assets/uploads/ans/'.$img->img.'"/>';
					}
					echo '<br>';
					$answers=$this->questions_model->get_answers($result->ques_id);
					foreach($answers as $answer){
						
					echo '<a id ="a1" class="quiz-btn" href="javascript:alert(default functionality)"><input name="answerid" value="'.$answer->ans_id.'" name="rb" type="radio" id="rb1"><label>'.$answer->ans_name.'</label></a>&nbsp;&nbsp;&nbsp;';
					} 
					
				
				}
				elseif(in_array(5,$ques_type))
				{
					echo '<p>'.$result->ques_name.'</p>';
					echo '<br>';
					$imgs=$this->main_model->getall('ques_img','ques_id',$result->ques_id);

					
					$answers=$this->questions_model->get_answers($result->ques_id);
					foreach($answers as $answer){
					
					if($answer->has_image==1){ 
						
					
						
					echo '<label class="anslabel"><input name="answerid" value="'.$answer->ans_id.'" name="rb" type="radio" id="rb1"><img src="/assets/uploads/ans/'.$answer->ans_name.'" class="border-none" /></label>&nbsp;&nbsp;&nbsp;';
					}
						
					}
					
				}
				elseif(in_array(6,$ques_type))
				{
					echo '<p>'.$result->ques_name.'</p>';
					echo '<br>';
					$imgs=$this->main_model->getall('ques_img','ques_id',$result->ques_id);
					foreach($imgs as $img){
					for($i=0;$i<$img->repeat;$i++){
					echo '<img src="http://dev.theuniversityofmaths.com/assets/uploads/ans/'.$img->img.'"/>';
					}
					echo '<br>';
					}
				
					
					$answers=$this->questions_model->get_answers($result->ques_id);
					foreach($answers as $answer){
					
					echo '<label class="anslabel"><input name="answerid" value="'.$answer->ans_id.'" name="rb" type="radio" id="rb1"><div class="quiz-btn">'.$answer->ans_name.'</div></label>&nbsp;&nbsp;&nbsp;';
						
					}
					
				}
				
				elseif(in_array(25,$ques_type)){ 
					
					echo'<p>'.$result->ques_name.'</p>';
					echo '<br>';
					$imgs=$this->main_model->getall('ques_img','ques_id',$result->ques_id);

					
					echo '<br>';
					$answers=$this->questions_model->get_answers($result->ques_id);
					foreach($answers as $answer){
						
					echo '<a id ="a1" class="quiz-btn" href="javascript:alert(default functionality)"><input name="answerid" value="'.$answer->ans_id.'" name="rb" type="radio" id="rb1"><label>'.$answer->ans_name.'</label></a>&nbsp;&nbsp;&nbsp;';
					}
					
				
				}
				
			
				elseif(in_array(22,$ques_type))
				{ 
					if(in_array(26,$ques_type)){
					$QuesDecoded = base64_decode($result->ques_name); 
					}
					else{$QuesDecoded =$result->ques_name; }
					echo $QuesDecoded;
					echo '<br>';
					$answers=$this->questions_model->get_answers($result->ques_id);
					foreach($answers as $answer){
						
					echo '<a id ="a1" class="quiz-btn" href="javascript:alert(default functionality)"><input name="answerid" value="'.$answer->ans_id.'" name="rb" type="checkbox" id="rb1"><label>'.$answer->ans_name.'</label></a>&nbsp;&nbsp;&nbsp;';
					}
					echo $result->ques_rightanswer;
					
				
				}
				elseif(in_array(26,$ques_type))
				{
					$QuesDecoded = base64_decode($result->ques_name); 
					echo $QuesDecoded;
					echo '<br>';
					$answers=$this->questions_model->get_answers($result->ques_id);
					foreach($answers as $answer){
						echo $answer->ans_name;
				
					}
					
				
				}
				else{ 
				echo '<p>'.$result->ques_name.'</p>';
				echo '<br>';
					$answers=$this->questions_model->get_answers($result->ques_id);
					foreach($answers as $answer){
						
					echo $answer->ans_name;
					}
					
				}
				}
				?>
			
				<div>
					<input type="hidden" name="questionid" value="<?php echo $result->ques_id;?>"/>
					<input type="hidden" name="action" value="submitanswer"/>	
					<input type="hidden" name="ques_type" value="<?php echo $result->ques_type;?>"/>
					<input type="hidden" name="ques_class" value="<?php echo $result->ques_class;?>"/>
					<input type="hidden" name="year_id" value="<?php echo $year_id;?>"/>
					<input type="hidden" name="subskill" value="<?php echo $subskill;?>"/>
					<input type="hidden" name="skill_id" value="<?php echo $skill_id;?>"/>
					<?php /*?><input type="submit" name="submit" value="Submit"><?php */?>
                    <?php /*<button class="btn-mn btn-3 btn-3e button-org">Submit</button>*/ ?>	</div></div>
					<input class="btn-mn btn-3 btn-3e button-org" type="submit" name="submit" value="Submit" id="btntestexam">
				
				<?php }
				else
				{ ?>
				  No Question found
				<?php }

			}
			else
			{
				if($textper_marks < 80)
				{
					//$testfail='<br><p style="color:red;">Your score is less than 80% so your exercise not valid.Please attempt exercise again to <a href="'.BASE_URL.'homework/'.$subskill.'?reh=1"><strong>Click Here</strong></a></p>';
				}
				else
				{
					$testfail='';
				}
				
			
				echo '<p>Your class exercise has been completed.</p>';
				echo $testfail;
				if($total_attempt_exam < 6)
				{
					echo '<p style="font-weight:bold;"><a href="'.BASE_URL.'classroom-exercise/'.$subskill.'?again=1">Attempt Exercise Again</a></p>';
				}
				else
				{
					echo '<br><p style="color:red;">Your exercise limit has been over!.<p>';
				}
			}				?>
				
				
		</form>

</div></div>
<?php

if($this->session->userdata('testagain')=='1' && $lastexam_status!='pending')
{
	$totalattent=0;
	$textper_marks=0;
}
else
{
	$totalattent=$totalattent;
	$textper_marks=$textper_marks;
}
?>
    <div class="col-xs-12 col-sm-12 col-md-3 col-lg-3">
    <div class="sidebar-play">
    <h3 class="org">Questions<br />answered</h3>
    <div class="number" id="textexamtotal"><?php echo $totalattent.'/20';?></div>
   <!-- <h3>Time<br />elapsed</h3>
   
        <div class="timeing">
   <ul id="showtimer">	 </ul>

 </div>-->

   
    
    <h3 class="green">Smart<br />
    Score</h3>
    <div class="number" id="testexampersent"><?php echo $textper_marks;?>%</div>
    </div>
    </div>

 </div>
 </div>
 </section>
 <style>
 .anslabel > input{ /* HIDE RADIO */
  visibility: hidden; /* Makes input not-clickable */
  position: absolute; /* Remove input from document flow */
}
.anslabel > input + img{ /* IMAGE STYLES */
  cursor:pointer;
  border:2px solid transparent;
  border-radius:10px;
  padding:0px;
}
.anslabel > input:checked + img{ /* (RADIO CHECKED) IMAGE STYLES */
  border:2px solid #1278a6;
   padding:0px;
}

.anslabel > input + div{ /* IMAGE STYLES */
  cursor:pointer;
  border:2px solid #00a7dc;
  border-radius:10px;
  padding:10px;
}
.anslabel > input:checked + div{ /* (RADIO CHECKED) IMAGE STYLES */
  border:2px solid #1278a6;
   padding:10px;
}
 </style>
 
 <script>
  $("#a1").click(function(event) {
    this.removeAttribute("href");            
    anchorClicked("a1");
  });
  
  $( document ).ready(function() {
    $("#infor").delay(3000).fadeOut("slow");
});

function validateForm() {
    var x = document.forms["myForm"]["answerid"].value;
	
    if (x == "") {
        var r = confirm("You did not complete the question.Are you sure you want to submit?!");
		if (r == true) {
			return true;
		} else {
			return false;
		}
    }
}
 </script>

    
 <!-- Page Content End -->
<?php include('footer.php'); ?>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script>  
 <script>

 $('#btntestexam').click(function(event) {
       form = $("#testexmfrm").serialize();

     $.ajax({
       type: "POST",
       url: "<?php echo site_url('ajaxcall/ajax_classexcercise'); ?>",
       data: form,

       success: function(data){
          // alert('Successful!'); //Unterminated String literal fixed
		    $('#question_list').html(data);
       }

     });
     event.preventDefault();
     return false;  //stop the actual form post !important!

  });
</script>
