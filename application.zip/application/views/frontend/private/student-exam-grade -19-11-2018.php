<?php include('header.php'); ?>

<!-- Page Content inner -->

<section id="title-inner" class="bgcolor-text">
<canvas id="demo-canvas"></canvas>
<div class="container">
<div class="text-tit">
<h1>
<span>Students Grade Report</span>
</h1>
</div>

</div>
</section>
 
 <section class="about_content content-text student-grade space-75">
 <div class="container">
 <?php
 if($examterm_list)
 {
	 foreach($examterm_list as $rowexam)
	 {
		    $examquery=$this->db->query("select * from student_exam left join user_details on  user_details.user_id=student_exam.user_id 
			where student_exam.year_id='".$rowexam->year_id."' and student_exam.term_id='".$rowexam->term_id."' and student_exam.exam_status='pass' order by student_exam.exam_date desc"); 
			$resutrowexam=$examquery->result();
	 /*echo '<pre>';
		 var_dump($resutrowexam);
		  echo '</pre>';
		  */
	 
 ?>
 <div class="row">

  <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
  <h1>Term-<?php echo $rowexam->term_id;?></h1>
<?php
if($resutrowexam)
{
	?>
  <div class="table-responsive">
  <table class="table table-striped table-light">
  <thead>
    <tr>
	<th scope="col">Student ID</th>
      <th scope="col">Student Name</th>
	  <th scope="col">Date</th>
      <th scope="col">Total  Question</th>     
      <th scope="col">Scores</th>
	  <th scope="col">Percentage(%)</th>
	   
    </tr>
  </thead>
  <tbody>
    <?php
	 $totalquestion="";
	  $totalright="";
	  $calper="";
	foreach($resutrowexam as $userexamrow)
	{
		
		 $examhquery=$this->db->query("select count(*) as totalquestion from sexam_history where exam_id='".$userexamrow->exam_id."' "); 
		   $ehistoryrow=$examhquery->row();
		   $totalquestion=$ehistoryrow->totalquestion;
		   $queryrightcount="select count(*) as totalright from sexam_history where exam_id='".$userexamrow->exam_id."' and answer_status='true'  ";
		  
		   $examhquery1=$this->db->query($queryrightcount); 
		   $exrightquestion=$examhquery1->row();
		   // var_dump($resultexam);
		    $totalright=$exrightquestion->totalright;
			$calper=($totalright/$totalquestion)*100;
			
		?>
	<tr>
	<td><a href="<?php echo  base_url();?>student-exam-sheet/<?php echo $userexamrow->exam_id;?>"><?php echo $userexamrow->exam_id;?></a> </td>
	<td><a href="<?php echo  base_url();?>student-exam-sheet/<?php echo $userexamrow->exam_id;?>"><?php echo ucfirst($userexamrow->first_name.' '.$userexamrow->last_name);?></a> </td>
	<td><a href="<?php echo  base_url();?>student-exam-sheet/<?php echo $userexamrow->exam_id;?>"><?php echo $userexamrow->exam_date;?></a></td>
	<td><a href="<?php echo  base_url();?>student-exam-sheet/<?php echo $userexamrow->exam_id;?>"><?php echo $totalquestion;?></a></td>
	<td><a href="<?php echo  base_url();?>student-exam-sheet/<?php echo $userexamrow->exam_id;?>"><?php echo $totalright.'/'.$totalquestion;?></a></td>
	<td><a href="<?php echo  base_url();?>student-exam-sheet/<?php echo $userexamrow->exam_id;?>"><?php echo number_format($calper);?>%</a></td>
	</tr>
   <?php
	}
	?>
    
  </tbody>
</table></div>
<?php
}
?>
 </div>
 
 </div>
 <?php
	 }
}
?> 
 </div>
 </section>
 
 
   
   
   
   
   
   
    
 <!-- Page Content End -->
<?php include('footer.php'); ?>