<?php
defined('BASEPATH') OR exit('No direct script access allowed');
error_reporting(E_ALL);
ini_set('display_errors',1);
header('Content-type: text/html; charset=utf-8');
class Unieducation extends MY_Controller {

	public function __construct()
    {
		parent::__construct();
			$this->load->library(array('session'));
			
			$this->load->helper('form');
			$this->load->helper(array('url','form'));
			$this->load->model('Login_model');	
			$this->load->model('classes_model');
			$this->load->model('center_model');	
			$this->load->model('User_model');
			$this->load->model('syllabus_model');
			$this->load->model('questions_model');	
			$this->load->model('weeks_model');
			$this->load->model('students_model');
			$this->load->model('plan_model');
			$this->load->model('order_model');
			$this->load->model('exam_model');
			$this->load->model('skill_model');
			$this->load->model('years_model');			
					
			$this->load->database();				
				
			//date_default_timezone_set('America/New_York');
			date_default_timezone_set('Africa/Banjul');
			$this->load->library("pagination");
			
			$this->load->library('form_validation');
			
    }
	public function index($year='')
	{	
	
		if($year!=""){
			$data["year"]=$year;
			$data["year_dtl"] = $this->main_model->get_detail('master_class','class_slug',$year);	
			$year_id=$data["year_dtl"]->class_id;
			$this->questions_model->CLASSID = $year_id;
			$data["year"]=$year;
			
			
		}
		$data['countskill_kg'] = $this->years_model->skill_list_count(1);
		$data['countskill_year1'] = $this->years_model->skill_list_count(2);
		$data['countskill_year2'] = $this->years_model->skill_list_count(3);
		$data['countskill_year3'] = $this->years_model->skill_list_count(4);
		$data['countskill_year4'] = $this->years_model->skill_list_count(5);
		$data['countskill_year5'] = $this->years_model->skill_list_count(6);
		$data['countskill_year6'] = $this->years_model->skill_list_count(7);
		$data['countskill_year7'] = $this->years_model->skill_list_count(8);
		$data['countskill_year8'] = $this->years_model->skill_list_count(9);
		$data['countskill_year9'] = $this->years_model->skill_list_count(10);
		$data['countskill_year10'] = $this->years_model->skill_list_count(11);
		$data['countskill_year11'] = $this->years_model->skill_list_count(12);
		$data['countskill_year12'] = $this->years_model->skill_list_count(13);
		$data['countskill_year13'] = $this->years_model->skill_list_count(14);
		
		  
		$data['error']='';
		$this->load->view('frontend/public/index',$data);
		
	}
	public function error()
	{
		//$this->load->view('frontend/public/page_system_404.php');
	}

	public function _404(){
		$yearid=$this->session->userdata('loginyear');
			$yeardata=$this->classes_model->classes_details($yearid);
			if($yeardata)
			{
				$data['year_name']=$yeardata[0]->class_name;
				$data['year_slug']=$yeardata[0]->class_slug;
			}
		$this->load->view("frontend/public/404");
	}
	
	public function login()
	{
		
	
		
		
		$this->form_validation->set_rules('username', 'Username', 'required');
		$this->form_validation->set_rules('password', 'Password', 'required');		
		if($this->form_validation->run())
		{
			
			$username = $this->input->post('username');
			$password = $this->input->post('password');
			$user_type = $this->input->post('user_type');
			$data=array('val'=>'',
						'table'=>'user_details',
						'where'=>array('user_name'=>$username,'password'=>md5($password),'status'=>'1','user_type'=>'6')
						);
			$res=$this->Login_model->signin($data);			
			
			if ($res['res']) 
			{	
				if($res['rows']->lastlogin!='' && $res['rows']->lastlogin!=null)
				{	
					$lastlogintime = strtotime($res['rows']->lastlogin);				
					$mylastlogin = date("m/d/y g:i A", $lastlogintime);
				}
				else
				{
					$mylastlogin='';
				}
				
				$userlogindata = array( 
									'username' => $res['rows']->user_name,
									'logged_in' => true,
									'user_id' => $res['rows']->user_id,
									'email' => $res['rows']->email,
									'user_type'=>$res['rows']->user_type,
									'fullname'=>$res['rows']->first_name.' '.$res['rows']->last_name,
									'lastlogedin'=>$mylastlogin,
									'loginyear'=>$res['rows']->year_id
									);						
				$this->session->set_userdata($userlogindata);
				$logindate=date("Y-m-d H:i:s");
				$lastlogin_data=array(					
							'lastlogin'=>$logindate	
							
							);	
				
				$lastlogin=$this->Login_model->lastlogin($lastlogin_data);
				
			redirect(base_url().'dashboard');
				
								
			} 
			else
			{
				$data['error']='Sorry your username and password did not match.<br/> <br/>Please try again.';
				$this->load->view('frontend/public/login',$data);
			}	
			
		}		
		else
		{
		$data['error']='';
		$this->load->view('frontend/public/login',$data);

		}	
		
	}
	
	
	
	public function logout() 
	{		
		$data = new stdClass();			
		session_destroy();
		redirect(BASE_URL,'redirect');
		
	}	
	
	public function whoarewe() 
	{		
		$this->load->view('frontend/public/who-are-we');
		
	}
	public function admissions() 
	{		
		$this->load->view('frontend/public/admissions');
		
	}
	public function students() 
	{		
		$this->load->view('frontend/public/students');
		
	}
	public function parents() 
	{		
		$this->load->view('frontend/public/parents');
		
	}
	public function curriculum() 
	{		
		$this->load->view('frontend/public/curriculum');
		
	}
	public function bookingpayment() 
	{		
		$this->load->view('frontend/public/booking-payment');
		
	}
	public function forgotpassword() 
	{		
		$this->form_validation->set_rules('emailid', 'Email-Id', 'required');
		
		if($this->form_validation->run())
		{
			$emailid = $this->input->post('emailid');
			
			$data=array('val'=>'',
						'table'=>'user_details',
						'where'=>array('email'=>$emailid,'status'=>'1','user_type'=>'6')
						);
			$res=$this->Login_model->signin($data);			
			
			if ($res['res']) 
			{	
				
				
				
				$password=$this->random_password();
			
				$user_data=array(							
							'password'=>md5($password)						
							
							);	
	            $userid=$this->User_model->Save_Password($user_data,$res['rows']->user_id);
				$data1['fullname']=$res['rows']->first_name.' '.$res['rows']->last_name;
				$data1['username']=$res['rows']->user_name;
				$data1['password']=$password;
				
				$this->load->library('email');
				$config = array (
				'mailtype' => 'html',
				'charset' => 'utf-8',
				'priority' => '1'
				);
				$this->email->initialize($config);
				
				$senderemail=$res['rows']->email;
			
				$body = $this->load->view('emails/forgotpassword',$data1,TRUE);
				$this->email->from('info@maths.com', 'maths');
				$this->email->to($senderemail);
				$this->email->subject('MATHS : Forgot Password Reply for USERID '.$res['rows']->user_name);
				$this->email->message($body);
				$this->email->send();
				
				$data['success']='Password sent to your email. Please check your inbox.';
			
				
								
			} 
			else
			{
				$data['error']='This email id is not registered with us.';
				
			}
		}
		else
		{
			$data['error']='';
		}
		
		$this->load->view('frontend/public/forget-password',$data);
		
	}
		
	public function mediaevent() 
	{	
		$this->load->view('frontend/public/event');
		
	}
	public function register() 
	{		
		
	
				/*----Submit registration----*/
		
		if($this->input->post('reg_email')!='')	
		{
			$createdate=date("Y-m-d H:i:s");
			$password=$this->random_password();
			
			$user_data=array(
							'email'=>$this->input->post('reg_email'),
							'user_type'=>'6',
							'user_name'=>$this->input->post('reg_userid'),
							'first_name'=>$this->input->post('reg_fname'),							
							'last_name'=>$this->input->post('reg_lname'),							
							'phone'=>$this->input->post('reg_mobile'),
							'edate'=>$createdate,
							'status'=>'1',
							'password'=>md5($password),
							'address'=>$this->input->post('reg_address'),
							'state'=>$this->input->post('reg_state'),
							'city'=>$this->input->post('reg_city'),
							'zipcode'=>$this->input->post('reg_zipcode'),
							'year_id'=>$this->input->post('reg_year'),
							'center_id'=>$this->input->post('reg_center'),	
							'paystatus'=>'complete'
							
							);	
	           $userid=$this->User_model->Save_Update($user_data);
			   if($userid!="" && $userid!=null)
			   {
					/*-----Add user payment detail------*/
					
					$user_pay=array(
							'pay_userid'=>$userid,
							'pay_yearid'=>$this->input->post('reg_year'),
							'pay_location'=>$this->input->post('reg_center'),
							'pay_amount'=>'',							
							'pay_status'=>'complete',							
							'pay_date'=>$createdate
							
							);
						$payid=$this->User_model->Save_payment($user_pay);	
						if($payid!="")
						{
							
							$this->load->library('email');
							$config = array (
							'mailtype' => 'html',
							'charset' => 'utf-8',
							'priority' => '1'
							);
							$this->email->initialize($config);
							$senderemail=$this->input->post('reg_email');
							$emailarr=explode('@',$senderemail);
							$username=$emailarr[0].$userid;
							/*----update user id----*/
								$username_data=array(
							'user_name'=>$username							
							);
						$userquery=$this->User_model->update_staff($userid,$username_data);	
							/*----end of update user id----*/
							
							$data['fullname']=$this->input->post('reg_fname').' '.$this->input->post('reg_lname');
							$data['username']=$username;
							$data['password']=$password;
							$body = $this->load->view('emails/signup-to-student',$data,TRUE);
							$this->email->from('info@maths.com', 'maths');
							$this->email->to($senderemail);
							$this->email->subject('Complete Your Registration Maths');
							$this->email->message($body);
							$this->email->send();
							redirect(BASE_URL.'registered');
	
	/*						
							
 <!--<form name="myForm" id="myForm" method="post" class="form-horizontal" role="form" action="paypal/create_payment_with_paypal">
                    <fieldset>
                        <input title="item_name" name="item_name" type="hidden" value="ahmed fakhr">
                        <input title="item_number" name="item_number" type="hidden" value="12345">
                        <input title="item_description" name="item_description" type="hidden" value="to buy samsung smart tv">
                        <input title="item_tax" name="item_tax" type="hidden" value="1">
                        <input title="item_price" name="item_price" type="hidden" value="7">
                        <input title="details_tax" name="details_tax" type="hidden" value="7">
                        <input title="details_subtotal" name="details_subtotal" type="hidden" value="7">

                        <div class="form-group">
                            <div class="col-sm-offset-5">
                                <input type="submit" name="submit" value="Submit" />
                            </div>
                        </div>
                    </fieldset>
                </form>

    <script>

    var auto_refresh = setInterval(
    function()
    {
    submitform();
    }, 10000);

    function submitform()
    {
      alert('test');
      document.myForm.submit();
    }
    </script>-->*/
						
							
						}
							
					/*----End of Add user payment detail-----*/
			   }
			   
			
		}
		/*----End Submit registration----*/
		$data['year_list']=$this->classes_model->classes_dropdown();
		$data['center_list']=$this->center_model->center_dropdown();
		
		$this->load->view('frontend/public/register',$data);
		
	}
	public function kg($subskill='') 
	{	
		
		$yearid=$this->session->userdata('loginyear');
			$yeardata=$this->classes_model->classes_details($yearid);
			if($yeardata)
			{
				$data['year_name']=$yeardata[0]->class_name;
				$data['year_slug']=$yeardata[0]->class_slug;
			}
		$year_id=1;
		$data['year_id']=$year_id;
		$this->questions_model->CLASSID = $year_id;
		$data["year_dtl"] = $this->main_model->get_detail('master_class','class_id',$year_id);	
		if($subskill!=""){
			/*---Start Assessment Test -----*/
			if($subskill=="assessment")
			{
				
					/*---get all past year of assessment list----*/
					$pastyear=$this->questions_model->assessment_pastyear($year_id);
						/*echo '<pre>';
						var_dump($pastyear);
						echo '</pre>';
						*/
					
					$todaydate=date("Y-m-d H:i:s");	
					$userid=$this->session->userdata('user_id');
					$asstime_query=$this->questions_model->assessment_time($year_id,$userid);
					$yourstart=$asstime_query->start_time;
					if($yourstart!="" && $yourstart!=null)
					{
						$seconds = strtotime($todaydate) - strtotime($yourstart);
						$days    = floor($seconds / 86400);
						$hours   = floor(($seconds - ($days * 86400)) / 3600);
						$minutes = floor(($seconds - ($days * 86400) - ($hours * 3600))/60);
						
						if($minutes >30)
						{
							//echo $minutes;
							$exam_status=array(
								'exam_status'=>'pass',							
								'end_time'=>$todaydate,
								);
						
						$updateexam_status=$this->questions_model->Update_Asstterm_status($exam_status,$asstime_query->exam_id);
						$data['timeover']=1;
						}
						else
						{
							$totalminutes=30-$minutes;
							$data['showtimer']='Duration Left: '.$totalminutes;
						}
					}
					else
					{
						$data['showtimer']='Duration: 30';
					}
					
					/*---end of get all past year of assessment list----*/	
					if($this->input->post('action')=='submitanswer')	
					{
						//var_dump($this->input->post());
					 $questionid=$this->input->post('questionid');
					 $answerid=$this->input->post('answerid');
					 $year_id=$this->input->post('year_id');
					 $ass_year_id=$this->input->post('ass_year_id');
				
					
					$data["ques_dtl"] = $this->main_model->get_detail('manage_question_'.$ass_year_id,'ques_id',$questionid);					
					//var_dump($data["ques_dtl"]);
					$data["correct_ans"] = $this->main_model->get_detail('manage_answer_'.$ass_year_id,'ans_id',$data["ques_dtl"]->ques_rightanswer);					
										
					if($data["ques_dtl"]->ques_rightanswer==$answerid)
					{
						
						$data['correct']=1;
						$answer_status='true';
					}
					else
					{
						$answer_status='false';
					}	
						/*----insert user exam list---------*/
						
						$createdate=date("Y-m-d H:i:s");
						$chkrow_exam=$this->questions_model->check_userassessment($userid,$year_id,1);	
						
						if($chkrow_exam->exam_id!="" )
						{
							$exam_id=$chkrow_exam->exam_id;
						}
						else
						{
							$user_exam=array(
									'user_id'=>$userid,
									'year_id'=>$year_id,
									'assyear_id'=>$ass_year_id,													
									'exam_date'=>$createdate,
									'start_time'=>$createdate
									
									);
							$exam_id=$this->questions_model->Save_Userassessment($user_exam);	
						}
						
						if($exam_id!="")
						{
							$uexam_history=array(
								'exam_id'=>$exam_id,
								'user_id'=>$userid,
								'year_id'=>$year_id,
								'assyear_id'=>$ass_year_id,													
								'question_id'=>$questionid,
								'answer_id'=>$answerid,
								'answer_status'=>$answer_status,
								
								);
							$historyexam_id=$this->questions_model->Save_Assessmenthistory($uexam_history);		
						}
						
						/*----End of insert user exam list-------*/
										
					/*----Get user exam question array------*/
					$exam_questermArr=array();
					$exam_questions=$this->questions_model->check_asstesthistory_question($userid,$year_id,1);
					if($exam_questions)
					{
						
						foreach($exam_questions as $examdata)
						{
							array_push($exam_questermArr,$examdata->question_id);
						}
					}
					
					
					/*----End of get user exam question array----*/
					$term_questermArr=array();
					$term_questions=$this->questions_model->assessment_exam($year_id,1);
					if($year_id <14)
					{	
					$afteryear=$year_id+1;
					}
					else
					{
						$afteryear=$year_id;
					}
					if($term_questions)
					{
						$limitatts_question=1;
						$limitatts_question1=1;
						foreach($term_questions as $tquestion)
						{
							
							if($tquestion->ass_year_id <=$year_id)
							{								
								if($limitatts_question < 10)
								{
									array_push($term_questermArr,$tquestion->ass_question);
								}
								$limitatts_question++;
							}
							else if($tquestion->ass_year_id > $year_id && $tquestion->ass_year_id <= $afteryear)
							{
								
								if($limitatts_question1 < 4)
								{
									
									array_push($term_questermArr,$tquestion->ass_question);
								}
								$limitatts_question1++;
							}
							
						}
						
					}
					//var_dump($term_questermArr);
					$total_exam_question=count($exam_questermArr);
					$total_term_question=count($term_questermArr);
					/*---update term by exam completed status----*/
					if($total_term_question==$total_exam_question)
					{
						$exam_status=array(
								'exam_status'=>'pass',							
								'end_time'=>$createdate,
								);
						
						$updateexam_status=$this->questions_model->Update_Asstterm_status($exam_status,$exam_id);
						$data['completed']=1;
					}
					/*---update term by exam completed status----*/
					
					$exam_output = array_merge(array_diff($term_questermArr, $exam_questermArr), array_diff($exam_questermArr, $term_questermArr));
					$exam_random=array_shift($exam_output);					
					$randquestion=$exam_random;
					
					/*---End of check user not applied question list---*/
					$data['Questionlist']=$this->questions_model->asstest_exam_question($year_id,1,$randquestion);
					
						//$data['Questionlist']=$this->questions_model->term_exam($year_id,1);
						$data['exam_id']=$exam_id;
						$this->load->view('frontend/private/assessmentplay',$data);

					
					
								
					}
				else
				{
					$userid=$this->session->userdata('user_id');
					/*---check user not applied question list---*/
					$userexams=$this->questions_model->check_uasstestbyyear($userid,$year_id);
					$data['exam_id']=$userexams->exam_id;
					if($userexams->exam_id!="" && $userexams->exam_status=='pending')
					{	
						$data['assyear_id']=$userexams->assyear_id;
					}
					
					else if($userexams->exam_id!="" && $userexams->exam_status=='pass')
					{	
						$data['assyear_id']=$userexams->assyear_id+1;
					}
				
					else
					{
						$data['assyear_id']=$pastyear[0]->ass_year_id;
						//echo $pastyear[0]->ass_year_id;
					}
					
					/*----Get user exam question array------*/
					$exam_questermArr=array();
					$exam_questions=$this->questions_model->check_asstesthistory_question($userid,$year_id,1);
					if($exam_questions)
					{
						
						foreach($exam_questions as $examdata)
						{
							array_push($exam_questermArr,$examdata->question_id);
						}
					}
					
					
					/*----End of get user exam question array----*/
					$term_questermArr=array();
					$next_questermArr=array();
					$term_questions=$this->questions_model->assessment_exam($year_id,1);
					//echo '<pre>';
					
					//echo '</pre>';
					if($year_id <14)
					{	
					$afteryear=$year_id+1;
					}
					else
					{
						$afteryear=$year_id;
					}
					if($term_questions)
					{
						$limitatts_question=1;
						$limitatts_question1=1;
						foreach($term_questions as $tquestion)
						{
							
							if($tquestion->ass_year_id <=$year_id)
							{								
								if($limitatts_question < 10)
								{
									array_push($term_questermArr,$tquestion->ass_question);
								}
								$limitatts_question++;
							}
							else if($tquestion->ass_year_id > $year_id && $tquestion->ass_year_id <= $afteryear)
							{
							
								if($limitatts_question1 < 4)
								{
									
									array_push($term_questermArr,$tquestion->ass_question);
								}
								$limitatts_question1++;
							}
							
						}
						
					}
					//var_dump($term_questermArr);
					
					$exam_output = array_merge(array_diff($term_questermArr, $exam_questermArr), array_diff($exam_questermArr, $term_questermArr));
					//$exam_random=array_rand($exam_output);
					$exam_random=array_shift($exam_output);
					//$randquestion=$exam_output[$exam_random];
					$randquestion=$exam_random;
					//var_dump($term_questermArr);
					/*---End of check user not applied question list---*/
					if($userexams->exam_status!='pass')
					{
					$data['Questionlist']=$this->questions_model->asstest_exam_question($year_id,1,$randquestion);
					}
					else
					{
						$data['Questionlist']='';
						$data['completed']=1;
					}
					//var_dump($data['Questionlist']);
					$this->load->view('frontend/private/assessmentplay',$data);
				}
			
			}
			/*---End Assessment Test -----*/
			/*---final year exam-----*/
			else if($subskill=="exam")
			{
				
				
					if($this->input->post('action')=='submitanswer')	
					{
					 $questionid=$this->input->post('questionid');
					 $answerid=$this->input->post('answerid');
					 $year_id=$this->input->post('year_id');
					 $term_id=$this->input->post('term_id');
				
					
					$data["ques_dtl"] = $this->main_model->get_detail('manage_question_'.$year_id,'ques_id',$questionid);					
					
					$data["correct_ans"] = $this->main_model->get_detail('manage_answer_'.$year_id,'ans_id',$data["ques_dtl"]->ques_rightanswer);					
										
					if($data["ques_dtl"]->ques_rightanswer==$answerid)
					{
						
						$data['correct']=1;
						/*----insert user exam list---------*/
						$userid=$this->session->userdata('user_id');
						$createdate=date("Y-m-d H:i:s");
						$chkrow_exam=$this->questions_model->check_userexam($userid,$year_id,$term_id);	
						
						if($chkrow_exam->exam_id!="" )
						{
							$exam_id=$chkrow_exam->exam_id;
						}
						else
						{
							$user_exam=array(
									'user_id'=>$userid,
									'year_id'=>$year_id,
									'term_id'=>$term_id,													
									'exam_date'=>$createdate
									
									);
							$exam_id=$this->questions_model->Save_Userexam($user_exam);	
						}
						
						if($exam_id!="")
						{
							$uexam_history=array(
								'exam_id'=>$exam_id,
								'user_id'=>$userid,
								'year_id'=>$year_id,
								'term_id'=>$term_id,													
								'question_id'=>$questionid,
								'answer_id'=>$answerid,
								'answer_status'=>'false',
								
								);
							$historyexam_id=$this->questions_model->Save_Examhistory($uexam_history);		
						}
						
						/*----End of insert user exam list-------*/
						
										/*---check user not applied question list---*/
					$userexams=$this->questions_model->check_uexambyyear($userid,$year_id);
					if($userexams->exam_id!="" && $userexams->exam_status=='pending')
					{	
						$data['term_id']=$userexams->term_id;
					}
					else if($userexams->exam_id!="" && $userexams->exam_status=='pass')
					{	
						$data['term_id']=$userexams->term_id+1;
					}
					else
					{
						$data['term_id']=1;
					}
					
					/*----Get user exam question array------*/
					$exam_questermArr=array();
					$exam_questions=$this->questions_model->check_examhistory_question($userid,$year_id,$data['term_id']);
					if($exam_questions)
					{
						
						foreach($exam_questions as $examdata)
						{
							array_push($exam_questermArr,$examdata->question_id);
						}
					}
					
					
					/*----End of get user exam question array----*/
					$term_questermArr=array();
					$term_questions=$this->questions_model->term_exam($year_id,$data['term_id']);
					if($term_questions)
					{
						
						foreach($term_questions as $tquestion)
						{
							array_push($term_questermArr,$tquestion->question_id);
						}
						
					}
					$total_exam_question=count($exam_questermArr);
					$total_term_question=count($exam_questermArr);
					/*---update term by exam completed status----*/
					if($total_term_question==$total_exam_question)
					{
						$exam_status=array(
								'exam_status'=>'pass',							
								
								);
						
						$updateexam_status=$this->questions_model->Update_Examterm_status($exam_status,$exam_id);
					}
					/*---update term by exam completed status----*/
					$exam_output = array_merge(array_diff($term_questermArr, $exam_questermArr), array_diff($exam_questermArr, $term_questermArr));
					$exam_random=array_rand($exam_output);					
					$randquestion=$exam_output[$exam_random];
					/*---End of check user not applied question list---*/
					$data['Questionlist']=$this->questions_model->term_exam_question($year_id,$data['term_id'],$randquestion);
						//$data['Questionlist']=$this->questions_model->term_exam($year_id,1);
						$this->load->view('frontend/private/examplay',$data);

					}
					else
					{
			
						/*----insert user exam list---------*/
						$userid=$this->session->userdata('user_id');
						$createdate=date("Y-m-d H:i:s");
						$chkrow_exam=$this->questions_model->check_userexam($userid,$year_id,$term_id);	
						
						if($chkrow_exam->exam_id!="" )
						{
							$exam_id=$chkrow_exam->exam_id;
						}
						else
						{
							$user_exam=array(
									'user_id'=>$userid,
									'year_id'=>$year_id,
									'term_id'=>$term_id,													
									'exam_date'=>$createdate
									
									);
							$exam_id=$this->questions_model->Save_Userexam($user_exam);	
						}
						
						if($exam_id!="")
						{
							$uexam_history=array(
								'exam_id'=>$exam_id,
								'user_id'=>$userid,
								'year_id'=>$year_id,
								'term_id'=>$term_id,													
								'question_id'=>$questionid,
								'answer_id'=>$answerid,
								'answer_status'=>'true',
								
								);
							$hexam_id=$this->questions_model->Save_Examhistory($uexam_history);		
						}
						
								/*----Get user exam question array------*/
					$exam_questermArr=array();
					$exam_questions=$this->questions_model->check_examhistory_question($userid,$year_id,$term_id);
					if($exam_questions)
					{
						
						foreach($exam_questions as $examdata)
						{
							array_push($exam_questermArr,$examdata->question_id);
						}
					}
					
					
					/*----End of get user exam question array----*/
					$term_questermArr=array();
					$term_questions=$this->questions_model->term_exam($year_id,$term_id);
					if($term_questions)
					{
						
						foreach($term_questions as $tquestion)
						{
							array_push($term_questermArr,$tquestion->question_id);
						}
						
					}
					$total_exam_question=count($exam_questermArr);
					$total_term_question=count($exam_questermArr);
					/*---update term by exam completed status----*/
					if($total_term_question==$total_exam_question)
					{
						$exam_status=array(
								'exam_status'=>'pass',							
								
								);
						
						$updateexam_status=$this->questions_model->Update_Examterm_status($exam_status,$exam_id);
					}
					/*---update term by exam completed status----*/
						
						/*----End of insert user exam list-------*/
						$data["yourans"] = $this->main_model->get_detail('manage_answer_'.$year_id,'ans_id',$answerid);	
						$this->load->view('frontend/private/explanation',$data);
					}
					
								
					}
				else
				{
					$userid=$this->session->userdata('user_id');
					/*---check user not applied question list---*/
					$userexams=$this->questions_model->check_uexambyyear($userid,$year_id);
					if($userexams->exam_id!="" && $userexams->exam_status=='pending')
					{	
						$data['term_id']=$userexams->term_id;
					}
					else if($userexams->exam_id!="" && $userexams->exam_status=='pass')
					{	
						$data['term_id']=$userexams->term_id+1;
					}
					else
					{
						$data['term_id']=1;
					}
					
					/*----Get user exam question array------*/
					$exam_questermArr=array();
					$exam_questions=$this->questions_model->check_examhistory_question($userid,$year_id,$data['term_id']);
					if($exam_questions)
					{
						
						foreach($exam_questions as $examdata)
						{
							array_push($exam_questermArr,$examdata->question_id);
						}
					}
					
					
					/*----End of get user exam question array----*/
					$term_questermArr=array();
					$term_questions=$this->questions_model->term_exam($year_id,$data['term_id']);
					if($term_questions)
					{
						
						foreach($term_questions as $tquestion)
						{
							array_push($term_questermArr,$tquestion->question_id);
						}
						
					}
					//var_dump($term_questermArr);
					
					$exam_output = array_merge(array_diff($term_questermArr, $exam_questermArr), array_diff($exam_questermArr, $term_questermArr));
					$exam_random=array_rand($exam_output);					
					$randquestion=$exam_output[$exam_random];
					/*---End of check user not applied question list---*/
					$data['Questionlist']=$this->questions_model->term_exam_question($year_id,$data['term_id'],$randquestion);
	
					$this->load->view('frontend/private/examplay',$data);
				}
			}
			/*---end final year exam-----*/
			else
			{
			$this->session->set_userdata('attempt', '0');	
			$this->session->set_userdata('ansattempt', '0');
			
			$data['subskill']=$subskill;
			$data["skill_dtl"] =$this->main_model->get_skill('master_skill','skill_slug',$subskill,'skill_class',$year_id);		
			  $subskill_id=$data["skill_dtl"]->skill_id;
			$this->questions_model->CLASSID = $year_id;
				//$data["Questionlist"] = $this->questions_model->question_list_subskill($subskill_id);
		
				if($this->input->post('action')=='submitanswer')	
					{
					 $questionid=$this->input->post('questionid');
					 $answerid=$this->input->post('answerid');
				
					
					$data["ques_dtl"] = $this->main_model->get_detail('manage_question_'.$year_id,'ques_id',$questionid);
					//print_r($data["ques_dtl"]);
					
					$data["correct_ans"] = $this->main_model->get_detail('manage_answer_'.$year_id,'ans_id',$data["ques_dtl"]->ques_rightanswer);
					//print_r($data["correct_ans"]);
					//echo $data["correct_ans"]->ans_name;
										
					if($data["ques_dtl"]->ques_rightanswer==$answerid)
					{
						
					$data['correct']=1;
					$data["Questionlist"] = $this->questions_model->random_question($subskill_id);
					$this->load->view('frontend/private/play',$data);

					}
					else{
			
					$data["yourans"] = $this->main_model->get_detail('manage_answer_'.$year_id,'ans_id',$answerid);	
					$this->load->view('frontend/private/explanation',$data);
					}
					
								
					}
				else{
					$data["Questionlist"] = $this->questions_model->random_question($subskill_id);
					$this->load->view('frontend/private/play',$data);
					}
			
				}
			}
			else{
				
				if($this->session->userdata('user_id')!='' and $this->session->userdata('username')!='')
				{

				$data["SylList1"] = $this->syllabus_model->syllabus_list($year_id,1);
				$data["SylList2"] = $this->syllabus_model->syllabus_list($year_id,2);
				$data["SylList3"] = $this->syllabus_model->syllabus_list($year_id,3);
				$data["SylList4"] = $this->syllabus_model->syllabus_list($year_id,4);

				$this->load->view('frontend/private/kindergarten', $data);
				}
				else{
				$data["SylList1"] = $this->syllabus_model->syllabus_list($year_id,1);
				$data["SylList2"] = $this->syllabus_model->syllabus_list($year_id,2);
				$data["SylList3"] = $this->syllabus_model->syllabus_list($year_id,3);
				$data["SylList4"] = $this->syllabus_model->syllabus_list($year_id,4);

				$this->load->view('frontend/public/kg_wtht_login', $data);	
					
				}

			}
		
	}
	
	public function year1($subskill='') 
	{
		$yearid=$this->session->userdata('loginyear');
			$yeardata=$this->classes_model->classes_details($yearid);
			if($yeardata)
			{
				$data['year_name']=$yeardata[0]->class_name;
				$data['year_slug']=$yeardata[0]->class_slug;
			}	
		
		$year_id=2;
		$data['year_id']=$year_id;
		$this->questions_model->CLASSID = $year_id;
		$data["year_dtl"] = $this->main_model->get_detail('master_class','class_id',$year_id);	
		if($subskill!=""){
			/*---Start Assessment Test -----*/
			if($subskill=="assessment")
			{
				
					/*---get all past year of assessment list----*/
					$pastyear=$this->questions_model->assessment_pastyear($year_id);
						/*echo '<pre>';
						var_dump($pastyear);
						echo '</pre>';
						*/
					$todaydate=date("Y-m-d H:i:s");	
					$userid=$this->session->userdata('user_id');
					$asstime_query=$this->questions_model->assessment_time($year_id,$userid);
					$yourstart=$asstime_query->start_time;
					if($yourstart!="" && $yourstart!=null)
					{
						$seconds = strtotime($todaydate) - strtotime($yourstart);
						$days    = floor($seconds / 86400);
						$hours   = floor(($seconds - ($days * 86400)) / 3600);
						$minutes = floor(($seconds - ($days * 86400) - ($hours * 3600))/60);
						
						if($minutes >30)
						{
							//echo $minutes;
							$exam_status=array(
								'exam_status'=>'pass',							
								'end_time'=>$todaydate,
								);
						
						$updateexam_status=$this->questions_model->Update_Asstterm_status($exam_status,$asstime_query->exam_id);
						$data['timeover']=1;
						}
						else
						{
							$totalminutes=30-$minutes;
							$data['showtimer']='Duration Left: '.$totalminutes;
						}
					}
					else
					{
						$data['showtimer']='Duration: 30';
					}
					
					/*---end of get all past year of assessment list----*/	
					if($this->input->post('action')=='submitanswer')	
					{
						//var_dump($this->input->post());
					 $questionid=$this->input->post('questionid');
					 $answerid=$this->input->post('answerid');
					 $year_id=$this->input->post('year_id');
					 $ass_year_id=$this->input->post('ass_year_id');
				
					
					$data["ques_dtl"] = $this->main_model->get_detail('manage_question_'.$ass_year_id,'ques_id',$questionid);					
					//var_dump($data["ques_dtl"]);
					$data["correct_ans"] = $this->main_model->get_detail('manage_answer_'.$ass_year_id,'ans_id',$data["ques_dtl"]->ques_rightanswer);					
										
					if($data["ques_dtl"]->ques_rightanswer==$answerid)
					{
						
						$data['correct']=1;
						/*----insert user exam list---------*/
						
						$createdate=date("Y-m-d H:i:s");
						$chkrow_exam=$this->questions_model->check_userassessment($userid,$year_id,1);	
						
						if($chkrow_exam->exam_id!="" )
						{
							$exam_id=$chkrow_exam->exam_id;
						}
						else
						{
							$user_exam=array(
									'user_id'=>$userid,
									'year_id'=>$year_id,
									'assyear_id'=>$ass_year_id,													
									'exam_date'=>$createdate,
									'start_time'=>$createdate
									
									);
							$exam_id=$this->questions_model->Save_Userassessment($user_exam);	
						}
						
						if($exam_id!="")
						{
							$uexam_history=array(
								'exam_id'=>$exam_id,
								'user_id'=>$userid,
								'year_id'=>$year_id,
								'assyear_id'=>$ass_year_id,													
								'question_id'=>$questionid,
								'answer_id'=>$answerid,
								'answer_status'=>'true',
								
								);
							$historyexam_id=$this->questions_model->Save_Assessmenthistory($uexam_history);		
						}
						
						/*----End of insert user exam list-------*/
										
					/*----Get user exam question array------*/
					$exam_questermArr=array();
					$exam_questions=$this->questions_model->check_asstesthistory_question($userid,$year_id,1);
					if($exam_questions)
					{
						
						foreach($exam_questions as $examdata)
						{
							array_push($exam_questermArr,$examdata->question_id);
						}
					}
					
					
					/*----End of get user exam question array----*/
					$term_questermArr=array();
					$term_questions=$this->questions_model->assessment_exam($year_id,1);
					if($term_questions)
					{
						
						foreach($term_questions as $tquestion)
						{
							array_push($term_questermArr,$tquestion->ass_question);
						}
						
					}
					$total_exam_question=count($exam_questermArr);
					$total_term_question=count($term_questermArr);
					/*---update term by exam completed status----*/
					if($total_term_question==$total_exam_question)
					{
						$exam_status=array(
								'exam_status'=>'pass',							
								'end_time'=>$createdate,
								);
						
						$updateexam_status=$this->questions_model->Update_Asstterm_status($exam_status,$exam_id);
						$data['completed']=1;
					}
					/*---update term by exam completed status----*/
					$exam_output = array_merge(array_diff($term_questermArr, $exam_questermArr), array_diff($exam_questermArr, $term_questermArr));
					$exam_random=array_rand($exam_output);					
					$randquestion=$exam_output[$exam_random];
					/*---End of check user not applied question list---*/
					$data['Questionlist']=$this->questions_model->asstest_exam_question($year_id,1,$randquestion);
						//$data['Questionlist']=$this->questions_model->term_exam($year_id,1);
						$data['exam_id']=$exam_id;
						$this->load->view('frontend/private/assessmentplay',$data);

					}
					else
					{
			
						/*----insert user exam list---------*/
						$userid=$this->session->userdata('user_id');
						$createdate=date("Y-m-d H:i:s");
						$chkrow_exam=$this->questions_model->check_userassessment($userid,$year_id,1);	
						
						if($chkrow_exam->exam_id!="" )
						{
							$exam_id=$chkrow_exam->exam_id;
						}
						else
						{
							$user_exam=array(
									'user_id'=>$userid,
									'year_id'=>$year_id,
									'assyear_id'=>$ass_year_id,													
									'exam_date'=>$createdate,
									'start_time'=>$createdate
									
									);
							$exam_id=$this->questions_model->Save_Userassessment($user_exam);	
						}
						
						if($exam_id!="")
						{
							$uexam_history=array(
								'exam_id'=>$exam_id,
								'user_id'=>$userid,
								'year_id'=>$year_id,
								'assyear_id'=>$ass_year_id,													
								'question_id'=>$questionid,
								'answer_id'=>$answerid,
								'answer_status'=>'false',
								
								);
							$hexam_id=$this->questions_model->Save_Assessmenthistory($uexam_history);		
						}
						
								/*----Get user exam question array------*/
					$exam_questermArr=array();
					$exam_questions=$this->questions_model->check_asstesthistory_question($userid,$year_id,$term_id);
					if($exam_questions)
					{
						
						foreach($exam_questions as $examdata)
						{
							array_push($exam_questermArr,$examdata->question_id);
						}
					}
					
					
					/*----End of get user exam question array----*/
					$term_questermArr=array();
					$term_questions=$this->questions_model->assessment_exam($year_id,1);
					if($term_questions)
					{
						
						foreach($term_questions as $tquestion)
						{
							array_push($term_questermArr,$tquestion->ass_question);
						}
						
					}
					$total_exam_question=count($exam_questermArr);
					$total_term_question=count($term_questermArr);
					/*---update term by exam completed status----*/
					if($total_term_question==$total_exam_question)
					{
						$exam_status=array(
								'exam_status'=>'pass',
								'end_time'=>$createdate,	
								
								);
						
						$updateexam_status=$this->questions_model->Update_Asstterm_status($exam_status,$exam_id);
						$data['completed']=1;
					}
					/*---update term by exam completed status----*/
						
						/*----End of insert user exam list-------*/
					
						$data["yourans"] = $this->main_model->get_detail('manage_answer_'.$ass_year_id,'ans_id',$answerid);	
						$data['exam_id']=$exam_id;
						$this->load->view('frontend/private/asstestexplanation',$data);
					}
					
								
					}
				else
				{
					$userid=$this->session->userdata('user_id');
					/*---check user not applied question list---*/
					$userexams=$this->questions_model->check_uasstestbyyear($userid,$year_id);
					$data['exam_id']=$userexams->exam_id;
					if($userexams->exam_id!="" && $userexams->exam_status=='pending')
					{	
						$data['assyear_id']=$userexams->assyear_id;
					}
					
					else if($userexams->exam_id!="" && $userexams->exam_status=='pass')
					{	
						$data['assyear_id']=$userexams->assyear_id+1;
					}
				
					else
					{
						$data['assyear_id']=$pastyear[0]->ass_year_id;
						//echo $pastyear[0]->ass_year_id;
					}
					
					/*----Get user exam question array------*/
					$exam_questermArr=array();
					$exam_questions=$this->questions_model->check_asstesthistory_question($userid,$year_id,1);
					if($exam_questions)
					{
						
						foreach($exam_questions as $examdata)
						{
							array_push($exam_questermArr,$examdata->question_id);
						}
					}
					
					
					/*----End of get user exam question array----*/
					$term_questermArr=array();
					$term_questions=$this->questions_model->assessment_exam($year_id,1);
					
					if($term_questions)
					{
						
						foreach($term_questions as $tquestion)
						{
							array_push($term_questermArr,$tquestion->ass_question);
						}
						
					}
					//var_dump($term_questermArr);
					
					$exam_output = array_merge(array_diff($term_questermArr, $exam_questermArr), array_diff($exam_questermArr, $term_questermArr));
					$exam_random=array_rand($exam_output);					
					$randquestion=$exam_output[$exam_random];
					/*---End of check user not applied question list---*/
					if($userexams->exam_status!='pass')
					{
					$data['Questionlist']=$this->questions_model->asstest_exam_question($year_id,1,$randquestion);
					}
					else
					{
						$data['Questionlist']='';
						$data['completed']=1;
					}
					//var_dump($data['Questionlist']);
					$this->load->view('frontend/private/assessmentplay',$data);
				}
			
			}
			/*---End Assessment Test -----*/
			/*---final year exam-----*/
			else if($subskill=="exam")
			{
				
				
					if($this->input->post('action')=='submitanswer')	
					{
					 $questionid=$this->input->post('questionid');
					 $answerid=$this->input->post('answerid');
					 $year_id=$this->input->post('year_id');
					 $term_id=$this->input->post('term_id');
				
					
					$data["ques_dtl"] = $this->main_model->get_detail('manage_question_'.$year_id,'ques_id',$questionid);					
					
					$data["correct_ans"] = $this->main_model->get_detail('manage_answer_'.$year_id,'ans_id',$data["ques_dtl"]->ques_rightanswer);					
										
					if($data["ques_dtl"]->ques_rightanswer==$answerid)
					{
						
						$data['correct']=1;
						/*----insert user exam list---------*/
						$userid=$this->session->userdata('user_id');
						$createdate=date("Y-m-d H:i:s");
						$chkrow_exam=$this->questions_model->check_userexam($userid,$year_id,$term_id);	
						
						if($chkrow_exam->exam_id!="" )
						{
							$exam_id=$chkrow_exam->exam_id;
						}
						else
						{
							$user_exam=array(
									'user_id'=>$userid,
									'year_id'=>$year_id,
									'term_id'=>$term_id,													
									'exam_date'=>$createdate
									
									);
							$exam_id=$this->questions_model->Save_Userexam($user_exam);	
						}
						
						if($exam_id!="")
						{
							$uexam_history=array(
								'exam_id'=>$exam_id,
								'user_id'=>$userid,
								'year_id'=>$year_id,
								'term_id'=>$term_id,													
								'question_id'=>$questionid,
								'answer_id'=>$answerid,
								'answer_status'=>'false',
								
								);
							$historyexam_id=$this->questions_model->Save_Examhistory($uexam_history);		
						}
						
						/*----End of insert user exam list-------*/
						
										/*---check user not applied question list---*/
					$userexams=$this->questions_model->check_uexambyyear($userid,$year_id);
					if($userexams->exam_id!="" && $userexams->exam_status=='pending')
					{	
						$data['term_id']=$userexams->term_id;
					}
					else if($userexams->exam_id!="" && $userexams->exam_status=='pass')
					{	
						$data['term_id']=$userexams->term_id+1;
					}
					else
					{
						$data['term_id']=1;
					}
					
					/*----Get user exam question array------*/
					$exam_questermArr=array();
					$exam_questions=$this->questions_model->check_examhistory_question($userid,$year_id,$data['term_id']);
					if($exam_questions)
					{
						
						foreach($exam_questions as $examdata)
						{
							array_push($exam_questermArr,$examdata->question_id);
						}
					}
					
					
					/*----End of get user exam question array----*/
					$term_questermArr=array();
					$term_questions=$this->questions_model->term_exam($year_id,$data['term_id']);
					if($term_questions)
					{
						
						foreach($term_questions as $tquestion)
						{
							array_push($term_questermArr,$tquestion->question_id);
						}
						
					}
					$total_exam_question=count($exam_questermArr);
					$total_term_question=count($exam_questermArr);
					/*---update term by exam completed status----*/
					if($total_term_question==$total_exam_question)
					{
						$exam_status=array(
								'exam_status'=>'pass',							
								
								);
						
						$updateexam_status=$this->questions_model->Update_Examterm_status($exam_status,$exam_id);
					}
					/*---update term by exam completed status----*/
					$exam_output = array_merge(array_diff($term_questermArr, $exam_questermArr), array_diff($exam_questermArr, $term_questermArr));
					$exam_random=array_rand($exam_output);					
					$randquestion=$exam_output[$exam_random];
					/*---End of check user not applied question list---*/
					$data['Questionlist']=$this->questions_model->term_exam_question($year_id,$data['term_id'],$randquestion);
						//$data['Questionlist']=$this->questions_model->term_exam($year_id,1);
						$this->load->view('frontend/private/examplay',$data);

					}
					else
					{
			
						/*----insert user exam list---------*/
						$userid=$this->session->userdata('user_id');
						$createdate=date("Y-m-d H:i:s");
						$chkrow_exam=$this->questions_model->check_userexam($userid,$year_id,$term_id);	
						
						if($chkrow_exam->exam_id!="" )
						{
							$exam_id=$chkrow_exam->exam_id;
						}
						else
						{
							$user_exam=array(
									'user_id'=>$userid,
									'year_id'=>$year_id,
									'term_id'=>$term_id,													
									'exam_date'=>$createdate
									
									);
							$exam_id=$this->questions_model->Save_Userexam($user_exam);	
						}
						
						if($exam_id!="")
						{
							$uexam_history=array(
								'exam_id'=>$exam_id,
								'user_id'=>$userid,
								'year_id'=>$year_id,
								'term_id'=>$term_id,													
								'question_id'=>$questionid,
								'answer_id'=>$answerid,
								'answer_status'=>'true',
								
								);
							$hexam_id=$this->questions_model->Save_Examhistory($uexam_history);		
						}
						
								/*----Get user exam question array------*/
					$exam_questermArr=array();
					$exam_questions=$this->questions_model->check_examhistory_question($userid,$year_id,$term_id);
					if($exam_questions)
					{
						
						foreach($exam_questions as $examdata)
						{
							array_push($exam_questermArr,$examdata->question_id);
						}
					}
					
					
					/*----End of get user exam question array----*/
					$term_questermArr=array();
					$term_questions=$this->questions_model->term_exam($year_id,$term_id);
					if($term_questions)
					{
						
						foreach($term_questions as $tquestion)
						{
							array_push($term_questermArr,$tquestion->question_id);
						}
						
					}
					$total_exam_question=count($exam_questermArr);
					$total_term_question=count($exam_questermArr);
					/*---update term by exam completed status----*/
					if($total_term_question==$total_exam_question)
					{
						$exam_status=array(
								'exam_status'=>'pass',							
								
								);
						
						$updateexam_status=$this->questions_model->Update_Examterm_status($exam_status,$exam_id);
					}
					/*---update term by exam completed status----*/
						
						/*----End of insert user exam list-------*/
						$data["yourans"] = $this->main_model->get_detail('manage_answer_'.$year_id,'ans_id',$answerid);	
						$this->load->view('frontend/private/explanation',$data);
					}
					
								
					}
				else
				{
					$userid=$this->session->userdata('user_id');
					/*---check user not applied question list---*/
					$userexams=$this->questions_model->check_uexambyyear($userid,$year_id);
					if($userexams->exam_id!="" && $userexams->exam_status=='pending')
					{	
						$data['term_id']=$userexams->term_id;
					}
					else if($userexams->exam_id!="" && $userexams->exam_status=='pass')
					{	
						$data['term_id']=$userexams->term_id+1;
					}
					else
					{
						$data['term_id']=1;
					}
					
					/*----Get user exam question array------*/
					$exam_questermArr=array();
					$exam_questions=$this->questions_model->check_examhistory_question($userid,$year_id,$data['term_id']);
					if($exam_questions)
					{
						
						foreach($exam_questions as $examdata)
						{
							array_push($exam_questermArr,$examdata->question_id);
						}
					}
					
					
					/*----End of get user exam question array----*/
					$term_questermArr=array();
					$term_questions=$this->questions_model->term_exam($year_id,$data['term_id']);
					if($term_questions)
					{
						
						foreach($term_questions as $tquestion)
						{
							array_push($term_questermArr,$tquestion->question_id);
						}
						
					}
					//var_dump($term_questermArr);
					
					$exam_output = array_merge(array_diff($term_questermArr, $exam_questermArr), array_diff($exam_questermArr, $term_questermArr));
					$exam_random=array_rand($exam_output);					
					$randquestion=$exam_output[$exam_random];
					/*---End of check user not applied question list---*/
					$data['Questionlist']=$this->questions_model->term_exam_question($year_id,$data['term_id'],$randquestion);
	
					$this->load->view('frontend/private/examplay',$data);
				}
			}
			/*---end final year exam-----*/
			else
			{	

			$data["skill_dtl"] =$this->main_model->get_skill('master_skill','skill_slug',$subskill,'skill_class',$year_id);		
			  $subskill_id=$data["skill_dtl"]->skill_id;
			$this->questions_model->CLASSID = $year_id;
				//$data["Questionlist"] = $this->questions_model->question_list_subskill($subskill_id);
		
				if($this->input->post('action')=='submitanswer')	
					{
					 $questionid=$this->input->post('questionid');
					 $answerid=$this->input->post('answerid');
				
					
					$data["ques_dtl"] = $this->main_model->get_detail('manage_question_'.$year_id,'ques_id',$questionid);
					//print_r($data["ques_dtl"]);
					
					$data["correct_ans"] = $this->main_model->get_detail('manage_answer_'.$year_id,'ans_id',$data["ques_dtl"]->ques_rightanswer);
					//print_r($data["correct_ans"]);
					//echo $data["correct_ans"]->ans_name;
										
					if($data["ques_dtl"]->ques_rightanswer==$answerid)
					{
						
					$data['correct']=1;
					$data["Questionlist"] = $this->questions_model->random_question($subskill_id);
					$this->load->view('frontend/private/play',$data);

					}
					else{
			
					$data["yourans"] = $this->main_model->get_detail('manage_answer_'.$year_id,'ans_id',$answerid);	
					$this->load->view('frontend/private/explanation',$data);
					}
					
								
					}
				else{
					$data["Questionlist"] = $this->questions_model->random_question($subskill_id);
					$this->load->view('frontend/private/play',$data);
					}
			
				}
			}
			else{
				
				if($this->session->userdata('user_id')!='' and $this->session->userdata('username')!='')
				{

				$data["SylList1"] = $this->syllabus_model->syllabus_list($year_id,1);
				$data["SylList2"] = $this->syllabus_model->syllabus_list($year_id,2);
				$data["SylList3"] = $this->syllabus_model->syllabus_list($year_id,3);
				$data["SylList4"] = $this->syllabus_model->syllabus_list($year_id,4);

				$this->load->view('frontend/private/kindergarten', $data);
				}
				else{
				$data["SylList1"] = $this->syllabus_model->syllabus_list($year_id,1);
				$data["SylList2"] = $this->syllabus_model->syllabus_list($year_id,2);
				$data["SylList3"] = $this->syllabus_model->syllabus_list($year_id,3);
				$data["SylList4"] = $this->syllabus_model->syllabus_list($year_id,4);

				$this->load->view('frontend/public/kg_wtht_login', $data);	
					
				}

			}
		
	}
	
	public function year2($subskill='') 
	{
			
		$yearid=$this->session->userdata('loginyear');
			$yeardata=$this->classes_model->classes_details($yearid);
			if($yeardata)
			{
				$data['year_name']=$yeardata[0]->class_name;
				$data['year_slug']=$yeardata[0]->class_slug;
			}
		$year_id=3;
		$data['year_id']=$year_id;
		$this->questions_model->CLASSID = $year_id;
		$data["year_dtl"] = $this->main_model->get_detail('master_class','class_id',$year_id);	
		if($subskill!=""){
			/*---Start Assessment Test -----*/
			if($subskill=="assessment")
			{
				
					/*---get all past year of assessment list----*/
					$pastyear=$this->questions_model->assessment_pastyear($year_id);
						/*echo '<pre>';
						var_dump($pastyear);
						echo '</pre>';
						*/
					$todaydate=date("Y-m-d H:i:s");	
					$userid=$this->session->userdata('user_id');
					$asstime_query=$this->questions_model->assessment_time($year_id,$userid);
					$yourstart=$asstime_query->start_time;
					if($yourstart!="" && $yourstart!=null)
					{
						$seconds = strtotime($todaydate) - strtotime($yourstart);
						$days    = floor($seconds / 86400);
						$hours   = floor(($seconds - ($days * 86400)) / 3600);
						$minutes = floor(($seconds - ($days * 86400) - ($hours * 3600))/60);
						
						if($minutes >30)
						{
							//echo $minutes;
							$exam_status=array(
								'exam_status'=>'pass',							
								'end_time'=>$todaydate,
								);
						
						$updateexam_status=$this->questions_model->Update_Asstterm_status($exam_status,$asstime_query->exam_id);
						$data['timeover']=1;
						}
						else
						{
							$totalminutes=30-$minutes;
							$data['showtimer']='Duration Left: '.$totalminutes;
						}
					}
					else
					{
						$data['showtimer']='Duration: 30';
					}
					
					/*---end of get all past year of assessment list----*/	
					if($this->input->post('action')=='submitanswer')	
					{
						//var_dump($this->input->post());
					 $questionid=$this->input->post('questionid');
					 $answerid=$this->input->post('answerid');
					 $year_id=$this->input->post('year_id');
					 $ass_year_id=$this->input->post('ass_year_id');
				
					
					$data["ques_dtl"] = $this->main_model->get_detail('manage_question_'.$ass_year_id,'ques_id',$questionid);					
					//var_dump($data["ques_dtl"]);
					$data["correct_ans"] = $this->main_model->get_detail('manage_answer_'.$ass_year_id,'ans_id',$data["ques_dtl"]->ques_rightanswer);					
										
					if($data["ques_dtl"]->ques_rightanswer==$answerid)
					{
						
						$data['correct']=1;
						/*----insert user exam list---------*/
						
						$createdate=date("Y-m-d H:i:s");
						$chkrow_exam=$this->questions_model->check_userassessment($userid,$year_id,1);	
						
						if($chkrow_exam->exam_id!="" )
						{
							$exam_id=$chkrow_exam->exam_id;
						}
						else
						{
							$user_exam=array(
									'user_id'=>$userid,
									'year_id'=>$year_id,
									'assyear_id'=>$ass_year_id,													
									'exam_date'=>$createdate,
									'start_time'=>$createdate
									
									);
							$exam_id=$this->questions_model->Save_Userassessment($user_exam);	
						}
						
						if($exam_id!="")
						{
							$uexam_history=array(
								'exam_id'=>$exam_id,
								'user_id'=>$userid,
								'year_id'=>$year_id,
								'assyear_id'=>$ass_year_id,													
								'question_id'=>$questionid,
								'answer_id'=>$answerid,
								'answer_status'=>'true',
								
								);
							$historyexam_id=$this->questions_model->Save_Assessmenthistory($uexam_history);		
						}
						
						/*----End of insert user exam list-------*/
										
					/*----Get user exam question array------*/
					$exam_questermArr=array();
					$exam_questions=$this->questions_model->check_asstesthistory_question($userid,$year_id,1);
					if($exam_questions)
					{
						
						foreach($exam_questions as $examdata)
						{
							array_push($exam_questermArr,$examdata->question_id);
						}
					}
					
					
					/*----End of get user exam question array----*/
					$term_questermArr=array();
					$term_questions=$this->questions_model->assessment_exam($year_id,1);
					if($term_questions)
					{
						
						foreach($term_questions as $tquestion)
						{
							array_push($term_questermArr,$tquestion->ass_question);
						}
						
					}
					$total_exam_question=count($exam_questermArr);
					$total_term_question=count($term_questermArr);
					/*---update term by exam completed status----*/
					if($total_term_question==$total_exam_question)
					{
						$exam_status=array(
								'exam_status'=>'pass',							
								'end_time'=>$createdate,
								);
						
						$updateexam_status=$this->questions_model->Update_Asstterm_status($exam_status,$exam_id);
						$data['completed']=1;
					}
					/*---update term by exam completed status----*/
					$exam_output = array_merge(array_diff($term_questermArr, $exam_questermArr), array_diff($exam_questermArr, $term_questermArr));
					$exam_random=array_rand($exam_output);					
					$randquestion=$exam_output[$exam_random];
					/*---End of check user not applied question list---*/
					$data['Questionlist']=$this->questions_model->asstest_exam_question($year_id,1,$randquestion);
						//$data['Questionlist']=$this->questions_model->term_exam($year_id,1);
						$data['exam_id']=$exam_id;
						$this->load->view('frontend/private/assessmentplay',$data);

					}
					else
					{
			
						/*----insert user exam list---------*/
						$userid=$this->session->userdata('user_id');
						$createdate=date("Y-m-d H:i:s");
						$chkrow_exam=$this->questions_model->check_userassessment($userid,$year_id,1);	
						
						if($chkrow_exam->exam_id!="" )
						{
							$exam_id=$chkrow_exam->exam_id;
						}
						else
						{
							$user_exam=array(
									'user_id'=>$userid,
									'year_id'=>$year_id,
									'assyear_id'=>$ass_year_id,													
									'exam_date'=>$createdate,
									'start_time'=>$createdate
									
									);
							$exam_id=$this->questions_model->Save_Userassessment($user_exam);	
						}
						
						if($exam_id!="")
						{
							$uexam_history=array(
								'exam_id'=>$exam_id,
								'user_id'=>$userid,
								'year_id'=>$year_id,
								'assyear_id'=>$ass_year_id,													
								'question_id'=>$questionid,
								'answer_id'=>$answerid,
								'answer_status'=>'false',
								
								);
							$hexam_id=$this->questions_model->Save_Assessmenthistory($uexam_history);		
						}
						
								/*----Get user exam question array------*/
					$exam_questermArr=array();
					$exam_questions=$this->questions_model->check_asstesthistory_question($userid,$year_id,$term_id);
					if($exam_questions)
					{
						
						foreach($exam_questions as $examdata)
						{
							array_push($exam_questermArr,$examdata->question_id);
						}
					}
					
					
					/*----End of get user exam question array----*/
					$term_questermArr=array();
					$term_questions=$this->questions_model->assessment_exam($year_id,1);
					if($term_questions)
					{
						
						foreach($term_questions as $tquestion)
						{
							array_push($term_questermArr,$tquestion->ass_question);
						}
						
					}
					$total_exam_question=count($exam_questermArr);
					$total_term_question=count($term_questermArr);
					/*---update term by exam completed status----*/
					if($total_term_question==$total_exam_question)
					{
						$exam_status=array(
								'exam_status'=>'pass',
								'end_time'=>$createdate,	
								
								);
						
						$updateexam_status=$this->questions_model->Update_Asstterm_status($exam_status,$exam_id);
						$data['completed']=1;
					}
					/*---update term by exam completed status----*/
						
						/*----End of insert user exam list-------*/
					
						$data["yourans"] = $this->main_model->get_detail('manage_answer_'.$ass_year_id,'ans_id',$answerid);	
						$data['exam_id']=$exam_id;
						$this->load->view('frontend/private/asstestexplanation',$data);
					}
					
								
					}
				else
				{
					$userid=$this->session->userdata('user_id');
					/*---check user not applied question list---*/
					$userexams=$this->questions_model->check_uasstestbyyear($userid,$year_id);
					$data['exam_id']=$userexams->exam_id;
					if($userexams->exam_id!="" && $userexams->exam_status=='pending')
					{	
						$data['assyear_id']=$userexams->assyear_id;
					}
					
					else if($userexams->exam_id!="" && $userexams->exam_status=='pass')
					{	
						$data['assyear_id']=$userexams->assyear_id+1;
					}
				
					else
					{
						$data['assyear_id']=$pastyear[0]->ass_year_id;
						//echo $pastyear[0]->ass_year_id;
					}
					
					/*----Get user exam question array------*/
					$exam_questermArr=array();
					$exam_questions=$this->questions_model->check_asstesthistory_question($userid,$year_id,1);
					if($exam_questions)
					{
						
						foreach($exam_questions as $examdata)
						{
							array_push($exam_questermArr,$examdata->question_id);
						}
					}
					
					
					/*----End of get user exam question array----*/
					$term_questermArr=array();
					$term_questions=$this->questions_model->assessment_exam($year_id,1);
					
					if($term_questions)
					{
						
						foreach($term_questions as $tquestion)
						{
							array_push($term_questermArr,$tquestion->ass_question);
						}
						
					}
					//var_dump($term_questermArr);
					
					$exam_output = array_merge(array_diff($term_questermArr, $exam_questermArr), array_diff($exam_questermArr, $term_questermArr));
					$exam_random=array_rand($exam_output);					
					$randquestion=$exam_output[$exam_random];
					/*---End of check user not applied question list---*/
					if($userexams->exam_status!='pass')
					{
					$data['Questionlist']=$this->questions_model->asstest_exam_question($year_id,1,$randquestion);
					}
					else
					{
						$data['Questionlist']='';
						$data['completed']=1;
					}
					//var_dump($data['Questionlist']);
					$this->load->view('frontend/private/assessmentplay',$data);
				}
			
			}
			/*---End Assessment Test -----*/
			/*---final year exam-----*/
			else if($subskill=="exam")
			{
				
				
					if($this->input->post('action')=='submitanswer')	
					{
					 $questionid=$this->input->post('questionid');
					 $answerid=$this->input->post('answerid');
					 $year_id=$this->input->post('year_id');
					 $term_id=$this->input->post('term_id');
				
					
					$data["ques_dtl"] = $this->main_model->get_detail('manage_question_'.$year_id,'ques_id',$questionid);					
					
					$data["correct_ans"] = $this->main_model->get_detail('manage_answer_'.$year_id,'ans_id',$data["ques_dtl"]->ques_rightanswer);					
										
					if($data["ques_dtl"]->ques_rightanswer==$answerid)
					{
						
						$data['correct']=1;
						/*----insert user exam list---------*/
						$userid=$this->session->userdata('user_id');
						$createdate=date("Y-m-d H:i:s");
						$chkrow_exam=$this->questions_model->check_userexam($userid,$year_id,$term_id);	
						
						if($chkrow_exam->exam_id!="" )
						{
							$exam_id=$chkrow_exam->exam_id;
						}
						else
						{
							$user_exam=array(
									'user_id'=>$userid,
									'year_id'=>$year_id,
									'term_id'=>$term_id,													
									'exam_date'=>$createdate
									
									);
							$exam_id=$this->questions_model->Save_Userexam($user_exam);	
						}
						
						if($exam_id!="")
						{
							$uexam_history=array(
								'exam_id'=>$exam_id,
								'user_id'=>$userid,
								'year_id'=>$year_id,
								'term_id'=>$term_id,													
								'question_id'=>$questionid,
								'answer_id'=>$answerid,
								'answer_status'=>'false',
								
								);
							$historyexam_id=$this->questions_model->Save_Examhistory($uexam_history);		
						}
						
						/*----End of insert user exam list-------*/
						
										/*---check user not applied question list---*/
					$userexams=$this->questions_model->check_uexambyyear($userid,$year_id);
					if($userexams->exam_id!="" && $userexams->exam_status=='pending')
					{	
						$data['term_id']=$userexams->term_id;
					}
					else if($userexams->exam_id!="" && $userexams->exam_status=='pass')
					{	
						$data['term_id']=$userexams->term_id+1;
					}
					else
					{
						$data['term_id']=1;
					}
					
					/*----Get user exam question array------*/
					$exam_questermArr=array();
					$exam_questions=$this->questions_model->check_examhistory_question($userid,$year_id,$data['term_id']);
					if($exam_questions)
					{
						
						foreach($exam_questions as $examdata)
						{
							array_push($exam_questermArr,$examdata->question_id);
						}
					}
					
					
					/*----End of get user exam question array----*/
					$term_questermArr=array();
					$term_questions=$this->questions_model->term_exam($year_id,$data['term_id']);
					if($term_questions)
					{
						
						foreach($term_questions as $tquestion)
						{
							array_push($term_questermArr,$tquestion->question_id);
						}
						
					}
					$total_exam_question=count($exam_questermArr);
					$total_term_question=count($exam_questermArr);
					/*---update term by exam completed status----*/
					if($total_term_question==$total_exam_question)
					{
						$exam_status=array(
								'exam_status'=>'pass',							
								
								);
						
						$updateexam_status=$this->questions_model->Update_Examterm_status($exam_status,$exam_id);
					}
					/*---update term by exam completed status----*/
					$exam_output = array_merge(array_diff($term_questermArr, $exam_questermArr), array_diff($exam_questermArr, $term_questermArr));
					$exam_random=array_rand($exam_output);					
					$randquestion=$exam_output[$exam_random];
					/*---End of check user not applied question list---*/
					$data['Questionlist']=$this->questions_model->term_exam_question($year_id,$data['term_id'],$randquestion);
						//$data['Questionlist']=$this->questions_model->term_exam($year_id,1);
						$this->load->view('frontend/private/examplay',$data);

					}
					else
					{
			
						/*----insert user exam list---------*/
						$userid=$this->session->userdata('user_id');
						$createdate=date("Y-m-d H:i:s");
						$chkrow_exam=$this->questions_model->check_userexam($userid,$year_id,$term_id);	
						
						if($chkrow_exam->exam_id!="" )
						{
							$exam_id=$chkrow_exam->exam_id;
						}
						else
						{
							$user_exam=array(
									'user_id'=>$userid,
									'year_id'=>$year_id,
									'term_id'=>$term_id,													
									'exam_date'=>$createdate
									
									);
							$exam_id=$this->questions_model->Save_Userexam($user_exam);	
						}
						
						if($exam_id!="")
						{
							$uexam_history=array(
								'exam_id'=>$exam_id,
								'user_id'=>$userid,
								'year_id'=>$year_id,
								'term_id'=>$term_id,													
								'question_id'=>$questionid,
								'answer_id'=>$answerid,
								'answer_status'=>'true',
								
								);
							$hexam_id=$this->questions_model->Save_Examhistory($uexam_history);		
						}
						
								/*----Get user exam question array------*/
					$exam_questermArr=array();
					$exam_questions=$this->questions_model->check_examhistory_question($userid,$year_id,$term_id);
					if($exam_questions)
					{
						
						foreach($exam_questions as $examdata)
						{
							array_push($exam_questermArr,$examdata->question_id);
						}
					}
					
					
					/*----End of get user exam question array----*/
					$term_questermArr=array();
					$term_questions=$this->questions_model->term_exam($year_id,$term_id);
					if($term_questions)
					{
						
						foreach($term_questions as $tquestion)
						{
							array_push($term_questermArr,$tquestion->question_id);
						}
						
					}
					$total_exam_question=count($exam_questermArr);
					$total_term_question=count($exam_questermArr);
					/*---update term by exam completed status----*/
					if($total_term_question==$total_exam_question)
					{
						$exam_status=array(
								'exam_status'=>'pass',							
								
								);
						
						$updateexam_status=$this->questions_model->Update_Examterm_status($exam_status,$exam_id);
					}
					/*---update term by exam completed status----*/
						
						/*----End of insert user exam list-------*/
						$data["yourans"] = $this->main_model->get_detail('manage_answer_'.$year_id,'ans_id',$answerid);	
						$this->load->view('frontend/private/explanation',$data);
					}
					
								
					}
				else
				{
					$userid=$this->session->userdata('user_id');
					/*---check user not applied question list---*/
					$userexams=$this->questions_model->check_uexambyyear($userid,$year_id);
					if($userexams->exam_id!="" && $userexams->exam_status=='pending')
					{	
						$data['term_id']=$userexams->term_id;
					}
					else if($userexams->exam_id!="" && $userexams->exam_status=='pass')
					{	
						$data['term_id']=$userexams->term_id+1;
					}
					else
					{
						$data['term_id']=1;
					}
					
					/*----Get user exam question array------*/
					$exam_questermArr=array();
					$exam_questions=$this->questions_model->check_examhistory_question($userid,$year_id,$data['term_id']);
					if($exam_questions)
					{
						
						foreach($exam_questions as $examdata)
						{
							array_push($exam_questermArr,$examdata->question_id);
						}
					}
					
					
					/*----End of get user exam question array----*/
					$term_questermArr=array();
					$term_questions=$this->questions_model->term_exam($year_id,$data['term_id']);
					if($term_questions)
					{
						
						foreach($term_questions as $tquestion)
						{
							array_push($term_questermArr,$tquestion->question_id);
						}
						
					}
					//var_dump($term_questermArr);
					
					$exam_output = array_merge(array_diff($term_questermArr, $exam_questermArr), array_diff($exam_questermArr, $term_questermArr));
					$exam_random=array_rand($exam_output);					
					$randquestion=$exam_output[$exam_random];
					/*---End of check user not applied question list---*/
					$data['Questionlist']=$this->questions_model->term_exam_question($year_id,$data['term_id'],$randquestion);
	
					$this->load->view('frontend/private/examplay',$data);
				}
			}
			/*---end final year exam-----*/
			else
			{	

			$data["skill_dtl"] =$this->main_model->get_skill('master_skill','skill_slug',$subskill,'skill_class',$year_id);		
			  $subskill_id=$data["skill_dtl"]->skill_id;
			$this->questions_model->CLASSID = $year_id;
				//$data["Questionlist"] = $this->questions_model->question_list_subskill($subskill_id);
		
				if($this->input->post('action')=='submitanswer')	
					{
					 $questionid=$this->input->post('questionid');
					 $answerid=$this->input->post('answerid');
				
					
					$data["ques_dtl"] = $this->main_model->get_detail('manage_question_'.$year_id,'ques_id',$questionid);
					//print_r($data["ques_dtl"]);
					
					$data["correct_ans"] = $this->main_model->get_detail('manage_answer_'.$year_id,'ans_id',$data["ques_dtl"]->ques_rightanswer);
					//print_r($data["correct_ans"]);
					//echo $data["correct_ans"]->ans_name;
										
					if($data["ques_dtl"]->ques_rightanswer==$answerid)
					{
						
					$data['correct']=1;
					$data["Questionlist"] = $this->questions_model->random_question($subskill_id);
					$this->load->view('frontend/private/play',$data);

					}
					else{
			
					$data["yourans"] = $this->main_model->get_detail('manage_answer_'.$year_id,'ans_id',$answerid);	
					$this->load->view('frontend/private/explanation',$data);
					}
					
								
					}
				else{
					$data["Questionlist"] = $this->questions_model->random_question($subskill_id);
					$this->load->view('frontend/private/play',$data);
					}
			
				}
			}
			else{
				
				if($this->session->userdata('user_id')!='' and $this->session->userdata('username')!='')
				{

				$data["SylList1"] = $this->syllabus_model->syllabus_list($year_id,1);
				$data["SylList2"] = $this->syllabus_model->syllabus_list($year_id,2);
				$data["SylList3"] = $this->syllabus_model->syllabus_list($year_id,3);
				$data["SylList4"] = $this->syllabus_model->syllabus_list($year_id,4);

				$this->load->view('frontend/private/kindergarten', $data);
				}
				else{
				$data["SylList1"] = $this->syllabus_model->syllabus_list($year_id,1);
				$data["SylList2"] = $this->syllabus_model->syllabus_list($year_id,2);
				$data["SylList3"] = $this->syllabus_model->syllabus_list($year_id,3);
				$data["SylList4"] = $this->syllabus_model->syllabus_list($year_id,4);

				$this->load->view('frontend/public/kg_wtht_login', $data);	
					
				}

			}
		
		
	}
	public function year3($subskill='') 
	{	
		$yearid=$this->session->userdata('loginyear');
			$yeardata=$this->classes_model->classes_details($yearid);
			if($yeardata)
			{
				$data['year_name']=$yeardata[0]->class_name;
				$data['year_slug']=$yeardata[0]->class_slug;
			}
		$year_id=4;
		$data['year_id']=$year_id;
		$this->questions_model->CLASSID = $year_id;
		$data["year_dtl"] = $this->main_model->get_detail('master_class','class_id',$year_id);	
		if($subskill!=""){
			/*---Start Assessment Test -----*/
			if($subskill=="assessment")
			{
				
					/*---get all past year of assessment list----*/
					$pastyear=$this->questions_model->assessment_pastyear($year_id);
						/*echo '<pre>';
						var_dump($pastyear);
						echo '</pre>';
						*/
					$todaydate=date("Y-m-d H:i:s");	
					$userid=$this->session->userdata('user_id');
					$asstime_query=$this->questions_model->assessment_time($year_id,$userid);
					$yourstart=$asstime_query->start_time;
					if($yourstart!="" && $yourstart!=null)
					{
						$seconds = strtotime($todaydate) - strtotime($yourstart);
						$days    = floor($seconds / 86400);
						$hours   = floor(($seconds - ($days * 86400)) / 3600);
						$minutes = floor(($seconds - ($days * 86400) - ($hours * 3600))/60);
						
						if($minutes >30)
						{
							//echo $minutes;
							$exam_status=array(
								'exam_status'=>'pass',							
								'end_time'=>$todaydate,
								);
						
						$updateexam_status=$this->questions_model->Update_Asstterm_status($exam_status,$asstime_query->exam_id);
						$data['timeover']=1;
						}
						else
						{
							$totalminutes=30-$minutes;
							$data['showtimer']='Duration Left: '.$totalminutes;
						}
					}
					else
					{
						$data['showtimer']='Duration: 30';
					}
					
					/*---end of get all past year of assessment list----*/	
					if($this->input->post('action')=='submitanswer')	
					{
						//var_dump($this->input->post());
					 $questionid=$this->input->post('questionid');
					 $answerid=$this->input->post('answerid');
					 $year_id=$this->input->post('year_id');
					 $ass_year_id=$this->input->post('ass_year_id');
				
					
					$data["ques_dtl"] = $this->main_model->get_detail('manage_question_'.$ass_year_id,'ques_id',$questionid);					
					//var_dump($data["ques_dtl"]);
					$data["correct_ans"] = $this->main_model->get_detail('manage_answer_'.$ass_year_id,'ans_id',$data["ques_dtl"]->ques_rightanswer);					
										
					if($data["ques_dtl"]->ques_rightanswer==$answerid)
					{
						
						$data['correct']=1;
						/*----insert user exam list---------*/
						
						$createdate=date("Y-m-d H:i:s");
						$chkrow_exam=$this->questions_model->check_userassessment($userid,$year_id,1);	
						
						if($chkrow_exam->exam_id!="" )
						{
							$exam_id=$chkrow_exam->exam_id;
						}
						else
						{
							$user_exam=array(
									'user_id'=>$userid,
									'year_id'=>$year_id,
									'assyear_id'=>$ass_year_id,													
									'exam_date'=>$createdate,
									'start_time'=>$createdate
									
									);
							$exam_id=$this->questions_model->Save_Userassessment($user_exam);	
						}
						
						if($exam_id!="")
						{
							$uexam_history=array(
								'exam_id'=>$exam_id,
								'user_id'=>$userid,
								'year_id'=>$year_id,
								'assyear_id'=>$ass_year_id,													
								'question_id'=>$questionid,
								'answer_id'=>$answerid,
								'answer_status'=>'true',
								
								);
							$historyexam_id=$this->questions_model->Save_Assessmenthistory($uexam_history);		
						}
						
						/*----End of insert user exam list-------*/
										
					/*----Get user exam question array------*/
					$exam_questermArr=array();
					$exam_questions=$this->questions_model->check_asstesthistory_question($userid,$year_id,1);
					if($exam_questions)
					{
						
						foreach($exam_questions as $examdata)
						{
							array_push($exam_questermArr,$examdata->question_id);
						}
					}
					
					
					/*----End of get user exam question array----*/
					$term_questermArr=array();
					$term_questions=$this->questions_model->assessment_exam($year_id,1);
					if($term_questions)
					{
						
						foreach($term_questions as $tquestion)
						{
							array_push($term_questermArr,$tquestion->ass_question);
						}
						
					}
					$total_exam_question=count($exam_questermArr);
					$total_term_question=count($term_questermArr);
					/*---update term by exam completed status----*/
					if($total_term_question==$total_exam_question)
					{
						$exam_status=array(
								'exam_status'=>'pass',							
								'end_time'=>$createdate,
								);
						
						$updateexam_status=$this->questions_model->Update_Asstterm_status($exam_status,$exam_id);
						$data['completed']=1;
					}
					/*---update term by exam completed status----*/
					$exam_output = array_merge(array_diff($term_questermArr, $exam_questermArr), array_diff($exam_questermArr, $term_questermArr));
					$exam_random=array_rand($exam_output);					
					$randquestion=$exam_output[$exam_random];
					/*---End of check user not applied question list---*/
					$data['Questionlist']=$this->questions_model->asstest_exam_question($year_id,1,$randquestion);
						//$data['Questionlist']=$this->questions_model->term_exam($year_id,1);
						$data['exam_id']=$exam_id;
						$this->load->view('frontend/private/assessmentplay',$data);

					}
					else
					{
			
						/*----insert user exam list---------*/
						$userid=$this->session->userdata('user_id');
						$createdate=date("Y-m-d H:i:s");
						$chkrow_exam=$this->questions_model->check_userassessment($userid,$year_id,1);	
						
						if($chkrow_exam->exam_id!="" )
						{
							$exam_id=$chkrow_exam->exam_id;
						}
						else
						{
							$user_exam=array(
									'user_id'=>$userid,
									'year_id'=>$year_id,
									'assyear_id'=>$ass_year_id,													
									'exam_date'=>$createdate,
									'start_time'=>$createdate
									
									);
							$exam_id=$this->questions_model->Save_Userassessment($user_exam);	
						}
						
						if($exam_id!="")
						{
							$uexam_history=array(
								'exam_id'=>$exam_id,
								'user_id'=>$userid,
								'year_id'=>$year_id,
								'assyear_id'=>$ass_year_id,													
								'question_id'=>$questionid,
								'answer_id'=>$answerid,
								'answer_status'=>'false',
								
								);
							$hexam_id=$this->questions_model->Save_Assessmenthistory($uexam_history);		
						}
						
								/*----Get user exam question array------*/
					$exam_questermArr=array();
					$exam_questions=$this->questions_model->check_asstesthistory_question($userid,$year_id,$term_id);
					if($exam_questions)
					{
						
						foreach($exam_questions as $examdata)
						{
							array_push($exam_questermArr,$examdata->question_id);
						}
					}
					
					
					/*----End of get user exam question array----*/
					$term_questermArr=array();
					$term_questions=$this->questions_model->assessment_exam($year_id,1);
					if($term_questions)
					{
						
						foreach($term_questions as $tquestion)
						{
							array_push($term_questermArr,$tquestion->ass_question);
						}
						
					}
					$total_exam_question=count($exam_questermArr);
					$total_term_question=count($term_questermArr);
					/*---update term by exam completed status----*/
					if($total_term_question==$total_exam_question)
					{
						$exam_status=array(
								'exam_status'=>'pass',
								'end_time'=>$createdate,	
								
								);
						
						$updateexam_status=$this->questions_model->Update_Asstterm_status($exam_status,$exam_id);
						$data['completed']=1;
					}
					/*---update term by exam completed status----*/
						
						/*----End of insert user exam list-------*/
					
						$data["yourans"] = $this->main_model->get_detail('manage_answer_'.$ass_year_id,'ans_id',$answerid);	
						$data['exam_id']=$exam_id;
						$this->load->view('frontend/private/asstestexplanation',$data);
					}
					
								
					}
				else
				{
					$userid=$this->session->userdata('user_id');
					/*---check user not applied question list---*/
					$userexams=$this->questions_model->check_uasstestbyyear($userid,$year_id);
					$data['exam_id']=$userexams->exam_id;
					if($userexams->exam_id!="" && $userexams->exam_status=='pending')
					{	
						$data['assyear_id']=$userexams->assyear_id;
					}
					
					else if($userexams->exam_id!="" && $userexams->exam_status=='pass')
					{	
						$data['assyear_id']=$userexams->assyear_id+1;
					}
				
					else
					{
						$data['assyear_id']=$pastyear[0]->ass_year_id;
						//echo $pastyear[0]->ass_year_id;
					}
					
					/*----Get user exam question array------*/
					$exam_questermArr=array();
					$exam_questions=$this->questions_model->check_asstesthistory_question($userid,$year_id,1);
					if($exam_questions)
					{
						
						foreach($exam_questions as $examdata)
						{
							array_push($exam_questermArr,$examdata->question_id);
						}
					}
					
					
					/*----End of get user exam question array----*/
					$term_questermArr=array();
					$term_questions=$this->questions_model->assessment_exam($year_id,1);
					
					if($term_questions)
					{
						
						foreach($term_questions as $tquestion)
						{
							array_push($term_questermArr,$tquestion->ass_question);
						}
						
					}
					//var_dump($term_questermArr);
					
					$exam_output = array_merge(array_diff($term_questermArr, $exam_questermArr), array_diff($exam_questermArr, $term_questermArr));
					$exam_random=array_rand($exam_output);					
					$randquestion=$exam_output[$exam_random];
					/*---End of check user not applied question list---*/
					if($userexams->exam_status!='pass')
					{
					$data['Questionlist']=$this->questions_model->asstest_exam_question($year_id,1,$randquestion);
					}
					else
					{
						$data['Questionlist']='';
						$data['completed']=1;
					}
					//var_dump($data['Questionlist']);
					$this->load->view('frontend/private/assessmentplay',$data);
				}
			
			}
			/*---End Assessment Test -----*/
			/*---final year exam-----*/
			else if($subskill=="exam")
			{
				
				
					if($this->input->post('action')=='submitanswer')	
					{
					 $questionid=$this->input->post('questionid');
					 $answerid=$this->input->post('answerid');
					 $year_id=$this->input->post('year_id');
					 $term_id=$this->input->post('term_id');
				
					
					$data["ques_dtl"] = $this->main_model->get_detail('manage_question_'.$year_id,'ques_id',$questionid);					
					
					$data["correct_ans"] = $this->main_model->get_detail('manage_answer_'.$year_id,'ans_id',$data["ques_dtl"]->ques_rightanswer);					
										
					if($data["ques_dtl"]->ques_rightanswer==$answerid)
					{
						
						$data['correct']=1;
						/*----insert user exam list---------*/
						$userid=$this->session->userdata('user_id');
						$createdate=date("Y-m-d H:i:s");
						$chkrow_exam=$this->questions_model->check_userexam($userid,$year_id,$term_id);	
						
						if($chkrow_exam->exam_id!="" )
						{
							$exam_id=$chkrow_exam->exam_id;
						}
						else
						{
							$user_exam=array(
									'user_id'=>$userid,
									'year_id'=>$year_id,
									'term_id'=>$term_id,													
									'exam_date'=>$createdate
									
									);
							$exam_id=$this->questions_model->Save_Userexam($user_exam);	
						}
						
						if($exam_id!="")
						{
							$uexam_history=array(
								'exam_id'=>$exam_id,
								'user_id'=>$userid,
								'year_id'=>$year_id,
								'term_id'=>$term_id,													
								'question_id'=>$questionid,
								'answer_id'=>$answerid,
								'answer_status'=>'false',
								
								);
							$historyexam_id=$this->questions_model->Save_Examhistory($uexam_history);		
						}
						
						/*----End of insert user exam list-------*/
						
										/*---check user not applied question list---*/
					$userexams=$this->questions_model->check_uexambyyear($userid,$year_id);
					if($userexams->exam_id!="" && $userexams->exam_status=='pending')
					{	
						$data['term_id']=$userexams->term_id;
					}
					else if($userexams->exam_id!="" && $userexams->exam_status=='pass')
					{	
						$data['term_id']=$userexams->term_id+1;
					}
					else
					{
						$data['term_id']=1;
					}
					
					/*----Get user exam question array------*/
					$exam_questermArr=array();
					$exam_questions=$this->questions_model->check_examhistory_question($userid,$year_id,$data['term_id']);
					if($exam_questions)
					{
						
						foreach($exam_questions as $examdata)
						{
							array_push($exam_questermArr,$examdata->question_id);
						}
					}
					
					
					/*----End of get user exam question array----*/
					$term_questermArr=array();
					$term_questions=$this->questions_model->term_exam($year_id,$data['term_id']);
					if($term_questions)
					{
						
						foreach($term_questions as $tquestion)
						{
							array_push($term_questermArr,$tquestion->question_id);
						}
						
					}
					$total_exam_question=count($exam_questermArr);
					$total_term_question=count($exam_questermArr);
					/*---update term by exam completed status----*/
					if($total_term_question==$total_exam_question)
					{
						$exam_status=array(
								'exam_status'=>'pass',							
								
								);
						
						$updateexam_status=$this->questions_model->Update_Examterm_status($exam_status,$exam_id);
					}
					/*---update term by exam completed status----*/
					$exam_output = array_merge(array_diff($term_questermArr, $exam_questermArr), array_diff($exam_questermArr, $term_questermArr));
					$exam_random=array_rand($exam_output);					
					$randquestion=$exam_output[$exam_random];
					/*---End of check user not applied question list---*/
					$data['Questionlist']=$this->questions_model->term_exam_question($year_id,$data['term_id'],$randquestion);
						//$data['Questionlist']=$this->questions_model->term_exam($year_id,1);
						$this->load->view('frontend/private/examplay',$data);

					}
					else
					{
			
						/*----insert user exam list---------*/
						$userid=$this->session->userdata('user_id');
						$createdate=date("Y-m-d H:i:s");
						$chkrow_exam=$this->questions_model->check_userexam($userid,$year_id,$term_id);	
						
						if($chkrow_exam->exam_id!="" )
						{
							$exam_id=$chkrow_exam->exam_id;
						}
						else
						{
							$user_exam=array(
									'user_id'=>$userid,
									'year_id'=>$year_id,
									'term_id'=>$term_id,													
									'exam_date'=>$createdate
									
									);
							$exam_id=$this->questions_model->Save_Userexam($user_exam);	
						}
						
						if($exam_id!="")
						{
							$uexam_history=array(
								'exam_id'=>$exam_id,
								'user_id'=>$userid,
								'year_id'=>$year_id,
								'term_id'=>$term_id,													
								'question_id'=>$questionid,
								'answer_id'=>$answerid,
								'answer_status'=>'true',
								
								);
							$hexam_id=$this->questions_model->Save_Examhistory($uexam_history);		
						}
						
								/*----Get user exam question array------*/
					$exam_questermArr=array();
					$exam_questions=$this->questions_model->check_examhistory_question($userid,$year_id,$term_id);
					if($exam_questions)
					{
						
						foreach($exam_questions as $examdata)
						{
							array_push($exam_questermArr,$examdata->question_id);
						}
					}
					
					
					/*----End of get user exam question array----*/
					$term_questermArr=array();
					$term_questions=$this->questions_model->term_exam($year_id,$term_id);
					if($term_questions)
					{
						
						foreach($term_questions as $tquestion)
						{
							array_push($term_questermArr,$tquestion->question_id);
						}
						
					}
					$total_exam_question=count($exam_questermArr);
					$total_term_question=count($exam_questermArr);
					/*---update term by exam completed status----*/
					if($total_term_question==$total_exam_question)
					{
						$exam_status=array(
								'exam_status'=>'pass',							
								
								);
						
						$updateexam_status=$this->questions_model->Update_Examterm_status($exam_status,$exam_id);
					}
					/*---update term by exam completed status----*/
						
						/*----End of insert user exam list-------*/
						$data["yourans"] = $this->main_model->get_detail('manage_answer_'.$year_id,'ans_id',$answerid);	
						$this->load->view('frontend/private/explanation',$data);
					}
					
								
					}
				else
				{
					$userid=$this->session->userdata('user_id');
					/*---check user not applied question list---*/
					$userexams=$this->questions_model->check_uexambyyear($userid,$year_id);
					if($userexams->exam_id!="" && $userexams->exam_status=='pending')
					{	
						$data['term_id']=$userexams->term_id;
					}
					else if($userexams->exam_id!="" && $userexams->exam_status=='pass')
					{	
						$data['term_id']=$userexams->term_id+1;
					}
					else
					{
						$data['term_id']=1;
					}
					
					/*----Get user exam question array------*/
					$exam_questermArr=array();
					$exam_questions=$this->questions_model->check_examhistory_question($userid,$year_id,$data['term_id']);
					if($exam_questions)
					{
						
						foreach($exam_questions as $examdata)
						{
							array_push($exam_questermArr,$examdata->question_id);
						}
					}
					
					
					/*----End of get user exam question array----*/
					$term_questermArr=array();
					$term_questions=$this->questions_model->term_exam($year_id,$data['term_id']);
					if($term_questions)
					{
						
						foreach($term_questions as $tquestion)
						{
							array_push($term_questermArr,$tquestion->question_id);
						}
						
					}
					//var_dump($term_questermArr);
					
					$exam_output = array_merge(array_diff($term_questermArr, $exam_questermArr), array_diff($exam_questermArr, $term_questermArr));
					$exam_random=array_rand($exam_output);					
					$randquestion=$exam_output[$exam_random];
					/*---End of check user not applied question list---*/
					$data['Questionlist']=$this->questions_model->term_exam_question($year_id,$data['term_id'],$randquestion);
	
					$this->load->view('frontend/private/examplay',$data);
				}
			}
			/*---end final year exam-----*/
			else
			{	

			$data["skill_dtl"] =$this->main_model->get_skill('master_skill','skill_slug',$subskill,'skill_class',$year_id);		
			  $subskill_id=$data["skill_dtl"]->skill_id;
			 $this->questions_model->CLASSID = $year_id;
				//$data["Questionlist"] = $this->questions_model->question_list_subskill($subskill_id);
		
				if($this->input->post('action')=='submitanswer')	
					{
					 $questionid=$this->input->post('questionid');
					
					 
					$ques_detail= $this->questions_model->question_details($questionid);
					$ques_type=explode(',',$ques_detail->ques_type);
					if(in_array(1,$ques_type)){  
						
					 $answerid=$this->input->post('answerid');
					$answerid=$this->input->post('answerid');
				
					
					$data["ques_dtl"] = $this->main_model->get_detail('manage_question_'.$year_id,'ques_id',$questionid);
					//print_r($data["ques_dtl"]);
					
					$data["correct_ans"] = $this->main_model->get_detail('manage_answer_'.$year_id,'ans_id',$data["ques_dtl"]->ques_rightanswer);
					//print_r($data["correct_ans"]);
					//echo $data["correct_ans"]->ans_name;
										
					if($data["ques_dtl"]->ques_rightanswer==$answerid)
					{
						
					$data['correct']=1;
					$data["Questionlist"] = $this->questions_model->random_question($subskill_id);
					$this->load->view('frontend/private/play',$data);

					}
					else{
			
					$data["yourans"] = $this->main_model->get_detail('manage_answer_'.$year_id,'ans_id',$answerid);	
					$this->load->view('frontend/private/explanation',$data);
					}
					}
					elseif(in_array(26,$ques_type))
					{
						
					$all_answer = $this->main_model->getall('manage_answer_'.$year_id,'ans_quesid',$questionid);
					$answer_count = count($all_answer);
					
					$cnt_post_input=count($_POST)-3;
					if($answer_count==$cnt_post_input){
					$correct=true;
					 for($i=0;$i<count($all_answer);$i++){
						 
						$incount=$i+1;
						if($all_answer[$i]->ans_name!=$this->input->post('input'.$incount))
						{ 
							$correct=false;
							
						}
						
					 	
					 }
					}
					else{$correct=false;}
					 if($correct){
						$data['correct']=1;
						$data["Questionlist"] = $this->questions_model->random_question($subskill_id);
						$this->load->view('frontend/private/play',$data);
					 }
					 else{
						$data["yourans"] = $this->main_model->get_detail('manage_answer_'.$year_id,'ans_id',$answerid);	
						$this->load->view('frontend/private/explanation',$data);
					 }
					 
					}
					 
					
					else{
						$data["yourans"] = $this->main_model->get_detail('manage_answer_'.$year_id,'ans_id',$answerid);	
						$this->load->view('frontend/private/explanation',$data);
						}
						
					}
				else{
					$data["Questionlist"] = $this->questions_model->random_question($subskill_id);
					$this->load->view('frontend/private/play',$data);
					}
			
				}
			}
			else{
				
				if($this->session->userdata('user_id')!='' and $this->session->userdata('username')!='')
				{

				$data["SylList1"] = $this->syllabus_model->syllabus_list($year_id,1);
				$data["SylList2"] = $this->syllabus_model->syllabus_list($year_id,2);
				$data["SylList3"] = $this->syllabus_model->syllabus_list($year_id,3);
				$data["SylList4"] = $this->syllabus_model->syllabus_list($year_id,4);

				$this->load->view('frontend/private/kindergarten', $data);
				}
				else{
				$data["SylList1"] = $this->syllabus_model->syllabus_list($year_id,1);
				$data["SylList2"] = $this->syllabus_model->syllabus_list($year_id,2);
				$data["SylList3"] = $this->syllabus_model->syllabus_list($year_id,3);
				$data["SylList4"] = $this->syllabus_model->syllabus_list($year_id,4);

				$this->load->view('frontend/public/kg_wtht_login', $data);	
					
				}

			}
		
	}
	public function year4($subskill='') 
	{	
		$yearid=$this->session->userdata('loginyear');
			$yeardata=$this->classes_model->classes_details($yearid);
			if($yeardata)
			{
				$data['year_name']=$yeardata[0]->class_name;
				$data['year_slug']=$yeardata[0]->class_slug;
			}
		$year_id=5;
		$data['year_id']=$year_id;
		$this->questions_model->CLASSID = $year_id;
		$data["year_dtl"] = $this->main_model->get_detail('master_class','class_id',$year_id);	
		if($subskill!=""){
			/*---Start Assessment Test -----*/
			if($subskill=="assessment")
			{
				
					/*---get all past year of assessment list----*/
					$pastyear=$this->questions_model->assessment_pastyear($year_id);
						/*echo '<pre>';
						var_dump($pastyear);
						echo '</pre>';
						*/
					$todaydate=date("Y-m-d H:i:s");	
					$userid=$this->session->userdata('user_id');
					$asstime_query=$this->questions_model->assessment_time($year_id,$userid);
					$yourstart=$asstime_query->start_time;
					if($yourstart!="" && $yourstart!=null)
					{
						$seconds = strtotime($todaydate) - strtotime($yourstart);
						$days    = floor($seconds / 86400);
						$hours   = floor(($seconds - ($days * 86400)) / 3600);
						$minutes = floor(($seconds - ($days * 86400) - ($hours * 3600))/60);
						
						if($minutes >30)
						{
							//echo $minutes;
							$exam_status=array(
								'exam_status'=>'pass',							
								'end_time'=>$todaydate,
								);
						
						$updateexam_status=$this->questions_model->Update_Asstterm_status($exam_status,$asstime_query->exam_id);
						$data['timeover']=1;
						}
						else
						{
							$totalminutes=30-$minutes;
							$data['showtimer']='Duration Left: '.$totalminutes;
						}
					}
					else
					{
						$data['showtimer']='Duration: 30';
					}
					
					/*---end of get all past year of assessment list----*/	
					if($this->input->post('action')=='submitanswer')	
					{
						//var_dump($this->input->post());
					 $questionid=$this->input->post('questionid');
					 $answerid=$this->input->post('answerid');
					 $year_id=$this->input->post('year_id');
					 $ass_year_id=$this->input->post('ass_year_id');
				
					
					$data["ques_dtl"] = $this->main_model->get_detail('manage_question_'.$ass_year_id,'ques_id',$questionid);					
					//var_dump($data["ques_dtl"]);
					$data["correct_ans"] = $this->main_model->get_detail('manage_answer_'.$ass_year_id,'ans_id',$data["ques_dtl"]->ques_rightanswer);					
										
					if($data["ques_dtl"]->ques_rightanswer==$answerid)
					{
						
						$data['correct']=1;
						/*----insert user exam list---------*/
						
						$createdate=date("Y-m-d H:i:s");
						$chkrow_exam=$this->questions_model->check_userassessment($userid,$year_id,1);	
						
						if($chkrow_exam->exam_id!="" )
						{
							$exam_id=$chkrow_exam->exam_id;
						}
						else
						{
							$user_exam=array(
									'user_id'=>$userid,
									'year_id'=>$year_id,
									'assyear_id'=>$ass_year_id,													
									'exam_date'=>$createdate,
									'start_time'=>$createdate
									
									);
							$exam_id=$this->questions_model->Save_Userassessment($user_exam);	
						}
						
						if($exam_id!="")
						{
							$uexam_history=array(
								'exam_id'=>$exam_id,
								'user_id'=>$userid,
								'year_id'=>$year_id,
								'assyear_id'=>$ass_year_id,													
								'question_id'=>$questionid,
								'answer_id'=>$answerid,
								'answer_status'=>'true',
								
								);
							$historyexam_id=$this->questions_model->Save_Assessmenthistory($uexam_history);		
						}
						
						/*----End of insert user exam list-------*/
										
					/*----Get user exam question array------*/
					$exam_questermArr=array();
					$exam_questions=$this->questions_model->check_asstesthistory_question($userid,$year_id,1);
					if($exam_questions)
					{
						
						foreach($exam_questions as $examdata)
						{
							array_push($exam_questermArr,$examdata->question_id);
						}
					}
					
					
					/*----End of get user exam question array----*/
					$term_questermArr=array();
					$term_questions=$this->questions_model->assessment_exam($year_id,1);
					if($term_questions)
					{
						
						foreach($term_questions as $tquestion)
						{
							array_push($term_questermArr,$tquestion->ass_question);
						}
						
					}
					$total_exam_question=count($exam_questermArr);
					$total_term_question=count($term_questermArr);
					/*---update term by exam completed status----*/
					if($total_term_question==$total_exam_question)
					{
						$exam_status=array(
								'exam_status'=>'pass',							
								'end_time'=>$createdate,
								);
						
						$updateexam_status=$this->questions_model->Update_Asstterm_status($exam_status,$exam_id);
						$data['completed']=1;
					}
					/*---update term by exam completed status----*/
					$exam_output = array_merge(array_diff($term_questermArr, $exam_questermArr), array_diff($exam_questermArr, $term_questermArr));
					$exam_random=array_rand($exam_output);					
					$randquestion=$exam_output[$exam_random];
					/*---End of check user not applied question list---*/
					$data['Questionlist']=$this->questions_model->asstest_exam_question($year_id,1,$randquestion);
						//$data['Questionlist']=$this->questions_model->term_exam($year_id,1);
						$data['exam_id']=$exam_id;
						$this->load->view('frontend/private/assessmentplay',$data);

					}
					else
					{
			
						/*----insert user exam list---------*/
						$userid=$this->session->userdata('user_id');
						$createdate=date("Y-m-d H:i:s");
						$chkrow_exam=$this->questions_model->check_userassessment($userid,$year_id,1);	
						
						if($chkrow_exam->exam_id!="" )
						{
							$exam_id=$chkrow_exam->exam_id;
						}
						else
						{
							$user_exam=array(
									'user_id'=>$userid,
									'year_id'=>$year_id,
									'assyear_id'=>$ass_year_id,													
									'exam_date'=>$createdate,
									'start_time'=>$createdate
									
									);
							$exam_id=$this->questions_model->Save_Userassessment($user_exam);	
						}
						
						if($exam_id!="")
						{
							$uexam_history=array(
								'exam_id'=>$exam_id,
								'user_id'=>$userid,
								'year_id'=>$year_id,
								'assyear_id'=>$ass_year_id,													
								'question_id'=>$questionid,
								'answer_id'=>$answerid,
								'answer_status'=>'false',
								
								);
							$hexam_id=$this->questions_model->Save_Assessmenthistory($uexam_history);		
						}
						
								/*----Get user exam question array------*/
					$exam_questermArr=array();
					$exam_questions=$this->questions_model->check_asstesthistory_question($userid,$year_id,$term_id);
					if($exam_questions)
					{
						
						foreach($exam_questions as $examdata)
						{
							array_push($exam_questermArr,$examdata->question_id);
						}
					}
					
					
					/*----End of get user exam question array----*/
					$term_questermArr=array();
					$term_questions=$this->questions_model->assessment_exam($year_id,1);
					if($term_questions)
					{
						
						foreach($term_questions as $tquestion)
						{
							array_push($term_questermArr,$tquestion->ass_question);
						}
						
					}
					$total_exam_question=count($exam_questermArr);
					$total_term_question=count($term_questermArr);
					/*---update term by exam completed status----*/
					if($total_term_question==$total_exam_question)
					{
						$exam_status=array(
								'exam_status'=>'pass',
								'end_time'=>$createdate,	
								
								);
						
						$updateexam_status=$this->questions_model->Update_Asstterm_status($exam_status,$exam_id);
						$data['completed']=1;
					}
					/*---update term by exam completed status----*/
						
						/*----End of insert user exam list-------*/
					
						$data["yourans"] = $this->main_model->get_detail('manage_answer_'.$ass_year_id,'ans_id',$answerid);	
						$data['exam_id']=$exam_id;
						$this->load->view('frontend/private/asstestexplanation',$data);
					}
					
								
					}
				else
				{
					$userid=$this->session->userdata('user_id');
					/*---check user not applied question list---*/
					$userexams=$this->questions_model->check_uasstestbyyear($userid,$year_id);
					$data['exam_id']=$userexams->exam_id;
					if($userexams->exam_id!="" && $userexams->exam_status=='pending')
					{	
						$data['assyear_id']=$userexams->assyear_id;
					}
					
					else if($userexams->exam_id!="" && $userexams->exam_status=='pass')
					{	
						$data['assyear_id']=$userexams->assyear_id+1;
					}
				
					else
					{
						$data['assyear_id']=$pastyear[0]->ass_year_id;
						//echo $pastyear[0]->ass_year_id;
					}
					
					/*----Get user exam question array------*/
					$exam_questermArr=array();
					$exam_questions=$this->questions_model->check_asstesthistory_question($userid,$year_id,1);
					if($exam_questions)
					{
						
						foreach($exam_questions as $examdata)
						{
							array_push($exam_questermArr,$examdata->question_id);
						}
					}
					
					
					/*----End of get user exam question array----*/
					$term_questermArr=array();
					$term_questions=$this->questions_model->assessment_exam($year_id,1);
					
					if($term_questions)
					{
						
						foreach($term_questions as $tquestion)
						{
							array_push($term_questermArr,$tquestion->ass_question);
						}
						
					}
					//var_dump($term_questermArr);
					
					$exam_output = array_merge(array_diff($term_questermArr, $exam_questermArr), array_diff($exam_questermArr, $term_questermArr));
					$exam_random=array_rand($exam_output);					
					$randquestion=$exam_output[$exam_random];
					/*---End of check user not applied question list---*/
					if($userexams->exam_status!='pass')
					{
					$data['Questionlist']=$this->questions_model->asstest_exam_question($year_id,1,$randquestion);
					}
					else
					{
						$data['Questionlist']='';
						$data['completed']=1;
					}
					//var_dump($data['Questionlist']);
					$this->load->view('frontend/private/assessmentplay',$data);
				}
			
			}
			/*---End Assessment Test -----*/
			/*---final year exam-----*/
			else if($subskill=="exam")
			{
				
				
					if($this->input->post('action')=='submitanswer')	
					{
					 $questionid=$this->input->post('questionid');
					 $answerid=$this->input->post('answerid');
					 $year_id=$this->input->post('year_id');
					 $term_id=$this->input->post('term_id');
				
					
					$data["ques_dtl"] = $this->main_model->get_detail('manage_question_'.$year_id,'ques_id',$questionid);					
					
					$data["correct_ans"] = $this->main_model->get_detail('manage_answer_'.$year_id,'ans_id',$data["ques_dtl"]->ques_rightanswer);					
										
					if($data["ques_dtl"]->ques_rightanswer==$answerid)
					{
						
						$data['correct']=1;
						/*----insert user exam list---------*/
						$userid=$this->session->userdata('user_id');
						$createdate=date("Y-m-d H:i:s");
						$chkrow_exam=$this->questions_model->check_userexam($userid,$year_id,$term_id);	
						
						if($chkrow_exam->exam_id!="" )
						{
							$exam_id=$chkrow_exam->exam_id;
						}
						else
						{
							$user_exam=array(
									'user_id'=>$userid,
									'year_id'=>$year_id,
									'term_id'=>$term_id,													
									'exam_date'=>$createdate
									
									);
							$exam_id=$this->questions_model->Save_Userexam($user_exam);	
						}
						
						if($exam_id!="")
						{
							$uexam_history=array(
								'exam_id'=>$exam_id,
								'user_id'=>$userid,
								'year_id'=>$year_id,
								'term_id'=>$term_id,													
								'question_id'=>$questionid,
								'answer_id'=>$answerid,
								'answer_status'=>'false',
								
								);
							$historyexam_id=$this->questions_model->Save_Examhistory($uexam_history);		
						}
						
						/*----End of insert user exam list-------*/
						
										/*---check user not applied question list---*/
					$userexams=$this->questions_model->check_uexambyyear($userid,$year_id);
					if($userexams->exam_id!="" && $userexams->exam_status=='pending')
					{	
						$data['term_id']=$userexams->term_id;
					}
					else if($userexams->exam_id!="" && $userexams->exam_status=='pass')
					{	
						$data['term_id']=$userexams->term_id+1;
					}
					else
					{
						$data['term_id']=1;
					}
					
					/*----Get user exam question array------*/
					$exam_questermArr=array();
					$exam_questions=$this->questions_model->check_examhistory_question($userid,$year_id,$data['term_id']);
					if($exam_questions)
					{
						
						foreach($exam_questions as $examdata)
						{
							array_push($exam_questermArr,$examdata->question_id);
						}
					}
					
					
					/*----End of get user exam question array----*/
					$term_questermArr=array();
					$term_questions=$this->questions_model->term_exam($year_id,$data['term_id']);
					if($term_questions)
					{
						
						foreach($term_questions as $tquestion)
						{
							array_push($term_questermArr,$tquestion->question_id);
						}
						
					}
					$total_exam_question=count($exam_questermArr);
					$total_term_question=count($exam_questermArr);
					/*---update term by exam completed status----*/
					if($total_term_question==$total_exam_question)
					{
						$exam_status=array(
								'exam_status'=>'pass',							
								
								);
						
						$updateexam_status=$this->questions_model->Update_Examterm_status($exam_status,$exam_id);
					}
					/*---update term by exam completed status----*/
					$exam_output = array_merge(array_diff($term_questermArr, $exam_questermArr), array_diff($exam_questermArr, $term_questermArr));
					$exam_random=array_rand($exam_output);					
					$randquestion=$exam_output[$exam_random];
					/*---End of check user not applied question list---*/
					$data['Questionlist']=$this->questions_model->term_exam_question($year_id,$data['term_id'],$randquestion);
						//$data['Questionlist']=$this->questions_model->term_exam($year_id,1);
						$this->load->view('frontend/private/examplay',$data);

					}
					else
					{
			
						/*----insert user exam list---------*/
						$userid=$this->session->userdata('user_id');
						$createdate=date("Y-m-d H:i:s");
						$chkrow_exam=$this->questions_model->check_userexam($userid,$year_id,$term_id);	
						
						if($chkrow_exam->exam_id!="" )
						{
							$exam_id=$chkrow_exam->exam_id;
						}
						else
						{
							$user_exam=array(
									'user_id'=>$userid,
									'year_id'=>$year_id,
									'term_id'=>$term_id,													
									'exam_date'=>$createdate
									
									);
							$exam_id=$this->questions_model->Save_Userexam($user_exam);	
						}
						
						if($exam_id!="")
						{
							$uexam_history=array(
								'exam_id'=>$exam_id,
								'user_id'=>$userid,
								'year_id'=>$year_id,
								'term_id'=>$term_id,													
								'question_id'=>$questionid,
								'answer_id'=>$answerid,
								'answer_status'=>'true',
								
								);
							$hexam_id=$this->questions_model->Save_Examhistory($uexam_history);		
						}
						
								/*----Get user exam question array------*/
					$exam_questermArr=array();
					$exam_questions=$this->questions_model->check_examhistory_question($userid,$year_id,$term_id);
					if($exam_questions)
					{
						
						foreach($exam_questions as $examdata)
						{
							array_push($exam_questermArr,$examdata->question_id);
						}
					}
					
					
					/*----End of get user exam question array----*/
					$term_questermArr=array();
					$term_questions=$this->questions_model->term_exam($year_id,$term_id);
					if($term_questions)
					{
						
						foreach($term_questions as $tquestion)
						{
							array_push($term_questermArr,$tquestion->question_id);
						}
						
					}
					$total_exam_question=count($exam_questermArr);
					$total_term_question=count($exam_questermArr);
					/*---update term by exam completed status----*/
					if($total_term_question==$total_exam_question)
					{
						$exam_status=array(
								'exam_status'=>'pass',							
								
								);
						
						$updateexam_status=$this->questions_model->Update_Examterm_status($exam_status,$exam_id);
					}
					/*---update term by exam completed status----*/
						
						/*----End of insert user exam list-------*/
						$data["yourans"] = $this->main_model->get_detail('manage_answer_'.$year_id,'ans_id',$answerid);	
						$this->load->view('frontend/private/explanation',$data);
					}
					
								
					}
				else
				{
					$userid=$this->session->userdata('user_id');
					/*---check user not applied question list---*/
					$userexams=$this->questions_model->check_uexambyyear($userid,$year_id);
					if($userexams->exam_id!="" && $userexams->exam_status=='pending')
					{	
						$data['term_id']=$userexams->term_id;
					}
					else if($userexams->exam_id!="" && $userexams->exam_status=='pass')
					{	
						$data['term_id']=$userexams->term_id+1;
					}
					else
					{
						$data['term_id']=1;
					}
					
					/*----Get user exam question array------*/
					$exam_questermArr=array();
					$exam_questions=$this->questions_model->check_examhistory_question($userid,$year_id,$data['term_id']);
					if($exam_questions)
					{
						
						foreach($exam_questions as $examdata)
						{
							array_push($exam_questermArr,$examdata->question_id);
						}
					}
					
					
					/*----End of get user exam question array----*/
					$term_questermArr=array();
					$term_questions=$this->questions_model->term_exam($year_id,$data['term_id']);
					if($term_questions)
					{
						
						foreach($term_questions as $tquestion)
						{
							array_push($term_questermArr,$tquestion->question_id);
						}
						
					}
					//var_dump($term_questermArr);
					
					$exam_output = array_merge(array_diff($term_questermArr, $exam_questermArr), array_diff($exam_questermArr, $term_questermArr));
					$exam_random=array_rand($exam_output);					
					$randquestion=$exam_output[$exam_random];
					/*---End of check user not applied question list---*/
					$data['Questionlist']=$this->questions_model->term_exam_question($year_id,$data['term_id'],$randquestion);
	
					$this->load->view('frontend/private/examplay',$data);
				}
			}
			/*---end final year exam-----*/
			else
			{	

			$data["skill_dtl"] =$this->main_model->get_skill('master_skill','skill_slug',$subskill,'skill_class',$year_id);		
			  $subskill_id=$data["skill_dtl"]->skill_id;
			 $this->questions_model->CLASSID = $year_id;
				//$data["Questionlist"] = $this->questions_model->question_list_subskill($subskill_id);
		
				if($this->input->post('action')=='submitanswer')	
					{
					 $questionid=$this->input->post('questionid');
					
					 
					$ques_detail= $this->questions_model->question_details($questionid);
					$ques_type=explode(',',$ques_detail->ques_type);
					if(in_array(1,$ques_type)){  
						
					 $answerid=$this->input->post('answerid');
					$answerid=$this->input->post('answerid');
				
					
					$data["ques_dtl"] = $this->main_model->get_detail('manage_question_'.$year_id,'ques_id',$questionid);
					//print_r($data["ques_dtl"]);
					
					$data["correct_ans"] = $this->main_model->get_detail('manage_answer_'.$year_id,'ans_id',$data["ques_dtl"]->ques_rightanswer);
					//print_r($data["correct_ans"]);
					//echo $data["correct_ans"]->ans_name;
										
					if($data["ques_dtl"]->ques_rightanswer==$answerid)
					{
						
					$data['correct']=1;
					$data["Questionlist"] = $this->questions_model->random_question($subskill_id);
					$this->load->view('frontend/private/play',$data);

					}
					else{
			
					$data["yourans"] = $this->main_model->get_detail('manage_answer_'.$year_id,'ans_id',$answerid);	
					$this->load->view('frontend/private/explanation',$data);
					}
					}
					elseif(in_array(26,$ques_type))
					{
						
					$all_answer = $this->main_model->getall('manage_answer_'.$year_id,'ans_quesid',$questionid);
					$correct=true;
					 for($i=0;$i<count($all_answer);$i++){
						 
						$incount=$i+1;
						if($all_answer[$i]->ans_name!=$this->input->post('input'.$incount))
						{ 
							$correct=false;
							
						}
						
					 	
					 }
					 
					 if($correct){
						$data['correct']=1;
						$data["Questionlist"] = $this->questions_model->random_question($subskill_id);
						$this->load->view('frontend/private/play',$data);
					 }
					 else{
						$data["yourans"] = $this->main_model->get_detail('manage_answer_'.$year_id,'ans_id',$answerid);	
						$this->load->view('frontend/private/explanation',$data);
					 }
					 
					}
					 
					
					else{
						$data["yourans"] = $this->main_model->get_detail('manage_answer_'.$year_id,'ans_id',$answerid);	
						$this->load->view('frontend/private/explanation',$data);
						}
						
					}
				else{
					$data["Questionlist"] = $this->questions_model->random_question($subskill_id);
					$this->load->view('frontend/private/play',$data);
					}
			
				}
			}
			else{
				
				if($this->session->userdata('user_id')!='' and $this->session->userdata('username')!='')
				{

				$data["SylList1"] = $this->syllabus_model->syllabus_list($year_id,1);
				$data["SylList2"] = $this->syllabus_model->syllabus_list($year_id,2);
				$data["SylList3"] = $this->syllabus_model->syllabus_list($year_id,3);
				$data["SylList4"] = $this->syllabus_model->syllabus_list($year_id,4);

				$this->load->view('frontend/private/kindergarten', $data);
				}
				else{
				$data["SylList1"] = $this->syllabus_model->syllabus_list($year_id,1);
				$data["SylList2"] = $this->syllabus_model->syllabus_list($year_id,2);
				$data["SylList3"] = $this->syllabus_model->syllabus_list($year_id,3);
				$data["SylList4"] = $this->syllabus_model->syllabus_list($year_id,4);

				$this->load->view('frontend/public/kg_wtht_login', $data);	
					
				}

			}
		
	}
	public function year5($subskill='') 
	{	
		$yearid=$this->session->userdata('loginyear');
			$yeardata=$this->classes_model->classes_details($yearid);
			if($yeardata)
			{
				$data['year_name']=$yeardata[0]->class_name;
				$data['year_slug']=$yeardata[0]->class_slug;
			}
		$year_id=6;
		$data['year_id']=$year_id;
		$this->questions_model->CLASSID = $year_id;
		$data["year_dtl"] = $this->main_model->get_detail('master_class','class_id',$year_id);	
		if($subskill!=""){
			/*---Start Assessment Test -----*/
			if($subskill=="assessment")
			{
				
					/*---get all past year of assessment list----*/
					$pastyear=$this->questions_model->assessment_pastyear($year_id);
						/*echo '<pre>';
						var_dump($pastyear);
						echo '</pre>';
						*/
					$todaydate=date("Y-m-d H:i:s");	
					$userid=$this->session->userdata('user_id');
					$asstime_query=$this->questions_model->assessment_time($year_id,$userid);
					$yourstart=$asstime_query->start_time;
					if($yourstart!="" && $yourstart!=null)
					{
						$seconds = strtotime($todaydate) - strtotime($yourstart);
						$days    = floor($seconds / 86400);
						$hours   = floor(($seconds - ($days * 86400)) / 3600);
						$minutes = floor(($seconds - ($days * 86400) - ($hours * 3600))/60);
						
						if($minutes >30)
						{
							//echo $minutes;
							$exam_status=array(
								'exam_status'=>'pass',							
								'end_time'=>$todaydate,
								);
						
						$updateexam_status=$this->questions_model->Update_Asstterm_status($exam_status,$asstime_query->exam_id);
						$data['timeover']=1;
						}
						else
						{
							$totalminutes=30-$minutes;
							$data['showtimer']='Duration Left: '.$totalminutes;
						}
					}
					else
					{
						$data['showtimer']='Duration: 30';
					}
					
					/*---end of get all past year of assessment list----*/	
					if($this->input->post('action')=='submitanswer')	
					{
						//var_dump($this->input->post());
					 $questionid=$this->input->post('questionid');
					 $answerid=$this->input->post('answerid');
					 $year_id=$this->input->post('year_id');
					 $ass_year_id=$this->input->post('ass_year_id');
				
					
					$data["ques_dtl"] = $this->main_model->get_detail('manage_question_'.$ass_year_id,'ques_id',$questionid);					
					//var_dump($data["ques_dtl"]);
					$data["correct_ans"] = $this->main_model->get_detail('manage_answer_'.$ass_year_id,'ans_id',$data["ques_dtl"]->ques_rightanswer);					
										
					if($data["ques_dtl"]->ques_rightanswer==$answerid)
					{
						
						$data['correct']=1;
						/*----insert user exam list---------*/
						
						$createdate=date("Y-m-d H:i:s");
						$chkrow_exam=$this->questions_model->check_userassessment($userid,$year_id,1);	
						
						if($chkrow_exam->exam_id!="" )
						{
							$exam_id=$chkrow_exam->exam_id;
						}
						else
						{
							$user_exam=array(
									'user_id'=>$userid,
									'year_id'=>$year_id,
									'assyear_id'=>$ass_year_id,													
									'exam_date'=>$createdate,
									'start_time'=>$createdate
									
									);
							$exam_id=$this->questions_model->Save_Userassessment($user_exam);	
						}
						
						if($exam_id!="")
						{
							$uexam_history=array(
								'exam_id'=>$exam_id,
								'user_id'=>$userid,
								'year_id'=>$year_id,
								'assyear_id'=>$ass_year_id,													
								'question_id'=>$questionid,
								'answer_id'=>$answerid,
								'answer_status'=>'true',
								
								);
							$historyexam_id=$this->questions_model->Save_Assessmenthistory($uexam_history);		
						}
						
						/*----End of insert user exam list-------*/
										
					/*----Get user exam question array------*/
					$exam_questermArr=array();
					$exam_questions=$this->questions_model->check_asstesthistory_question($userid,$year_id,1);
					if($exam_questions)
					{
						
						foreach($exam_questions as $examdata)
						{
							array_push($exam_questermArr,$examdata->question_id);
						}
					}
					
					
					/*----End of get user exam question array----*/
					$term_questermArr=array();
					$term_questions=$this->questions_model->assessment_exam($year_id,1);
					if($term_questions)
					{
						
						foreach($term_questions as $tquestion)
						{
							array_push($term_questermArr,$tquestion->ass_question);
						}
						
					}
					$total_exam_question=count($exam_questermArr);
					$total_term_question=count($term_questermArr);
					/*---update term by exam completed status----*/
					if($total_term_question==$total_exam_question)
					{
						$exam_status=array(
								'exam_status'=>'pass',							
								'end_time'=>$createdate,
								);
						
						$updateexam_status=$this->questions_model->Update_Asstterm_status($exam_status,$exam_id);
						$data['completed']=1;
					}
					/*---update term by exam completed status----*/
					$exam_output = array_merge(array_diff($term_questermArr, $exam_questermArr), array_diff($exam_questermArr, $term_questermArr));
					$exam_random=array_rand($exam_output);					
					$randquestion=$exam_output[$exam_random];
					/*---End of check user not applied question list---*/
					$data['Questionlist']=$this->questions_model->asstest_exam_question($year_id,1,$randquestion);
						//$data['Questionlist']=$this->questions_model->term_exam($year_id,1);
						$data['exam_id']=$exam_id;
						$this->load->view('frontend/private/assessmentplay',$data);

					}
					else
					{
			
						/*----insert user exam list---------*/
						$userid=$this->session->userdata('user_id');
						$createdate=date("Y-m-d H:i:s");
						$chkrow_exam=$this->questions_model->check_userassessment($userid,$year_id,1);	
						
						if($chkrow_exam->exam_id!="" )
						{
							$exam_id=$chkrow_exam->exam_id;
						}
						else
						{
							$user_exam=array(
									'user_id'=>$userid,
									'year_id'=>$year_id,
									'assyear_id'=>$ass_year_id,													
									'exam_date'=>$createdate,
									'start_time'=>$createdate
									
									);
							$exam_id=$this->questions_model->Save_Userassessment($user_exam);	
						}
						
						if($exam_id!="")
						{
							$uexam_history=array(
								'exam_id'=>$exam_id,
								'user_id'=>$userid,
								'year_id'=>$year_id,
								'assyear_id'=>$ass_year_id,													
								'question_id'=>$questionid,
								'answer_id'=>$answerid,
								'answer_status'=>'false',
								
								);
							$hexam_id=$this->questions_model->Save_Assessmenthistory($uexam_history);		
						}
						
								/*----Get user exam question array------*/
					$exam_questermArr=array();
					$exam_questions=$this->questions_model->check_asstesthistory_question($userid,$year_id,$term_id);
					if($exam_questions)
					{
						
						foreach($exam_questions as $examdata)
						{
							array_push($exam_questermArr,$examdata->question_id);
						}
					}
					
					
					/*----End of get user exam question array----*/
					$term_questermArr=array();
					$term_questions=$this->questions_model->assessment_exam($year_id,1);
					if($term_questions)
					{
						
						foreach($term_questions as $tquestion)
						{
							array_push($term_questermArr,$tquestion->ass_question);
						}
						
					}
					$total_exam_question=count($exam_questermArr);
					$total_term_question=count($term_questermArr);
					/*---update term by exam completed status----*/
					if($total_term_question==$total_exam_question)
					{
						$exam_status=array(
								'exam_status'=>'pass',
								'end_time'=>$createdate,	
								
								);
						
						$updateexam_status=$this->questions_model->Update_Asstterm_status($exam_status,$exam_id);
						$data['completed']=1;
					}
					/*---update term by exam completed status----*/
						
						/*----End of insert user exam list-------*/
					
						$data["yourans"] = $this->main_model->get_detail('manage_answer_'.$ass_year_id,'ans_id',$answerid);	
						$data['exam_id']=$exam_id;
						$this->load->view('frontend/private/asstestexplanation',$data);
					}
					
								
					}
				else
				{
					$userid=$this->session->userdata('user_id');
					/*---check user not applied question list---*/
					$userexams=$this->questions_model->check_uasstestbyyear($userid,$year_id);
					$data['exam_id']=$userexams->exam_id;
					if($userexams->exam_id!="" && $userexams->exam_status=='pending')
					{	
						$data['assyear_id']=$userexams->assyear_id;
					}
					
					else if($userexams->exam_id!="" && $userexams->exam_status=='pass')
					{	
						$data['assyear_id']=$userexams->assyear_id+1;
					}
				
					else
					{
						$data['assyear_id']=$pastyear[0]->ass_year_id;
						//echo $pastyear[0]->ass_year_id;
					}
					
					/*----Get user exam question array------*/
					$exam_questermArr=array();
					$exam_questions=$this->questions_model->check_asstesthistory_question($userid,$year_id,1);
					if($exam_questions)
					{
						
						foreach($exam_questions as $examdata)
						{
							array_push($exam_questermArr,$examdata->question_id);
						}
					}
					
					
					/*----End of get user exam question array----*/
					$term_questermArr=array();
					$term_questions=$this->questions_model->assessment_exam($year_id,1);
					
					if($term_questions)
					{
						
						foreach($term_questions as $tquestion)
						{
							array_push($term_questermArr,$tquestion->ass_question);
						}
						
					}
					//var_dump($term_questermArr);
					
					$exam_output = array_merge(array_diff($term_questermArr, $exam_questermArr), array_diff($exam_questermArr, $term_questermArr));
					$exam_random=array_rand($exam_output);					
					$randquestion=$exam_output[$exam_random];
					/*---End of check user not applied question list---*/
					if($userexams->exam_status!='pass')
					{
					$data['Questionlist']=$this->questions_model->asstest_exam_question($year_id,1,$randquestion);
					}
					else
					{
						$data['Questionlist']='';
						$data['completed']=1;
					}
					//var_dump($data['Questionlist']);
					$this->load->view('frontend/private/assessmentplay',$data);
				}
			
			}
			/*---End Assessment Test -----*/
			/*---final year exam-----*/
			else if($subskill=="exam")
			{
				
				
					if($this->input->post('action')=='submitanswer')	
					{
					 $questionid=$this->input->post('questionid');
					 $answerid=$this->input->post('answerid');
					 $year_id=$this->input->post('year_id');
					 $term_id=$this->input->post('term_id');
				
					
					$data["ques_dtl"] = $this->main_model->get_detail('manage_question_'.$year_id,'ques_id',$questionid);					
					
					$data["correct_ans"] = $this->main_model->get_detail('manage_answer_'.$year_id,'ans_id',$data["ques_dtl"]->ques_rightanswer);					
										
					if($data["ques_dtl"]->ques_rightanswer==$answerid)
					{
						
						$data['correct']=1;
						/*----insert user exam list---------*/
						$userid=$this->session->userdata('user_id');
						$createdate=date("Y-m-d H:i:s");
						$chkrow_exam=$this->questions_model->check_userexam($userid,$year_id,$term_id);	
						
						if($chkrow_exam->exam_id!="" )
						{
							$exam_id=$chkrow_exam->exam_id;
						}
						else
						{
							$user_exam=array(
									'user_id'=>$userid,
									'year_id'=>$year_id,
									'term_id'=>$term_id,													
									'exam_date'=>$createdate
									
									);
							$exam_id=$this->questions_model->Save_Userexam($user_exam);	
						}
						
						if($exam_id!="")
						{
							$uexam_history=array(
								'exam_id'=>$exam_id,
								'user_id'=>$userid,
								'year_id'=>$year_id,
								'term_id'=>$term_id,													
								'question_id'=>$questionid,
								'answer_id'=>$answerid,
								'answer_status'=>'false',
								
								);
							$historyexam_id=$this->questions_model->Save_Examhistory($uexam_history);		
						}
						
						/*----End of insert user exam list-------*/
						
										/*---check user not applied question list---*/
					$userexams=$this->questions_model->check_uexambyyear($userid,$year_id);
					if($userexams->exam_id!="" && $userexams->exam_status=='pending')
					{	
						$data['term_id']=$userexams->term_id;
					}
					else if($userexams->exam_id!="" && $userexams->exam_status=='pass')
					{	
						$data['term_id']=$userexams->term_id+1;
					}
					else
					{
						$data['term_id']=1;
					}
					
					/*----Get user exam question array------*/
					$exam_questermArr=array();
					$exam_questions=$this->questions_model->check_examhistory_question($userid,$year_id,$data['term_id']);
					if($exam_questions)
					{
						
						foreach($exam_questions as $examdata)
						{
							array_push($exam_questermArr,$examdata->question_id);
						}
					}
					
					
					/*----End of get user exam question array----*/
					$term_questermArr=array();
					$term_questions=$this->questions_model->term_exam($year_id,$data['term_id']);
					if($term_questions)
					{
						
						foreach($term_questions as $tquestion)
						{
							array_push($term_questermArr,$tquestion->question_id);
						}
						
					}
					$total_exam_question=count($exam_questermArr);
					$total_term_question=count($exam_questermArr);
					/*---update term by exam completed status----*/
					if($total_term_question==$total_exam_question)
					{
						$exam_status=array(
								'exam_status'=>'pass',							
								
								);
						
						$updateexam_status=$this->questions_model->Update_Examterm_status($exam_status,$exam_id);
					}
					/*---update term by exam completed status----*/
					$exam_output = array_merge(array_diff($term_questermArr, $exam_questermArr), array_diff($exam_questermArr, $term_questermArr));
					$exam_random=array_rand($exam_output);					
					$randquestion=$exam_output[$exam_random];
					/*---End of check user not applied question list---*/
					$data['Questionlist']=$this->questions_model->term_exam_question($year_id,$data['term_id'],$randquestion);
						//$data['Questionlist']=$this->questions_model->term_exam($year_id,1);
						$this->load->view('frontend/private/examplay',$data);

					}
					else
					{
			
						/*----insert user exam list---------*/
						$userid=$this->session->userdata('user_id');
						$createdate=date("Y-m-d H:i:s");
						$chkrow_exam=$this->questions_model->check_userexam($userid,$year_id,$term_id);	
						
						if($chkrow_exam->exam_id!="" )
						{
							$exam_id=$chkrow_exam->exam_id;
						}
						else
						{
							$user_exam=array(
									'user_id'=>$userid,
									'year_id'=>$year_id,
									'term_id'=>$term_id,													
									'exam_date'=>$createdate
									
									);
							$exam_id=$this->questions_model->Save_Userexam($user_exam);	
						}
						
						if($exam_id!="")
						{
							$uexam_history=array(
								'exam_id'=>$exam_id,
								'user_id'=>$userid,
								'year_id'=>$year_id,
								'term_id'=>$term_id,													
								'question_id'=>$questionid,
								'answer_id'=>$answerid,
								'answer_status'=>'true',
								
								);
							$hexam_id=$this->questions_model->Save_Examhistory($uexam_history);		
						}
						
								/*----Get user exam question array------*/
					$exam_questermArr=array();
					$exam_questions=$this->questions_model->check_examhistory_question($userid,$year_id,$term_id);
					if($exam_questions)
					{
						
						foreach($exam_questions as $examdata)
						{
							array_push($exam_questermArr,$examdata->question_id);
						}
					}
					
					
					/*----End of get user exam question array----*/
					$term_questermArr=array();
					$term_questions=$this->questions_model->term_exam($year_id,$term_id);
					if($term_questions)
					{
						
						foreach($term_questions as $tquestion)
						{
							array_push($term_questermArr,$tquestion->question_id);
						}
						
					}
					$total_exam_question=count($exam_questermArr);
					$total_term_question=count($exam_questermArr);
					/*---update term by exam completed status----*/
					if($total_term_question==$total_exam_question)
					{
						$exam_status=array(
								'exam_status'=>'pass',							
								
								);
						
						$updateexam_status=$this->questions_model->Update_Examterm_status($exam_status,$exam_id);
					}
					/*---update term by exam completed status----*/
						
						/*----End of insert user exam list-------*/
						$data["yourans"] = $this->main_model->get_detail('manage_answer_'.$year_id,'ans_id',$answerid);	
						$this->load->view('frontend/private/explanation',$data);
					}
					
								
					}
				else
				{
					$userid=$this->session->userdata('user_id');
					/*---check user not applied question list---*/
					$userexams=$this->questions_model->check_uexambyyear($userid,$year_id);
					if($userexams->exam_id!="" && $userexams->exam_status=='pending')
					{	
						$data['term_id']=$userexams->term_id;
					}
					else if($userexams->exam_id!="" && $userexams->exam_status=='pass')
					{	
						$data['term_id']=$userexams->term_id+1;
					}
					else
					{
						$data['term_id']=1;
					}
					
					/*----Get user exam question array------*/
					$exam_questermArr=array();
					$exam_questions=$this->questions_model->check_examhistory_question($userid,$year_id,$data['term_id']);
					if($exam_questions)
					{
						
						foreach($exam_questions as $examdata)
						{
							array_push($exam_questermArr,$examdata->question_id);
						}
					}
					
					
					/*----End of get user exam question array----*/
					$term_questermArr=array();
					$term_questions=$this->questions_model->term_exam($year_id,$data['term_id']);
					if($term_questions)
					{
						
						foreach($term_questions as $tquestion)
						{
							array_push($term_questermArr,$tquestion->question_id);
						}
						
					}
					//var_dump($term_questermArr);
					
					$exam_output = array_merge(array_diff($term_questermArr, $exam_questermArr), array_diff($exam_questermArr, $term_questermArr));
					$exam_random=array_rand($exam_output);					
					$randquestion=$exam_output[$exam_random];
					/*---End of check user not applied question list---*/
					$data['Questionlist']=$this->questions_model->term_exam_question($year_id,$data['term_id'],$randquestion);
	
					$this->load->view('frontend/private/examplay',$data);
				}
			}
			/*---end final year exam-----*/
			else
			{	

			$data["skill_dtl"] =$this->main_model->get_skill('master_skill','skill_slug',$subskill,'skill_class',$year_id);		
			  $subskill_id=$data["skill_dtl"]->skill_id;
			$this->questions_model->CLASSID = $year_id;
				//$data["Questionlist"] = $this->questions_model->question_list_subskill($subskill_id);
		
				if($this->input->post('action')=='submitanswer')	
					{
					 $questionid=$this->input->post('questionid');
					 $answerid=$this->input->post('answerid');
				
					
					$data["ques_dtl"] = $this->main_model->get_detail('manage_question_'.$year_id,'ques_id',$questionid);
					//print_r($data["ques_dtl"]);
					
					$data["correct_ans"] = $this->main_model->get_detail('manage_answer_'.$year_id,'ans_id',$data["ques_dtl"]->ques_rightanswer);
					//print_r($data["correct_ans"]);
					//echo $data["correct_ans"]->ans_name;
										
					if($data["ques_dtl"]->ques_rightanswer==$answerid)
					{
						
					$data['correct']=1;
					$data["Questionlist"] = $this->questions_model->random_question($subskill_id);
					$this->load->view('frontend/private/play',$data);

					}
					else{
			
					$data["yourans"] = $this->main_model->get_detail('manage_answer_'.$year_id,'ans_id',$answerid);	
					$this->load->view('frontend/private/explanation',$data);
					}
					
								
					}
				else{
					$data["Questionlist"] = $this->questions_model->random_question($subskill_id);
					$this->load->view('frontend/private/play',$data);
					}
			
				}
			}
			else{
				
				if($this->session->userdata('user_id')!='' and $this->session->userdata('username')!='')
				{

				$data["SylList1"] = $this->syllabus_model->syllabus_list($year_id,1);
				$data["SylList2"] = $this->syllabus_model->syllabus_list($year_id,2);
				$data["SylList3"] = $this->syllabus_model->syllabus_list($year_id,3);
				$data["SylList4"] = $this->syllabus_model->syllabus_list($year_id,4);

				$this->load->view('frontend/private/kindergarten', $data);
				}
				else{
				$data["SylList1"] = $this->syllabus_model->syllabus_list($year_id,1);
				$data["SylList2"] = $this->syllabus_model->syllabus_list($year_id,2);
				$data["SylList3"] = $this->syllabus_model->syllabus_list($year_id,3);
				$data["SylList4"] = $this->syllabus_model->syllabus_list($year_id,4);

				$this->load->view('frontend/public/kg_wtht_login', $data);	
					
				}

			}
		
	}
	public function year6($subskill='') 
	{	
		$yearid=$this->session->userdata('loginyear');
			$yeardata=$this->classes_model->classes_details($yearid);
			if($yeardata)
			{
				$data['year_name']=$yeardata[0]->class_name;
				$data['year_slug']=$yeardata[0]->class_slug;
			}
		$year_id=7;
		$data['year_id']=$year_id;
		$this->questions_model->CLASSID = $year_id;
		$data["year_dtl"] = $this->main_model->get_detail('master_class','class_id',$year_id);	
		if($subskill!=""){
			/*---Start Assessment Test -----*/
			if($subskill=="assessment")
			{
				
					/*---get all past year of assessment list----*/
					$pastyear=$this->questions_model->assessment_pastyear($year_id);
						/*echo '<pre>';
						var_dump($pastyear);
						echo '</pre>';
						*/
					$todaydate=date("Y-m-d H:i:s");	
					$userid=$this->session->userdata('user_id');
					$asstime_query=$this->questions_model->assessment_time($year_id,$userid);
					$yourstart=$asstime_query->start_time;
					if($yourstart!="" && $yourstart!=null)
					{
						$seconds = strtotime($todaydate) - strtotime($yourstart);
						$days    = floor($seconds / 86400);
						$hours   = floor(($seconds - ($days * 86400)) / 3600);
						$minutes = floor(($seconds - ($days * 86400) - ($hours * 3600))/60);
						
						if($minutes >30)
						{
							//echo $minutes;
							$exam_status=array(
								'exam_status'=>'pass',							
								'end_time'=>$todaydate,
								);
						
						$updateexam_status=$this->questions_model->Update_Asstterm_status($exam_status,$asstime_query->exam_id);
						$data['timeover']=1;
						}
						else
						{
							$totalminutes=30-$minutes;
							$data['showtimer']='Duration Left: '.$totalminutes;
						}
					}
					else
					{
						$data['showtimer']='Duration: 30';
					}
					
					/*---end of get all past year of assessment list----*/	
					if($this->input->post('action')=='submitanswer')	
					{
						//var_dump($this->input->post());
					 $questionid=$this->input->post('questionid');
					 $answerid=$this->input->post('answerid');
					 $year_id=$this->input->post('year_id');
					 $ass_year_id=$this->input->post('ass_year_id');
				
					
					$data["ques_dtl"] = $this->main_model->get_detail('manage_question_'.$ass_year_id,'ques_id',$questionid);					
					//var_dump($data["ques_dtl"]);
					$data["correct_ans"] = $this->main_model->get_detail('manage_answer_'.$ass_year_id,'ans_id',$data["ques_dtl"]->ques_rightanswer);					
										
					if($data["ques_dtl"]->ques_rightanswer==$answerid)
					{
						
						$data['correct']=1;
						/*----insert user exam list---------*/
						
						$createdate=date("Y-m-d H:i:s");
						$chkrow_exam=$this->questions_model->check_userassessment($userid,$year_id,1);	
						
						if($chkrow_exam->exam_id!="" )
						{
							$exam_id=$chkrow_exam->exam_id;
						}
						else
						{
							$user_exam=array(
									'user_id'=>$userid,
									'year_id'=>$year_id,
									'assyear_id'=>$ass_year_id,													
									'exam_date'=>$createdate,
									'start_time'=>$createdate
									
									);
							$exam_id=$this->questions_model->Save_Userassessment($user_exam);	
						}
						
						if($exam_id!="")
						{
							$uexam_history=array(
								'exam_id'=>$exam_id,
								'user_id'=>$userid,
								'year_id'=>$year_id,
								'assyear_id'=>$ass_year_id,													
								'question_id'=>$questionid,
								'answer_id'=>$answerid,
								'answer_status'=>'true',
								
								);
							$historyexam_id=$this->questions_model->Save_Assessmenthistory($uexam_history);		
						}
						
						/*----End of insert user exam list-------*/
										
					/*----Get user exam question array------*/
					$exam_questermArr=array();
					$exam_questions=$this->questions_model->check_asstesthistory_question($userid,$year_id,1);
					if($exam_questions)
					{
						
						foreach($exam_questions as $examdata)
						{
							array_push($exam_questermArr,$examdata->question_id);
						}
					}
					
					
					/*----End of get user exam question array----*/
					$term_questermArr=array();
					$term_questions=$this->questions_model->assessment_exam($year_id,1);
					if($term_questions)
					{
						
						foreach($term_questions as $tquestion)
						{
							array_push($term_questermArr,$tquestion->ass_question);
						}
						
					}
					$total_exam_question=count($exam_questermArr);
					$total_term_question=count($term_questermArr);
					/*---update term by exam completed status----*/
					if($total_term_question==$total_exam_question)
					{
						$exam_status=array(
								'exam_status'=>'pass',							
								'end_time'=>$createdate,
								);
						
						$updateexam_status=$this->questions_model->Update_Asstterm_status($exam_status,$exam_id);
						$data['completed']=1;
					}
					/*---update term by exam completed status----*/
					$exam_output = array_merge(array_diff($term_questermArr, $exam_questermArr), array_diff($exam_questermArr, $term_questermArr));
					$exam_random=array_rand($exam_output);					
					$randquestion=$exam_output[$exam_random];
					/*---End of check user not applied question list---*/
					$data['Questionlist']=$this->questions_model->asstest_exam_question($year_id,1,$randquestion);
						//$data['Questionlist']=$this->questions_model->term_exam($year_id,1);
						$data['exam_id']=$exam_id;
						$this->load->view('frontend/private/assessmentplay',$data);

					}
					else
					{
			
						/*----insert user exam list---------*/
						$userid=$this->session->userdata('user_id');
						$createdate=date("Y-m-d H:i:s");
						$chkrow_exam=$this->questions_model->check_userassessment($userid,$year_id,1);	
						
						if($chkrow_exam->exam_id!="" )
						{
							$exam_id=$chkrow_exam->exam_id;
						}
						else
						{
							$user_exam=array(
									'user_id'=>$userid,
									'year_id'=>$year_id,
									'assyear_id'=>$ass_year_id,													
									'exam_date'=>$createdate,
									'start_time'=>$createdate
									
									);
							$exam_id=$this->questions_model->Save_Userassessment($user_exam);	
						}
						
						if($exam_id!="")
						{
							$uexam_history=array(
								'exam_id'=>$exam_id,
								'user_id'=>$userid,
								'year_id'=>$year_id,
								'assyear_id'=>$ass_year_id,													
								'question_id'=>$questionid,
								'answer_id'=>$answerid,
								'answer_status'=>'false',
								
								);
							$hexam_id=$this->questions_model->Save_Assessmenthistory($uexam_history);		
						}
						
								/*----Get user exam question array------*/
					$exam_questermArr=array();
					$exam_questions=$this->questions_model->check_asstesthistory_question($userid,$year_id,$term_id);
					if($exam_questions)
					{
						
						foreach($exam_questions as $examdata)
						{
							array_push($exam_questermArr,$examdata->question_id);
						}
					}
					
					
					/*----End of get user exam question array----*/
					$term_questermArr=array();
					$term_questions=$this->questions_model->assessment_exam($year_id,1);
					if($term_questions)
					{
						
						foreach($term_questions as $tquestion)
						{
							array_push($term_questermArr,$tquestion->ass_question);
						}
						
					}
					$total_exam_question=count($exam_questermArr);
					$total_term_question=count($term_questermArr);
					/*---update term by exam completed status----*/
					if($total_term_question==$total_exam_question)
					{
						$exam_status=array(
								'exam_status'=>'pass',
								'end_time'=>$createdate,	
								
								);
						
						$updateexam_status=$this->questions_model->Update_Asstterm_status($exam_status,$exam_id);
						$data['completed']=1;
					}
					/*---update term by exam completed status----*/
						
						/*----End of insert user exam list-------*/
					
						$data["yourans"] = $this->main_model->get_detail('manage_answer_'.$ass_year_id,'ans_id',$answerid);	
						$data['exam_id']=$exam_id;
						$this->load->view('frontend/private/asstestexplanation',$data);
					}
					
								
					}
				else
				{
					$userid=$this->session->userdata('user_id');
					/*---check user not applied question list---*/
					$userexams=$this->questions_model->check_uasstestbyyear($userid,$year_id);
					$data['exam_id']=$userexams->exam_id;
					if($userexams->exam_id!="" && $userexams->exam_status=='pending')
					{	
						$data['assyear_id']=$userexams->assyear_id;
					}
					
					else if($userexams->exam_id!="" && $userexams->exam_status=='pass')
					{	
						$data['assyear_id']=$userexams->assyear_id+1;
					}
				
					else
					{
						$data['assyear_id']=$pastyear[0]->ass_year_id;
						//echo $pastyear[0]->ass_year_id;
					}
					
					/*----Get user exam question array------*/
					$exam_questermArr=array();
					$exam_questions=$this->questions_model->check_asstesthistory_question($userid,$year_id,1);
					if($exam_questions)
					{
						
						foreach($exam_questions as $examdata)
						{
							array_push($exam_questermArr,$examdata->question_id);
						}
					}
					
					
					/*----End of get user exam question array----*/
					$term_questermArr=array();
					$term_questions=$this->questions_model->assessment_exam($year_id,1);
					
					if($term_questions)
					{
						
						foreach($term_questions as $tquestion)
						{
							array_push($term_questermArr,$tquestion->ass_question);
						}
						
					}
					//var_dump($term_questermArr);
					
					$exam_output = array_merge(array_diff($term_questermArr, $exam_questermArr), array_diff($exam_questermArr, $term_questermArr));
					$exam_random=array_rand($exam_output);					
					$randquestion=$exam_output[$exam_random];
					/*---End of check user not applied question list---*/
					if($userexams->exam_status!='pass')
					{
					$data['Questionlist']=$this->questions_model->asstest_exam_question($year_id,1,$randquestion);
					}
					else
					{
						$data['Questionlist']='';
						$data['completed']=1;
					}
					//var_dump($data['Questionlist']);
					$this->load->view('frontend/private/assessmentplay',$data);
				}
			
			}
			/*---End Assessment Test -----*/
			/*---final year exam-----*/
			else if($subskill=="exam")
			{
				
				
					if($this->input->post('action')=='submitanswer')	
					{
					 $questionid=$this->input->post('questionid');
					 $answerid=$this->input->post('answerid');
					 $year_id=$this->input->post('year_id');
					 $term_id=$this->input->post('term_id');
				
					
					$data["ques_dtl"] = $this->main_model->get_detail('manage_question_'.$year_id,'ques_id',$questionid);					
					
					$data["correct_ans"] = $this->main_model->get_detail('manage_answer_'.$year_id,'ans_id',$data["ques_dtl"]->ques_rightanswer);					
										
					if($data["ques_dtl"]->ques_rightanswer==$answerid)
					{
						
						$data['correct']=1;
						/*----insert user exam list---------*/
						$userid=$this->session->userdata('user_id');
						$createdate=date("Y-m-d H:i:s");
						$chkrow_exam=$this->questions_model->check_userexam($userid,$year_id,$term_id);	
						
						if($chkrow_exam->exam_id!="" )
						{
							$exam_id=$chkrow_exam->exam_id;
						}
						else
						{
							$user_exam=array(
									'user_id'=>$userid,
									'year_id'=>$year_id,
									'term_id'=>$term_id,													
									'exam_date'=>$createdate
									
									);
							$exam_id=$this->questions_model->Save_Userexam($user_exam);	
						}
						
						if($exam_id!="")
						{
							$uexam_history=array(
								'exam_id'=>$exam_id,
								'user_id'=>$userid,
								'year_id'=>$year_id,
								'term_id'=>$term_id,													
								'question_id'=>$questionid,
								'answer_id'=>$answerid,
								'answer_status'=>'false',
								
								);
							$historyexam_id=$this->questions_model->Save_Examhistory($uexam_history);		
						}
						
						/*----End of insert user exam list-------*/
						
										/*---check user not applied question list---*/
					$userexams=$this->questions_model->check_uexambyyear($userid,$year_id);
					if($userexams->exam_id!="" && $userexams->exam_status=='pending')
					{	
						$data['term_id']=$userexams->term_id;
					}
					else if($userexams->exam_id!="" && $userexams->exam_status=='pass')
					{	
						$data['term_id']=$userexams->term_id+1;
					}
					else
					{
						$data['term_id']=1;
					}
					
					/*----Get user exam question array------*/
					$exam_questermArr=array();
					$exam_questions=$this->questions_model->check_examhistory_question($userid,$year_id,$data['term_id']);
					if($exam_questions)
					{
						
						foreach($exam_questions as $examdata)
						{
							array_push($exam_questermArr,$examdata->question_id);
						}
					}
					
					
					/*----End of get user exam question array----*/
					$term_questermArr=array();
					$term_questions=$this->questions_model->term_exam($year_id,$data['term_id']);
					if($term_questions)
					{
						
						foreach($term_questions as $tquestion)
						{
							array_push($term_questermArr,$tquestion->question_id);
						}
						
					}
					$total_exam_question=count($exam_questermArr);
					$total_term_question=count($exam_questermArr);
					/*---update term by exam completed status----*/
					if($total_term_question==$total_exam_question)
					{
						$exam_status=array(
								'exam_status'=>'pass',							
								
								);
						
						$updateexam_status=$this->questions_model->Update_Examterm_status($exam_status,$exam_id);
					}
					/*---update term by exam completed status----*/
					$exam_output = array_merge(array_diff($term_questermArr, $exam_questermArr), array_diff($exam_questermArr, $term_questermArr));
					$exam_random=array_rand($exam_output);					
					$randquestion=$exam_output[$exam_random];
					/*---End of check user not applied question list---*/
					$data['Questionlist']=$this->questions_model->term_exam_question($year_id,$data['term_id'],$randquestion);
						//$data['Questionlist']=$this->questions_model->term_exam($year_id,1);
						$this->load->view('frontend/private/examplay',$data);

					}
					else
					{
			
						/*----insert user exam list---------*/
						$userid=$this->session->userdata('user_id');
						$createdate=date("Y-m-d H:i:s");
						$chkrow_exam=$this->questions_model->check_userexam($userid,$year_id,$term_id);	
						
						if($chkrow_exam->exam_id!="" )
						{
							$exam_id=$chkrow_exam->exam_id;
						}
						else
						{
							$user_exam=array(
									'user_id'=>$userid,
									'year_id'=>$year_id,
									'term_id'=>$term_id,													
									'exam_date'=>$createdate
									
									);
							$exam_id=$this->questions_model->Save_Userexam($user_exam);	
						}
						
						if($exam_id!="")
						{
							$uexam_history=array(
								'exam_id'=>$exam_id,
								'user_id'=>$userid,
								'year_id'=>$year_id,
								'term_id'=>$term_id,													
								'question_id'=>$questionid,
								'answer_id'=>$answerid,
								'answer_status'=>'true',
								
								);
							$hexam_id=$this->questions_model->Save_Examhistory($uexam_history);		
						}
						
								/*----Get user exam question array------*/
					$exam_questermArr=array();
					$exam_questions=$this->questions_model->check_examhistory_question($userid,$year_id,$term_id);
					if($exam_questions)
					{
						
						foreach($exam_questions as $examdata)
						{
							array_push($exam_questermArr,$examdata->question_id);
						}
					}
					
					
					/*----End of get user exam question array----*/
					$term_questermArr=array();
					$term_questions=$this->questions_model->term_exam($year_id,$term_id);
					if($term_questions)
					{
						
						foreach($term_questions as $tquestion)
						{
							array_push($term_questermArr,$tquestion->question_id);
						}
						
					}
					$total_exam_question=count($exam_questermArr);
					$total_term_question=count($exam_questermArr);
					/*---update term by exam completed status----*/
					if($total_term_question==$total_exam_question)
					{
						$exam_status=array(
								'exam_status'=>'pass',							
								
								);
						
						$updateexam_status=$this->questions_model->Update_Examterm_status($exam_status,$exam_id);
					}
					/*---update term by exam completed status----*/
						
						/*----End of insert user exam list-------*/
						$data["yourans"] = $this->main_model->get_detail('manage_answer_'.$year_id,'ans_id',$answerid);	
						$this->load->view('frontend/private/explanation',$data);
					}
					
								
					}
				else
				{
					$userid=$this->session->userdata('user_id');
					/*---check user not applied question list---*/
					$userexams=$this->questions_model->check_uexambyyear($userid,$year_id);
					if($userexams->exam_id!="" && $userexams->exam_status=='pending')
					{	
						$data['term_id']=$userexams->term_id;
					}
					else if($userexams->exam_id!="" && $userexams->exam_status=='pass')
					{	
						$data['term_id']=$userexams->term_id+1;
					}
					else
					{
						$data['term_id']=1;
					}
					
					/*----Get user exam question array------*/
					$exam_questermArr=array();
					$exam_questions=$this->questions_model->check_examhistory_question($userid,$year_id,$data['term_id']);
					if($exam_questions)
					{
						
						foreach($exam_questions as $examdata)
						{
							array_push($exam_questermArr,$examdata->question_id);
						}
					}
					
					
					/*----End of get user exam question array----*/
					$term_questermArr=array();
					$term_questions=$this->questions_model->term_exam($year_id,$data['term_id']);
					if($term_questions)
					{
						
						foreach($term_questions as $tquestion)
						{
							array_push($term_questermArr,$tquestion->question_id);
						}
						
					}
					//var_dump($term_questermArr);
					
					$exam_output = array_merge(array_diff($term_questermArr, $exam_questermArr), array_diff($exam_questermArr, $term_questermArr));
					$exam_random=array_rand($exam_output);					
					$randquestion=$exam_output[$exam_random];
					/*---End of check user not applied question list---*/
					$data['Questionlist']=$this->questions_model->term_exam_question($year_id,$data['term_id'],$randquestion);
	
					$this->load->view('frontend/private/examplay',$data);
				}
			}
			/*---end final year exam-----*/
			else
			{	

			$data["skill_dtl"] =$this->main_model->get_skill('master_skill','skill_slug',$subskill,'skill_class',$year_id);		
			  $subskill_id=$data["skill_dtl"]->skill_id;
			$this->questions_model->CLASSID = $year_id;
				//$data["Questionlist"] = $this->questions_model->question_list_subskill($subskill_id);
		
				if($this->input->post('action')=='submitanswer')	
					{
					 $questionid=$this->input->post('questionid');
					 $answerid=$this->input->post('answerid');
				
					
					$data["ques_dtl"] = $this->main_model->get_detail('manage_question_'.$year_id,'ques_id',$questionid);
					//print_r($data["ques_dtl"]);
					
					$data["correct_ans"] = $this->main_model->get_detail('manage_answer_'.$year_id,'ans_id',$data["ques_dtl"]->ques_rightanswer);
					//print_r($data["correct_ans"]);
					//echo $data["correct_ans"]->ans_name;
										
					if($data["ques_dtl"]->ques_rightanswer==$answerid)
					{
						
					$data['correct']=1;
					$data["Questionlist"] = $this->questions_model->random_question($subskill_id);
					$this->load->view('frontend/private/play',$data);

					}
					else{
			
					$data["yourans"] = $this->main_model->get_detail('manage_answer_'.$year_id,'ans_id',$answerid);	
					$this->load->view('frontend/private/explanation',$data);
					}
					
								
					}
				else{
					$data["Questionlist"] = $this->questions_model->random_question($subskill_id);
					$this->load->view('frontend/private/play',$data);
					}
			
				}
			}
			else{
				
				if($this->session->userdata('user_id')!='' and $this->session->userdata('username')!='')
				{

				$data["SylList1"] = $this->syllabus_model->syllabus_list($year_id,1);
				$data["SylList2"] = $this->syllabus_model->syllabus_list($year_id,2);
				$data["SylList3"] = $this->syllabus_model->syllabus_list($year_id,3);
				$data["SylList4"] = $this->syllabus_model->syllabus_list($year_id,4);

				$this->load->view('frontend/private/kindergarten', $data);
				}
				else{
				$data["SylList1"] = $this->syllabus_model->syllabus_list($year_id,1);
				$data["SylList2"] = $this->syllabus_model->syllabus_list($year_id,2);
				$data["SylList3"] = $this->syllabus_model->syllabus_list($year_id,3);
				$data["SylList4"] = $this->syllabus_model->syllabus_list($year_id,4);

				$this->load->view('frontend/public/kg_wtht_login', $data);	
					
				}

			}
		
	}
	public function year7($subskill='') 
	{	
		$yearid=$this->session->userdata('loginyear');
			$yeardata=$this->classes_model->classes_details($yearid);
			if($yeardata)
			{
				$data['year_name']=$yeardata[0]->class_name;
				$data['year_slug']=$yeardata[0]->class_slug;
			}
		$year_id=8;
		$data['year_id']=$year_id;
		$this->questions_model->CLASSID = $year_id;
		$data["year_dtl"] = $this->main_model->get_detail('master_class','class_id',$year_id);	
		if($subskill!="")
		{
			/*---Start Assessment Test -----*/
			if($subskill=="assessment")
			{
				
					/*---get all past year of assessment list----*/
					$pastyear=$this->questions_model->assessment_pastyear($year_id);
						/*echo '<pre>';
						var_dump($pastyear);
						echo '</pre>';
						*/
					$todaydate=date("Y-m-d H:i:s");	
					$userid=$this->session->userdata('user_id');
					$asstime_query=$this->questions_model->assessment_time($year_id,$userid);
					$yourstart=$asstime_query->start_time;
					if($yourstart!="" && $yourstart!=null)
					{
						$seconds = strtotime($todaydate) - strtotime($yourstart);
						$days    = floor($seconds / 86400);
						$hours   = floor(($seconds - ($days * 86400)) / 3600);
						$minutes = floor(($seconds - ($days * 86400) - ($hours * 3600))/60);
						
						if($minutes >30)
						{
							//echo $minutes;
							$exam_status=array(
								'exam_status'=>'pass',							
								'end_time'=>$todaydate,
								);
						
						$updateexam_status=$this->questions_model->Update_Asstterm_status($exam_status,$asstime_query->exam_id);
						$data['timeover']=1;
						}
						else
						{
							$totalminutes=30-$minutes;
							$data['showtimer']='Duration Left: '.$totalminutes;
						}
					}
					else
					{
						$data['showtimer']='Duration: 30';
					}
					
					/*---end of get all past year of assessment list----*/	
					if($this->input->post('action')=='submitanswer')	
					{
						//var_dump($this->input->post());
					 $questionid=$this->input->post('questionid');
					 $answerid=$this->input->post('answerid');
					 $year_id=$this->input->post('year_id');
					 $ass_year_id=$this->input->post('ass_year_id');
				
					
					$data["ques_dtl"] = $this->main_model->get_detail('manage_question_'.$ass_year_id,'ques_id',$questionid);					
					//var_dump($data["ques_dtl"]);
					$data["correct_ans"] = $this->main_model->get_detail('manage_answer_'.$ass_year_id,'ans_id',$data["ques_dtl"]->ques_rightanswer);					
										
					if($data["ques_dtl"]->ques_rightanswer==$answerid)
					{
						
						$data['correct']=1;
						/*----insert user exam list---------*/
						
						$createdate=date("Y-m-d H:i:s");
						$chkrow_exam=$this->questions_model->check_userassessment($userid,$year_id,1);	
						
						if($chkrow_exam->exam_id!="" )
						{
							$exam_id=$chkrow_exam->exam_id;
						}
						else
						{
							$user_exam=array(
									'user_id'=>$userid,
									'year_id'=>$year_id,
									'assyear_id'=>$ass_year_id,													
									'exam_date'=>$createdate,
									'start_time'=>$createdate
									
									);
							$exam_id=$this->questions_model->Save_Userassessment($user_exam);	
						}
						
						if($exam_id!="")
						{
							$uexam_history=array(
								'exam_id'=>$exam_id,
								'user_id'=>$userid,
								'year_id'=>$year_id,
								'assyear_id'=>$ass_year_id,													
								'question_id'=>$questionid,
								'answer_id'=>$answerid,
								'answer_status'=>'true',
								
								);
							$historyexam_id=$this->questions_model->Save_Assessmenthistory($uexam_history);		
						}
						
						/*----End of insert user exam list-------*/
										
					/*----Get user exam question array------*/
					$exam_questermArr=array();
					$exam_questions=$this->questions_model->check_asstesthistory_question($userid,$year_id,1);
					if($exam_questions)
					{
						
						foreach($exam_questions as $examdata)
						{
							array_push($exam_questermArr,$examdata->question_id);
						}
					}
					
					
					/*----End of get user exam question array----*/
					$term_questermArr=array();
					$term_questions=$this->questions_model->assessment_exam($year_id,1);
					if($term_questions)
					{
						
						foreach($term_questions as $tquestion)
						{
							array_push($term_questermArr,$tquestion->ass_question);
						}
						
					}
					$total_exam_question=count($exam_questermArr);
					$total_term_question=count($term_questermArr);
					/*---update term by exam completed status----*/
					if($total_term_question==$total_exam_question)
					{
						$exam_status=array(
								'exam_status'=>'pass',							
								'end_time'=>$createdate,
								);
						
						$updateexam_status=$this->questions_model->Update_Asstterm_status($exam_status,$exam_id);
						$data['completed']=1;
					}
					/*---update term by exam completed status----*/
					$exam_output = array_merge(array_diff($term_questermArr, $exam_questermArr), array_diff($exam_questermArr, $term_questermArr));
					$exam_random=array_rand($exam_output);					
					$randquestion=$exam_output[$exam_random];
					/*---End of check user not applied question list---*/
					$data['Questionlist']=$this->questions_model->asstest_exam_question($year_id,1,$randquestion);
						//$data['Questionlist']=$this->questions_model->term_exam($year_id,1);
						$data['exam_id']=$exam_id;
						$this->load->view('frontend/private/assessmentplay',$data);

					}
					else
					{
			
						/*----insert user exam list---------*/
						$userid=$this->session->userdata('user_id');
						$createdate=date("Y-m-d H:i:s");
						$chkrow_exam=$this->questions_model->check_userassessment($userid,$year_id,1);	
						
						if($chkrow_exam->exam_id!="" )
						{
							$exam_id=$chkrow_exam->exam_id;
						}
						else
						{
							$user_exam=array(
									'user_id'=>$userid,
									'year_id'=>$year_id,
									'assyear_id'=>$ass_year_id,													
									'exam_date'=>$createdate,
									'start_time'=>$createdate
									
									);
							$exam_id=$this->questions_model->Save_Userassessment($user_exam);	
						}
						
						if($exam_id!="")
						{
							$uexam_history=array(
								'exam_id'=>$exam_id,
								'user_id'=>$userid,
								'year_id'=>$year_id,
								'assyear_id'=>$ass_year_id,													
								'question_id'=>$questionid,
								'answer_id'=>$answerid,
								'answer_status'=>'false',
								
								);
							$hexam_id=$this->questions_model->Save_Assessmenthistory($uexam_history);		
						}
						
								/*----Get user exam question array------*/
					$exam_questermArr=array();
					$exam_questions=$this->questions_model->check_asstesthistory_question($userid,$year_id,$term_id);
					if($exam_questions)
					{
						
						foreach($exam_questions as $examdata)
						{
							array_push($exam_questermArr,$examdata->question_id);
						}
					}
					
					
					/*----End of get user exam question array----*/
					$term_questermArr=array();
					$term_questions=$this->questions_model->assessment_exam($year_id,1);
					if($term_questions)
					{
						
						foreach($term_questions as $tquestion)
						{
							array_push($term_questermArr,$tquestion->ass_question);
						}
						
					}
					$total_exam_question=count($exam_questermArr);
					$total_term_question=count($term_questermArr);
					/*---update term by exam completed status----*/
					if($total_term_question==$total_exam_question)
					{
						$exam_status=array(
								'exam_status'=>'pass',
								'end_time'=>$createdate,	
								
								);
						
						$updateexam_status=$this->questions_model->Update_Asstterm_status($exam_status,$exam_id);
						$data['completed']=1;
					}
					/*---update term by exam completed status----*/
						
						/*----End of insert user exam list-------*/
					
						$data["yourans"] = $this->main_model->get_detail('manage_answer_'.$ass_year_id,'ans_id',$answerid);	
						$data['exam_id']=$exam_id;
						$this->load->view('frontend/private/asstestexplanation',$data);
					}
					
								
					}
				else
				{
					$userid=$this->session->userdata('user_id');
					/*---check user not applied question list---*/
					$userexams=$this->questions_model->check_uasstestbyyear($userid,$year_id);
					$data['exam_id']=$userexams->exam_id;
					if($userexams->exam_id!="" && $userexams->exam_status=='pending')
					{	
						$data['assyear_id']=$userexams->assyear_id;
					}
					
					else if($userexams->exam_id!="" && $userexams->exam_status=='pass')
					{	
						$data['assyear_id']=$userexams->assyear_id+1;
					}
				
					else
					{
						$data['assyear_id']=$pastyear[0]->ass_year_id;
						//echo $pastyear[0]->ass_year_id;
					}
					
					/*----Get user exam question array------*/
					$exam_questermArr=array();
					$exam_questions=$this->questions_model->check_asstesthistory_question($userid,$year_id,1);
					if($exam_questions)
					{
						
						foreach($exam_questions as $examdata)
						{
							array_push($exam_questermArr,$examdata->question_id);
						}
					}
					
					
					/*----End of get user exam question array----*/
					$term_questermArr=array();
					$term_questions=$this->questions_model->assessment_exam($year_id,1);
					
					if($term_questions)
					{
						
						foreach($term_questions as $tquestion)
						{
							array_push($term_questermArr,$tquestion->ass_question);
						}
						
					}
					//var_dump($term_questermArr);
					
					$exam_output = array_merge(array_diff($term_questermArr, $exam_questermArr), array_diff($exam_questermArr, $term_questermArr));
					$exam_random=array_rand($exam_output);					
					$randquestion=$exam_output[$exam_random];
					/*---End of check user not applied question list---*/
					if($userexams->exam_status!='pass')
					{
					$data['Questionlist']=$this->questions_model->asstest_exam_question($year_id,1,$randquestion);
					}
					else
					{
						$data['Questionlist']='';
						$data['completed']=1;
					}
					//var_dump($data['Questionlist']);
					$this->load->view('frontend/private/assessmentplay',$data);
				}
			
			}
			/*---End Assessment Test -----*/
			/*---final year exam-----*/
			else if($subskill=="exam")
			{
				
				
					if($this->input->post('action')=='submitanswer')	
					{
					 $questionid=$this->input->post('questionid');
					 $answerid=$this->input->post('answerid');
					 $year_id=$this->input->post('year_id');
					 $term_id=$this->input->post('term_id');
				
					
					$data["ques_dtl"] = $this->main_model->get_detail('manage_question_'.$year_id,'ques_id',$questionid);					
					
					$data["correct_ans"] = $this->main_model->get_detail('manage_answer_'.$year_id,'ans_id',$data["ques_dtl"]->ques_rightanswer);					
										
					if($data["ques_dtl"]->ques_rightanswer==$answerid)
					{
						
						$data['correct']=1;
						/*----insert user exam list---------*/
						$userid=$this->session->userdata('user_id');
						$createdate=date("Y-m-d H:i:s");
						$chkrow_exam=$this->questions_model->check_userexam($userid,$year_id,$term_id);	
						
						if($chkrow_exam->exam_id!="" )
						{
							$exam_id=$chkrow_exam->exam_id;
						}
						else
						{
							$user_exam=array(
									'user_id'=>$userid,
									'year_id'=>$year_id,
									'term_id'=>$term_id,													
									'exam_date'=>$createdate
									
									);
							$exam_id=$this->questions_model->Save_Userexam($user_exam);	
						}
						
						if($exam_id!="")
						{
							$uexam_history=array(
								'exam_id'=>$exam_id,
								'user_id'=>$userid,
								'year_id'=>$year_id,
								'term_id'=>$term_id,													
								'question_id'=>$questionid,
								'answer_id'=>$answerid,
								'answer_status'=>'false',
								
								);
							$historyexam_id=$this->questions_model->Save_Examhistory($uexam_history);		
						}
						
						/*----End of insert user exam list-------*/
						
										/*---check user not applied question list---*/
					$userexams=$this->questions_model->check_uexambyyear($userid,$year_id);
					if($userexams->exam_id!="" && $userexams->exam_status=='pending')
					{	
						$data['term_id']=$userexams->term_id;
					}
					else if($userexams->exam_id!="" && $userexams->exam_status=='pass')
					{	
						$data['term_id']=$userexams->term_id+1;
					}
					else
					{
						$data['term_id']=1;
					}
					
					/*----Get user exam question array------*/
					$exam_questermArr=array();
					$exam_questions=$this->questions_model->check_examhistory_question($userid,$year_id,$data['term_id']);
					if($exam_questions)
					{
						
						foreach($exam_questions as $examdata)
						{
							array_push($exam_questermArr,$examdata->question_id);
						}
					}
					
					
					/*----End of get user exam question array----*/
					$term_questermArr=array();
					$term_questions=$this->questions_model->term_exam($year_id,$data['term_id']);
					if($term_questions)
					{
						
						foreach($term_questions as $tquestion)
						{
							array_push($term_questermArr,$tquestion->question_id);
						}
						
					}
					$total_exam_question=count($exam_questermArr);
					$total_term_question=count($exam_questermArr);
					/*---update term by exam completed status----*/
					if($total_term_question==$total_exam_question)
					{
						$exam_status=array(
								'exam_status'=>'pass',							
								
								);
						
						$updateexam_status=$this->questions_model->Update_Examterm_status($exam_status,$exam_id);
					}
					/*---update term by exam completed status----*/
					$exam_output = array_merge(array_diff($term_questermArr, $exam_questermArr), array_diff($exam_questermArr, $term_questermArr));
					$exam_random=array_rand($exam_output);					
					$randquestion=$exam_output[$exam_random];
					/*---End of check user not applied question list---*/
					$data['Questionlist']=$this->questions_model->term_exam_question($year_id,$data['term_id'],$randquestion);
						//$data['Questionlist']=$this->questions_model->term_exam($year_id,1);
						$this->load->view('frontend/private/examplay',$data);

					}
					else
					{
			
						/*----insert user exam list---------*/
						$userid=$this->session->userdata('user_id');
						$createdate=date("Y-m-d H:i:s");
						$chkrow_exam=$this->questions_model->check_userexam($userid,$year_id,$term_id);	
						
						if($chkrow_exam->exam_id!="" )
						{
							$exam_id=$chkrow_exam->exam_id;
						}
						else
						{
							$user_exam=array(
									'user_id'=>$userid,
									'year_id'=>$year_id,
									'term_id'=>$term_id,													
									'exam_date'=>$createdate
									
									);
							$exam_id=$this->questions_model->Save_Userexam($user_exam);	
						}
						
						if($exam_id!="")
						{
							$uexam_history=array(
								'exam_id'=>$exam_id,
								'user_id'=>$userid,
								'year_id'=>$year_id,
								'term_id'=>$term_id,													
								'question_id'=>$questionid,
								'answer_id'=>$answerid,
								'answer_status'=>'true',
								
								);
							$hexam_id=$this->questions_model->Save_Examhistory($uexam_history);		
						}
						
								/*----Get user exam question array------*/
					$exam_questermArr=array();
					$exam_questions=$this->questions_model->check_examhistory_question($userid,$year_id,$term_id);
					if($exam_questions)
					{
						
						foreach($exam_questions as $examdata)
						{
							array_push($exam_questermArr,$examdata->question_id);
						}
					}
					
					
					/*----End of get user exam question array----*/
					$term_questermArr=array();
					$term_questions=$this->questions_model->term_exam($year_id,$term_id);
					if($term_questions)
					{
						
						foreach($term_questions as $tquestion)
						{
							array_push($term_questermArr,$tquestion->question_id);
						}
						
					}
					$total_exam_question=count($exam_questermArr);
					$total_term_question=count($exam_questermArr);
					/*---update term by exam completed status----*/
					if($total_term_question==$total_exam_question)
					{
						$exam_status=array(
								'exam_status'=>'pass',							
								
								);
						
						$updateexam_status=$this->questions_model->Update_Examterm_status($exam_status,$exam_id);
					}
					/*---update term by exam completed status----*/
						
						/*----End of insert user exam list-------*/
						$data["yourans"] = $this->main_model->get_detail('manage_answer_'.$year_id,'ans_id',$answerid);	
						$this->load->view('frontend/private/explanation',$data);
					}
					
								
					}
				else
				{
					$userid=$this->session->userdata('user_id');
					/*---check user not applied question list---*/
					$userexams=$this->questions_model->check_uexambyyear($userid,$year_id);
					if($userexams->exam_id!="" && $userexams->exam_status=='pending')
					{	
						$data['term_id']=$userexams->term_id;
					}
					else if($userexams->exam_id!="" && $userexams->exam_status=='pass')
					{	
						$data['term_id']=$userexams->term_id+1;
					}
					else
					{
						$data['term_id']=1;
					}
					
					/*----Get user exam question array------*/
					$exam_questermArr=array();
					$exam_questions=$this->questions_model->check_examhistory_question($userid,$year_id,$data['term_id']);
					if($exam_questions)
					{
						
						foreach($exam_questions as $examdata)
						{
							array_push($exam_questermArr,$examdata->question_id);
						}
					}
					
					
					/*----End of get user exam question array----*/
					$term_questermArr=array();
					$term_questions=$this->questions_model->term_exam($year_id,$data['term_id']);
					if($term_questions)
					{
						
						foreach($term_questions as $tquestion)
						{
							array_push($term_questermArr,$tquestion->question_id);
						}
						
					}
					//var_dump($term_questermArr);
					
					$exam_output = array_merge(array_diff($term_questermArr, $exam_questermArr), array_diff($exam_questermArr, $term_questermArr));
					$exam_random=array_rand($exam_output);					
					$randquestion=$exam_output[$exam_random];
					/*---End of check user not applied question list---*/
					$data['Questionlist']=$this->questions_model->term_exam_question($year_id,$data['term_id'],$randquestion);
	
					$this->load->view('frontend/private/examplay',$data);
				}
			}
			/*---end final year exam-----*/
			else
			{	

			$data["skill_dtl"] =$this->main_model->get_skill('master_skill','skill_slug',$subskill,'skill_class',$year_id);		
			  $subskill_id=$data["skill_dtl"]->skill_id;
			$this->questions_model->CLASSID = $year_id;
				//$data["Questionlist"] = $this->questions_model->question_list_subskill($subskill_id);
		
				if($this->input->post('action')=='submitanswer')	
					{
					 $questionid=$this->input->post('questionid');
					 $answerid=$this->input->post('answerid');
				
					
					$data["ques_dtl"] = $this->main_model->get_detail('manage_question_'.$year_id,'ques_id',$questionid);
					//print_r($data["ques_dtl"]);
					
					$data["correct_ans"] = $this->main_model->get_detail('manage_answer_'.$year_id,'ans_id',$data["ques_dtl"]->ques_rightanswer);
					//print_r($data["correct_ans"]);
					//echo $data["correct_ans"]->ans_name;
										
					if($data["ques_dtl"]->ques_rightanswer==$answerid)
					{
						
					$data['correct']=1;
					$data["Questionlist"] = $this->questions_model->random_question($subskill_id);
					$this->load->view('frontend/private/play',$data);

					}
					else{
			
					$data["yourans"] = $this->main_model->get_detail('manage_answer_'.$year_id,'ans_id',$answerid);	
					$this->load->view('frontend/private/explanation',$data);
					}
					
								
					}
				else{
					$data["Questionlist"] = $this->questions_model->random_question($subskill_id);
					$this->load->view('frontend/private/play',$data);
					}
			
				}
			}
			else{
				
				if($this->session->userdata('user_id')!='' and $this->session->userdata('username')!='')
				{

				$data["SylList1"] = $this->syllabus_model->syllabus_list($year_id,1);
				$data["SylList2"] = $this->syllabus_model->syllabus_list($year_id,2);
				$data["SylList3"] = $this->syllabus_model->syllabus_list($year_id,3);
				$data["SylList4"] = $this->syllabus_model->syllabus_list($year_id,4);

				$this->load->view('frontend/private/kindergarten', $data);
				}
				else{
				$data["SylList1"] = $this->syllabus_model->syllabus_list($year_id,1);
				$data["SylList2"] = $this->syllabus_model->syllabus_list($year_id,2);
				$data["SylList3"] = $this->syllabus_model->syllabus_list($year_id,3);
				$data["SylList4"] = $this->syllabus_model->syllabus_list($year_id,4);

				$this->load->view('frontend/public/kg_wtht_login', $data);	
					
				}

			}
		
	}
	public function year8($subskill='') 
	{	
		$yearid=$this->session->userdata('loginyear');
			$yeardata=$this->classes_model->classes_details($yearid);
			if($yeardata)
			{
				$data['year_name']=$yeardata[0]->class_name;
				$data['year_slug']=$yeardata[0]->class_slug;
			}
		$year_id=9;
		$data['year_id']=$year_id;
		$this->questions_model->CLASSID = $year_id;
		$data["year_dtl"] = $this->main_model->get_detail('master_class','class_id',$year_id);	
		if($subskill!=""){
			/*---Start Assessment Test -----*/
			if($subskill=="assessment")
			{
				
					/*---get all past year of assessment list----*/
					$pastyear=$this->questions_model->assessment_pastyear($year_id);
						/*echo '<pre>';
						var_dump($pastyear);
						echo '</pre>';
						*/
					$todaydate=date("Y-m-d H:i:s");	
					$userid=$this->session->userdata('user_id');
					$asstime_query=$this->questions_model->assessment_time($year_id,$userid);
					$yourstart=$asstime_query->start_time;
					if($yourstart!="" && $yourstart!=null)
					{
						$seconds = strtotime($todaydate) - strtotime($yourstart);
						$days    = floor($seconds / 86400);
						$hours   = floor(($seconds - ($days * 86400)) / 3600);
						$minutes = floor(($seconds - ($days * 86400) - ($hours * 3600))/60);
						
						if($minutes >30)
						{
							//echo $minutes;
							$exam_status=array(
								'exam_status'=>'pass',							
								'end_time'=>$todaydate,
								);
						
						$updateexam_status=$this->questions_model->Update_Asstterm_status($exam_status,$asstime_query->exam_id);
						$data['timeover']=1;
						}
						else
						{
							$totalminutes=30-$minutes;
							$data['showtimer']='Duration Left: '.$totalminutes;
						}
					}
					else
					{
						$data['showtimer']='Duration: 30';
					}
					
					/*---end of get all past year of assessment list----*/	
					if($this->input->post('action')=='submitanswer')	
					{
						//var_dump($this->input->post());
					 $questionid=$this->input->post('questionid');
					 $answerid=$this->input->post('answerid');
					 $year_id=$this->input->post('year_id');
					 $ass_year_id=$this->input->post('ass_year_id');
				
					
					$data["ques_dtl"] = $this->main_model->get_detail('manage_question_'.$ass_year_id,'ques_id',$questionid);					
					//var_dump($data["ques_dtl"]);
					$data["correct_ans"] = $this->main_model->get_detail('manage_answer_'.$ass_year_id,'ans_id',$data["ques_dtl"]->ques_rightanswer);					
										
					if($data["ques_dtl"]->ques_rightanswer==$answerid)
					{
						
						$data['correct']=1;
						/*----insert user exam list---------*/
						
						$createdate=date("Y-m-d H:i:s");
						$chkrow_exam=$this->questions_model->check_userassessment($userid,$year_id,1);	
						
						if($chkrow_exam->exam_id!="" )
						{
							$exam_id=$chkrow_exam->exam_id;
						}
						else
						{
							$user_exam=array(
									'user_id'=>$userid,
									'year_id'=>$year_id,
									'assyear_id'=>$ass_year_id,													
									'exam_date'=>$createdate,
									'start_time'=>$createdate
									
									);
							$exam_id=$this->questions_model->Save_Userassessment($user_exam);	
						}
						
						if($exam_id!="")
						{
							$uexam_history=array(
								'exam_id'=>$exam_id,
								'user_id'=>$userid,
								'year_id'=>$year_id,
								'assyear_id'=>$ass_year_id,													
								'question_id'=>$questionid,
								'answer_id'=>$answerid,
								'answer_status'=>'true',
								
								);
							$historyexam_id=$this->questions_model->Save_Assessmenthistory($uexam_history);		
						}
						
						/*----End of insert user exam list-------*/
										
					/*----Get user exam question array------*/
					$exam_questermArr=array();
					$exam_questions=$this->questions_model->check_asstesthistory_question($userid,$year_id,1);
					if($exam_questions)
					{
						
						foreach($exam_questions as $examdata)
						{
							array_push($exam_questermArr,$examdata->question_id);
						}
					}
					
					
					/*----End of get user exam question array----*/
					$term_questermArr=array();
					$term_questions=$this->questions_model->assessment_exam($year_id,1);
					if($term_questions)
					{
						
						foreach($term_questions as $tquestion)
						{
							array_push($term_questermArr,$tquestion->ass_question);
						}
						
					}
					$total_exam_question=count($exam_questermArr);
					$total_term_question=count($term_questermArr);
					/*---update term by exam completed status----*/
					if($total_term_question==$total_exam_question)
					{
						$exam_status=array(
								'exam_status'=>'pass',							
								'end_time'=>$createdate,
								);
						
						$updateexam_status=$this->questions_model->Update_Asstterm_status($exam_status,$exam_id);
						$data['completed']=1;
					}
					/*---update term by exam completed status----*/
					$exam_output = array_merge(array_diff($term_questermArr, $exam_questermArr), array_diff($exam_questermArr, $term_questermArr));
					$exam_random=array_rand($exam_output);					
					$randquestion=$exam_output[$exam_random];
					/*---End of check user not applied question list---*/
					$data['Questionlist']=$this->questions_model->asstest_exam_question($year_id,1,$randquestion);
						//$data['Questionlist']=$this->questions_model->term_exam($year_id,1);
						$data['exam_id']=$exam_id;
						$this->load->view('frontend/private/assessmentplay',$data);

					}
					else
					{
			
						/*----insert user exam list---------*/
						$userid=$this->session->userdata('user_id');
						$createdate=date("Y-m-d H:i:s");
						$chkrow_exam=$this->questions_model->check_userassessment($userid,$year_id,1);	
						
						if($chkrow_exam->exam_id!="" )
						{
							$exam_id=$chkrow_exam->exam_id;
						}
						else
						{
							$user_exam=array(
									'user_id'=>$userid,
									'year_id'=>$year_id,
									'assyear_id'=>$ass_year_id,													
									'exam_date'=>$createdate,
									'start_time'=>$createdate
									
									);
							$exam_id=$this->questions_model->Save_Userassessment($user_exam);	
						}
						
						if($exam_id!="")
						{
							$uexam_history=array(
								'exam_id'=>$exam_id,
								'user_id'=>$userid,
								'year_id'=>$year_id,
								'assyear_id'=>$ass_year_id,													
								'question_id'=>$questionid,
								'answer_id'=>$answerid,
								'answer_status'=>'false',
								
								);
							$hexam_id=$this->questions_model->Save_Assessmenthistory($uexam_history);		
						}
						
								/*----Get user exam question array------*/
					$exam_questermArr=array();
					$exam_questions=$this->questions_model->check_asstesthistory_question($userid,$year_id,$term_id);
					if($exam_questions)
					{
						
						foreach($exam_questions as $examdata)
						{
							array_push($exam_questermArr,$examdata->question_id);
						}
					}
					
					
					/*----End of get user exam question array----*/
					$term_questermArr=array();
					$term_questions=$this->questions_model->assessment_exam($year_id,1);
					if($term_questions)
					{
						
						foreach($term_questions as $tquestion)
						{
							array_push($term_questermArr,$tquestion->ass_question);
						}
						
					}
					$total_exam_question=count($exam_questermArr);
					$total_term_question=count($term_questermArr);
					/*---update term by exam completed status----*/
					if($total_term_question==$total_exam_question)
					{
						$exam_status=array(
								'exam_status'=>'pass',
								'end_time'=>$createdate,	
								
								);
						
						$updateexam_status=$this->questions_model->Update_Asstterm_status($exam_status,$exam_id);
						$data['completed']=1;
					}
					/*---update term by exam completed status----*/
						
						/*----End of insert user exam list-------*/
					
						$data["yourans"] = $this->main_model->get_detail('manage_answer_'.$ass_year_id,'ans_id',$answerid);	
						$data['exam_id']=$exam_id;
						$this->load->view('frontend/private/asstestexplanation',$data);
					}
					
								
					}
				else
				{
					$userid=$this->session->userdata('user_id');
					/*---check user not applied question list---*/
					$userexams=$this->questions_model->check_uasstestbyyear($userid,$year_id);
					$data['exam_id']=$userexams->exam_id;
					if($userexams->exam_id!="" && $userexams->exam_status=='pending')
					{	
						$data['assyear_id']=$userexams->assyear_id;
					}
					
					else if($userexams->exam_id!="" && $userexams->exam_status=='pass')
					{	
						$data['assyear_id']=$userexams->assyear_id+1;
					}
				
					else
					{
						$data['assyear_id']=$pastyear[0]->ass_year_id;
						//echo $pastyear[0]->ass_year_id;
					}
					
					/*----Get user exam question array------*/
					$exam_questermArr=array();
					$exam_questions=$this->questions_model->check_asstesthistory_question($userid,$year_id,1);
					if($exam_questions)
					{
						
						foreach($exam_questions as $examdata)
						{
							array_push($exam_questermArr,$examdata->question_id);
						}
					}
					
					
					/*----End of get user exam question array----*/
					$term_questermArr=array();
					$term_questions=$this->questions_model->assessment_exam($year_id,1);
					
					if($term_questions)
					{
						
						foreach($term_questions as $tquestion)
						{
							array_push($term_questermArr,$tquestion->ass_question);
						}
						
					}
					//var_dump($term_questermArr);
					
					$exam_output = array_merge(array_diff($term_questermArr, $exam_questermArr), array_diff($exam_questermArr, $term_questermArr));
					$exam_random=array_rand($exam_output);					
					$randquestion=$exam_output[$exam_random];
					/*---End of check user not applied question list---*/
					if($userexams->exam_status!='pass')
					{
					$data['Questionlist']=$this->questions_model->asstest_exam_question($year_id,1,$randquestion);
					}
					else
					{
						$data['Questionlist']='';
						$data['completed']=1;
					}
					//var_dump($data['Questionlist']);
					$this->load->view('frontend/private/assessmentplay',$data);
				}
			
			}
			/*---End Assessment Test -----*/
			/*---final year exam-----*/
			else if($subskill=="exam")
			{
				
				
					if($this->input->post('action')=='submitanswer')	
					{
					 $questionid=$this->input->post('questionid');
					 $answerid=$this->input->post('answerid');
					 $year_id=$this->input->post('year_id');
					 $term_id=$this->input->post('term_id');
				
					
					$data["ques_dtl"] = $this->main_model->get_detail('manage_question_'.$year_id,'ques_id',$questionid);					
					
					$data["correct_ans"] = $this->main_model->get_detail('manage_answer_'.$year_id,'ans_id',$data["ques_dtl"]->ques_rightanswer);					
										
					if($data["ques_dtl"]->ques_rightanswer==$answerid)
					{
						
						$data['correct']=1;
						/*----insert user exam list---------*/
						$userid=$this->session->userdata('user_id');
						$createdate=date("Y-m-d H:i:s");
						$chkrow_exam=$this->questions_model->check_userexam($userid,$year_id,$term_id);	
						
						if($chkrow_exam->exam_id!="" )
						{
							$exam_id=$chkrow_exam->exam_id;
						}
						else
						{
							$user_exam=array(
									'user_id'=>$userid,
									'year_id'=>$year_id,
									'term_id'=>$term_id,													
									'exam_date'=>$createdate
									
									);
							$exam_id=$this->questions_model->Save_Userexam($user_exam);	
						}
						
						if($exam_id!="")
						{
							$uexam_history=array(
								'exam_id'=>$exam_id,
								'user_id'=>$userid,
								'year_id'=>$year_id,
								'term_id'=>$term_id,													
								'question_id'=>$questionid,
								'answer_id'=>$answerid,
								'answer_status'=>'false',
								
								);
							$historyexam_id=$this->questions_model->Save_Examhistory($uexam_history);		
						}
						
						/*----End of insert user exam list-------*/
						
										/*---check user not applied question list---*/
					$userexams=$this->questions_model->check_uexambyyear($userid,$year_id);
					if($userexams->exam_id!="" && $userexams->exam_status=='pending')
					{	
						$data['term_id']=$userexams->term_id;
					}
					else if($userexams->exam_id!="" && $userexams->exam_status=='pass')
					{	
						$data['term_id']=$userexams->term_id+1;
					}
					else
					{
						$data['term_id']=1;
					}
					
					/*----Get user exam question array------*/
					$exam_questermArr=array();
					$exam_questions=$this->questions_model->check_examhistory_question($userid,$year_id,$data['term_id']);
					if($exam_questions)
					{
						
						foreach($exam_questions as $examdata)
						{
							array_push($exam_questermArr,$examdata->question_id);
						}
					}
					
					
					/*----End of get user exam question array----*/
					$term_questermArr=array();
					$term_questions=$this->questions_model->term_exam($year_id,$data['term_id']);
					if($term_questions)
					{
						
						foreach($term_questions as $tquestion)
						{
							array_push($term_questermArr,$tquestion->question_id);
						}
						
					}
					$total_exam_question=count($exam_questermArr);
					$total_term_question=count($exam_questermArr);
					/*---update term by exam completed status----*/
					if($total_term_question==$total_exam_question)
					{
						$exam_status=array(
								'exam_status'=>'pass',							
								
								);
						
						$updateexam_status=$this->questions_model->Update_Examterm_status($exam_status,$exam_id);
					}
					/*---update term by exam completed status----*/
					$exam_output = array_merge(array_diff($term_questermArr, $exam_questermArr), array_diff($exam_questermArr, $term_questermArr));
					$exam_random=array_rand($exam_output);					
					$randquestion=$exam_output[$exam_random];
					/*---End of check user not applied question list---*/
					$data['Questionlist']=$this->questions_model->term_exam_question($year_id,$data['term_id'],$randquestion);
						//$data['Questionlist']=$this->questions_model->term_exam($year_id,1);
						$this->load->view('frontend/private/examplay',$data);

					}
					else
					{
			
						/*----insert user exam list---------*/
						$userid=$this->session->userdata('user_id');
						$createdate=date("Y-m-d H:i:s");
						$chkrow_exam=$this->questions_model->check_userexam($userid,$year_id,$term_id);	
						
						if($chkrow_exam->exam_id!="" )
						{
							$exam_id=$chkrow_exam->exam_id;
						}
						else
						{
							$user_exam=array(
									'user_id'=>$userid,
									'year_id'=>$year_id,
									'term_id'=>$term_id,													
									'exam_date'=>$createdate
									
									);
							$exam_id=$this->questions_model->Save_Userexam($user_exam);	
						}
						
						if($exam_id!="")
						{
							$uexam_history=array(
								'exam_id'=>$exam_id,
								'user_id'=>$userid,
								'year_id'=>$year_id,
								'term_id'=>$term_id,													
								'question_id'=>$questionid,
								'answer_id'=>$answerid,
								'answer_status'=>'true',
								
								);
							$hexam_id=$this->questions_model->Save_Examhistory($uexam_history);		
						}
						
								/*----Get user exam question array------*/
					$exam_questermArr=array();
					$exam_questions=$this->questions_model->check_examhistory_question($userid,$year_id,$term_id);
					if($exam_questions)
					{
						
						foreach($exam_questions as $examdata)
						{
							array_push($exam_questermArr,$examdata->question_id);
						}
					}
					
					
					/*----End of get user exam question array----*/
					$term_questermArr=array();
					$term_questions=$this->questions_model->term_exam($year_id,$term_id);
					if($term_questions)
					{
						
						foreach($term_questions as $tquestion)
						{
							array_push($term_questermArr,$tquestion->question_id);
						}
						
					}
					$total_exam_question=count($exam_questermArr);
					$total_term_question=count($exam_questermArr);
					/*---update term by exam completed status----*/
					if($total_term_question==$total_exam_question)
					{
						$exam_status=array(
								'exam_status'=>'pass',							
								
								);
						
						$updateexam_status=$this->questions_model->Update_Examterm_status($exam_status,$exam_id);
					}
					/*---update term by exam completed status----*/
						
						/*----End of insert user exam list-------*/
						$data["yourans"] = $this->main_model->get_detail('manage_answer_'.$year_id,'ans_id',$answerid);	
						$this->load->view('frontend/private/explanation',$data);
					}
					
								
					}
				else
				{
					$userid=$this->session->userdata('user_id');
					/*---check user not applied question list---*/
					$userexams=$this->questions_model->check_uexambyyear($userid,$year_id);
					if($userexams->exam_id!="" && $userexams->exam_status=='pending')
					{	
						$data['term_id']=$userexams->term_id;
					}
					else if($userexams->exam_id!="" && $userexams->exam_status=='pass')
					{	
						$data['term_id']=$userexams->term_id+1;
					}
					else
					{
						$data['term_id']=1;
					}
					
					/*----Get user exam question array------*/
					$exam_questermArr=array();
					$exam_questions=$this->questions_model->check_examhistory_question($userid,$year_id,$data['term_id']);
					if($exam_questions)
					{
						
						foreach($exam_questions as $examdata)
						{
							array_push($exam_questermArr,$examdata->question_id);
						}
					}
					
					
					/*----End of get user exam question array----*/
					$term_questermArr=array();
					$term_questions=$this->questions_model->term_exam($year_id,$data['term_id']);
					if($term_questions)
					{
						
						foreach($term_questions as $tquestion)
						{
							array_push($term_questermArr,$tquestion->question_id);
						}
						
					}
					//var_dump($term_questermArr);
					
					$exam_output = array_merge(array_diff($term_questermArr, $exam_questermArr), array_diff($exam_questermArr, $term_questermArr));
					$exam_random=array_rand($exam_output);					
					$randquestion=$exam_output[$exam_random];
					/*---End of check user not applied question list---*/
					$data['Questionlist']=$this->questions_model->term_exam_question($year_id,$data['term_id'],$randquestion);
	
					$this->load->view('frontend/private/examplay',$data);
				}
			}
			/*---end final year exam-----*/
			else
			{	

			$data["skill_dtl"] =$this->main_model->get_skill('master_skill','skill_slug',$subskill,'skill_class',$year_id);		
			  $subskill_id=$data["skill_dtl"]->skill_id;
			$this->questions_model->CLASSID = $year_id;
				//$data["Questionlist"] = $this->questions_model->question_list_subskill($subskill_id);
		
				if($this->input->post('action')=='submitanswer')	
					{
					 $questionid=$this->input->post('questionid');
					 $answerid=$this->input->post('answerid');
				
					
					$data["ques_dtl"] = $this->main_model->get_detail('manage_question_'.$year_id,'ques_id',$questionid);
					//print_r($data["ques_dtl"]);
					
					$data["correct_ans"] = $this->main_model->get_detail('manage_answer_'.$year_id,'ans_id',$data["ques_dtl"]->ques_rightanswer);
					//print_r($data["correct_ans"]);
					//echo $data["correct_ans"]->ans_name;
										
					if($data["ques_dtl"]->ques_rightanswer==$answerid)
					{
						
					$data['correct']=1;
					$data["Questionlist"] = $this->questions_model->random_question($subskill_id);
					$this->load->view('frontend/private/play',$data);

					}
					else{
			
					$data["yourans"] = $this->main_model->get_detail('manage_answer_'.$year_id,'ans_id',$answerid);	
					$this->load->view('frontend/private/explanation',$data);
					}
					
								
					}
				else{
					$data["Questionlist"] = $this->questions_model->random_question($subskill_id);
					$this->load->view('frontend/private/play',$data);
					}
			
				}
			}
			else{
				
				if($this->session->userdata('user_id')!='' and $this->session->userdata('username')!='')
				{

				$data["SylList1"] = $this->syllabus_model->syllabus_list($year_id,1);
				$data["SylList2"] = $this->syllabus_model->syllabus_list($year_id,2);
				$data["SylList3"] = $this->syllabus_model->syllabus_list($year_id,3);
				$data["SylList4"] = $this->syllabus_model->syllabus_list($year_id,4);

				$this->load->view('frontend/private/kindergarten', $data);
				}
				else{
				$data["SylList1"] = $this->syllabus_model->syllabus_list($year_id,1);
				$data["SylList2"] = $this->syllabus_model->syllabus_list($year_id,2);
				$data["SylList3"] = $this->syllabus_model->syllabus_list($year_id,3);
				$data["SylList4"] = $this->syllabus_model->syllabus_list($year_id,4);

				$this->load->view('frontend/public/kg_wtht_login', $data);	
					
				}

			}
	}
	public function year9($subskill='') 
	{	
		$yearid=$this->session->userdata('loginyear');
			$yeardata=$this->classes_model->classes_details($yearid);
			if($yeardata)
			{
				$data['year_name']=$yeardata[0]->class_name;
				$data['year_slug']=$yeardata[0]->class_slug;
			}
		$year_id=10;
		$data['year_id']=$year_id;
		$this->questions_model->CLASSID = $year_id;
		$data["year_dtl"] = $this->main_model->get_detail('master_class','class_id',$year_id);	
		if($subskill!=""){
			/*---Start Assessment Test -----*/
			if($subskill=="assessment")
			{
				
					/*---get all past year of assessment list----*/
					$pastyear=$this->questions_model->assessment_pastyear($year_id);
						/*echo '<pre>';
						var_dump($pastyear);
						echo '</pre>';
						*/
					$todaydate=date("Y-m-d H:i:s");	
					$userid=$this->session->userdata('user_id');
					$asstime_query=$this->questions_model->assessment_time($year_id,$userid);
					$yourstart=$asstime_query->start_time;
					if($yourstart!="" && $yourstart!=null)
					{
						$seconds = strtotime($todaydate) - strtotime($yourstart);
						$days    = floor($seconds / 86400);
						$hours   = floor(($seconds - ($days * 86400)) / 3600);
						$minutes = floor(($seconds - ($days * 86400) - ($hours * 3600))/60);
						
						if($minutes >30)
						{
							//echo $minutes;
							$exam_status=array(
								'exam_status'=>'pass',							
								'end_time'=>$todaydate,
								);
						
						$updateexam_status=$this->questions_model->Update_Asstterm_status($exam_status,$asstime_query->exam_id);
						$data['timeover']=1;
						}
						else
						{
							$totalminutes=30-$minutes;
							$data['showtimer']='Duration Left: '.$totalminutes;
						}
					}
					else
					{
						$data['showtimer']='Duration: 30';
					}
					
					/*---end of get all past year of assessment list----*/	
					if($this->input->post('action')=='submitanswer')	
					{
						//var_dump($this->input->post());
					 $questionid=$this->input->post('questionid');
					 $answerid=$this->input->post('answerid');
					 $year_id=$this->input->post('year_id');
					 $ass_year_id=$this->input->post('ass_year_id');
				
					
					$data["ques_dtl"] = $this->main_model->get_detail('manage_question_'.$ass_year_id,'ques_id',$questionid);					
					//var_dump($data["ques_dtl"]);
					$data["correct_ans"] = $this->main_model->get_detail('manage_answer_'.$ass_year_id,'ans_id',$data["ques_dtl"]->ques_rightanswer);					
										
					if($data["ques_dtl"]->ques_rightanswer==$answerid)
					{
						
						$data['correct']=1;
						/*----insert user exam list---------*/
						
						$createdate=date("Y-m-d H:i:s");
						$chkrow_exam=$this->questions_model->check_userassessment($userid,$year_id,1);	
						
						if($chkrow_exam->exam_id!="" )
						{
							$exam_id=$chkrow_exam->exam_id;
						}
						else
						{
							$user_exam=array(
									'user_id'=>$userid,
									'year_id'=>$year_id,
									'assyear_id'=>$ass_year_id,													
									'exam_date'=>$createdate,
									'start_time'=>$createdate
									
									);
							$exam_id=$this->questions_model->Save_Userassessment($user_exam);	
						}
						
						if($exam_id!="")
						{
							$uexam_history=array(
								'exam_id'=>$exam_id,
								'user_id'=>$userid,
								'year_id'=>$year_id,
								'assyear_id'=>$ass_year_id,													
								'question_id'=>$questionid,
								'answer_id'=>$answerid,
								'answer_status'=>'true',
								
								);
							$historyexam_id=$this->questions_model->Save_Assessmenthistory($uexam_history);		
						}
						
						/*----End of insert user exam list-------*/
										
					/*----Get user exam question array------*/
					$exam_questermArr=array();
					$exam_questions=$this->questions_model->check_asstesthistory_question($userid,$year_id,1);
					if($exam_questions)
					{
						
						foreach($exam_questions as $examdata)
						{
							array_push($exam_questermArr,$examdata->question_id);
						}
					}
					
					
					/*----End of get user exam question array----*/
					$term_questermArr=array();
					$term_questions=$this->questions_model->assessment_exam($year_id,1);
					if($term_questions)
					{
						
						foreach($term_questions as $tquestion)
						{
							array_push($term_questermArr,$tquestion->ass_question);
						}
						
					}
					$total_exam_question=count($exam_questermArr);
					$total_term_question=count($term_questermArr);
					/*---update term by exam completed status----*/
					if($total_term_question==$total_exam_question)
					{
						$exam_status=array(
								'exam_status'=>'pass',							
								'end_time'=>$createdate,
								);
						
						$updateexam_status=$this->questions_model->Update_Asstterm_status($exam_status,$exam_id);
						$data['completed']=1;
					}
					/*---update term by exam completed status----*/
					$exam_output = array_merge(array_diff($term_questermArr, $exam_questermArr), array_diff($exam_questermArr, $term_questermArr));
					$exam_random=array_rand($exam_output);					
					$randquestion=$exam_output[$exam_random];
					/*---End of check user not applied question list---*/
					$data['Questionlist']=$this->questions_model->asstest_exam_question($year_id,1,$randquestion);
						//$data['Questionlist']=$this->questions_model->term_exam($year_id,1);
						$data['exam_id']=$exam_id;
						$this->load->view('frontend/private/assessmentplay',$data);

					}
					else
					{
			
						/*----insert user exam list---------*/
						$userid=$this->session->userdata('user_id');
						$createdate=date("Y-m-d H:i:s");
						$chkrow_exam=$this->questions_model->check_userassessment($userid,$year_id,1);	
						
						if($chkrow_exam->exam_id!="" )
						{
							$exam_id=$chkrow_exam->exam_id;
						}
						else
						{
							$user_exam=array(
									'user_id'=>$userid,
									'year_id'=>$year_id,
									'assyear_id'=>$ass_year_id,													
									'exam_date'=>$createdate,
									'start_time'=>$createdate
									
									);
							$exam_id=$this->questions_model->Save_Userassessment($user_exam);	
						}
						
						if($exam_id!="")
						{
							$uexam_history=array(
								'exam_id'=>$exam_id,
								'user_id'=>$userid,
								'year_id'=>$year_id,
								'assyear_id'=>$ass_year_id,													
								'question_id'=>$questionid,
								'answer_id'=>$answerid,
								'answer_status'=>'false',
								
								);
							$hexam_id=$this->questions_model->Save_Assessmenthistory($uexam_history);		
						}
						
								/*----Get user exam question array------*/
					$exam_questermArr=array();
					$exam_questions=$this->questions_model->check_asstesthistory_question($userid,$year_id,$term_id);
					if($exam_questions)
					{
						
						foreach($exam_questions as $examdata)
						{
							array_push($exam_questermArr,$examdata->question_id);
						}
					}
					
					
					/*----End of get user exam question array----*/
					$term_questermArr=array();
					$term_questions=$this->questions_model->assessment_exam($year_id,1);
					if($term_questions)
					{
						
						foreach($term_questions as $tquestion)
						{
							array_push($term_questermArr,$tquestion->ass_question);
						}
						
					}
					$total_exam_question=count($exam_questermArr);
					$total_term_question=count($term_questermArr);
					/*---update term by exam completed status----*/
					if($total_term_question==$total_exam_question)
					{
						$exam_status=array(
								'exam_status'=>'pass',
								'end_time'=>$createdate,	
								
								);
						
						$updateexam_status=$this->questions_model->Update_Asstterm_status($exam_status,$exam_id);
						$data['completed']=1;
					}
					/*---update term by exam completed status----*/
						
						/*----End of insert user exam list-------*/
					
						$data["yourans"] = $this->main_model->get_detail('manage_answer_'.$ass_year_id,'ans_id',$answerid);	
						$data['exam_id']=$exam_id;
						$this->load->view('frontend/private/asstestexplanation',$data);
					}
					
								
					}
				else
				{
					$userid=$this->session->userdata('user_id');
					/*---check user not applied question list---*/
					$userexams=$this->questions_model->check_uasstestbyyear($userid,$year_id);
					$data['exam_id']=$userexams->exam_id;
					if($userexams->exam_id!="" && $userexams->exam_status=='pending')
					{	
						$data['assyear_id']=$userexams->assyear_id;
					}
					
					else if($userexams->exam_id!="" && $userexams->exam_status=='pass')
					{	
						$data['assyear_id']=$userexams->assyear_id+1;
					}
				
					else
					{
						$data['assyear_id']=$pastyear[0]->ass_year_id;
						//echo $pastyear[0]->ass_year_id;
					}
					
					/*----Get user exam question array------*/
					$exam_questermArr=array();
					$exam_questions=$this->questions_model->check_asstesthistory_question($userid,$year_id,1);
					if($exam_questions)
					{
						
						foreach($exam_questions as $examdata)
						{
							array_push($exam_questermArr,$examdata->question_id);
						}
					}
					
					
					/*----End of get user exam question array----*/
					$term_questermArr=array();
					$term_questions=$this->questions_model->assessment_exam($year_id,1);
					
					if($term_questions)
					{
						
						foreach($term_questions as $tquestion)
						{
							array_push($term_questermArr,$tquestion->ass_question);
						}
						
					}
					//var_dump($term_questermArr);
					
					$exam_output = array_merge(array_diff($term_questermArr, $exam_questermArr), array_diff($exam_questermArr, $term_questermArr));
					$exam_random=array_rand($exam_output);					
					$randquestion=$exam_output[$exam_random];
					/*---End of check user not applied question list---*/
					if($userexams->exam_status!='pass')
					{
					$data['Questionlist']=$this->questions_model->asstest_exam_question($year_id,1,$randquestion);
					}
					else
					{
						$data['Questionlist']='';
						$data['completed']=1;
					}
					//var_dump($data['Questionlist']);
					$this->load->view('frontend/private/assessmentplay',$data);
				}
			
			}
			/*---End Assessment Test -----*/
			/*---final year exam-----*/
			else if($subskill=="exam")
			{
				
				
					if($this->input->post('action')=='submitanswer')	
					{
					 $questionid=$this->input->post('questionid');
					 $answerid=$this->input->post('answerid');
					 $year_id=$this->input->post('year_id');
					 $term_id=$this->input->post('term_id');
				
					
					$data["ques_dtl"] = $this->main_model->get_detail('manage_question_'.$year_id,'ques_id',$questionid);					
					
					$data["correct_ans"] = $this->main_model->get_detail('manage_answer_'.$year_id,'ans_id',$data["ques_dtl"]->ques_rightanswer);					
										
					if($data["ques_dtl"]->ques_rightanswer==$answerid)
					{
						
						$data['correct']=1;
						/*----insert user exam list---------*/
						$userid=$this->session->userdata('user_id');
						$createdate=date("Y-m-d H:i:s");
						$chkrow_exam=$this->questions_model->check_userexam($userid,$year_id,$term_id);	
						
						if($chkrow_exam->exam_id!="" )
						{
							$exam_id=$chkrow_exam->exam_id;
						}
						else
						{
							$user_exam=array(
									'user_id'=>$userid,
									'year_id'=>$year_id,
									'term_id'=>$term_id,													
									'exam_date'=>$createdate
									
									);
							$exam_id=$this->questions_model->Save_Userexam($user_exam);	
						}
						
						if($exam_id!="")
						{
							$uexam_history=array(
								'exam_id'=>$exam_id,
								'user_id'=>$userid,
								'year_id'=>$year_id,
								'term_id'=>$term_id,													
								'question_id'=>$questionid,
								'answer_id'=>$answerid,
								'answer_status'=>'false',
								
								);
							$historyexam_id=$this->questions_model->Save_Examhistory($uexam_history);		
						}
						
						/*----End of insert user exam list-------*/
						
										/*---check user not applied question list---*/
					$userexams=$this->questions_model->check_uexambyyear($userid,$year_id);
					if($userexams->exam_id!="" && $userexams->exam_status=='pending')
					{	
						$data['term_id']=$userexams->term_id;
					}
					else if($userexams->exam_id!="" && $userexams->exam_status=='pass')
					{	
						$data['term_id']=$userexams->term_id+1;
					}
					else
					{
						$data['term_id']=1;
					}
					
					/*----Get user exam question array------*/
					$exam_questermArr=array();
					$exam_questions=$this->questions_model->check_examhistory_question($userid,$year_id,$data['term_id']);
					if($exam_questions)
					{
						
						foreach($exam_questions as $examdata)
						{
							array_push($exam_questermArr,$examdata->question_id);
						}
					}
					
					
					/*----End of get user exam question array----*/
					$term_questermArr=array();
					$term_questions=$this->questions_model->term_exam($year_id,$data['term_id']);
					if($term_questions)
					{
						
						foreach($term_questions as $tquestion)
						{
							array_push($term_questermArr,$tquestion->question_id);
						}
						
					}
					$total_exam_question=count($exam_questermArr);
					$total_term_question=count($exam_questermArr);
					/*---update term by exam completed status----*/
					if($total_term_question==$total_exam_question)
					{
						$exam_status=array(
								'exam_status'=>'pass',							
								
								);
						
						$updateexam_status=$this->questions_model->Update_Examterm_status($exam_status,$exam_id);
					}
					/*---update term by exam completed status----*/
					$exam_output = array_merge(array_diff($term_questermArr, $exam_questermArr), array_diff($exam_questermArr, $term_questermArr));
					$exam_random=array_rand($exam_output);					
					$randquestion=$exam_output[$exam_random];
					/*---End of check user not applied question list---*/
					$data['Questionlist']=$this->questions_model->term_exam_question($year_id,$data['term_id'],$randquestion);
						//$data['Questionlist']=$this->questions_model->term_exam($year_id,1);
						$this->load->view('frontend/private/examplay',$data);

					}
					else
					{
			
						/*----insert user exam list---------*/
						$userid=$this->session->userdata('user_id');
						$createdate=date("Y-m-d H:i:s");
						$chkrow_exam=$this->questions_model->check_userexam($userid,$year_id,$term_id);	
						
						if($chkrow_exam->exam_id!="" )
						{
							$exam_id=$chkrow_exam->exam_id;
						}
						else
						{
							$user_exam=array(
									'user_id'=>$userid,
									'year_id'=>$year_id,
									'term_id'=>$term_id,													
									'exam_date'=>$createdate
									
									);
							$exam_id=$this->questions_model->Save_Userexam($user_exam);	
						}
						
						if($exam_id!="")
						{
							$uexam_history=array(
								'exam_id'=>$exam_id,
								'user_id'=>$userid,
								'year_id'=>$year_id,
								'term_id'=>$term_id,													
								'question_id'=>$questionid,
								'answer_id'=>$answerid,
								'answer_status'=>'true',
								
								);
							$hexam_id=$this->questions_model->Save_Examhistory($uexam_history);		
						}
						
								/*----Get user exam question array------*/
					$exam_questermArr=array();
					$exam_questions=$this->questions_model->check_examhistory_question($userid,$year_id,$term_id);
					if($exam_questions)
					{
						
						foreach($exam_questions as $examdata)
						{
							array_push($exam_questermArr,$examdata->question_id);
						}
					}
					
					
					/*----End of get user exam question array----*/
					$term_questermArr=array();
					$term_questions=$this->questions_model->term_exam($year_id,$term_id);
					if($term_questions)
					{
						
						foreach($term_questions as $tquestion)
						{
							array_push($term_questermArr,$tquestion->question_id);
						}
						
					}
					$total_exam_question=count($exam_questermArr);
					$total_term_question=count($exam_questermArr);
					/*---update term by exam completed status----*/
					if($total_term_question==$total_exam_question)
					{
						$exam_status=array(
								'exam_status'=>'pass',							
								
								);
						
						$updateexam_status=$this->questions_model->Update_Examterm_status($exam_status,$exam_id);
					}
					/*---update term by exam completed status----*/
						
						/*----End of insert user exam list-------*/
						$data["yourans"] = $this->main_model->get_detail('manage_answer_'.$year_id,'ans_id',$answerid);	
						$this->load->view('frontend/private/explanation',$data);
					}
					
								
					}
				else
				{
					$userid=$this->session->userdata('user_id');
					/*---check user not applied question list---*/
					$userexams=$this->questions_model->check_uexambyyear($userid,$year_id);
					if($userexams->exam_id!="" && $userexams->exam_status=='pending')
					{	
						$data['term_id']=$userexams->term_id;
					}
					else if($userexams->exam_id!="" && $userexams->exam_status=='pass')
					{	
						$data['term_id']=$userexams->term_id+1;
					}
					else
					{
						$data['term_id']=1;
					}
					
					/*----Get user exam question array------*/
					$exam_questermArr=array();
					$exam_questions=$this->questions_model->check_examhistory_question($userid,$year_id,$data['term_id']);
					if($exam_questions)
					{
						
						foreach($exam_questions as $examdata)
						{
							array_push($exam_questermArr,$examdata->question_id);
						}
					}
					
					
					/*----End of get user exam question array----*/
					$term_questermArr=array();
					$term_questions=$this->questions_model->term_exam($year_id,$data['term_id']);
					if($term_questions)
					{
						
						foreach($term_questions as $tquestion)
						{
							array_push($term_questermArr,$tquestion->question_id);
						}
						
					}
					//var_dump($term_questermArr);
					
					$exam_output = array_merge(array_diff($term_questermArr, $exam_questermArr), array_diff($exam_questermArr, $term_questermArr));
					$exam_random=array_rand($exam_output);					
					$randquestion=$exam_output[$exam_random];
					/*---End of check user not applied question list---*/
					$data['Questionlist']=$this->questions_model->term_exam_question($year_id,$data['term_id'],$randquestion);
	
					$this->load->view('frontend/private/examplay',$data);
				}
			}
			/*---end final year exam-----*/
			else
			{	

			$data["skill_dtl"] =$this->main_model->get_skill('master_skill','skill_slug',$subskill,'skill_class',$year_id);		
			  $subskill_id=$data["skill_dtl"]->skill_id;
			$this->questions_model->CLASSID = $year_id;
				//$data["Questionlist"] = $this->questions_model->question_list_subskill($subskill_id);
		
				if($this->input->post('action')=='submitanswer')	
					{
					 $questionid=$this->input->post('questionid');
					 $answerid=$this->input->post('answerid');
				
					
					$data["ques_dtl"] = $this->main_model->get_detail('manage_question_'.$year_id,'ques_id',$questionid);
					//print_r($data["ques_dtl"]);
					
					$data["correct_ans"] = $this->main_model->get_detail('manage_answer_'.$year_id,'ans_id',$data["ques_dtl"]->ques_rightanswer);
					//print_r($data["correct_ans"]);
					//echo $data["correct_ans"]->ans_name;
										
					if($data["ques_dtl"]->ques_rightanswer==$answerid)
					{
						
					$data['correct']=1;
					$data["Questionlist"] = $this->questions_model->random_question($subskill_id);
					$this->load->view('frontend/private/play',$data);

					}
					else{
			
					$data["yourans"] = $this->main_model->get_detail('manage_answer_'.$year_id,'ans_id',$answerid);	
					$this->load->view('frontend/private/explanation',$data);
					}
					
								
					}
				else{
					$data["Questionlist"] = $this->questions_model->random_question($subskill_id);
					$this->load->view('frontend/private/play',$data);
					}
			
				}
			}
			else{
				
				if($this->session->userdata('user_id')!='' and $this->session->userdata('username')!='')
				{

				$data["SylList1"] = $this->syllabus_model->syllabus_list($year_id,1);
				$data["SylList2"] = $this->syllabus_model->syllabus_list($year_id,2);
				$data["SylList3"] = $this->syllabus_model->syllabus_list($year_id,3);
				$data["SylList4"] = $this->syllabus_model->syllabus_list($year_id,4);

				$this->load->view('frontend/private/kindergarten', $data);
				}
				else{
				$data["SylList1"] = $this->syllabus_model->syllabus_list($year_id,1);
				$data["SylList2"] = $this->syllabus_model->syllabus_list($year_id,2);
				$data["SylList3"] = $this->syllabus_model->syllabus_list($year_id,3);
				$data["SylList4"] = $this->syllabus_model->syllabus_list($year_id,4);

				$this->load->view('frontend/public/kg_wtht_login', $data);	
					
				}

			}
		
	}
	public function year10($subskill='') 
	{	
		$yearid=$this->session->userdata('loginyear');
			$yeardata=$this->classes_model->classes_details($yearid);
			if($yeardata)
			{
				$data['year_name']=$yeardata[0]->class_name;
				$data['year_slug']=$yeardata[0]->class_slug;
			}
		$year_id=11;
		$data['year_id']=$year_id;
		$this->questions_model->CLASSID = $year_id;
		$data["year_dtl"] = $this->main_model->get_detail('master_class','class_id',$year_id);	
		if($subskill!=""){
			/*---Start Assessment Test -----*/
			if($subskill=="assessment")
			{
				
					/*---get all past year of assessment list----*/
					$pastyear=$this->questions_model->assessment_pastyear($year_id);
						/*echo '<pre>';
						var_dump($pastyear);
						echo '</pre>';
						*/
					$todaydate=date("Y-m-d H:i:s");	
					$userid=$this->session->userdata('user_id');
					$asstime_query=$this->questions_model->assessment_time($year_id,$userid);
					$yourstart=$asstime_query->start_time;
					if($yourstart!="" && $yourstart!=null)
					{
						$seconds = strtotime($todaydate) - strtotime($yourstart);
						$days    = floor($seconds / 86400);
						$hours   = floor(($seconds - ($days * 86400)) / 3600);
						$minutes = floor(($seconds - ($days * 86400) - ($hours * 3600))/60);
						
						if($minutes >30)
						{
							//echo $minutes;
							$exam_status=array(
								'exam_status'=>'pass',							
								'end_time'=>$todaydate,
								);
						
						$updateexam_status=$this->questions_model->Update_Asstterm_status($exam_status,$asstime_query->exam_id);
						$data['timeover']=1;
						}
						else
						{
							$totalminutes=30-$minutes;
							$data['showtimer']='Duration Left: '.$totalminutes;
						}
					}
					else
					{
						$data['showtimer']='Duration: 30';
					}
					
					/*---end of get all past year of assessment list----*/	
					if($this->input->post('action')=='submitanswer')	
					{
						//var_dump($this->input->post());
					 $questionid=$this->input->post('questionid');
					 $answerid=$this->input->post('answerid');
					 $year_id=$this->input->post('year_id');
					 $ass_year_id=$this->input->post('ass_year_id');
				
					
					$data["ques_dtl"] = $this->main_model->get_detail('manage_question_'.$ass_year_id,'ques_id',$questionid);					
					//var_dump($data["ques_dtl"]);
					$data["correct_ans"] = $this->main_model->get_detail('manage_answer_'.$ass_year_id,'ans_id',$data["ques_dtl"]->ques_rightanswer);					
										
					if($data["ques_dtl"]->ques_rightanswer==$answerid)
					{
						
						$data['correct']=1;
						/*----insert user exam list---------*/
						
						$createdate=date("Y-m-d H:i:s");
						$chkrow_exam=$this->questions_model->check_userassessment($userid,$year_id,1);	
						
						if($chkrow_exam->exam_id!="" )
						{
							$exam_id=$chkrow_exam->exam_id;
						}
						else
						{
							$user_exam=array(
									'user_id'=>$userid,
									'year_id'=>$year_id,
									'assyear_id'=>$ass_year_id,													
									'exam_date'=>$createdate,
									'start_time'=>$createdate
									
									);
							$exam_id=$this->questions_model->Save_Userassessment($user_exam);	
						}
						
						if($exam_id!="")
						{
							$uexam_history=array(
								'exam_id'=>$exam_id,
								'user_id'=>$userid,
								'year_id'=>$year_id,
								'assyear_id'=>$ass_year_id,													
								'question_id'=>$questionid,
								'answer_id'=>$answerid,
								'answer_status'=>'true',
								
								);
							$historyexam_id=$this->questions_model->Save_Assessmenthistory($uexam_history);		
						}
						
						/*----End of insert user exam list-------*/
										
					/*----Get user exam question array------*/
					$exam_questermArr=array();
					$exam_questions=$this->questions_model->check_asstesthistory_question($userid,$year_id,1);
					if($exam_questions)
					{
						
						foreach($exam_questions as $examdata)
						{
							array_push($exam_questermArr,$examdata->question_id);
						}
					}
					
					
					/*----End of get user exam question array----*/
					$term_questermArr=array();
					$term_questions=$this->questions_model->assessment_exam($year_id,1);
					if($term_questions)
					{
						
						foreach($term_questions as $tquestion)
						{
							array_push($term_questermArr,$tquestion->ass_question);
						}
						
					}
					$total_exam_question=count($exam_questermArr);
					$total_term_question=count($term_questermArr);
					/*---update term by exam completed status----*/
					if($total_term_question==$total_exam_question)
					{
						$exam_status=array(
								'exam_status'=>'pass',							
								'end_time'=>$createdate,
								);
						
						$updateexam_status=$this->questions_model->Update_Asstterm_status($exam_status,$exam_id);
						$data['completed']=1;
					}
					/*---update term by exam completed status----*/
					$exam_output = array_merge(array_diff($term_questermArr, $exam_questermArr), array_diff($exam_questermArr, $term_questermArr));
					$exam_random=array_rand($exam_output);					
					$randquestion=$exam_output[$exam_random];
					/*---End of check user not applied question list---*/
					$data['Questionlist']=$this->questions_model->asstest_exam_question($year_id,1,$randquestion);
						//$data['Questionlist']=$this->questions_model->term_exam($year_id,1);
						$data['exam_id']=$exam_id;
						$this->load->view('frontend/private/assessmentplay',$data);

					}
					else
					{
			
						/*----insert user exam list---------*/
						$userid=$this->session->userdata('user_id');
						$createdate=date("Y-m-d H:i:s");
						$chkrow_exam=$this->questions_model->check_userassessment($userid,$year_id,1);	
						
						if($chkrow_exam->exam_id!="" )
						{
							$exam_id=$chkrow_exam->exam_id;
						}
						else
						{
							$user_exam=array(
									'user_id'=>$userid,
									'year_id'=>$year_id,
									'assyear_id'=>$ass_year_id,													
									'exam_date'=>$createdate,
									'start_time'=>$createdate
									
									);
							$exam_id=$this->questions_model->Save_Userassessment($user_exam);	
						}
						
						if($exam_id!="")
						{
							$uexam_history=array(
								'exam_id'=>$exam_id,
								'user_id'=>$userid,
								'year_id'=>$year_id,
								'assyear_id'=>$ass_year_id,													
								'question_id'=>$questionid,
								'answer_id'=>$answerid,
								'answer_status'=>'false',
								
								);
							$hexam_id=$this->questions_model->Save_Assessmenthistory($uexam_history);		
						}
						
								/*----Get user exam question array------*/
					$exam_questermArr=array();
					$exam_questions=$this->questions_model->check_asstesthistory_question($userid,$year_id,$term_id);
					if($exam_questions)
					{
						
						foreach($exam_questions as $examdata)
						{
							array_push($exam_questermArr,$examdata->question_id);
						}
					}
					
					
					/*----End of get user exam question array----*/
					$term_questermArr=array();
					$term_questions=$this->questions_model->assessment_exam($year_id,1);
					if($term_questions)
					{
						
						foreach($term_questions as $tquestion)
						{
							array_push($term_questermArr,$tquestion->ass_question);
						}
						
					}
					$total_exam_question=count($exam_questermArr);
					$total_term_question=count($term_questermArr);
					/*---update term by exam completed status----*/
					if($total_term_question==$total_exam_question)
					{
						$exam_status=array(
								'exam_status'=>'pass',
								'end_time'=>$createdate,	
								
								);
						
						$updateexam_status=$this->questions_model->Update_Asstterm_status($exam_status,$exam_id);
						$data['completed']=1;
					}
					/*---update term by exam completed status----*/
						
						/*----End of insert user exam list-------*/
					
						$data["yourans"] = $this->main_model->get_detail('manage_answer_'.$ass_year_id,'ans_id',$answerid);	
						$data['exam_id']=$exam_id;
						$this->load->view('frontend/private/asstestexplanation',$data);
					}
					
								
					}
				else
				{
					$userid=$this->session->userdata('user_id');
					/*---check user not applied question list---*/
					$userexams=$this->questions_model->check_uasstestbyyear($userid,$year_id);
					$data['exam_id']=$userexams->exam_id;
					if($userexams->exam_id!="" && $userexams->exam_status=='pending')
					{	
						$data['assyear_id']=$userexams->assyear_id;
					}
					
					else if($userexams->exam_id!="" && $userexams->exam_status=='pass')
					{	
						$data['assyear_id']=$userexams->assyear_id+1;
					}
				
					else
					{
						$data['assyear_id']=$pastyear[0]->ass_year_id;
						//echo $pastyear[0]->ass_year_id;
					}
					
					/*----Get user exam question array------*/
					$exam_questermArr=array();
					$exam_questions=$this->questions_model->check_asstesthistory_question($userid,$year_id,1);
					if($exam_questions)
					{
						
						foreach($exam_questions as $examdata)
						{
							array_push($exam_questermArr,$examdata->question_id);
						}
					}
					
					
					/*----End of get user exam question array----*/
					$term_questermArr=array();
					$term_questions=$this->questions_model->assessment_exam($year_id,1);
					
					if($term_questions)
					{
						
						foreach($term_questions as $tquestion)
						{
							array_push($term_questermArr,$tquestion->ass_question);
						}
						
					}
					//var_dump($term_questermArr);
					
					$exam_output = array_merge(array_diff($term_questermArr, $exam_questermArr), array_diff($exam_questermArr, $term_questermArr));
					$exam_random=array_rand($exam_output);					
					$randquestion=$exam_output[$exam_random];
					/*---End of check user not applied question list---*/
					if($userexams->exam_status!='pass')
					{
					$data['Questionlist']=$this->questions_model->asstest_exam_question($year_id,1,$randquestion);
					}
					else
					{
						$data['Questionlist']='';
						$data['completed']=1;
					}
					//var_dump($data['Questionlist']);
					$this->load->view('frontend/private/assessmentplay',$data);
				}
			
			}
			/*---End Assessment Test -----*/
			/*---final year exam-----*/
			else if($subskill=="exam")
			{
				
				
					if($this->input->post('action')=='submitanswer')	
					{
					 $questionid=$this->input->post('questionid');
					 $answerid=$this->input->post('answerid');
					 $year_id=$this->input->post('year_id');
					 $term_id=$this->input->post('term_id');
				
					
					$data["ques_dtl"] = $this->main_model->get_detail('manage_question_'.$year_id,'ques_id',$questionid);					
					
					$data["correct_ans"] = $this->main_model->get_detail('manage_answer_'.$year_id,'ans_id',$data["ques_dtl"]->ques_rightanswer);					
										
					if($data["ques_dtl"]->ques_rightanswer==$answerid)
					{
						
						$data['correct']=1;
						/*----insert user exam list---------*/
						$userid=$this->session->userdata('user_id');
						$createdate=date("Y-m-d H:i:s");
						$chkrow_exam=$this->questions_model->check_userexam($userid,$year_id,$term_id);	
						
						if($chkrow_exam->exam_id!="" )
						{
							$exam_id=$chkrow_exam->exam_id;
						}
						else
						{
							$user_exam=array(
									'user_id'=>$userid,
									'year_id'=>$year_id,
									'term_id'=>$term_id,													
									'exam_date'=>$createdate
									
									);
							$exam_id=$this->questions_model->Save_Userexam($user_exam);	
						}
						
						if($exam_id!="")
						{
							$uexam_history=array(
								'exam_id'=>$exam_id,
								'user_id'=>$userid,
								'year_id'=>$year_id,
								'term_id'=>$term_id,													
								'question_id'=>$questionid,
								'answer_id'=>$answerid,
								'answer_status'=>'false',
								
								);
							$historyexam_id=$this->questions_model->Save_Examhistory($uexam_history);		
						}
						
						/*----End of insert user exam list-------*/
						
										/*---check user not applied question list---*/
					$userexams=$this->questions_model->check_uexambyyear($userid,$year_id);
					if($userexams->exam_id!="" && $userexams->exam_status=='pending')
					{	
						$data['term_id']=$userexams->term_id;
					}
					else if($userexams->exam_id!="" && $userexams->exam_status=='pass')
					{	
						$data['term_id']=$userexams->term_id+1;
					}
					else
					{
						$data['term_id']=1;
					}
					
					/*----Get user exam question array------*/
					$exam_questermArr=array();
					$exam_questions=$this->questions_model->check_examhistory_question($userid,$year_id,$data['term_id']);
					if($exam_questions)
					{
						
						foreach($exam_questions as $examdata)
						{
							array_push($exam_questermArr,$examdata->question_id);
						}
					}
					
					
					/*----End of get user exam question array----*/
					$term_questermArr=array();
					$term_questions=$this->questions_model->term_exam($year_id,$data['term_id']);
					if($term_questions)
					{
						
						foreach($term_questions as $tquestion)
						{
							array_push($term_questermArr,$tquestion->question_id);
						}
						
					}
					$total_exam_question=count($exam_questermArr);
					$total_term_question=count($exam_questermArr);
					/*---update term by exam completed status----*/
					if($total_term_question==$total_exam_question)
					{
						$exam_status=array(
								'exam_status'=>'pass',							
								
								);
						
						$updateexam_status=$this->questions_model->Update_Examterm_status($exam_status,$exam_id);
					}
					/*---update term by exam completed status----*/
					$exam_output = array_merge(array_diff($term_questermArr, $exam_questermArr), array_diff($exam_questermArr, $term_questermArr));
					$exam_random=array_rand($exam_output);					
					$randquestion=$exam_output[$exam_random];
					/*---End of check user not applied question list---*/
					$data['Questionlist']=$this->questions_model->term_exam_question($year_id,$data['term_id'],$randquestion);
						//$data['Questionlist']=$this->questions_model->term_exam($year_id,1);
						$this->load->view('frontend/private/examplay',$data);

					}
					else
					{
			
						/*----insert user exam list---------*/
						$userid=$this->session->userdata('user_id');
						$createdate=date("Y-m-d H:i:s");
						$chkrow_exam=$this->questions_model->check_userexam($userid,$year_id,$term_id);	
						
						if($chkrow_exam->exam_id!="" )
						{
							$exam_id=$chkrow_exam->exam_id;
						}
						else
						{
							$user_exam=array(
									'user_id'=>$userid,
									'year_id'=>$year_id,
									'term_id'=>$term_id,													
									'exam_date'=>$createdate
									
									);
							$exam_id=$this->questions_model->Save_Userexam($user_exam);	
						}
						
						if($exam_id!="")
						{
							$uexam_history=array(
								'exam_id'=>$exam_id,
								'user_id'=>$userid,
								'year_id'=>$year_id,
								'term_id'=>$term_id,													
								'question_id'=>$questionid,
								'answer_id'=>$answerid,
								'answer_status'=>'true',
								
								);
							$hexam_id=$this->questions_model->Save_Examhistory($uexam_history);		
						}
						
								/*----Get user exam question array------*/
					$exam_questermArr=array();
					$exam_questions=$this->questions_model->check_examhistory_question($userid,$year_id,$term_id);
					if($exam_questions)
					{
						
						foreach($exam_questions as $examdata)
						{
							array_push($exam_questermArr,$examdata->question_id);
						}
					}
					
					
					/*----End of get user exam question array----*/
					$term_questermArr=array();
					$term_questions=$this->questions_model->term_exam($year_id,$term_id);
					if($term_questions)
					{
						
						foreach($term_questions as $tquestion)
						{
							array_push($term_questermArr,$tquestion->question_id);
						}
						
					}
					$total_exam_question=count($exam_questermArr);
					$total_term_question=count($exam_questermArr);
					/*---update term by exam completed status----*/
					if($total_term_question==$total_exam_question)
					{
						$exam_status=array(
								'exam_status'=>'pass',							
								
								);
						
						$updateexam_status=$this->questions_model->Update_Examterm_status($exam_status,$exam_id);
					}
					/*---update term by exam completed status----*/
						
						/*----End of insert user exam list-------*/
						$data["yourans"] = $this->main_model->get_detail('manage_answer_'.$year_id,'ans_id',$answerid);	
						$this->load->view('frontend/private/explanation',$data);
					}
					
								
					}
				else
				{
					$userid=$this->session->userdata('user_id');
					/*---check user not applied question list---*/
					$userexams=$this->questions_model->check_uexambyyear($userid,$year_id);
					if($userexams->exam_id!="" && $userexams->exam_status=='pending')
					{	
						$data['term_id']=$userexams->term_id;
					}
					else if($userexams->exam_id!="" && $userexams->exam_status=='pass')
					{	
						$data['term_id']=$userexams->term_id+1;
					}
					else
					{
						$data['term_id']=1;
					}
					
					/*----Get user exam question array------*/
					$exam_questermArr=array();
					$exam_questions=$this->questions_model->check_examhistory_question($userid,$year_id,$data['term_id']);
					if($exam_questions)
					{
						
						foreach($exam_questions as $examdata)
						{
							array_push($exam_questermArr,$examdata->question_id);
						}
					}
					
					
					/*----End of get user exam question array----*/
					$term_questermArr=array();
					$term_questions=$this->questions_model->term_exam($year_id,$data['term_id']);
					if($term_questions)
					{
						
						foreach($term_questions as $tquestion)
						{
							array_push($term_questermArr,$tquestion->question_id);
						}
						
					}
					//var_dump($term_questermArr);
					
					$exam_output = array_merge(array_diff($term_questermArr, $exam_questermArr), array_diff($exam_questermArr, $term_questermArr));
					$exam_random=array_rand($exam_output);					
					$randquestion=$exam_output[$exam_random];
					/*---End of check user not applied question list---*/
					$data['Questionlist']=$this->questions_model->term_exam_question($year_id,$data['term_id'],$randquestion);
	
					$this->load->view('frontend/private/examplay',$data);
				}
			}
			/*---end final year exam-----*/
			else
			{	

			$data["skill_dtl"] =$this->main_model->get_skill('master_skill','skill_slug',$subskill,'skill_class',$year_id);		
			  $subskill_id=$data["skill_dtl"]->skill_id;
			$this->questions_model->CLASSID = $year_id;
				//$data["Questionlist"] = $this->questions_model->question_list_subskill($subskill_id);
		
				if($this->input->post('action')=='submitanswer')	
					{
					 $questionid=$this->input->post('questionid');
					 $answerid=$this->input->post('answerid');
				
					
					$data["ques_dtl"] = $this->main_model->get_detail('manage_question_'.$year_id,'ques_id',$questionid);
					//print_r($data["ques_dtl"]);
					
					$data["correct_ans"] = $this->main_model->get_detail('manage_answer_'.$year_id,'ans_id',$data["ques_dtl"]->ques_rightanswer);
					//print_r($data["correct_ans"]);
					//echo $data["correct_ans"]->ans_name;
										
					if($data["ques_dtl"]->ques_rightanswer==$answerid)
					{
						
					$data['correct']=1;
					$data["Questionlist"] = $this->questions_model->random_question($subskill_id);
					$this->load->view('frontend/private/play',$data);

					}
					else{
			
					$data["yourans"] = $this->main_model->get_detail('manage_answer_'.$year_id,'ans_id',$answerid);	
					$this->load->view('frontend/private/explanation',$data);
					}
					
								
					}
				else{
					$data["Questionlist"] = $this->questions_model->random_question($subskill_id);
					$this->load->view('frontend/private/play',$data);
					}
			
				}
			}
			else{
				
				if($this->session->userdata('user_id')!='' and $this->session->userdata('username')!='')
				{

				$data["SylList1"] = $this->syllabus_model->syllabus_list($year_id,1);
				$data["SylList2"] = $this->syllabus_model->syllabus_list($year_id,2);
				$data["SylList3"] = $this->syllabus_model->syllabus_list($year_id,3);
				$data["SylList4"] = $this->syllabus_model->syllabus_list($year_id,4);

				$this->load->view('frontend/private/kindergarten', $data);
				}
				else{
				$data["SylList1"] = $this->syllabus_model->syllabus_list($year_id,1);
				$data["SylList2"] = $this->syllabus_model->syllabus_list($year_id,2);
				$data["SylList3"] = $this->syllabus_model->syllabus_list($year_id,3);
				$data["SylList4"] = $this->syllabus_model->syllabus_list($year_id,4);

				$this->load->view('frontend/public/kg_wtht_login', $data);	
					
				}

			}
	}
	public function year11($subskill='') 
	{	
		$yearid=$this->session->userdata('loginyear');
			$yeardata=$this->classes_model->classes_details($yearid);
			if($yeardata)
			{
				$data['year_name']=$yeardata[0]->class_name;
				$data['year_slug']=$yeardata[0]->class_slug;
			}
		$year_id=12;
		$data['year_id']=$year_id;
		$this->questions_model->CLASSID = $year_id;
		$data["year_dtl"] = $this->main_model->get_detail('master_class','class_id',$year_id);	
		if($subskill!=""){
			/*---Start Assessment Test -----*/
			if($subskill=="assessment")
			{
				
					/*---get all past year of assessment list----*/
					$pastyear=$this->questions_model->assessment_pastyear($year_id);
						/*echo '<pre>';
						var_dump($pastyear);
						echo '</pre>';
						*/
					$todaydate=date("Y-m-d H:i:s");	
					$userid=$this->session->userdata('user_id');
					$asstime_query=$this->questions_model->assessment_time($year_id,$userid);
					$yourstart=$asstime_query->start_time;
					if($yourstart!="" && $yourstart!=null)
					{
						$seconds = strtotime($todaydate) - strtotime($yourstart);
						$days    = floor($seconds / 86400);
						$hours   = floor(($seconds - ($days * 86400)) / 3600);
						$minutes = floor(($seconds - ($days * 86400) - ($hours * 3600))/60);
						
						if($minutes >30)
						{
							//echo $minutes;
							$exam_status=array(
								'exam_status'=>'pass',							
								'end_time'=>$todaydate,
								);
						
						$updateexam_status=$this->questions_model->Update_Asstterm_status($exam_status,$asstime_query->exam_id);
						$data['timeover']=1;
						}
						else
						{
							$totalminutes=30-$minutes;
							$data['showtimer']='Duration Left: '.$totalminutes;
						}
					}
					else
					{
						$data['showtimer']='Duration: 30';
					}
					
					/*---end of get all past year of assessment list----*/	
					if($this->input->post('action')=='submitanswer')	
					{
						//var_dump($this->input->post());
					 $questionid=$this->input->post('questionid');
					 $answerid=$this->input->post('answerid');
					 $year_id=$this->input->post('year_id');
					 $ass_year_id=$this->input->post('ass_year_id');
				
					
					$data["ques_dtl"] = $this->main_model->get_detail('manage_question_'.$ass_year_id,'ques_id',$questionid);					
					//var_dump($data["ques_dtl"]);
					$data["correct_ans"] = $this->main_model->get_detail('manage_answer_'.$ass_year_id,'ans_id',$data["ques_dtl"]->ques_rightanswer);					
										
					if($data["ques_dtl"]->ques_rightanswer==$answerid)
					{
						
						$data['correct']=1;
						/*----insert user exam list---------*/
						
						$createdate=date("Y-m-d H:i:s");
						$chkrow_exam=$this->questions_model->check_userassessment($userid,$year_id,1);	
						
						if($chkrow_exam->exam_id!="" )
						{
							$exam_id=$chkrow_exam->exam_id;
						}
						else
						{
							$user_exam=array(
									'user_id'=>$userid,
									'year_id'=>$year_id,
									'assyear_id'=>$ass_year_id,													
									'exam_date'=>$createdate,
									'start_time'=>$createdate
									
									);
							$exam_id=$this->questions_model->Save_Userassessment($user_exam);	
						}
						
						if($exam_id!="")
						{
							$uexam_history=array(
								'exam_id'=>$exam_id,
								'user_id'=>$userid,
								'year_id'=>$year_id,
								'assyear_id'=>$ass_year_id,													
								'question_id'=>$questionid,
								'answer_id'=>$answerid,
								'answer_status'=>'true',
								
								);
							$historyexam_id=$this->questions_model->Save_Assessmenthistory($uexam_history);		
						}
						
						/*----End of insert user exam list-------*/
										
					/*----Get user exam question array------*/
					$exam_questermArr=array();
					$exam_questions=$this->questions_model->check_asstesthistory_question($userid,$year_id,1);
					if($exam_questions)
					{
						
						foreach($exam_questions as $examdata)
						{
							array_push($exam_questermArr,$examdata->question_id);
						}
					}
					
					
					/*----End of get user exam question array----*/
					$term_questermArr=array();
					$term_questions=$this->questions_model->assessment_exam($year_id,1);
					if($term_questions)
					{
						
						foreach($term_questions as $tquestion)
						{
							array_push($term_questermArr,$tquestion->ass_question);
						}
						
					}
					$total_exam_question=count($exam_questermArr);
					$total_term_question=count($term_questermArr);
					/*---update term by exam completed status----*/
					if($total_term_question==$total_exam_question)
					{
						$exam_status=array(
								'exam_status'=>'pass',							
								'end_time'=>$createdate,
								);
						
						$updateexam_status=$this->questions_model->Update_Asstterm_status($exam_status,$exam_id);
						$data['completed']=1;
					}
					/*---update term by exam completed status----*/
					$exam_output = array_merge(array_diff($term_questermArr, $exam_questermArr), array_diff($exam_questermArr, $term_questermArr));
					$exam_random=array_rand($exam_output);					
					$randquestion=$exam_output[$exam_random];
					/*---End of check user not applied question list---*/
					$data['Questionlist']=$this->questions_model->asstest_exam_question($year_id,1,$randquestion);
						//$data['Questionlist']=$this->questions_model->term_exam($year_id,1);
						$data['exam_id']=$exam_id;
						$this->load->view('frontend/private/assessmentplay',$data);

					}
					else
					{
			
						/*----insert user exam list---------*/
						$userid=$this->session->userdata('user_id');
						$createdate=date("Y-m-d H:i:s");
						$chkrow_exam=$this->questions_model->check_userassessment($userid,$year_id,1);	
						
						if($chkrow_exam->exam_id!="" )
						{
							$exam_id=$chkrow_exam->exam_id;
						}
						else
						{
							$user_exam=array(
									'user_id'=>$userid,
									'year_id'=>$year_id,
									'assyear_id'=>$ass_year_id,													
									'exam_date'=>$createdate,
									'start_time'=>$createdate
									
									);
							$exam_id=$this->questions_model->Save_Userassessment($user_exam);	
						}
						
						if($exam_id!="")
						{
							$uexam_history=array(
								'exam_id'=>$exam_id,
								'user_id'=>$userid,
								'year_id'=>$year_id,
								'assyear_id'=>$ass_year_id,													
								'question_id'=>$questionid,
								'answer_id'=>$answerid,
								'answer_status'=>'false',
								
								);
							$hexam_id=$this->questions_model->Save_Assessmenthistory($uexam_history);		
						}
						
								/*----Get user exam question array------*/
					$exam_questermArr=array();
					$exam_questions=$this->questions_model->check_asstesthistory_question($userid,$year_id,$term_id);
					if($exam_questions)
					{
						
						foreach($exam_questions as $examdata)
						{
							array_push($exam_questermArr,$examdata->question_id);
						}
					}
					
					
					/*----End of get user exam question array----*/
					$term_questermArr=array();
					$term_questions=$this->questions_model->assessment_exam($year_id,1);
					if($term_questions)
					{
						
						foreach($term_questions as $tquestion)
						{
							array_push($term_questermArr,$tquestion->ass_question);
						}
						
					}
					$total_exam_question=count($exam_questermArr);
					$total_term_question=count($term_questermArr);
					/*---update term by exam completed status----*/
					if($total_term_question==$total_exam_question)
					{
						$exam_status=array(
								'exam_status'=>'pass',
								'end_time'=>$createdate,	
								
								);
						
						$updateexam_status=$this->questions_model->Update_Asstterm_status($exam_status,$exam_id);
						$data['completed']=1;
					}
					/*---update term by exam completed status----*/
						
						/*----End of insert user exam list-------*/
					
						$data["yourans"] = $this->main_model->get_detail('manage_answer_'.$ass_year_id,'ans_id',$answerid);	
						$data['exam_id']=$exam_id;
						$this->load->view('frontend/private/asstestexplanation',$data);
					}
					
								
					}
				else
				{
					$userid=$this->session->userdata('user_id');
					/*---check user not applied question list---*/
					$userexams=$this->questions_model->check_uasstestbyyear($userid,$year_id);
					$data['exam_id']=$userexams->exam_id;
					if($userexams->exam_id!="" && $userexams->exam_status=='pending')
					{	
						$data['assyear_id']=$userexams->assyear_id;
					}
					
					else if($userexams->exam_id!="" && $userexams->exam_status=='pass')
					{	
						$data['assyear_id']=$userexams->assyear_id+1;
					}
				
					else
					{
						$data['assyear_id']=$pastyear[0]->ass_year_id;
						//echo $pastyear[0]->ass_year_id;
					}
					
					/*----Get user exam question array------*/
					$exam_questermArr=array();
					$exam_questions=$this->questions_model->check_asstesthistory_question($userid,$year_id,1);
					if($exam_questions)
					{
						
						foreach($exam_questions as $examdata)
						{
							array_push($exam_questermArr,$examdata->question_id);
						}
					}
					
					
					/*----End of get user exam question array----*/
					$term_questermArr=array();
					$term_questions=$this->questions_model->assessment_exam($year_id,1);
					
					if($term_questions)
					{
						
						foreach($term_questions as $tquestion)
						{
							array_push($term_questermArr,$tquestion->ass_question);
						}
						
					}
					//var_dump($term_questermArr);
					
					$exam_output = array_merge(array_diff($term_questermArr, $exam_questermArr), array_diff($exam_questermArr, $term_questermArr));
					$exam_random=array_rand($exam_output);					
					$randquestion=$exam_output[$exam_random];
					/*---End of check user not applied question list---*/
					if($userexams->exam_status!='pass')
					{
					$data['Questionlist']=$this->questions_model->asstest_exam_question($year_id,1,$randquestion);
					}
					else
					{
						$data['Questionlist']='';
						$data['completed']=1;
					}
					//var_dump($data['Questionlist']);
					$this->load->view('frontend/private/assessmentplay',$data);
				}
			
			}
			/*---End Assessment Test -----*/
			/*---final year exam-----*/
			else if($subskill=="exam")
			{
				
				
					if($this->input->post('action')=='submitanswer')	
					{
					 $questionid=$this->input->post('questionid');
					 $answerid=$this->input->post('answerid');
					 $year_id=$this->input->post('year_id');
					 $term_id=$this->input->post('term_id');
				
					
					$data["ques_dtl"] = $this->main_model->get_detail('manage_question_'.$year_id,'ques_id',$questionid);					
					
					$data["correct_ans"] = $this->main_model->get_detail('manage_answer_'.$year_id,'ans_id',$data["ques_dtl"]->ques_rightanswer);					
										
					if($data["ques_dtl"]->ques_rightanswer==$answerid)
					{
						
						$data['correct']=1;
						/*----insert user exam list---------*/
						$userid=$this->session->userdata('user_id');
						$createdate=date("Y-m-d H:i:s");
						$chkrow_exam=$this->questions_model->check_userexam($userid,$year_id,$term_id);	
						
						if($chkrow_exam->exam_id!="" )
						{
							$exam_id=$chkrow_exam->exam_id;
						}
						else
						{
							$user_exam=array(
									'user_id'=>$userid,
									'year_id'=>$year_id,
									'term_id'=>$term_id,													
									'exam_date'=>$createdate
									
									);
							$exam_id=$this->questions_model->Save_Userexam($user_exam);	
						}
						
						if($exam_id!="")
						{
							$uexam_history=array(
								'exam_id'=>$exam_id,
								'user_id'=>$userid,
								'year_id'=>$year_id,
								'term_id'=>$term_id,													
								'question_id'=>$questionid,
								'answer_id'=>$answerid,
								'answer_status'=>'false',
								
								);
							$historyexam_id=$this->questions_model->Save_Examhistory($uexam_history);		
						}
						
						/*----End of insert user exam list-------*/
						
										/*---check user not applied question list---*/
					$userexams=$this->questions_model->check_uexambyyear($userid,$year_id);
					if($userexams->exam_id!="" && $userexams->exam_status=='pending')
					{	
						$data['term_id']=$userexams->term_id;
					}
					else if($userexams->exam_id!="" && $userexams->exam_status=='pass')
					{	
						$data['term_id']=$userexams->term_id+1;
					}
					else
					{
						$data['term_id']=1;
					}
					
					/*----Get user exam question array------*/
					$exam_questermArr=array();
					$exam_questions=$this->questions_model->check_examhistory_question($userid,$year_id,$data['term_id']);
					if($exam_questions)
					{
						
						foreach($exam_questions as $examdata)
						{
							array_push($exam_questermArr,$examdata->question_id);
						}
					}
					
					
					/*----End of get user exam question array----*/
					$term_questermArr=array();
					$term_questions=$this->questions_model->term_exam($year_id,$data['term_id']);
					if($term_questions)
					{
						
						foreach($term_questions as $tquestion)
						{
							array_push($term_questermArr,$tquestion->question_id);
						}
						
					}
					$total_exam_question=count($exam_questermArr);
					$total_term_question=count($exam_questermArr);
					/*---update term by exam completed status----*/
					if($total_term_question==$total_exam_question)
					{
						$exam_status=array(
								'exam_status'=>'pass',							
								
								);
						
						$updateexam_status=$this->questions_model->Update_Examterm_status($exam_status,$exam_id);
					}
					/*---update term by exam completed status----*/
					$exam_output = array_merge(array_diff($term_questermArr, $exam_questermArr), array_diff($exam_questermArr, $term_questermArr));
					$exam_random=array_rand($exam_output);					
					$randquestion=$exam_output[$exam_random];
					/*---End of check user not applied question list---*/
					$data['Questionlist']=$this->questions_model->term_exam_question($year_id,$data['term_id'],$randquestion);
						//$data['Questionlist']=$this->questions_model->term_exam($year_id,1);
						$this->load->view('frontend/private/examplay',$data);

					}
					else
					{
			
						/*----insert user exam list---------*/
						$userid=$this->session->userdata('user_id');
						$createdate=date("Y-m-d H:i:s");
						$chkrow_exam=$this->questions_model->check_userexam($userid,$year_id,$term_id);	
						
						if($chkrow_exam->exam_id!="" )
						{
							$exam_id=$chkrow_exam->exam_id;
						}
						else
						{
							$user_exam=array(
									'user_id'=>$userid,
									'year_id'=>$year_id,
									'term_id'=>$term_id,													
									'exam_date'=>$createdate
									
									);
							$exam_id=$this->questions_model->Save_Userexam($user_exam);	
						}
						
						if($exam_id!="")
						{
							$uexam_history=array(
								'exam_id'=>$exam_id,
								'user_id'=>$userid,
								'year_id'=>$year_id,
								'term_id'=>$term_id,													
								'question_id'=>$questionid,
								'answer_id'=>$answerid,
								'answer_status'=>'true',
								
								);
							$hexam_id=$this->questions_model->Save_Examhistory($uexam_history);		
						}
						
								/*----Get user exam question array------*/
					$exam_questermArr=array();
					$exam_questions=$this->questions_model->check_examhistory_question($userid,$year_id,$term_id);
					if($exam_questions)
					{
						
						foreach($exam_questions as $examdata)
						{
							array_push($exam_questermArr,$examdata->question_id);
						}
					}
					
					
					/*----End of get user exam question array----*/
					$term_questermArr=array();
					$term_questions=$this->questions_model->term_exam($year_id,$term_id);
					if($term_questions)
					{
						
						foreach($term_questions as $tquestion)
						{
							array_push($term_questermArr,$tquestion->question_id);
						}
						
					}
					$total_exam_question=count($exam_questermArr);
					$total_term_question=count($exam_questermArr);
					/*---update term by exam completed status----*/
					if($total_term_question==$total_exam_question)
					{
						$exam_status=array(
								'exam_status'=>'pass',							
								
								);
						
						$updateexam_status=$this->questions_model->Update_Examterm_status($exam_status,$exam_id);
					}
					/*---update term by exam completed status----*/
						
						/*----End of insert user exam list-------*/
						$data["yourans"] = $this->main_model->get_detail('manage_answer_'.$year_id,'ans_id',$answerid);	
						$this->load->view('frontend/private/explanation',$data);
					}
					
								
					}
				else
				{
					$userid=$this->session->userdata('user_id');
					/*---check user not applied question list---*/
					$userexams=$this->questions_model->check_uexambyyear($userid,$year_id);
					if($userexams->exam_id!="" && $userexams->exam_status=='pending')
					{	
						$data['term_id']=$userexams->term_id;
					}
					else if($userexams->exam_id!="" && $userexams->exam_status=='pass')
					{	
						$data['term_id']=$userexams->term_id+1;
					}
					else
					{
						$data['term_id']=1;
					}
					
					/*----Get user exam question array------*/
					$exam_questermArr=array();
					$exam_questions=$this->questions_model->check_examhistory_question($userid,$year_id,$data['term_id']);
					if($exam_questions)
					{
						
						foreach($exam_questions as $examdata)
						{
							array_push($exam_questermArr,$examdata->question_id);
						}
					}
					
					
					/*----End of get user exam question array----*/
					$term_questermArr=array();
					$term_questions=$this->questions_model->term_exam($year_id,$data['term_id']);
					if($term_questions)
					{
						
						foreach($term_questions as $tquestion)
						{
							array_push($term_questermArr,$tquestion->question_id);
						}
						
					}
					//var_dump($term_questermArr);
					
					$exam_output = array_merge(array_diff($term_questermArr, $exam_questermArr), array_diff($exam_questermArr, $term_questermArr));
					$exam_random=array_rand($exam_output);					
					$randquestion=$exam_output[$exam_random];
					/*---End of check user not applied question list---*/
					$data['Questionlist']=$this->questions_model->term_exam_question($year_id,$data['term_id'],$randquestion);
	
					$this->load->view('frontend/private/examplay',$data);
				}
			}
			/*---end final year exam-----*/
			else
			{	

			$data["skill_dtl"] =$this->main_model->get_skill('master_skill','skill_slug',$subskill,'skill_class',$year_id);		
			  $subskill_id=$data["skill_dtl"]->skill_id;
			 $this->questions_model->CLASSID = $year_id;
				//$data["Questionlist"] = $this->questions_model->question_list_subskill($subskill_id);
		
				if($this->input->post('action')=='submitanswer')	
					{
					 $questionid=$this->input->post('questionid');
					
					 
					$ques_detail= $this->questions_model->question_details($questionid);
					$ques_type=explode(',',$ques_detail->ques_type);
					if(in_array(1,$ques_type)){  
						
					 $answerid=$this->input->post('answerid');
					$answerid=$this->input->post('answerid');
				
					
					$data["ques_dtl"] = $this->main_model->get_detail('manage_question_'.$year_id,'ques_id',$questionid);
					//print_r($data["ques_dtl"]);
					
					$data["correct_ans"] = $this->main_model->get_detail('manage_answer_'.$year_id,'ans_id',$data["ques_dtl"]->ques_rightanswer);
					//print_r($data["correct_ans"]);
					//echo $data["correct_ans"]->ans_name;
										
					if($data["ques_dtl"]->ques_rightanswer==$answerid)
					{
						
					$data['correct']=1;
					$data["Questionlist"] = $this->questions_model->random_question($subskill_id);
					$this->load->view('frontend/private/play',$data);

					}
					else{
			
					$data["yourans"] = $this->main_model->get_detail('manage_answer_'.$year_id,'ans_id',$answerid);	
					$this->load->view('frontend/private/explanation',$data);
					}
					}
					elseif(in_array(26,$ques_type))
					{
						
					$all_answer = $this->main_model->getall('manage_answer_'.$year_id,'ans_quesid',$questionid);
					$correct=true;
					 for($i=0;$i<count($all_answer);$i++){
						 
						$incount=$i+1;
						if($all_answer[$i]->ans_name!=$this->input->post('input'.$incount))
						{ 
							$correct=false;
							
						}
						
					 	
					 }
					 
					 if($correct){
						$data['correct']=1;
						$data["Questionlist"] = $this->questions_model->random_question($subskill_id);
						$this->load->view('frontend/private/play',$data);
					 }
					 else{
						$data["yourans"] = $this->main_model->get_detail('manage_answer_'.$year_id,'ans_id',$answerid);	
						$this->load->view('frontend/private/explanation',$data);
					 }
					 
					}
					 
					
					else{
						$data["yourans"] = $this->main_model->get_detail('manage_answer_'.$year_id,'ans_id',$answerid);	
						$this->load->view('frontend/private/explanation',$data);
						}
						
					}
				else{
					$data["Questionlist"] = $this->questions_model->random_question($subskill_id);
					$this->load->view('frontend/private/play',$data);
					}
			
				}
			}
			else{
				
				if($this->session->userdata('user_id')!='' and $this->session->userdata('username')!='')
				{

				$data["SylList1"] = $this->syllabus_model->syllabus_list($year_id,1);
				$data["SylList2"] = $this->syllabus_model->syllabus_list($year_id,2);
				$data["SylList3"] = $this->syllabus_model->syllabus_list($year_id,3);
				$data["SylList4"] = $this->syllabus_model->syllabus_list($year_id,4);

				$this->load->view('frontend/private/kindergarten', $data);
				}
				else{
				$data["SylList1"] = $this->syllabus_model->syllabus_list($year_id,1);
				$data["SylList2"] = $this->syllabus_model->syllabus_list($year_id,2);
				$data["SylList3"] = $this->syllabus_model->syllabus_list($year_id,3);
				$data["SylList4"] = $this->syllabus_model->syllabus_list($year_id,4);

				$this->load->view('frontend/public/kg_wtht_login', $data);	
					
				}

			}
		
		
	}
	public function year12($subskill='') 
	{	
		$yearid=$this->session->userdata('loginyear');
			$yeardata=$this->classes_model->classes_details($yearid);
			if($yeardata)
			{
				$data['year_name']=$yeardata[0]->class_name;
				$data['year_slug']=$yeardata[0]->class_slug;
			}
		$year_id=13;
		$data['year_id']=$year_id;
		$this->questions_model->CLASSID = $year_id;
		$data["year_dtl"] = $this->main_model->get_detail('master_class','class_id',$year_id);	
		if($subskill!=""){
			/*---Start Assessment Test -----*/
			if($subskill=="assessment")
			{
				
					/*---get all past year of assessment list----*/
					$pastyear=$this->questions_model->assessment_pastyear($year_id);
						/*echo '<pre>';
						var_dump($pastyear);
						echo '</pre>';
						*/
					$todaydate=date("Y-m-d H:i:s");	
					$userid=$this->session->userdata('user_id');
					$asstime_query=$this->questions_model->assessment_time($year_id,$userid);
					$yourstart=$asstime_query->start_time;
					if($yourstart!="" && $yourstart!=null)
					{
						$seconds = strtotime($todaydate) - strtotime($yourstart);
						$days    = floor($seconds / 86400);
						$hours   = floor(($seconds - ($days * 86400)) / 3600);
						$minutes = floor(($seconds - ($days * 86400) - ($hours * 3600))/60);
						
						if($minutes >30)
						{
							//echo $minutes;
							$exam_status=array(
								'exam_status'=>'pass',							
								'end_time'=>$todaydate,
								);
						
						$updateexam_status=$this->questions_model->Update_Asstterm_status($exam_status,$asstime_query->exam_id);
						$data['timeover']=1;
						}
						else
						{
							$totalminutes=30-$minutes;
							$data['showtimer']='Duration Left: '.$totalminutes;
						}
					}
					else
					{
						$data['showtimer']='Duration: 30';
					}
					
					/*---end of get all past year of assessment list----*/	
					if($this->input->post('action')=='submitanswer')	
					{
						//var_dump($this->input->post());
					 $questionid=$this->input->post('questionid');
					 $answerid=$this->input->post('answerid');
					 $year_id=$this->input->post('year_id');
					 $ass_year_id=$this->input->post('ass_year_id');
				
					
					$data["ques_dtl"] = $this->main_model->get_detail('manage_question_'.$ass_year_id,'ques_id',$questionid);					
					//var_dump($data["ques_dtl"]);
					$data["correct_ans"] = $this->main_model->get_detail('manage_answer_'.$ass_year_id,'ans_id',$data["ques_dtl"]->ques_rightanswer);					
										
					if($data["ques_dtl"]->ques_rightanswer==$answerid)
					{
						
						$data['correct']=1;
						/*----insert user exam list---------*/
						
						$createdate=date("Y-m-d H:i:s");
						$chkrow_exam=$this->questions_model->check_userassessment($userid,$year_id,1);	
						
						if($chkrow_exam->exam_id!="" )
						{
							$exam_id=$chkrow_exam->exam_id;
						}
						else
						{
							$user_exam=array(
									'user_id'=>$userid,
									'year_id'=>$year_id,
									'assyear_id'=>$ass_year_id,													
									'exam_date'=>$createdate,
									'start_time'=>$createdate
									
									);
							$exam_id=$this->questions_model->Save_Userassessment($user_exam);	
						}
						
						if($exam_id!="")
						{
							$uexam_history=array(
								'exam_id'=>$exam_id,
								'user_id'=>$userid,
								'year_id'=>$year_id,
								'assyear_id'=>$ass_year_id,													
								'question_id'=>$questionid,
								'answer_id'=>$answerid,
								'answer_status'=>'true',
								
								);
							$historyexam_id=$this->questions_model->Save_Assessmenthistory($uexam_history);		
						}
						
						/*----End of insert user exam list-------*/
										
					/*----Get user exam question array------*/
					$exam_questermArr=array();
					$exam_questions=$this->questions_model->check_asstesthistory_question($userid,$year_id,1);
					if($exam_questions)
					{
						
						foreach($exam_questions as $examdata)
						{
							array_push($exam_questermArr,$examdata->question_id);
						}
					}
					
					
					/*----End of get user exam question array----*/
					$term_questermArr=array();
					$term_questions=$this->questions_model->assessment_exam($year_id,1);
					if($term_questions)
					{
						
						foreach($term_questions as $tquestion)
						{
							array_push($term_questermArr,$tquestion->ass_question);
						}
						
					}
					$total_exam_question=count($exam_questermArr);
					$total_term_question=count($term_questermArr);
					/*---update term by exam completed status----*/
					if($total_term_question==$total_exam_question)
					{
						$exam_status=array(
								'exam_status'=>'pass',							
								'end_time'=>$createdate,
								);
						
						$updateexam_status=$this->questions_model->Update_Asstterm_status($exam_status,$exam_id);
						$data['completed']=1;
					}
					/*---update term by exam completed status----*/
					$exam_output = array_merge(array_diff($term_questermArr, $exam_questermArr), array_diff($exam_questermArr, $term_questermArr));
					$exam_random=array_rand($exam_output);					
					$randquestion=$exam_output[$exam_random];
					/*---End of check user not applied question list---*/
					$data['Questionlist']=$this->questions_model->asstest_exam_question($year_id,1,$randquestion);
						//$data['Questionlist']=$this->questions_model->term_exam($year_id,1);
						$data['exam_id']=$exam_id;
						$this->load->view('frontend/private/assessmentplay',$data);

					}
					else
					{
			
						/*----insert user exam list---------*/
						$userid=$this->session->userdata('user_id');
						$createdate=date("Y-m-d H:i:s");
						$chkrow_exam=$this->questions_model->check_userassessment($userid,$year_id,1);	
						
						if($chkrow_exam->exam_id!="" )
						{
							$exam_id=$chkrow_exam->exam_id;
						}
						else
						{
							$user_exam=array(
									'user_id'=>$userid,
									'year_id'=>$year_id,
									'assyear_id'=>$ass_year_id,													
									'exam_date'=>$createdate,
									'start_time'=>$createdate
									
									);
							$exam_id=$this->questions_model->Save_Userassessment($user_exam);	
						}
						
						if($exam_id!="")
						{
							$uexam_history=array(
								'exam_id'=>$exam_id,
								'user_id'=>$userid,
								'year_id'=>$year_id,
								'assyear_id'=>$ass_year_id,													
								'question_id'=>$questionid,
								'answer_id'=>$answerid,
								'answer_status'=>'false',
								
								);
							$hexam_id=$this->questions_model->Save_Assessmenthistory($uexam_history);		
						}
						
								/*----Get user exam question array------*/
					$exam_questermArr=array();
					$exam_questions=$this->questions_model->check_asstesthistory_question($userid,$year_id,$term_id);
					if($exam_questions)
					{
						
						foreach($exam_questions as $examdata)
						{
							array_push($exam_questermArr,$examdata->question_id);
						}
					}
					
					
					/*----End of get user exam question array----*/
					$term_questermArr=array();
					$term_questions=$this->questions_model->assessment_exam($year_id,1);
					if($term_questions)
					{
						
						foreach($term_questions as $tquestion)
						{
							array_push($term_questermArr,$tquestion->ass_question);
						}
						
					}
					$total_exam_question=count($exam_questermArr);
					$total_term_question=count($term_questermArr);
					/*---update term by exam completed status----*/
					if($total_term_question==$total_exam_question)
					{
						$exam_status=array(
								'exam_status'=>'pass',
								'end_time'=>$createdate,	
								
								);
						
						$updateexam_status=$this->questions_model->Update_Asstterm_status($exam_status,$exam_id);
						$data['completed']=1;
					}
					/*---update term by exam completed status----*/
						
						/*----End of insert user exam list-------*/
					
						$data["yourans"] = $this->main_model->get_detail('manage_answer_'.$ass_year_id,'ans_id',$answerid);	
						$data['exam_id']=$exam_id;
						$this->load->view('frontend/private/asstestexplanation',$data);
					}
					
								
					}
				else
				{
					$userid=$this->session->userdata('user_id');
					/*---check user not applied question list---*/
					$userexams=$this->questions_model->check_uasstestbyyear($userid,$year_id);
					$data['exam_id']=$userexams->exam_id;
					if($userexams->exam_id!="" && $userexams->exam_status=='pending')
					{	
						$data['assyear_id']=$userexams->assyear_id;
					}
					
					else if($userexams->exam_id!="" && $userexams->exam_status=='pass')
					{	
						$data['assyear_id']=$userexams->assyear_id+1;
					}
				
					else
					{
						$data['assyear_id']=$pastyear[0]->ass_year_id;
						//echo $pastyear[0]->ass_year_id;
					}
					
					/*----Get user exam question array------*/
					$exam_questermArr=array();
					$exam_questions=$this->questions_model->check_asstesthistory_question($userid,$year_id,1);
					if($exam_questions)
					{
						
						foreach($exam_questions as $examdata)
						{
							array_push($exam_questermArr,$examdata->question_id);
						}
					}
					
					
					/*----End of get user exam question array----*/
					$term_questermArr=array();
					$term_questions=$this->questions_model->assessment_exam($year_id,1);
					
					if($term_questions)
					{
						
						foreach($term_questions as $tquestion)
						{
							array_push($term_questermArr,$tquestion->ass_question);
						}
						
					}
					//var_dump($term_questermArr);
					
					$exam_output = array_merge(array_diff($term_questermArr, $exam_questermArr), array_diff($exam_questermArr, $term_questermArr));
					$exam_random=array_rand($exam_output);					
					$randquestion=$exam_output[$exam_random];
					/*---End of check user not applied question list---*/
					if($userexams->exam_status!='pass')
					{
					$data['Questionlist']=$this->questions_model->asstest_exam_question($year_id,1,$randquestion);
					}
					else
					{
						$data['Questionlist']='';
						$data['completed']=1;
					}
					//var_dump($data['Questionlist']);
					$this->load->view('frontend/private/assessmentplay',$data);
				}
			
			}
			/*---End Assessment Test -----*/
			/*---final year exam-----*/
			else if($subskill=="exam")
			{
				
				
					if($this->input->post('action')=='submitanswer')	
					{
					 $questionid=$this->input->post('questionid');
					 $answerid=$this->input->post('answerid');
					 $year_id=$this->input->post('year_id');
					 $term_id=$this->input->post('term_id');
				
					
					$data["ques_dtl"] = $this->main_model->get_detail('manage_question_'.$year_id,'ques_id',$questionid);					
					
					$data["correct_ans"] = $this->main_model->get_detail('manage_answer_'.$year_id,'ans_id',$data["ques_dtl"]->ques_rightanswer);					
										
					if($data["ques_dtl"]->ques_rightanswer==$answerid)
					{
						
						$data['correct']=1;
						/*----insert user exam list---------*/
						$userid=$this->session->userdata('user_id');
						$createdate=date("Y-m-d H:i:s");
						$chkrow_exam=$this->questions_model->check_userexam($userid,$year_id,$term_id);	
						
						if($chkrow_exam->exam_id!="" )
						{
							$exam_id=$chkrow_exam->exam_id;
						}
						else
						{
							$user_exam=array(
									'user_id'=>$userid,
									'year_id'=>$year_id,
									'term_id'=>$term_id,													
									'exam_date'=>$createdate
									
									);
							$exam_id=$this->questions_model->Save_Userexam($user_exam);	
						}
						
						if($exam_id!="")
						{
							$uexam_history=array(
								'exam_id'=>$exam_id,
								'user_id'=>$userid,
								'year_id'=>$year_id,
								'term_id'=>$term_id,													
								'question_id'=>$questionid,
								'answer_id'=>$answerid,
								'answer_status'=>'false',
								
								);
							$historyexam_id=$this->questions_model->Save_Examhistory($uexam_history);		
						}
						
						/*----End of insert user exam list-------*/
						
										/*---check user not applied question list---*/
					$userexams=$this->questions_model->check_uexambyyear($userid,$year_id);
					if($userexams->exam_id!="" && $userexams->exam_status=='pending')
					{	
						$data['term_id']=$userexams->term_id;
					}
					else if($userexams->exam_id!="" && $userexams->exam_status=='pass')
					{	
						$data['term_id']=$userexams->term_id+1;
					}
					else
					{
						$data['term_id']=1;
					}
					
					/*----Get user exam question array------*/
					$exam_questermArr=array();
					$exam_questions=$this->questions_model->check_examhistory_question($userid,$year_id,$data['term_id']);
					if($exam_questions)
					{
						
						foreach($exam_questions as $examdata)
						{
							array_push($exam_questermArr,$examdata->question_id);
						}
					}
					
					
					/*----End of get user exam question array----*/
					$term_questermArr=array();
					$term_questions=$this->questions_model->term_exam($year_id,$data['term_id']);
					if($term_questions)
					{
						
						foreach($term_questions as $tquestion)
						{
							array_push($term_questermArr,$tquestion->question_id);
						}
						
					}
					$total_exam_question=count($exam_questermArr);
					$total_term_question=count($exam_questermArr);
					/*---update term by exam completed status----*/
					if($total_term_question==$total_exam_question)
					{
						$exam_status=array(
								'exam_status'=>'pass',							
								
								);
						
						$updateexam_status=$this->questions_model->Update_Examterm_status($exam_status,$exam_id);
					}
					/*---update term by exam completed status----*/
					$exam_output = array_merge(array_diff($term_questermArr, $exam_questermArr), array_diff($exam_questermArr, $term_questermArr));
					$exam_random=array_rand($exam_output);					
					$randquestion=$exam_output[$exam_random];
					/*---End of check user not applied question list---*/
					$data['Questionlist']=$this->questions_model->term_exam_question($year_id,$data['term_id'],$randquestion);
						//$data['Questionlist']=$this->questions_model->term_exam($year_id,1);
						$this->load->view('frontend/private/examplay',$data);

					}
					else
					{
			
						/*----insert user exam list---------*/
						$userid=$this->session->userdata('user_id');
						$createdate=date("Y-m-d H:i:s");
						$chkrow_exam=$this->questions_model->check_userexam($userid,$year_id,$term_id);	
						
						if($chkrow_exam->exam_id!="" )
						{
							$exam_id=$chkrow_exam->exam_id;
						}
						else
						{
							$user_exam=array(
									'user_id'=>$userid,
									'year_id'=>$year_id,
									'term_id'=>$term_id,													
									'exam_date'=>$createdate
									
									);
							$exam_id=$this->questions_model->Save_Userexam($user_exam);	
						}
						
						if($exam_id!="")
						{
							$uexam_history=array(
								'exam_id'=>$exam_id,
								'user_id'=>$userid,
								'year_id'=>$year_id,
								'term_id'=>$term_id,													
								'question_id'=>$questionid,
								'answer_id'=>$answerid,
								'answer_status'=>'true',
								
								);
							$hexam_id=$this->questions_model->Save_Examhistory($uexam_history);		
						}
						
								/*----Get user exam question array------*/
					$exam_questermArr=array();
					$exam_questions=$this->questions_model->check_examhistory_question($userid,$year_id,$term_id);
					if($exam_questions)
					{
						
						foreach($exam_questions as $examdata)
						{
							array_push($exam_questermArr,$examdata->question_id);
						}
					}
					
					
					/*----End of get user exam question array----*/
					$term_questermArr=array();
					$term_questions=$this->questions_model->term_exam($year_id,$term_id);
					if($term_questions)
					{
						
						foreach($term_questions as $tquestion)
						{
							array_push($term_questermArr,$tquestion->question_id);
						}
						
					}
					$total_exam_question=count($exam_questermArr);
					$total_term_question=count($exam_questermArr);
					/*---update term by exam completed status----*/
					if($total_term_question==$total_exam_question)
					{
						$exam_status=array(
								'exam_status'=>'pass',							
								
								);
						
						$updateexam_status=$this->questions_model->Update_Examterm_status($exam_status,$exam_id);
					}
					/*---update term by exam completed status----*/
						
						/*----End of insert user exam list-------*/
						$data["yourans"] = $this->main_model->get_detail('manage_answer_'.$year_id,'ans_id',$answerid);	
						$this->load->view('frontend/private/explanation',$data);
					}
					
								
					}
				else
				{
					$userid=$this->session->userdata('user_id');
					/*---check user not applied question list---*/
					$userexams=$this->questions_model->check_uexambyyear($userid,$year_id);
					if($userexams->exam_id!="" && $userexams->exam_status=='pending')
					{	
						$data['term_id']=$userexams->term_id;
					}
					else if($userexams->exam_id!="" && $userexams->exam_status=='pass')
					{	
						$data['term_id']=$userexams->term_id+1;
					}
					else
					{
						$data['term_id']=1;
					}
					
					/*----Get user exam question array------*/
					$exam_questermArr=array();
					$exam_questions=$this->questions_model->check_examhistory_question($userid,$year_id,$data['term_id']);
					if($exam_questions)
					{
						
						foreach($exam_questions as $examdata)
						{
							array_push($exam_questermArr,$examdata->question_id);
						}
					}
					
					
					/*----End of get user exam question array----*/
					$term_questermArr=array();
					$term_questions=$this->questions_model->term_exam($year_id,$data['term_id']);
					if($term_questions)
					{
						
						foreach($term_questions as $tquestion)
						{
							array_push($term_questermArr,$tquestion->question_id);
						}
						
					}
					//var_dump($term_questermArr);
					
					$exam_output = array_merge(array_diff($term_questermArr, $exam_questermArr), array_diff($exam_questermArr, $term_questermArr));
					$exam_random=array_rand($exam_output);					
					$randquestion=$exam_output[$exam_random];
					/*---End of check user not applied question list---*/
					$data['Questionlist']=$this->questions_model->term_exam_question($year_id,$data['term_id'],$randquestion);
	
					$this->load->view('frontend/private/examplay',$data);
				}
			}
			/*---end final year exam-----*/
			else
			{	

			$data["skill_dtl"] =$this->main_model->get_skill('master_skill','skill_slug',$subskill,'skill_class',$year_id);		
			  $subskill_id=$data["skill_dtl"]->skill_id;
			$this->questions_model->CLASSID = $year_id;
				//$data["Questionlist"] = $this->questions_model->question_list_subskill($subskill_id);
		
				if($this->input->post('action')=='submitanswer')	
					{
					 $questionid=$this->input->post('questionid');
					 $answerid=$this->input->post('answerid');
				
					
					$data["ques_dtl"] = $this->main_model->get_detail('manage_question_'.$year_id,'ques_id',$questionid);
					//print_r($data["ques_dtl"]);
					
					$data["correct_ans"] = $this->main_model->get_detail('manage_answer_'.$year_id,'ans_id',$data["ques_dtl"]->ques_rightanswer);
					//print_r($data["correct_ans"]);
					//echo $data["correct_ans"]->ans_name;
										
					if($data["ques_dtl"]->ques_rightanswer==$answerid)
					{
						
					$data['correct']=1;
					$data["Questionlist"] = $this->questions_model->random_question($subskill_id);
					$this->load->view('frontend/private/play',$data);

					}
					else{
			
					$data["yourans"] = $this->main_model->get_detail('manage_answer_'.$year_id,'ans_id',$answerid);	
					$this->load->view('frontend/private/explanation',$data);
					}
					
								
					}
				else{
					$data["Questionlist"] = $this->questions_model->random_question($subskill_id);
					$this->load->view('frontend/private/play',$data);
					}
			
				}
			}
			else{
				
				if($this->session->userdata('user_id')!='' and $this->session->userdata('username')!='')
				{

				$data["SylList1"] = $this->syllabus_model->syllabus_list($year_id,1);
				$data["SylList2"] = $this->syllabus_model->syllabus_list($year_id,2);
				$data["SylList3"] = $this->syllabus_model->syllabus_list($year_id,3);
				$data["SylList4"] = $this->syllabus_model->syllabus_list($year_id,4);

				$this->load->view('frontend/private/kindergarten', $data);
				}
				else{
				$data["SylList1"] = $this->syllabus_model->syllabus_list($year_id,1);
				$data["SylList2"] = $this->syllabus_model->syllabus_list($year_id,2);
				$data["SylList3"] = $this->syllabus_model->syllabus_list($year_id,3);
				$data["SylList4"] = $this->syllabus_model->syllabus_list($year_id,4);

				$this->load->view('frontend/public/kg_wtht_login', $data);	
					
				}

			}
		
		
	}
	public function year13($subskill='') 
	{
			
		$yearid=$this->session->userdata('loginyear');
			$yeardata=$this->classes_model->classes_details($yearid);
			if($yeardata)
			{
				$data['year_name']=$yeardata[0]->class_name;
				$data['year_slug']=$yeardata[0]->class_slug;
			}
		$year_id=14;
		$data['year_id']=$year_id;
		$this->questions_model->CLASSID = $year_id;
		$data["year_dtl"] = $this->main_model->get_detail('master_class','class_id',$year_id);	
		if($subskill!=""){
			/*---Start Assessment Test -----*/
			if($subskill=="assessment")
			{
				
					/*---get all past year of assessment list----*/
					$pastyear=$this->questions_model->assessment_pastyear($year_id);
						/*echo '<pre>';
						var_dump($pastyear);
						echo '</pre>';
						*/
					$todaydate=date("Y-m-d H:i:s");	
					$userid=$this->session->userdata('user_id');
					$asstime_query=$this->questions_model->assessment_time($year_id,$userid);
					$yourstart=$asstime_query->start_time;
					if($yourstart!="" && $yourstart!=null)
					{
						$seconds = strtotime($todaydate) - strtotime($yourstart);
						$days    = floor($seconds / 86400);
						$hours   = floor(($seconds - ($days * 86400)) / 3600);
						$minutes = floor(($seconds - ($days * 86400) - ($hours * 3600))/60);
						
						if($minutes >30)
						{
							//echo $minutes;
							$exam_status=array(
								'exam_status'=>'pass',							
								'end_time'=>$todaydate,
								);
						
						$updateexam_status=$this->questions_model->Update_Asstterm_status($exam_status,$asstime_query->exam_id);
						$data['timeover']=1;
						}
						else
						{
							$totalminutes=30-$minutes;
							$data['showtimer']='Duration Left: '.$totalminutes;
						}
					}
					else
					{
						$data['showtimer']='Duration: 30';
					}
					
					/*---end of get all past year of assessment list----*/	
					if($this->input->post('action')=='submitanswer')	
					{
						//var_dump($this->input->post());
					 $questionid=$this->input->post('questionid');
					 $answerid=$this->input->post('answerid');
					 $year_id=$this->input->post('year_id');
					 $ass_year_id=$this->input->post('ass_year_id');
				
					
					$data["ques_dtl"] = $this->main_model->get_detail('manage_question_'.$ass_year_id,'ques_id',$questionid);					
					//var_dump($data["ques_dtl"]);
					$data["correct_ans"] = $this->main_model->get_detail('manage_answer_'.$ass_year_id,'ans_id',$data["ques_dtl"]->ques_rightanswer);					
										
					if($data["ques_dtl"]->ques_rightanswer==$answerid)
					{
						
						$data['correct']=1;
						/*----insert user exam list---------*/
						
						$createdate=date("Y-m-d H:i:s");
						$chkrow_exam=$this->questions_model->check_userassessment($userid,$year_id,1);	
						
						if($chkrow_exam->exam_id!="" )
						{
							$exam_id=$chkrow_exam->exam_id;
						}
						else
						{
							$user_exam=array(
									'user_id'=>$userid,
									'year_id'=>$year_id,
									'assyear_id'=>$ass_year_id,													
									'exam_date'=>$createdate,
									'start_time'=>$createdate
									
									);
							$exam_id=$this->questions_model->Save_Userassessment($user_exam);	
						}
						
						if($exam_id!="")
						{
							$uexam_history=array(
								'exam_id'=>$exam_id,
								'user_id'=>$userid,
								'year_id'=>$year_id,
								'assyear_id'=>$ass_year_id,													
								'question_id'=>$questionid,
								'answer_id'=>$answerid,
								'answer_status'=>'true',
								
								);
							$historyexam_id=$this->questions_model->Save_Assessmenthistory($uexam_history);		
						}
						
						/*----End of insert user exam list-------*/
										
					/*----Get user exam question array------*/
					$exam_questermArr=array();
					$exam_questions=$this->questions_model->check_asstesthistory_question($userid,$year_id,1);
					if($exam_questions)
					{
						
						foreach($exam_questions as $examdata)
						{
							array_push($exam_questermArr,$examdata->question_id);
						}
					}
					
					
					/*----End of get user exam question array----*/
					$term_questermArr=array();
					$term_questions=$this->questions_model->assessment_exam($year_id,1);
					if($term_questions)
					{
						
						foreach($term_questions as $tquestion)
						{
							array_push($term_questermArr,$tquestion->ass_question);
						}
						
					}
					$total_exam_question=count($exam_questermArr);
					$total_term_question=count($term_questermArr);
					/*---update term by exam completed status----*/
					if($total_term_question==$total_exam_question)
					{
						$exam_status=array(
								'exam_status'=>'pass',							
								'end_time'=>$createdate,
								);
						
						$updateexam_status=$this->questions_model->Update_Asstterm_status($exam_status,$exam_id);
						$data['completed']=1;
					}
					/*---update term by exam completed status----*/
					$exam_output = array_merge(array_diff($term_questermArr, $exam_questermArr), array_diff($exam_questermArr, $term_questermArr));
					$exam_random=array_rand($exam_output);					
					$randquestion=$exam_output[$exam_random];
					/*---End of check user not applied question list---*/
					$data['Questionlist']=$this->questions_model->asstest_exam_question($year_id,1,$randquestion);
						//$data['Questionlist']=$this->questions_model->term_exam($year_id,1);
						$data['exam_id']=$exam_id;
						$this->load->view('frontend/private/assessmentplay',$data);

					}
					else
					{
			
						/*----insert user exam list---------*/
						$userid=$this->session->userdata('user_id');
						$createdate=date("Y-m-d H:i:s");
						$chkrow_exam=$this->questions_model->check_userassessment($userid,$year_id,1);	
						
						if($chkrow_exam->exam_id!="" )
						{
							$exam_id=$chkrow_exam->exam_id;
						}
						else
						{
							$user_exam=array(
									'user_id'=>$userid,
									'year_id'=>$year_id,
									'assyear_id'=>$ass_year_id,													
									'exam_date'=>$createdate,
									'start_time'=>$createdate
									
									);
							$exam_id=$this->questions_model->Save_Userassessment($user_exam);	
						}
						
						if($exam_id!="")
						{
							$uexam_history=array(
								'exam_id'=>$exam_id,
								'user_id'=>$userid,
								'year_id'=>$year_id,
								'assyear_id'=>$ass_year_id,													
								'question_id'=>$questionid,
								'answer_id'=>$answerid,
								'answer_status'=>'false',
								
								);
							$hexam_id=$this->questions_model->Save_Assessmenthistory($uexam_history);		
						}
						
								/*----Get user exam question array------*/
					$exam_questermArr=array();
					$exam_questions=$this->questions_model->check_asstesthistory_question($userid,$year_id,$term_id);
					if($exam_questions)
					{
						
						foreach($exam_questions as $examdata)
						{
							array_push($exam_questermArr,$examdata->question_id);
						}
					}
					
					
					/*----End of get user exam question array----*/
					$term_questermArr=array();
					$term_questions=$this->questions_model->assessment_exam($year_id,1);
					if($term_questions)
					{
						
						foreach($term_questions as $tquestion)
						{
							array_push($term_questermArr,$tquestion->ass_question);
						}
						
					}
					$total_exam_question=count($exam_questermArr);
					$total_term_question=count($term_questermArr);
					/*---update term by exam completed status----*/
					if($total_term_question==$total_exam_question)
					{
						$exam_status=array(
								'exam_status'=>'pass',
								'end_time'=>$createdate,	
								
								);
						
						$updateexam_status=$this->questions_model->Update_Asstterm_status($exam_status,$exam_id);
						$data['completed']=1;
					}
					/*---update term by exam completed status----*/
						
						/*----End of insert user exam list-------*/
					
						$data["yourans"] = $this->main_model->get_detail('manage_answer_'.$ass_year_id,'ans_id',$answerid);	
						$data['exam_id']=$exam_id;
						$this->load->view('frontend/private/asstestexplanation',$data);
					}
					
								
					}
				else
				{
					$userid=$this->session->userdata('user_id');
					/*---check user not applied question list---*/
					$userexams=$this->questions_model->check_uasstestbyyear($userid,$year_id);
					$data['exam_id']=$userexams->exam_id;
					if($userexams->exam_id!="" && $userexams->exam_status=='pending')
					{	
						$data['assyear_id']=$userexams->assyear_id;
					}
					
					else if($userexams->exam_id!="" && $userexams->exam_status=='pass')
					{	
						$data['assyear_id']=$userexams->assyear_id+1;
					}
				
					else
					{
						$data['assyear_id']=$pastyear[0]->ass_year_id;
						//echo $pastyear[0]->ass_year_id;
					}
					
					/*----Get user exam question array------*/
					$exam_questermArr=array();
					$exam_questions=$this->questions_model->check_asstesthistory_question($userid,$year_id,1);
					if($exam_questions)
					{
						
						foreach($exam_questions as $examdata)
						{
							array_push($exam_questermArr,$examdata->question_id);
						}
					}
					
					
					/*----End of get user exam question array----*/
					$term_questermArr=array();
					$term_questions=$this->questions_model->assessment_exam($year_id,1);
					
					if($term_questions)
					{
						
						foreach($term_questions as $tquestion)
						{
							array_push($term_questermArr,$tquestion->ass_question);
						}
						
					}
					//var_dump($term_questermArr);
					
					$exam_output = array_merge(array_diff($term_questermArr, $exam_questermArr), array_diff($exam_questermArr, $term_questermArr));
					$exam_random=array_rand($exam_output);					
					$randquestion=$exam_output[$exam_random];
					/*---End of check user not applied question list---*/
					if($userexams->exam_status!='pass')
					{
					$data['Questionlist']=$this->questions_model->asstest_exam_question($year_id,1,$randquestion);
					}
					else
					{
						$data['Questionlist']='';
						$data['completed']=1;
					}
					//var_dump($data['Questionlist']);
					$this->load->view('frontend/private/assessmentplay',$data);
				}
			
			}
			/*---End Assessment Test -----*/
			/*---final year exam-----*/
			else if($subskill=="exam")
			{
				
				
					if($this->input->post('action')=='submitanswer')	
					{
					 $questionid=$this->input->post('questionid');
					 $answerid=$this->input->post('answerid');
					 $year_id=$this->input->post('year_id');
					 $term_id=$this->input->post('term_id');
				
					
					$data["ques_dtl"] = $this->main_model->get_detail('manage_question_'.$year_id,'ques_id',$questionid);					
					
					$data["correct_ans"] = $this->main_model->get_detail('manage_answer_'.$year_id,'ans_id',$data["ques_dtl"]->ques_rightanswer);					
										
					if($data["ques_dtl"]->ques_rightanswer==$answerid)
					{
						
						$data['correct']=1;
						/*----insert user exam list---------*/
						$userid=$this->session->userdata('user_id');
						$createdate=date("Y-m-d H:i:s");
						$chkrow_exam=$this->questions_model->check_userexam($userid,$year_id,$term_id);	
						
						if($chkrow_exam->exam_id!="" )
						{
							$exam_id=$chkrow_exam->exam_id;
						}
						else
						{
							$user_exam=array(
									'user_id'=>$userid,
									'year_id'=>$year_id,
									'term_id'=>$term_id,													
									'exam_date'=>$createdate
									
									);
							$exam_id=$this->questions_model->Save_Userexam($user_exam);	
						}
						
						if($exam_id!="")
						{
							$uexam_history=array(
								'exam_id'=>$exam_id,
								'user_id'=>$userid,
								'year_id'=>$year_id,
								'term_id'=>$term_id,													
								'question_id'=>$questionid,
								'answer_id'=>$answerid,
								'answer_status'=>'false',
								
								);
							$historyexam_id=$this->questions_model->Save_Examhistory($uexam_history);		
						}
						
						/*----End of insert user exam list-------*/
						
										/*---check user not applied question list---*/
					$userexams=$this->questions_model->check_uexambyyear($userid,$year_id);
					if($userexams->exam_id!="" && $userexams->exam_status=='pending')
					{	
						$data['term_id']=$userexams->term_id;
					}
					else if($userexams->exam_id!="" && $userexams->exam_status=='pass')
					{	
						$data['term_id']=$userexams->term_id+1;
					}
					else
					{
						$data['term_id']=1;
					}
					
					/*----Get user exam question array------*/
					$exam_questermArr=array();
					$exam_questions=$this->questions_model->check_examhistory_question($userid,$year_id,$data['term_id']);
					if($exam_questions)
					{
						
						foreach($exam_questions as $examdata)
						{
							array_push($exam_questermArr,$examdata->question_id);
						}
					}
					
					
					/*----End of get user exam question array----*/
					$term_questermArr=array();
					$term_questions=$this->questions_model->term_exam($year_id,$data['term_id']);
					if($term_questions)
					{
						
						foreach($term_questions as $tquestion)
						{
							array_push($term_questermArr,$tquestion->question_id);
						}
						
					}
					$total_exam_question=count($exam_questermArr);
					$total_term_question=count($exam_questermArr);
					/*---update term by exam completed status----*/
					if($total_term_question==$total_exam_question)
					{
						$exam_status=array(
								'exam_status'=>'pass',							
								
								);
						
						$updateexam_status=$this->questions_model->Update_Examterm_status($exam_status,$exam_id);
					}
					/*---update term by exam completed status----*/
					$exam_output = array_merge(array_diff($term_questermArr, $exam_questermArr), array_diff($exam_questermArr, $term_questermArr));
					$exam_random=array_rand($exam_output);					
					$randquestion=$exam_output[$exam_random];
					/*---End of check user not applied question list---*/
					$data['Questionlist']=$this->questions_model->term_exam_question($year_id,$data['term_id'],$randquestion);
						//$data['Questionlist']=$this->questions_model->term_exam($year_id,1);
						$this->load->view('frontend/private/examplay',$data);

					}
					else
					{
			
						/*----insert user exam list---------*/
						$userid=$this->session->userdata('user_id');
						$createdate=date("Y-m-d H:i:s");
						$chkrow_exam=$this->questions_model->check_userexam($userid,$year_id,$term_id);	
						
						if($chkrow_exam->exam_id!="" )
						{
							$exam_id=$chkrow_exam->exam_id;
						}
						else
						{
							$user_exam=array(
									'user_id'=>$userid,
									'year_id'=>$year_id,
									'term_id'=>$term_id,													
									'exam_date'=>$createdate
									
									);
							$exam_id=$this->questions_model->Save_Userexam($user_exam);	
						}
						
						if($exam_id!="")
						{
							$uexam_history=array(
								'exam_id'=>$exam_id,
								'user_id'=>$userid,
								'year_id'=>$year_id,
								'term_id'=>$term_id,													
								'question_id'=>$questionid,
								'answer_id'=>$answerid,
								'answer_status'=>'true',
								
								);
							$hexam_id=$this->questions_model->Save_Examhistory($uexam_history);		
						}
						
								/*----Get user exam question array------*/
					$exam_questermArr=array();
					$exam_questions=$this->questions_model->check_examhistory_question($userid,$year_id,$term_id);
					if($exam_questions)
					{
						
						foreach($exam_questions as $examdata)
						{
							array_push($exam_questermArr,$examdata->question_id);
						}
					}
					
					
					/*----End of get user exam question array----*/
					$term_questermArr=array();
					$term_questions=$this->questions_model->term_exam($year_id,$term_id);
					if($term_questions)
					{
						
						foreach($term_questions as $tquestion)
						{
							array_push($term_questermArr,$tquestion->question_id);
						}
						
					}
					$total_exam_question=count($exam_questermArr);
					$total_term_question=count($exam_questermArr);
					/*---update term by exam completed status----*/
					if($total_term_question==$total_exam_question)
					{
						$exam_status=array(
								'exam_status'=>'pass',							
								
								);
						
						$updateexam_status=$this->questions_model->Update_Examterm_status($exam_status,$exam_id);
					}
					/*---update term by exam completed status----*/
						
						/*----End of insert user exam list-------*/
						$data["yourans"] = $this->main_model->get_detail('manage_answer_'.$year_id,'ans_id',$answerid);	
						$this->load->view('frontend/private/explanation',$data);
					}
					
								
					}
				else
				{
					$userid=$this->session->userdata('user_id');
					/*---check user not applied question list---*/
					$userexams=$this->questions_model->check_uexambyyear($userid,$year_id);
					if($userexams->exam_id!="" && $userexams->exam_status=='pending')
					{	
						$data['term_id']=$userexams->term_id;
					}
					else if($userexams->exam_id!="" && $userexams->exam_status=='pass')
					{	
						$data['term_id']=$userexams->term_id+1;
					}
					else
					{
						$data['term_id']=1;
					}
					
					/*----Get user exam question array------*/
					$exam_questermArr=array();
					$exam_questions=$this->questions_model->check_examhistory_question($userid,$year_id,$data['term_id']);
					if($exam_questions)
					{
						
						foreach($exam_questions as $examdata)
						{
							array_push($exam_questermArr,$examdata->question_id);
						}
					}
					
					
					/*----End of get user exam question array----*/
					$term_questermArr=array();
					$term_questions=$this->questions_model->term_exam($year_id,$data['term_id']);
					if($term_questions)
					{
						
						foreach($term_questions as $tquestion)
						{
							array_push($term_questermArr,$tquestion->question_id);
						}
						
					}
					//var_dump($term_questermArr);
					
					$exam_output = array_merge(array_diff($term_questermArr, $exam_questermArr), array_diff($exam_questermArr, $term_questermArr));
					$exam_random=array_rand($exam_output);					
					$randquestion=$exam_output[$exam_random];
					/*---End of check user not applied question list---*/
					$data['Questionlist']=$this->questions_model->term_exam_question($year_id,$data['term_id'],$randquestion);
	
					$this->load->view('frontend/private/examplay',$data);
				}
			}
			/*---end final year exam-----*/
			else
			{	

			$data["skill_dtl"] =$this->main_model->get_skill('master_skill','skill_slug',$subskill,'skill_class',$year_id);		
			  $subskill_id=$data["skill_dtl"]->skill_id;
			$this->questions_model->CLASSID = $year_id;
				//$data["Questionlist"] = $this->questions_model->question_list_subskill($subskill_id);
		
				if($this->input->post('action')=='submitanswer')	
					{
					 $questionid=$this->input->post('questionid');
					 $answerid=$this->input->post('answerid');
				
					
					$data["ques_dtl"] = $this->main_model->get_detail('manage_question_'.$year_id,'ques_id',$questionid);
					//print_r($data["ques_dtl"]);
					
					$data["correct_ans"] = $this->main_model->get_detail('manage_answer_'.$year_id,'ans_id',$data["ques_dtl"]->ques_rightanswer);
					//print_r($data["correct_ans"]);
					//echo $data["correct_ans"]->ans_name;
										
					if($data["ques_dtl"]->ques_rightanswer==$answerid)
					{
						
					$data['correct']=1;
					$data["Questionlist"] = $this->questions_model->random_question($subskill_id);
					$this->load->view('frontend/private/play',$data);

					}
					else{
			
					$data["yourans"] = $this->main_model->get_detail('manage_answer_'.$year_id,'ans_id',$answerid);	
					$this->load->view('frontend/private/explanation',$data);
					}
					
								
					}
				else{
					$data["Questionlist"] = $this->questions_model->random_question($subskill_id);
					$this->load->view('frontend/private/play',$data);
					}
			
				}
			}
			else{
				
				if($this->session->userdata('user_id')!='' and $this->session->userdata('username')!='')
				{

				$data["SylList1"] = $this->syllabus_model->syllabus_list($year_id,1);
				$data["SylList2"] = $this->syllabus_model->syllabus_list($year_id,2);
				$data["SylList3"] = $this->syllabus_model->syllabus_list($year_id,3);
				$data["SylList4"] = $this->syllabus_model->syllabus_list($year_id,4);

				$this->load->view('frontend/private/kindergarten', $data);
				}
				else{
				$data["SylList1"] = $this->syllabus_model->syllabus_list($year_id,1);
				$data["SylList2"] = $this->syllabus_model->syllabus_list($year_id,2);
				$data["SylList3"] = $this->syllabus_model->syllabus_list($year_id,3);
				$data["SylList4"] = $this->syllabus_model->syllabus_list($year_id,4);

				$this->load->view('frontend/public/kg_wtht_login', $data);	
					
				}

			}
		
	}
	public function auckland() 
	{		
		$this->load->view('frontend/public/auckland');
	
	}
	public function tauranga() 
	{		
		$this->load->view('frontend/public/tauranga');
	
	}
	public function ourteam() 
	{		
		$this->load->view('frontend/public/our-team');
	
	}
	public function email($to,$from,$sub,$msg,$file=null)
    {
        $this->load->library('email');
        $htmlContent =$msg;
        $config['mailtype'] = 'html';
        $this->email->initialize($config);
        $this->email->to($to);
        $this->email->from($from,$from);
        $this->email->subject($sub);
        $this->email->message($htmlContent);
        $this->email->attach($file);
        $this->email->send();
    }
	public function contactus() 
	{	
		$this->load->model('Contact_model');

		$this->form_validation->set_rules('fname', 'Please fill detail in first name', 'trim|required');
		$this->form_validation->set_rules('lname', 'Please fill detail in Last name', 'trim|required');
		$this->form_validation->set_rules('email', 'Please fill detail in Email', 'trim|required|valid_email');
		$this->form_validation->set_rules('msg', 'Please fill detail in Message box', 'required');
		if($this->form_validation->run() == false)
		{
			$this->load->view('frontend/public/contact-us');
		}
		else
		{
			$insert=$this->Contact_model->insert_data();
			if($insert)
			{
				$this->session->set_flashdata('msg','Your requst submitted');
				$to='testing80@iwesh.com';
				$from='testing80@iwesh.com';
				$sub="Contact us requst";
				$data=array('Name' => $this->input->post('fname').' '.$this->input->post('lname'),
							'Email'  => $this->input->post('email'),
							'Message'  => $this->input->post('msg'),
 							);
				$msg='';
				$msg.='<table>';
				
				foreach ($data as $key => $value) 
				{
					$msg.='<tr><td>'.$key.'</td><td>'.$value.'</td></tr>';

				}
				$msg.='</table>';
				
				$this->email($to,$from,$sub,$msg);
				redirect($_SERVER['http_FERERER']);

			}else{
				$this->session->set_flashdata('msg','Your requst not submitted');
				redirect($_SERVER['http_FERERER']);
			}

		}
	
	}
	public function noticeboard() 
	{		
		$this->load->view('frontend/private/notice-board');
	
	}
	public function helpcenter() 
	{		
		$this->load->view('frontend/public/help-center');
	
	}
	public function faqs() 
	{		
		$this->load->view('frontend/public/faqs');
	
	}
	public function termconditions() 
	{		
		$this->load->view('frontend/public/term-conditions');
	
	}
	public function privacypolicy() 
	{		
		$this->load->view('frontend/public/privacy-policy');
	
	}
	public function disclaimer() 
	{		
		$this->load->view('frontend/public/disclaimer');
	
	}
	public function testimonial() 
	{		
		$this->load->view('frontend/public/testimonial');
	
	}


	public function doupload($path,$type,$filename)
     {
         
        $config = array(
        'upload_path' => $path,
        'allowed_types' => $type,
        'overwrite' => TRUE,
        'max_size' => "2048000", 
        'max_height' => "768",
        'max_width' => "1024"
        );
        $this->load->library('upload', $config);
        if(!$this->upload->do_upload($filename))
        { 
            $data['imageError'] =  $this->upload->display_errors();
            $data=array('success'=>false,'$msg'=>$data['imageError']);

        }
        else
        {
            $imageDetailArray = $this->upload->data();
            $image =  $imageDetailArray['file_name'];
            $data=array('success'=>true,'$msg'=>'file upload successfully' ,'file_name'=>$image);
        }
        return $data;
     }	
	public function becomeaninstructor() 
	{

		$this->load->model('Contact_model');
		$this->form_validation->set_rules('fname', 'Please fill detail in first name', 'trim|required');
		$this->form_validation->set_rules('lname', 'Please fill detail in Last name', 'trim|required');
		$this->form_validation->set_rules('email', 'Please fill detail in Email', 'trim|required|valid_email');
		$this->form_validation->set_rules('exp_yr', 'Please select Total Work Experience year', 'required');
		$this->form_validation->set_rules('exp_mn', 'Please select Total Work Experience year', 'required');
		$this->form_validation->set_rules('job_title', 'Please select job title', 'required');
		$this->form_validation->set_rules('phone', 'Please fill detail in phone input box', 'required');
		$this->form_validation->set_rules('state', 'Please select job state', 'required');
		$this->form_validation->set_rules('city', 'Please select job state', 'required');
		if($this->form_validation->run() == false)
		{
			$this->load->view('frontend/public/become-an-instructor');
		}
		else
		{	
			$path="assets/uploads/resume/";
			$type='pdf|docs|docs';
		    $upload=$this->doupload($path,$type,'resume');
		    if($upload['success'])
		    {
		    	$insert=$this->Contact_model->becomeaninstructor_insert($upload['file_name']);
		    	if($insert)
		    	{
		    		$to='testing80@iwesh.com';
					$from='testing80@iwesh.com';
					$sub="Become an Instructor request";
					$data=array('Name' 			=> 	$this->input->post('fname').' '.$this->input->post('lname'),
								'Email'  		=> 	$this->input->post('email'),
								'Experience'	=> 	$this->input->post('exp_yr').' Year and '. $this->input->post('exp_mn').' Month ',
								'Job title'		=> 	$this->input->post('job_title'),
								'Email'  		=> 	$this->input->post('email'),
								'Phone'  		=> 	$this->input->post('phone'),
								'State' 		=>	$this->input->post('state'),
								'city' 			=> 	$this->input->post('city'),
								'resume'  		=>	'<a href="'.base_url('/'.$path.$upload['file_name']).'">View Resume</a>',
	 							);
					$msg='';
					$msg.='<table>';
					foreach ($data as $key => $value) 
					{
						$msg.='<tr><td>'.$key.'</td><td>'.$value.'</td></tr>';
					}
					$msg.='</table>';
					$this->email($to,$from,$sub,$msg,$file=base_url('/'.$path.$upload['file_name']));
		    		$this->session->set_flashdata('msg','resume upload successfully');
					redirect($_SERVER['HTTP_REFERER']);
		    	}
		    	else
		    	{

			    	$this->session->set_flashdata('msg','Please Try after some time');
			    	redirect($_SERVER['HTTP_REFERER']);	
		    	}
		    }
		    else
		    {
		    	$this->session->set_flashdata('msg','Please Try after some time');
		    	redirect($_SERVER['HTTP_REFERER']);
		    }

		}
	
	}
	public function becomeanaffiliate() 
	{		
		$this->load->view('frontend/public/become-an-affiliate');
	
	}
	
	public function single_post($event) 
	{	
		$data['event']=$event;
		$this->load->view('frontend/public/single-post',$data);
	
	}
	
	public function random_password() 
	{
		$alphabet = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890';
		$password = array(); 
		$alpha_length = strlen($alphabet) - 1; 
		for ($i = 0; $i < 8; $i++) 
		{
			$n = rand(0, $alpha_length);
			$password[] = $alphabet[$n];
		}
		return implode($password); 
	}
	

	public function registered() 
	{	
		$data['regthank']='';
		$this->load->view('frontend/public/thanks-signup',$data);
	
	}		
	
	
	public function play($subskill_id) 
	{
		$year_id=1;
		$this->questions_model->CLASSID = $year_id;
		//$data["Questionlist"] = $this->questions_model->question_list_subskill($subskill_id);
		
		if($this->input->post('action')=='submitanswer')	
				{
					 $questionid=$this->input->post('questionid');
					 $answerid=$this->input->post('answerid');
				
					
					$data["ques_dtl"] = $this->main_model->get_detail('manage_question_'.$year_id,'ques_id',$questionid);
					//print_r($data["ques_dtl"]);
					
					$data["correct_ans"] = $this->main_model->get_detail('manage_answer_'.$year_id,'ans_id',$data["ques_dtl"]->ques_rightanswer);
					//print_r($data["correct_ans"]);
					//echo $data["correct_ans"]->ans_name;
										
					if($data["ques_dtl"]->ques_rightanswer==$answerid)
					{
						
					$data['correct']=1;
					$data["Questionlist"] = $this->questions_model->random_question($subskill_id);
					$this->load->view('frontend/private/play',$data);

					}
					else{
			
					$data["yourans"] = $this->main_model->get_detail('manage_answer_'.$year_id,'ans_id',$answerid);	
					$this->load->view('frontend/private/explanation',$data);
					}
					
								
				}
				else{
					$data["Questionlist"] = $this->questions_model->random_question($subskill_id);
					$this->load->view('frontend/private/play',$data);
				}
	
	}

	public function mynoticeboard() 
	{		
		if($this->session->userdata('username')!='')
		{		
			$user_id=$this->session->userdata('user_id');
			$yearid=$this->session->userdata('loginyear');
			$yeardata=$this->classes_model->classes_details($yearid);
			if($yeardata)
			{
				$data['year_name']=$yeardata[0]->class_name;
				$data['year_slug']=$yeardata[0]->class_slug;
			}
			$data['aatcount']=$this->exam_model->checkuser_aat_status($yearid,$user_id);
			$this->load->view('frontend/private/my-notice-board',$data);
		}
		else
		{
			redirect(base_url().'login');
		}
	
	}

	
	public function changepassword() 
	{		
		
		$this->form_validation->set_rules('password', 'Password', 'required');
		$this->form_validation->set_rules('cpassword', 'Confirm Password', 'required');
		
		if($this->form_validation->run())
		{
			$password = $this->input->post('password');
			$cpassword = $this->input->post('cpassword');
			
			if ($password==$cpassword) 
			{
			
			
				$user_data=array(							
							'password'=>md5($password)						
							
							);	
	            $userid=$this->User_model->Save_Password($user_data,$this->session->userdata('user_id'));
				$data1['fullname']=$this->session->userdata('fullname');
			
				$data1['password']=$password;
				
				$this->load->library('email');
				$config = array (
				'mailtype' => 'html',
				'charset' => 'utf-8',
				'priority' => '1'
				);
				$this->email->initialize($config);
				
				$senderemail=$this->session->userdata('email');
			
				$body = $this->load->view('emails/changepassword',$data1,TRUE);
				$this->email->from('info@maths.com', 'maths');
				$this->email->to($senderemail);
				$this->email->subject('Your Maths account password reset');
				$this->email->message($body);
				$this->email->send();				
				
				$data['success']='Your password has been changed successfully';
			
				
								
			} 
			else
			{
				$data['error']='Sorry your password did not match. <br/>Please try again.';
				
			}
		}
		else
		{
			$data['error']='';
		}
		
		
		$this->load->view('frontend/private/changepassword',$data);
	
	}
		
	
	public function thisweekclassroomexercise() 
	{		
		if($this->session->userdata('username')!='')
		{		
			$yearid=$this->session->userdata('loginyear');
			$data['year_id']=$yearid;
			$yeardata=$this->classes_model->classes_details($yearid);
			if($yeardata)
			{
				$data['year_name']=$yeardata[0]->class_name;
				$data['year_slug']=$yeardata[0]->class_slug;
				$year_date=$yeardata[0]->year_date;
				if($year_date!="")
				{
					$yeararr=explode("-",$year_date);
					$dt1 = $yeararr[1].'/'.$yeararr[2].'/'.$yeararr[0];
					$dt2 = date('m/d/Y');
					$data['yearstart']=$dt1;
					$data['currentdate']=$dt2;
					$totalweek=$this->week_between_two_dates($dt1, $dt2);
					$data['week_id']=$totalweek;
					if($totalweek <=10)
					{
						$termid=1;
						$data['term_id']=1;
						$data['yeargoal']=$this->weeks_model->weeks_bytermyear($totalweek,$termid,$yearid);
					
					}
				}
			}
			$this->load->view('frontend/private/this-week-classroom-exercise',$data);
		}
		else
		{
			redirect(base_url().'login');
		}
	
	}
	
	public function week_between_two_dates($date1, $date2)
	{
		
		
		$first = DateTime::createFromFormat('m/d/Y', $date1);
		$second = DateTime::createFromFormat('m/d/Y', $date2);
		if($date1 > $date2) return week_between_two_dates($date2, $date1);
		return floor($first->diff($second)->days/7);
	}

	public function homeworkexercise() 
	{		
		if($this->session->userdata('username')!='')
		{		
			$yearid=$this->session->userdata('loginyear');
			$data['year_id']=$yearid;
			$yeardata=$this->classes_model->classes_details($yearid);
			if($yeardata)
			{
				$data['year_name']=$yeardata[0]->class_name;
				$data['year_slug']=$yeardata[0]->class_slug;
				$year_date=$yeardata[0]->year_date;
				if($year_date!="")
				{
					$yeararr=explode("-",$year_date);
					$dt1 = $yeararr[1].'/'.$yeararr[2].'/'.$yeararr[0];
					$dt2 = date('m/d/Y');
					$data['yearstart']=$dt1;
					$data['currentdate']=$dt2;
					$totalweek=$this->week_between_two_dates($dt1, $dt2);
					$data['week_id']=$totalweek;
					if($totalweek <=10)
					{
						$termid=1;
						$data['term_id']=1;
						$data['yeargoal']=$this->weeks_model->weeks_bytermyear($totalweek,$termid,$yearid);
						if($totalweek > 1)
						{
							$pretweek=$totalweek-1;
						$data['yeargoal2']=$this->weeks_model->weeks_bytermyear($pretweek,$termid,$yearid);
						}
					
					}
				}
			}
			$this->load->view('frontend/private/homework-exercise',$data);
		}
		else
		{
			redirect(base_url().'login');
		}
	
	}
	
	public function studentexamgrade() 
	{		
		if($this->session->userdata('username')!='')
		{		
			$yearid=$this->session->userdata('loginyear');
			$data['year_id']=$yearid;
			$yeardata=$this->classes_model->classes_details($yearid);
			if($yeardata)
			{
				$data['year_name']=$yeardata[0]->class_name;
				$data['year_slug']=$yeardata[0]->class_slug;
				
				$data['examterm_list']=$this->students_model->student_exambyterm($yearid);
				
			}
			$this->load->view('frontend/private/student-exam-grade',$data);
		}
		else
		{
			redirect(base_url().'login');
		}
	
	}

	public function studentexamsheet($exam_id='') 
	{		
		if($this->session->userdata('username')!='')
		{		
			
			if($exam_id)
			{
				
				
				$data['exam_details']=$this->students_model->exam_details($exam_id);
				
			}
			$this->load->view('frontend/private/student-exam-sheet',$data);
		}
		else
		{
			redirect(base_url().'login');
		}
	
	}

	public function membership_plans() 
	{		
		if($this->session->userdata('username')!='')
		{		
			
				
			
			$config["per_page"] = 100;	
			$page = ($_REQUEST['page']) ? $_REQUEST['page'] : 0;	
				
			$data["planlist"] = $this->plan_model->plan_list($config["per_page"],$page);				
			
			$this->load->view('frontend/private/membership-plan',$data);
		}
		else
		{
			redirect(base_url().'login');
		}
	
	}

	public function paynow($id="") 
	{		
		if($this->session->userdata('username')!='')
		{		
			
			/*-----send order to paypal-----*/
			if($id!="" && $id!=null)
			{
				$plandata=$this->plan_model->plan_details($id);
				if($plandata)
				{
						$userid=$this->session->userdata('user_id');
						$planinfo=$plandata[0];
						$data["plandetail"]=$plandata[0];
						$year=$this->uri->segment(3);
						$query_chkpro=$this->db->query("select * from student_promoted  where user_id='".$userid."' and pay_status='pending' order by  pid desc ");
						$num_chkpro=$query_chkpro->num_rows();
						if($num_chkpro > 0)
						{
							$yearchk=$query_chkpro->row();
							$centerid=$yearchk->center_id;
						}
						else
						{
							$query_user=$this->db->query("select center_id from user_details  where user_id='".$userid."'  ");
							$yearchk=$query_user->row();
							$centerid=$yearchk->center_id;
						}
						$createdate=date("Y-m-d H:i:s");
						$ord_data=array(
							'userid'=>$userid,
							'year_id'=>$year,
							'center_id'=>$centerid,
							'plan_id'=>$id,
							'amount'=>$planinfo->plan_price,
							'order_status'=>'inactive',
							'pay_status'=>'pending',
							'order_week'=>$planinfo->plan_week,
							'order_date'=>$createdate,
							);
						$orderid=$this->order_model->Save_Order($ord_data);	
						$data["orderid"]=$orderid;	
					
					
				}
			}
			else
			{
				redirect(base_url().'membership-plan');
			}
			/*-----end of order send to paypal----*/
			
			
				
				
			//$data["planlist"] = $this->plan_model->plan_list($config["per_page"],$page);				
			
			$this->load->view('frontend/private/paynow',$data);
		}
		else
		{
			redirect(base_url().'login');
		}
	
	}
	
	public function paythank() 
	{		
		if($this->session->userdata('username')!='')
		{		
			
			
			$this->load->view('frontend/private/pay-thank',$data);
		}
		else
		{
			redirect(base_url().'login');
		}
	
	}
	public function paycancel() 
	{		
		if($this->session->userdata('username')!='')
		{		
			
			
			$this->load->view('frontend/private/pay-cancel',$data);
		}
		else
		{
			redirect(base_url().'login');
		}
	
	}
	
	public function paynotified() 
	{		
		define("DEBUG", 1);
		// Set to 0 once you're ready to go live
		define("USE_SANDBOX", 1);
		define("LOG_FILE", "ipn.log");
		// Read POST data
		// reading posted data directly from $_POST causes serialization
		// issues with array data in POST. Reading raw POST data from input stream instead.
		$raw_post_data = file_get_contents('php://input');
		$raw_post_array = explode('&', $raw_post_data);
		$myPost = array();
		foreach ($raw_post_array as $keyval) {
			$keyval = explode ('=', $keyval);
			if (count($keyval) == 2)
				$myPost[$keyval[0]] = urldecode($keyval[1]);
		}
		// read the post from PayPal system and add 'cmd'
		$req = 'cmd=_notify-validate';
		if(function_exists('get_magic_quotes_gpc')) {
			$get_magic_quotes_exists = true;
		}
		foreach ($myPost as $key => $value) {
			if($get_magic_quotes_exists == true && get_magic_quotes_gpc() == 1) {
				$value = urlencode(stripslashes($value));
			} else {
				$value = urlencode($value);
			}
			$req .= "&$key=$value";
		}
		// Post IPN data back to PayPal to validate the IPN data is genuine
		// Without this step anyone can fake IPN data
		if(USE_SANDBOX == true) {
			$paypal_url = "https://www.sandbox.paypal.com/cgi-bin/webscr";
		} else {
			$paypal_url = "https://www.paypal.com/cgi-bin/webscr";
		}
		$ch = curl_init($paypal_url);
		if ($ch == FALSE) {
			return FALSE;
		}
		curl_setopt($ch, CURLOPT_HTTP_VERSION, CURL_HTTP_VERSION_1_1);
		curl_setopt($ch, CURLOPT_POST, 1);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER,1);
		curl_setopt($ch, CURLOPT_POSTFIELDS, $req);
		curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 1);
		curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 2);
		curl_setopt($ch, CURLOPT_FORBID_REUSE, 1);
		if(DEBUG == true) {
			curl_setopt($ch, CURLOPT_HEADER, 1);
			curl_setopt($ch, CURLINFO_HEADER_OUT, 1);
		}
		// CONFIG: Optional proxy configuration
		//curl_setopt($ch, CURLOPT_PROXY, $proxy);
		//curl_setopt($ch, CURLOPT_HTTPPROXYTUNNEL, 1);
		// Set TCP timeout to 30 seconds
		curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 30);
		curl_setopt($ch, CURLOPT_HTTPHEADER, array('Connection: Close'));
		// CONFIG: Please download 'cacert.pem' from "http://curl.haxx.se/docs/caextract.html" and set the directory path
		// of the certificate as shown below. Ensure the file is readable by the webserver.
		// This is mandatory for some environments.
		//$cert = __DIR__ . "./cacert.pem";
		//curl_setopt($ch, CURLOPT_CAINFO, $cert);
		$res = curl_exec($ch);
		if (curl_errno($ch) != 0) // cURL error
			{
			if(DEBUG == true) {	
				error_log(date('[Y-m-d H:i e] '). "Can't connect to PayPal to validate IPN message: " . curl_error($ch) . PHP_EOL, 3, LOG_FILE);
			}
			curl_close($ch);
			exit;
		} else {
				// Log the entire HTTP response if debug is switched on.
				if(DEBUG == true) {
					error_log(date('[Y-m-d H:i e] '). "HTTP request of validation request:". curl_getinfo($ch, CURLINFO_HEADER_OUT) ." for IPN payload: $req" . PHP_EOL, 3, LOG_FILE);
					error_log(date('[Y-m-d H:i e] '). "HTTP response of validation request: $res" . PHP_EOL, 3, LOG_FILE);
				}
				curl_close($ch);
		}
		// Inspect IPN validation result and act accordingly
		// Split response headers and payload, a better way for strcmp
		$tokens = explode("\r\n\r\n", trim($res));
		$res = trim(end($tokens));
		if (strcmp ($res, "VERIFIED") == 0) 
		{
			// assign posted variables to local variables
			$item_name = $this->input->post('item_name');
			$item_number = $this->input->post('item_number');
			$payment_status = $this->input->post('payment_status');
			$payment_amount = $this->input->post('mc_gross');
			$payment_currency = $this->input->post('mc_currency');
			$txn_id = $this->input->post('txn_id');
			$receiver_email = $this->input->post('receiver_email');
			$payer_email = $this->input->post('payer_email');
			
		
			// check whether the payment_status is Completed
			$isPaymentCompleted = false;
			if($payment_status == "Completed") {
				$isPaymentCompleted = true;
			}
			// check that txn_id has not been previously processed
			/*$isUniqueTxnId = false; 
			$result = $db->selectQuery("SELECT * FROM payments WHERE txn_id = '$txn_id'");
			if(empty($result)) {
				$isUniqueTxnId = true;
			}
*/			
			// check that receiver_email is your PayPal email
			// check that payment_amount/payment_currency are correct
			if($isPaymentCompleted && $payment_currency == "USD") {
				$createdate=date("Y-m-d H:i:s");
				$ord_data=array(
							
							'order_status'=>'active',
							'pay_status'=>'confirm',
							'trans_id'=>$txn_id,
							'pay_date'=>$createdate
							);
						$orderid=$this->order_model->Update_Order($ord_data,$item_number);
						
	/*----promoted user class status---*/	
	$query_ordinfo=$this->db->query("select userid from orders  where orderid='".$item_number."' ");	
	$orderinfo=$query_ordinfo->row();
	if($orderinfo->userid !="")
	{	
		$query_chkpro=$this->db->query("select * from student_promoted  where user_id='".$orderinfo->userid."' and pay_status='pending' order by  pid desc ");
		$num_chkpro=$query_chkpro->num_rows();
		if($num_chkpro > 0)
		{
					$prot_row=$query_chkpro->row();
						$prod_data=array(						
								'pay_status'=>'confirm',							
								'promote_date'=>$createdate
								);
							$orderid=$this->exam_model->Update_Promoted_Assessment($prod_data,$orderinfo->userid);
							
						/*---update user current year----*/ 
						$promotedyear=array(						
								'year_id'=>$prot_row->promote_year,
								'center_id'=>$prot_row->center_id	
								
								);
						$updateuseryear=$this->exam_model->promoted_student_year($promotedyear,$orderinfo->userid);	
						/*---end of update user current year----*/
						/*----update center stock-------*/
						 $centerdata=$this->center_model->centerseat_byyear($prot_row->center_id,$prot_row->promote_year);	
			
					 if($centerdata)
					 {
						  if($centerdata->sell_seat < $centerdata->aviable_seat)
						  {
							$leftseat=$centerdata->sell_seat+1;
							$centerup=$this->db->query("update  master_center_seats set sell_seat='".$leftseat."'  where center_id='".$prot_row->center_id."' and year_id='".$prot_row->promote_year."'");
						  }
					 }
						/*-----end of update center stock---*/
			
		}
		
	}
	/*----promoted user class status---*/						
			}
			// process payment and mark item as paid.
			
			
			if(DEBUG == true) {
				error_log(date('[Y-m-d H:i e] '). "Verified IPN: $req ". PHP_EOL, 3, LOG_FILE);
			}
			
		} else if (strcmp ($res, "INVALID") == 0) {
			// log for manual investigation
			// Add business logic here which deals with invalid IPN messages
			if(DEBUG == true) {
				error_log(date('[Y-m-d H:i e] '). "Invalid IPN: $req" . PHP_EOL, 3, LOG_FILE);
			}
		}
	}
	
	public function orderhistory() 
	{		
		if($this->session->userdata('username')!='')
		{		
			
			$userid=$this->session->userdata('user_id');
			$user_year=$this->User_model->user_year($userid);
			$year_id=$user_year->year_id;			
			$yeardata=$this->classes_model->classes_details($year_id);
			if($yeardata)
			{
				$data['year_name']=$yeardata[0]->class_name;
				$data['year_slug']=$yeardata[0]->class_slug;
			}
			$config["base_url"] =  BASE_URL_ADMIN. "order-history";
			$config["total_rows"] = $this->order_model->orderlist_currentyear_count($year_id,$userid);
			$config["per_page"] = 20;
			
			$this->pagination->initialize($config);

			$page = ($_REQUEST['page']) ? $_REQUEST['page'] : 0;
			$data["orderlist"] = $this->order_model->orderlist_currentyear($config["per_page"], $page,$year_id,$userid);
			$data["links"] = $this->pagination->create_links();
			
			$this->load->view('frontend/private/order-history',$data);
		}
		else
		{
			redirect(base_url().'login');
		}
	
	}
	
	public function assessment_report() 
	{		
		if($this->session->userdata('username')!='')
		{		
			
		    $userid=$this->session->userdata('user_id');
			$user_year=$this->User_model->user_year($userid);
			$query_chkpro=$this->db->query("select * from student_promoted  where user_id='".$userid."' and pay_status='confirm' order by  pid desc ");
			$year_chkpro=$query_chkpro->row();	
			$yearid=$this->session->userdata('loginyear');			
			//$yeardata=$this->classes_model->classes_details($year_chkpro->reg_year);
			$yeardata=$this->classes_model->classes_details($yearid);
			if($yeardata)
			{
				$data['year_name']=$yeardata[0]->class_name;
				$data['year_slug']=$yeardata[0]->class_slug;
			}
			
			$data["asstestlist"] = $this->exam_model->asstest_by_user($userid, $year_chkpro->reg_year);
			
			
			$this->load->view('frontend/private/assessment-report',$data);
		}
		else
		{
			redirect(base_url().'login');
		}
	
	}
/*-----Book Center class----*/
	public function bookcenterclass($id="") 
	{		
		if($this->session->userdata('username')!='')
		{		
			
			/*-----send order to paypal-----*/
			$userid=$this->session->userdata('user_id');
			if($id!="" && $id!=null)
			{
				
				
				$userarray=$this->User_model->user_details($userid);
				$data['userinfo']=$userarray[0];
				$data['elg_yearname']=$this->classes_model->GetClassName($id);
				$data['center_list']=$this->center_model->center_dropdown();
				$data['elg_yearid']=$id;
				
				if($this->input->post('reg_center')!='' && $this->input->post('reg_center')!=null)
				{
					
					$first_name=$this->input->post('first_name');
					$last_name=$this->input->post('last_name');
					$email=$this->input->post('email');
					$phone=$this->input->post('phone');
					$dob=$this->input->post('dob');
					if($dob!="")
					{
						$dobarray=explode('/',$dob);
						$dob=$dobarray[2].'-'.$dobarray[0].'-'.$dobarray[1];
					}						
					$address=$this->input->post('address');
					
					
					$studentinfo=array(
								'first_name'=>$first_name,
								'last_name'=>$last_name,
								'email'=>$email,
								'phone'=>$phone,
								'dob'=>$dob,
								'address'=>$address
								
								);
					$updateusers=$this->User_model->update_staff($userid,$studentinfo);	
					
					$center_id=$this->input->post('reg_center');
					$elg_yearid=$this->input->post('elg_yearid');
					$ord_data=array(
								'center_id'=>$center_id
								);
					$orderid=$this->exam_model->Update_Promoted_Assessment($ord_data,$userid);	
					//redirect(base_url().'membership-plan');
					redirect(base_url().'booking-parents/'.$id);
				}
			}
			
			else
			{
				redirect(base_url().'assessment');
			}
			/*-----end of order send to paypal----*/
			
			
				
				
			//$data["planlist"] = $this->plan_model->plan_list($config["per_page"],$page);				
			
			$this->load->view('frontend/private/book-center-class',$data);
		}
		else
		{
			redirect(base_url().'login');
		}
	
	}
/*----End of booking center class-----*/
	public function our_centers() 
	{		
		
			
		$this->load->view('frontend/public/our-centers',$data);
		
	
	}
	
/*-----Book Center class----*/
	public function bookingparents($id="") 
	{		
		if($this->session->userdata('username')!='')
		{		
			
			/*-----send order to paypal-----*/
			$userid=$this->session->userdata('user_id');
			if($id!="" && $id!=null)
			{
				
				
				$userarray=$this->User_model->user_details($userid);
				$data['userinfo']=$userarray[0];
				$data['elg_yearname']=$this->classes_model->GetClassName($id);
				$data['center_list']=$this->center_model->center_dropdown();
				$data['elg_yearid']=$id;
				
				if($this->input->post('mother_name')!='' && $this->input->post('mother_name')!=null)
				{
					
					$mother_name=$this->input->post('mother_name');
					$father_name=$this->input->post('father_name');
					$email=$this->input->post('email');
					$phone=$this->input->post('phone');											
					$occupation=$this->input->post('occupation');
					
					
					$parentinfo=array(
								'student_id'=>$userid,
								'mother_name'=>$mother_name,
								'father_name'=>$father_name,
								'email'=>$email,
								'phone'=>$phone,								
								'occupation'=>$occupation
								
								);
					$updateusers=$this->exam_model->Save_Parents($parentinfo,$userid);	
					
					
					redirect(base_url().'membership-plan');
				}
			}
			
			else
			{
				//redirect(base_url().'assessment');
			}
			/*-----end of order send to paypal----*/
						
			
			$this->load->view('frontend/private/booking-parents',$data);
		}
		else
		{
			redirect(base_url().'login');
		}
	
	}

public function pre_view($year='',$queId='')
	{
		


		$yearid=$this->session->userdata('loginyear');
			$yeardata=$this->classes_model->classes_details($yearid);
			if($yeardata)
			{
				$data['year_name']=$yeardata[0]->class_name;
				$data['year_slug']=$yeardata[0]->class_slug;
			}
		$year_id=$year;
		$data['year_id']=$year_id;
		$this->questions_model->CLASSID = $year_id;
		$data["year_dtl"] = $this->main_model->get_detail('master_class','class_id',$year_id);	
		if($queId!=""){
			/*---Start Assessment Test -----*/
			
	
			$this->questions_model->CLASSID = $year_id;
				//$data["Questionlist"] = $this->questions_model->question_list_subskill($subskill_id);
		
				if($this->input->post('action')=='submitanswer')	
					{
					 $questionid=$this->input->post('questionid');
					
					 
					$ques_detail= $this->questions_model->question_details($questionid);
					$ques_type=explode(',',$ques_detail->ques_type);
					if(in_array(1,$ques_type)){  
						
					 $answerid=$this->input->post('answerid');
					$answerid=$this->input->post('answerid');
				
					
					$data["ques_dtl"] = $this->main_model->get_detail('manage_question_'.$year_id,'ques_id',$questionid);
					//print_r($data["ques_dtl"]);
					
					$data["correct_ans"] = $this->main_model->get_detail('manage_answer_'.$year_id,'ans_id',$data["ques_dtl"]->ques_rightanswer);
					//print_r($data["correct_ans"]);
					//echo $data["correct_ans"]->ans_name;
										
					if($data["ques_dtl"]->ques_rightanswer==$answerid)
					{
						
					$data['correct']=1;
					$data["Questionlist"] = $this->questions_model->random_question($subskill_id);
					$this->load->view('frontend/private/play',$data);

					}
					else{
			
					$data["yourans"] = $this->main_model->get_detail('manage_answer_'.$year_id,'ans_id',$answerid);	
					$this->load->view('frontend/private/explanation',$data);
					}
					}
					elseif(in_array(26,$ques_type))
					{
						
					$all_answer = $this->main_model->getall('manage_answer_'.$year_id,'ans_quesid',$questionid);
					$correct=true;
					 for($i=0;$i<count($all_answer);$i++){
						 
						$incount=$i+1;
						if($all_answer[$i]->ans_name!=$this->input->post('input'.$incount))
						{ 
							$correct=false;
							
						}
						
					 	
					 }
					 
					 if($correct){
						$data['correct']=1;
						$data["Questionlist"] = $this->questions_model->random_question($subskill_id);
						$this->load->view('frontend/private/play',$data);
					 }
					 else{
						$data["yourans"] = $this->main_model->get_detail('manage_answer_'.$year_id,'ans_id',$answerid);	
						$this->load->view('frontend/private/explanation',$data);
					 }
					 
					}
					 
					
					else{
						$data["yourans"] = $this->main_model->get_detail('manage_answer_'.$year_id,'ans_id',$answerid);	
						$this->load->view('frontend/private/explanation',$data);
						}
						
					}
				else{
					$data["Questionlist"] = $this->main_model->preview('manage_question_'.$year_id,'ques_id',$queId);
					
					$this->load->view('frontend/public/preview',$data);
					}
			
				
			}
			else{
				
				if($this->session->userdata('user_id')!='' and $this->session->userdata('username')!='')
				{

				$data["SylList1"] = $this->syllabus_model->syllabus_list($year_id,1);
				$data["SylList2"] = $this->syllabus_model->syllabus_list($year_id,2);
				$data["SylList3"] = $this->syllabus_model->syllabus_list($year_id,3);
				$data["SylList4"] = $this->syllabus_model->syllabus_list($year_id,4);

				$this->load->view('frontend/private/kindergarten', $data);
				}
				else{
				$data["SylList1"] = $this->syllabus_model->syllabus_list($year_id,1);
				$data["SylList2"] = $this->syllabus_model->syllabus_list($year_id,2);
				$data["SylList3"] = $this->syllabus_model->syllabus_list($year_id,3);
				$data["SylList4"] = $this->syllabus_model->syllabus_list($year_id,4);

				$this->load->view('frontend/public/preview', $data);	
					
				

			}
		

	}
}


/*----End of booking center class-----*/
	
	
}
