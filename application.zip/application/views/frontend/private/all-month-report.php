<?php include('header.php'); ?>

<!-- Page Content inner -->
<section id="title-inner" class="bgcolor-text">
<canvas id="demo-canvas"></canvas>
<div class="container">
<div class="text-tit">
<h1>
<span>All Month Report</span>
</h1>
</div>

</div>
</section>

 
 <section class="about_content content-text analysis-report space-75">
 <div class="container">
 <div class="row">
 
<?php
function getMonthName($monthNumber)
{
    return date("F", mktime(0, 0, 0, $monthNumber, 1));
}


$sqlcmonth=$this->db->query("select MONTH(exam_date) as creportmonth from student_classexcerise  where 
				user_id='".$this->session->userdata('user_id')."' and year_id='".$year_id."' and exam_status='pass' 
				GROUP BY MONTH(exam_date) order by exam_date asc");
$num_cmonth=$sqlcmonth->num_rows();
if($num_cmonth > 0)
{
	$result_cmonth=$sqlcmonth->result();
	$classmonth_arr=array();
	foreach($result_cmonth as $rowcmonth)
	{
		array_push($classmonth_arr,$rowcmonth->creportmonth);
	}
}

$sqlhmonth=$this->db->query("select MONTH(exam_date) as hreportmonth from student_homeworktest  where 
				user_id='".$this->session->userdata('user_id')."' and year_id='".$year_id."' and exam_status='pass' 
				GROUP BY MONTH(exam_date) order by exam_date asc");
$num_hmonth=$sqlhmonth->num_rows();
if($num_hmonth > 0)
{
	$result_hmonth=$sqlhmonth->result();
	$homemonth_arr=array();
	foreach($result_hmonth as $rowhmonth)
	{
		array_push($homemonth_arr,$rowhmonth->hreportmonth);
	}
}
//$finalmonth=array();
$finalmonth=array_unique(array_merge ($classmonth_arr, $homemonth_arr));
asort($finalmonth);

if($finalmonth)
{
$current_date = date("Y-m-d");
$last_date =date("Y-m-t", strtotime($current_date));	
foreach($finalmonth as $allmonth)
{
	if($allmonth==date('m'))
	{
		if($current_date==$last_date)
		{
?>

<div class="col-xs-12 col-sm-4 col-md-4 col-lg-4">
<a href="<?php echo base_url().'monthly-report/'.getMonthName($allmonth);?>" class="btn-mn btn-3 btn-3e ans-btn"><?php echo getMonthName($allmonth);?></a>
</div>

<?php
		}
	}
	else
	{
		?>
		<div class="col-xs-12 col-sm-4 col-md-4 col-lg-4">
<a href="<?php echo base_url().'monthly-report/'.getMonthName($allmonth);?>" class="btn-mn btn-3 btn-3e ans-btn"><?php echo getMonthName($allmonth);?></a>
</div>
<?php		
	}
}
}
else
{
echo '<br/><br/><p class="error" align="center">No report found .<br/>
		<a href="'.base_url().'analysis-report"><strong>Go Back</strong></a></p>';	
}


//}
?>


 
 
 
 
 </div>
 </div>
 </section>
 
 
   
   
   
   
   
   
    
 <!-- Page Content End -->
<?php include('footer.php'); ?>