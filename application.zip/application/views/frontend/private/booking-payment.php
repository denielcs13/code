<?php 
if($this->session->userdata('user_id')!='')
{

	include(APPPATH.'/views/frontend/private/header.php');
	
}
else
{
	include('header.php');
}	
?>

<section id="title-inner" class="bgcolor-text">
<canvas id="demo-canvas"></canvas>
<div class="container">
<div class="text-tit">
<h1>
<span>Booking Payment</span>
</h1>
</div>

</div>
</section>
<!-- Page Content inner -->


 
 <section class="about_content content-text space-75">
 <div class="container">
 <div class="row">
 
 <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
<p>
<strong>Remarks:</strong> if you want to If you need to change any confirmed class,  please <a href="<?php echo base_url().'contact-us';?>">contact the centre</a> during opening hours, 48 hours ahead of the class
</p>


 
 </div>
 
  </div>
  <br>
   <div class="row">
  <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
  	<div class="table-wrap">
	<div class="table-responsive">
	  <table class="table table-hover table-bordered mb-0">
		<thead>
		  <tr>
			<th>Order ID</th>
			<th>Year</th>
			<th>Center</th>			
			<th>Plan</th>
			<th>Amount</th>
			<th>Status</th>
			<th>Payment Status</th>
			<th>Tansation ID</th>
			<th>Date</th>			
			<th class="text-nowrap">View</th>
		  </tr>
		</thead>
		<tbody>
		<?php 
		$expirydate="";
		$orddb="";
		if($orderlist != null && $orderlist != ""){		
		  foreach($orderlist as $result)
		  {
			$plan_name=$this->plan_model->GetPlanName($result->plan_id);
			/*----expired order plan------*/
			$expirydate=strtotime("+".$result->order_totalweek." week", strtotime($result->order_date));
			if($today > $expirydate)
			{
				$orddb=array('order_status'=>'expired');				
				$this->order_model->Update_Order($orddb,$result->orderid);
			}
			/*----end of expired order plan------*/	
		if($result->pay_status=='confirm'){
		?>
		<tr>
		<td><?php echo $result->orderid;?></td>
		<td><?php echo $this->classes_model->GetClassName($result->year_id);?></td>
		<td><?php echo $this->center_model->GetDepartmeantName($result->center_id);?></td>
		<td><?php echo $plan_name;?></td>
		<td>$<?php echo $result->amount;?></td> 
		<td><?php echo ucfirst($result->order_status);?></td>
		<td><?php echo ucfirst($result->pay_status);?></td>
		<td><?php echo $result->trans_id;?></td>
		<td><?php echo date('m/d/Y',strtotime($result->order_date));?></td>
		<td><a href="<?php echo  base_url();?>order-invoice/<?php echo $result->orderid;?> ">Invoice</a>
		
		</td>
		</tr>
		<?php
		  }
		  }
		}
		else
		{
			?>
		<tr>
		<td colspan="8">No Order available!</td>
</tr>
<?php
		}
?>		
		</tbody>
		</table>
		<br/>
		
		
		<?php 
		global $week_arr;
		if($classlist != null && $classlist != ""){	?>
		
		<h3>Class Schedule</h3>
		<table class="table table-hover table-bordered mb-0">
		<thead>
		  <tr>
			<th>Date</th>
			<th>Weekday</th>
			<th>Time</th>			
			<th>Week No.</th>
		</tr>
		</thead>
		<tbody>
		<?php	
		  foreach($classlist as $result)
		  {
				$classroombook_row=$this->main_model->get_detail('classroom_booking','id',$result->classroom_booking_id);
				
				$classschdl_row=$this->main_model->get_detail('class_schedule','id',$result->class_schdl_id);
				$time_row=$this->main_model->get_detail('weekday_time','id',$classschdl_row->time);	
				if((date('Y-m-d',strtotime($classroombook_row->class_schdl_date))!='1970-01-01') && $time_row->class_time!=""){
		?>
		<tr>
		<td><?php echo date('Y/m/d',strtotime($classroombook_row->class_schdl_date));?></td>
		<td><?php echo $week_arr[$classschdl_row->day];?></td>
		<td><?php  echo  date('h:i a',strtotime($time_row->class_time));?></td>
		<td><?php echo 'Week-'.$classroombook_row->week_id;?></td> 
		
		</tr>
		<?php
		  }
		  }
		  ?>
	
		
		</tbody>
		</table>
		
	<?php
		}
?>	<div style="clear:both"><br></div>
		
		
		<center><a href="<?php echo  base_url();?>membership-plan"><button class="btn-mn btn-3 btn-3e button-org">Join Class</button></a></center>
</div>
	 </div>
 
  </div>
 
 
 
 </div>
 </div>
 </section>
 
   
    
 <!-- Page Content End -->
<?php 
if($this->session->userdata('user_id')!='')
{
	include(APPPATH.'/views/frontend/private/footer.php');
}
else
{
	include('footer.php');
}	
?>