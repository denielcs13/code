<?php include('header.php'); ?>

<section id="title-inner" style="background-image:url(<?= base_url('assets/images/contact-bg.jpg')?>);">
<div id="large-header">   
<canvas id="demo-canvas"></canvas>
<div class="container">
<div class="text-tit">
 <div class="bb"></div>
<span class="lefttop-icon"></span>
<h1>
<span>Membership-Plans</span>
</h1>
<span class="rightbotm-icon"></span>
</div>

</div></div>

</section>

<!-- Page Content inner -->
<div class="login-page signup-page">

<div class="container">
<div class="row">


<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 space-75">

<div class="row">
<?php
echo '<pre>';
//var_dump($planinfo);
echo '</pre>';
?>
<p>Please do not refesh or back button for payment proccessing<p>

<form name="paypal" action="https://www.sandbox.paypal.com/cgi-bin/webscr" method="post" target="_top">
<input type="hidden" name="cmd" value="_xclick">
<input type="hidden" name="business" value="testing80-facilitator@iwesh.com">
<input type='hidden' name='item_name' value='<?php echo $plandetail->plan_name;?>'>
	<input type='hidden' name='item_number' value='<?php echo $orderid;?>'>
	<input type='hidden' name='quantity' value='1'>
	<input type='hidden' name='amount' value='<?php echo number_format($plandetail->plan_price);?>'>	
	<input type='hidden' name='currency_code' value='USD'>
	<input type='hidden' name='notify_url' value='http://dev.theuniversityofmaths.com/pay-notified'>
	<input type='hidden' name='cancel_return' value='http://dev.theuniversityofmaths.com/pay-cancel'>
	<input type='hidden' name='return' value='http://dev.theuniversityofmaths.com/pay-thank'>
<input type="image" src="https://www.sandbox.paypal.com/en_US/i/btn/btn_paynowCC_LG.gif" border="0" name="submit" alt="PayPal - The safer, easier way to pay online!">
<img alt="" border="0" src="https://www.sandbox.paypal.com/en_US/i/scr/pixel.gif" width="1" height="1">
</form>


</div>
</div>

</div>
</div>

</div>

 <!-- Page Content End -->
 <?php include('footer.php'); ?>
 <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>

<script type="text/javascript">
window.onload = function(){
  document.forms['paypal'].submit();
}
</script>
