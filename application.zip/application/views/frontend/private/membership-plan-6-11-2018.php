<?php include('header.php'); ?>

<section id="title-inner" style="background-image:url(<?= base_url('assets/images/contact-bg.jpg')?>);">
<div id="large-header">   
<canvas id="demo-canvas"></canvas>
<div class="container">
<div class="text-tit">
 <div class="bb"></div>
<span class="lefttop-icon"></span>
<h1>
<span>Membership-Plans</span>
</h1>
<span class="rightbotm-icon"></span>
</div>

</div></div>

</section>

<!-- Page Content inner -->
<div class="login-page signup-page">

<div class="container">
<div class="row">


<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 space-75">

<div class="row">
<?php
if($planlist)
{
	$userid=$this->session->userdata('user_id');
	$query_chkpro=$this->db->query("select * from student_promoted  where user_id='".$userid."' and pay_status='pending' order by  pid desc ");
	$num_chkpro=$query_chkpro->num_rows();
	if($num_chkpro > 0)
	{
		$yearchk=$query_chkpro->row();
		$payyear=$yearchk->promote_year;
	}
	else
	{
			$query_chkpro=$this->db->query("select year_id from student_promoted  where user_id='".$userid."'  ");
			$yearchk=$query_chkpro->row();
			$payyear=$yearchk->year_id;
	}
	foreach($planlist as $rowplan)
	{
?>	
	<div class="col-xs-12 col-sm-12 col-md-5 col-lg-5">
	<div class="box-syllabus">
	<div class="text-content">
	  <ul>
	  <li>
	  <h2><?php echo $rowplan->plan_name;?></h2>
	  </li>
	  <li>
	  $<?php echo number_format($rowplan->plan_price);?>
	  </li>
	  
	  <li>
	  <a href="<?php echo  base_url();?>paynow/<?php echo $rowplan->planid;?>/<?php echo $payyear;?>" class="button">Buy Now</a>
	  <li>
	  </ul>
	</div>
	</div>
	</div>


<?php
	}
}
?>

</div>
</div>

</div>
</div>

</div>

 <!-- Page Content End -->
 <?php include('footer.php'); ?>
 <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>

<script type="text/javascript">
jQuery(document).ready(function(){

    jQuery('#reg_year').change(function(){
		
      var yearid=$('#reg_year').val();
            jQuery.ajax({
                type : 'POST',
                url : '<?php echo BASE_URL.'ajaxcall/yearsprice';?>',
                data : {yearid:yearid}
				,	
        success: function(result){
           // alert(result);
           jQuery( "#priceshow" ).html('Price $'+result);
		    jQuery("#yearprice").val(result);
        }


    });
    });    
});

</script>
