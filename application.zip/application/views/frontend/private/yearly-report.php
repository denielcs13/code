<?php 	$this->load->view('frontend/private/header');  ?>

<!-- Page Content inner -->


<section id="title-inner" class="bgcolor-text">
<canvas id="demo-canvas"></canvas>
<div class="container">
<div class="text-tit">
<h1>
<span>Students Exam Sheet</span>
</h1>
</div>

</div>
</section>

<section class="about_content content-text space-75 space-top-0">
  <br>
 <br>
 <div class="container">
 <?php
 if($exam_details)
 {
	 foreach($exam_details as $rowexam)
	 {
		    $user_query=$this->db->query("select user_id,first_name,last_name,dob from user_details where user_id='".$rowexam->user_id."' "); 
			$result_user=$user_query->row();
	 
	 
 ?>
 <div class="row">

  <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
   <div class="row">
   <div class="col-md-6 col-sm-6">
    <table class="table table-striped table-light">
	<tr>
	<td>Student ID</td>
	<td><strong><?php echo $rowexam->user_id;?></strong></td>
	</tr>
	<tr>
	<td>First Name</strong></td>
	<td><strong><?php echo $result_user->first_name;?></strong></td>
	</tr>
	<tr>
	<td>Last Name</td>
	<td><strong><?php echo $result_user->last_name;?></strong></td>
	</tr>
	<tr>
	<td>Reporting Period</td>
	<?php 
	$data=array('year_id'=>$rowexam->year_id,'term_id'=>1);
	$query1=$this->db->where($data)->get('yearterm_date');
	$result=$query1->row();
	
	
	$check_term_exams =$this->students_model->check_term_exam();
	
	foreach($check_term_exams as $check_term_exam)
	{
		$terms[]= 'Term '.$check_term_exam->term_id;
		
	}
	$terms=implode(', ',$terms);
	?>
	<td colspan="3"><strong><?php echo date("d M Y",strtotime($result->term_date));?> to <?php echo date("d M Y");?> (<?php echo $terms;?>)</strong></td>
	</tr>
	</table>
   </div>
     <div class="col-md-6 col-sm-6">
	 <table class="table table-striped table-light">
	<tr>
	<td>Date</td>
	<td><strong><?php echo date("d M Y");?></strong></td>
	</tr>
	<tr>
	<td>Year</td>
	<td><strong><?php 
	if($rowexam->year_id==1)
	{
	echo 'kindergarten';
	}
	else	
	{
		echo $rowexam->year_id;
	}
	?></strong></td>
	</tr>
	<tr>
	<td>Date  of  Birth</td>
	<td><strong><?php 
	if($result_user->dob!="")
	{	
		echo date("d M Y", strtotime($result_user->dob));
		
	}
	
	?></strong></td>
	</tr>
	
	
	</table>
   </div>
  
</div>
 </div>
 
 </div>
<?php


	 }
}
?> 
 </div>
  <div  class="container" style="background-color: #fecc98;">
  	<div class="row">
 	<div  style="padding-top: 5px; width:100%; text-align: center; line-height: 50px;"><b style="font-size: 20px">Summary</b></div>
</div>
 </div>
 <div class="container">
 	<div style="margin-top: 25px;margin-bottom: 25px;  text-align: center;"><b><span style="color: #6eb72f;font-size: 20px;" >Total number of stars for 4 semester milestone assessment test is 18.</span></b></div>
	
	<div class="row"> 
	
	
	<?php
	for ($j=1;$j<=4;$j++){
	
	$data=array('user_id'=>$this->session->userdata('user_id'),'term_id'=>$j,'exam_status'=>'done');
	$query1=$this->db->where($data)->limit(5)->get('student_exam');
	$result=$query1->result();
	if($result){ 
	
	$i=1;
 				$calc=array();
 				foreach ($result as $value) 
 				{
 					$data=array('user_id'=>$this->session->userdata('user_id'),'attempt'=>$value->attempt,'term_id'=>$value->term_id);
		 			$abc=$this->db->where($data)->get('sexam_history');
 				
 					
 						$data=array('user_id'=>$this->session->userdata('user_id'),'attempt'=>$value->attempt,'answer_status'=>'true');
 					
 					 $totalright=$this->db->where($data)->get('sexam_history')->num_rows().'/'.$totalquestion=$abc->num_rows();
						$calper=($totalright/$totalquestion)*100;
				array_push($calc, array('per'=>$calper,'totalright'=>$totalright,'totalquestion'->$totalquestion,'date'=>$value->exam_date));
 				$i++;
							
				}
		$star_p=$calc[getmax($calc)]['per'];
		echo get_grade($star_p);	
	
	}
	}



	//echo get_grade();?>
	
	
	
	</div>
 </div>
 
 <!-- For Term 1 to Term 4 --- -->
 <?php
	
	for ($j=1;$j<=4;$j++){
	
	$data=array('user_id'=>$this->session->userdata('user_id'),'term_id'=>$j,'exam_status'=>'done');
	$query1=$this->db->where($data)->limit(5)->get('student_exam');
	$result=$query1->result();
	if($result){
 		?>
 
 <div  class="container" style="background-color: #ffff99;height: 35px">
 	<div class="row">
 	<div  style="padding-top: 5px; "><b style="font-size: 25px">Term <?php echo $j;?>:<span style="color: #6eb72f; font-family: initial ;
    font-size: 25px" > Semester Milestone Test (30  minutes)</span></b></div>
</div>
 </div>
 <div class="container">
 	
 	<table class="table">
 		<thead>
 			<tr>
 				<th style="border-bottom: 1px solid #1a1b1d;">Attempts</th>
 				<th style="border-bottom: 1px solid #1a1b1d;">Date</th>
 				<th style="border-bottom: 1px solid #1a1b1d;">Time</th>
 				<th style="border-bottom: 1px solid #1a1b1d;">Total Questions</th>
 				<th style="border-bottom: 1px solid #1a1b1d;">Score</th>
 				<th style="border-bottom: 1px solid #1a1b1d;">Percentage (%)</th>
 			</tr>
 		</thead>
 		
 		<tbody>
 			<?php
 			$i=1;
 				$calc=array();
 				foreach ($result as $value) 
 				{
 					$data=array('user_id'=>$this->session->userdata('user_id'),'attempt'=>$value->attempt,'term_id'=>$value->term_id);
		 			$abc=$this->db->where($data)->get('sexam_history');
 				?>
 					<tr>
 					<td><?=$value->attempt?></td>
 					<td><?=date("d M Y", strtotime($value->exam_date));?></td>
 					<td><?=$value->duration;?></td>
 					<td><?=($abc->num_rows());?></td>
 					<?php 
 						$data=array('user_id'=>$this->session->userdata('user_id'),'attempt'=>$value->attempt,'answer_status'=>'true');
 					?>
 					<td><?= $totalright=$this->db->where($data)->get('sexam_history')->num_rows().'/'.$totalquestion=$abc->num_rows();?></td>
 					<?PHP 
							$calper=($totalright/$totalquestion)*100;
							?>
 					<td><?=number_format($calper).'% <pre>'; ?></td>
 				</tr>
 				<?php 
 				
 					array_push($calc, array('per'=>$calper,'totalright'=>$totalright,'totalquestion'->$totalquestion,'date'=>$value->exam_date));
 				$i++; 
 			}
 			?>
 		</tbody>
 	</table>
 	
 	<b><u><span>Analysis (using most recent data) </span></u></b>
 	<div>
 		<table >
 		<thead>
 			<tr>
 				<th style="border-bottom: 1px solid #1a1b1d; width: 150px;">Lowest Score</th>
 				<th style="border-bottom: 1px solid #1a1b1d;width: 150px;">Percentage(%)</th>
 				<th style="border-bottom: 1px solid #1a1b1d;width: 100px;">Date</th>
 				
 			</tr>
 		</thead>
 		<tr>
 		<td style="width: 150px;"><?=$calc[get_min($calc)]['totalright']?>	</td>
 				<td style="width: 150px;"><?= round($calc[get_min($calc)]['per'])?>%</td>
 				<td style="width: 100px;"><?=date('d M y',strtotime($calc[get_min($calc)]['date'])) ?></td>
 			</tr>
 		<tbody>
 			
 		</tbody>
 	</table>
 	</div>
 		<br>
 		<div>
 		<table >
 		<thead>
 			<tr>
 				<th style="border-bottom: 1px solid #1a1b1d; width: 150px;">Highest Score</th>
 				<th style="border-bottom: 1px solid #1a1b1d;width: 150px;">Percentage(%)</th>
 				<th style="border-bottom: 1px solid #1a1b1d;width: 100px;">Date</th>
 				
 			</tr>
 		</thead>
 		
		<?php
			 
		?>	
		
		<tr>
 		<td style="width: 150px;"><?=$calc[getmax($calc)]['totalright']?>	</td>
 				<td style="width: 150px;"><?= round($calc[getmax($calc)]['per'])?>%</td>
 				<td style="width: 100px;"><?=date('d M y',strtotime($calc[getmax($calc)]['date'])) ?></td>
 			</tr>
 			
 			
 		<tbody>
 			
 		</tbody>
 	</table>
 	</div>
 		<br>
 		<div>
 		<table >
 		<thead>
 			<tr>
 				<th style="border-bottom: 1px solid #1a1b1d; width: 150px;">Mean Score</th>
 				<th style="border-bottom: 1px solid #1a1b1d;width: 150px;">Median Score</th>
 				<th style="border-bottom: 1px solid #1a1b1d;width: 100px;">Mode Score</th>
 				
 			</tr>
 		</thead>
 		<?PHP 
 		?>
 		<td style="width: 150px;"><?= round(mean($calc)); ?>%</td>
 				<td style="width: 150px;"><?=round( median($calc),2);?>%</td>
 				<td style="width: 100px;"><?= round($calc[getmax($calc)]['per'])?>%</td>
 		<tbody>
 			
 		</tbody>
 	</table>
 	</div>
 		<br>
 <span><b>Grade (Highest  <?php echo $calc[getmax($calc)]['per'];?>%) </b></span>
 	<?php
	$star_p=$calc[getmax($calc)]['per'];
	echo get_grade($star_p);

 	?>
	
	
	
	
	
 </div>
 
	<?php } ?>
	<?php } // End of Term loop ?>
	
	
	<?php $comment_row=$this->main_model->get_detail('student_comment','user_id',$rowexam->user_id);
	
	if($comment_row->comment!=""){?>
	<div class="container">
		<div class="row">
			<div class="col-md-10 col-sm-10">
			<table>
			<tr><td>Tutor Comment : </td><td>&nbsp;</td> <td><strong> <?php echo ' '.$comment_row->comment;?></strong></td></tr>
		</table></div>
  
	</div>
	</div>
	<?php } ?>
<div class="container">
 <div class="row">
	<div class="col-md-5"></div>
	<div class="col-md-4">
		<?php //href="<?= base_url('Reportpre/print/').$this->uri->segment('2');"?>
		<button type="button"  id="print" class="btn-mn btn-3 btn-3e" style="color: white; width: 100px; line-height:50px;">Print</button>

	</div>
	<div class="col-md-3"></div>
</div>
</div>
 <script type="text/javascript">
		 $('#print').click(function(){
			//var last_uri="<?=$this->uri->segment('2')?>";
			var url ='<?=base_url("yearly-report-print")?>';
			window.location.href=url;
		});
</script>
 
 
 
 
 
 </section>

 
 
 
 
 
 
 <?php


	
function getMax( $array )
{
    $max = 0;
    foreach( $array as $k => $v )
    {
        $max = max( array( $max, $v['per'] ) );
        
    }
    foreach ($array as $key => $val) 
    {
       if ($val['per'] === $max) 
       {

           	 $abc=$key;
       }
   }
    return $abc;
} 

  
    //echo min($min);

function get_min($array)
{
	$min = array();
    foreach( $array as $k => $v )
    {
    	array_push($min,$v['per']);
    }
  foreach($min as $k => $v )
    {
    	if($v==min($min))
    	{
    		
    		return $k;	
    	}
    	
    }
}
   
   
function mean($array)
{
	$total=0;
    foreach( $array as $k => $v )
		    {
		        $total=$total+$v['per'];
		         $total.'<br>';
		    }
	 $mean=round($total)/count($array);
	 return $mean;
}
   


function median($array) {

	$arr=array();
	foreach ($array as $key => $value) {
		array_push($arr, $value['per']);
	}

    $count = count($arr);
    $middleval = floor(($count-1)/2); 
    if($count % 2) 
    { 
        $median = $arr[$middleval];
    } 
    else
    { 
        $low = $arr[$middleval];
        $high = $arr[$middleval+1];
        $median = (($low+$high)/2);
    }
    return $median;
}
  

function mode($array)
{
	$arr=array();
	foreach ($array as $key => $value) 
	{
	array_push($arr, intval(round($value['per'])));
	}
	

$values = array_count_values($arr);

if($values)
{

$popular = array_slice(array_keys($values), 0, 1, true);
}

return $popular;
}

 	function get_grade($star_p){
	
 	
	if(1>=$star_p||$star_p<=49)
 	{
 		$star=1;
 	}elseif (50>=$star_p||$star_p<=79) {
 		$star=2;
 	}elseif (80>=$star_p||$star_p<=89) {
 		$star=3;
 	}elseif (90>=$star_p||$star_p<=99) {
 		$star=4;
 	}else{
 		$star=5;
 	}
 	$html.= '<div class="col-md-3">';
    for($i=0;$i<$star;$i++)
    {
    	$html.='<img style="height: 61px" src="'.base_url('assets/star/img.png').'">';
    }
$html.= '</div>';

return $html;

	}

   ?>
    
 <!-- Page Content End -->
<?php include('footer.php'); ?>