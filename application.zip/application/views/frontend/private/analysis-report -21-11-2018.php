<?php include('header.php'); ?>

<!-- Page Content inner -->

<div class="tabs-login">
<div class="container">
<div class="row">
<ul class="links-menu">
<li><a href="notice-board">Notice Board</a></li>
<li><a href="this-week-classroom-exercise">This Week Classroom Exercise</a></li>
<li><a href="homework-exercise">Homework Exercise</a></li>
<li><a href="year-1-syllabus">Year 1 - Syllabus</a></li>
<li><a href="analysis-report" class="active">Analysis Report</a></li>
<li><a href="booking-payment">Booking & Payment</a></li>
<li><a href="certificate-award">Certificate & Award</a></li> 

</ul>

</div>
</div>

</div>
 
 <section class="about_content content-text space-75 space-top-0">
 <div class="container">
 <div class="row">
 
 <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
 
 
 Monthly Analysis Reporting
 
 </div>
 
 
 
 
 </div>
 </div>
 </section>
 
 
    
 <!-- Page Content End -->
<?php include('footer.php'); ?>