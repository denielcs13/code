<?php include('header.php'); ?>
<?php  $img=ucfirst($year_dtl->class_slug.'_bg.jpg');?>
<?php
if($this->session->userdata('loginyear')!="")
{
	if($year_id!=$this->session->userdata('loginyear'))
	{
		redirect(base_url().'dashboard');
		exit;
	}
}
?>
<section id="title-inner" style="background-image:url(<?= base_url('assets/images/'.$img)?>);">
  <div id="large-header">
    <canvas id="demo-canvas"></canvas>
    <div class="container">
      <div class="text-tit">
        <div class="bb"></div>
        <span class="lefttop-icon"></span>
        <h1> <span><?php echo $year_dtl->class_name;?></span> </h1>
        <span class="rightbotm-icon"></span> </div>
    </div>
  </div>
</section>


<!-- Page Content inner -->

<section class="about_content content-text syllabus-page space-75">
  <div class="container">
    <div class="row"> 
      <!-- Bootstrap Tabs -->
      
      <div class="tab-content">
        <?php 
      if($SylList1 != null && $SylList1 != ""){
			global $order_arr;
			$tid=0;$wid=0;
									?>
        <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
          <h2 class="blue-title">Term 1</h2>
          <div class="row">
            <?php foreach($SylList1 as $result){
	$term= $this->main_model->get_detail('master_terms','term_id',$result->term_id);
	$skl_dtl= $this->main_model->get_detail('master_skill','skill_id',$result->skill_id);
	$query=$this->db->query('select * from syllabus_week_subskill where skill_id = "'.$result->skill_id.'"'); 
	 $ct2= $query->num_rows();
	$comp2=0;

	?>
            <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
              <div class="syllabus-sec">
                <h3><?php echo $order_arr[$result->skill_order].'. '.$skl_dtl->skill_name;?></h3>
                <div class="row">
                  <?php 

foreach($query->result() as $ress){
	
	$subskl_dtl= $this->main_model->get_detail('master_skill','skill_id',$ress->subskill_id);
	$comp2++;
	?>
                  <?php if($wid!=$ress->week_id || $comp2==1){
	
	$query1=$this->db->query('select count(*) as "ct" from syllabus_week_subskill where week_id="'.$ress->week_id.'" and term_id="'.$ress->term_id.'" and year_id="'.$ress->year_id.'"');
	$res1=$query1->row();
	$ct= $res1->ct;
	
	$comp=0;

	$week_dtl= $this->main_model->get_detail('master_weeks','week_id',$ress->week_id);
	$this->db->select('*'); 
	$this->db->from('master_goal');
	$this->db->where('term_id',$result->term_id);
	$this->db->where('year_id',$result->class_id);
	$this->db->where('week_id',$ress->week_id);
	$goal= $this->db->get()->row();
	$color_class=explode(',' ,$ress->week_id);
	$color_class=$color_class[0];
	?>
                  <div class="col-xs-12 col-sm-12 col-md-4 col-lg-4">
                    <div class="box-syllabus">
                      <div class="text-content">
                        <ul>
                          <li>
                            <div class="row">
                              <div class="col-xs-8 col-sm-8 col-md-6 col-lg-8 col-8"><strong><?php echo $goal->goal_name;?></strong></div>
                              <div class="col-xs-4 col-sm-4 col-md-6 col-lg-4 col-4">
                                <h4 class="cyan_bg color-<?php echo $color_class;?>"><?php echo $week_dtl->week_name;?></h4>
                              </div>
                            </div>
                          </li>
                          <?php } $comp++; ?>
                          <a href="<?php echo base_url().strtolower($year_dtl->class_slug).'/'.$subskl_dtl->skill_slug;?>">
                          <li><strong><?php echo $order_arr[$result->skill_order].'.'.$ress->subskill_order;?></strong> <?php echo $subskl_dtl->skill_name;?></li>
                          </a>
                          <?php if(($ct==$comp) || ($ct2==$comp2)){?>
                        </ul>
                      </div>
                    </div>
                  </div>
                  <?php } $wid=$ress->week_id;?>
                  <?php } ?>
                </div>
              </div>
            </div>
            <?PHP } ?>
          </div>
        </div>
        <?PHP } ?>
        <?php 
      if($SylList2 != null && $SylList2 != ""){
			global $order_arr;
			$tid=0;$wid=0;
									?>
        <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
          <h2  class="green-title">Term 2</h2>
          <div class="row">
            <?php foreach($SylList2 as $result){
	$term= $this->main_model->get_detail('master_terms','term_id',$result->term_id);
	$skl_dtl= $this->main_model->get_detail('master_skill','skill_id',$result->skill_id);
	$query=$this->db->query('select * from syllabus_week_subskill where skill_id = "'.$result->skill_id.'"'); 
	 $ct2= $query->num_rows();
	$comp2=0;

	?>
            <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
              <div class="syllabus-sec">
                <h3><?php echo $order_arr[$result->skill_order].'. '.$skl_dtl->skill_name;?></h3>
                <div class="row">
                  <?php 

foreach($query->result() as $ress){
	
	$subskl_dtl= $this->main_model->get_detail('master_skill','skill_id',$ress->subskill_id);
	$comp2++;
	?>
                  <?php if($wid!=$ress->week_id || $comp2==1){
	
	$query1=$this->db->query('select count(*) as "ct" from syllabus_week_subskill where week_id="'.$ress->week_id.'" and term_id="'.$ress->term_id.'" and year_id="'.$ress->year_id.'"');
	$res1=$query1->row();
	$ct= $res1->ct;
	
	$comp=0;

	$week_dtl= $this->main_model->get_detail('master_weeks','week_id',$ress->week_id);
	$this->db->select('*'); 
	$this->db->from('master_goal');
	$this->db->where('term_id',$result->term_id);
	$this->db->where('year_id',$result->class_id);
	$this->db->where('week_id',$ress->week_id);
	$goal= $this->db->get()->row();
	$color_class=explode(',' ,$ress->week_id);
	$color_class=$color_class[0];
	
	?>
                  <div class="col-xs-12 col-sm-12 col-md-4 col-lg-4">
                    <div class="box-syllabus ">
                      <div class="text-content">
                        <ul>
                          <li>
                            <div class="row">
                              <div class="col-xs-8 col-sm-8 col-md-6 col-lg-8 col-8"><strong><?php echo $goal->goal_name;?></strong></div>
                              <div class="col-xs-4 col-sm-4 col-md-6 col-lg-4 col-4">
                                <h4 class="cyan_bg color-<?php echo $color_class;?>"><?php echo $week_dtl->week_name;?></h4>
                              </div>
                            </div>
                          </li>
                          <?php } $comp++; ?>
                          <a href="<?php echo base_url().strtolower($year_dtl->class_slug).'/'.$subskl_dtl->skill_slug;?>">
                          <li><strong><?php echo $order_arr[$result->skill_order].'.'.$ress->subskill_order;?></strong> <?php echo $subskl_dtl->skill_name;?></li>
                          </a>
                          <?php if(($ct==$comp) || ($ct2==$comp2)){?>
                        </ul>
                      </div>
                    </div>
                  </div>
                  <?php } $wid=$ress->week_id;?>
                  <?php } ?>
                </div>
              </div>
            </div>
            <?PHP } ?>
          </div>
        </div>
        <?PHP } ?>
        <?php 
      if($SylList3 != null && $SylList3 != ""){
			global $order_arr;
			$tid=0;$wid=0;
									?>
        <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
          <h2 class="cyan-title">Term 3</h2>
          <div class="row">
            <?php foreach($SylList3 as $result){
	$term= $this->main_model->get_detail('master_terms','term_id',$result->term_id);
	$skl_dtl= $this->main_model->get_detail('master_skill','skill_id',$result->skill_id);
	$query=$this->db->query('select * from syllabus_week_subskill where skill_id = "'.$result->skill_id.'"'); 
	 $ct2= $query->num_rows();
	$comp2=0;

	?>
            <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
              <div class="syllabus-sec">
                <h3><?php echo $order_arr[$result->skill_order].'. '.$skl_dtl->skill_name;?></h3>
                <div class="row">
                  <?php 

foreach($query->result() as $ress){
	
	$subskl_dtl= $this->main_model->get_detail('master_skill','skill_id',$ress->subskill_id);
	$comp2++;
	?>
                  <?php if($wid!=$ress->week_id || $comp2==1){
	
	$query1=$this->db->query('select count(*) as "ct" from syllabus_week_subskill where week_id="'.$ress->week_id.'" and term_id="'.$ress->term_id.'" and year_id="'.$ress->year_id.'"');
	$res1=$query1->row();
	$ct= $res1->ct;
	
	$comp=0;

	$week_dtl= $this->main_model->get_detail('master_weeks','week_id',$ress->week_id);
	$this->db->select('*'); 
	$this->db->from('master_goal');
	$this->db->where('term_id',$result->term_id);
	$this->db->where('year_id',$result->class_id);
	$this->db->where('week_id',$ress->week_id);
	$goal= $this->db->get()->row();
	$color_class=explode(',' ,$ress->week_id);
	$color_class=$color_class[0];
	
	?>
                  <div class="col-xs-12 col-sm-12 col-md-4 col-lg-4">
                    <div class="box-syllabus">
                      <div class="text-content">
                        <ul>
                          <li>
                            <div class="row">
                              <div class="col-xs-8 col-sm-8 col-md-6 col-lg-8 col-8"><strong><?php echo $goal->goal_name;?></strong></div>
                              <div class="col-xs-4 col-sm-4 col-md-6 col-lg-4 col-4">
                                <h4 class="cyan_bg color-<?php echo $color_class;?>"><?php echo $week_dtl->week_name;?></h4>
                              </div>
                            </div>
                          </li>
                          <?php } $comp++; ?>
                          <a href="<?php echo base_url().strtolower($year_dtl->class_slug).'/'.$subskl_dtl->skill_slug;?>">
                          <li><strong><?php echo $order_arr[$result->skill_order].'.'.$ress->subskill_order;?></strong> <?php echo $subskl_dtl->skill_name;?></li>
                          </a>
                          <?php if(($ct==$comp) || ($ct2==$comp2)){?>
                        </ul>
                      </div>
                    </div>
                  </div>
                  <?php } $wid=$ress->week_id;?>
                  <?php } ?>
                </div>
              </div>
            </div>
            <?PHP } ?>
          </div>
        </div>
        <?PHP } ?>
		
		
		   <?php 
      if($SylList4 != null && $SylList4 != ""){
			global $order_arr;
			$tid=0;$wid=0;
									?>
        <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
          <h2 class="red-title">Term 4</h2>
          <div class="row">
            <?php foreach($SylList4 as $result){
	$term= $this->main_model->get_detail('master_terms','term_id',$result->term_id);
	$skl_dtl= $this->main_model->get_detail('master_skill','skill_id',$result->skill_id);
	$query=$this->db->query('select * from syllabus_week_subskill where skill_id = "'.$result->skill_id.'"'); 
	 $ct2= $query->num_rows();
	$comp2=0;

	?>
            <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
              <div class="syllabus-sec">
                <h3><?php echo $order_arr[$result->skill_order].'. '.$skl_dtl->skill_name;?></h3>
                <div class="row">
                  <?php 

foreach($query->result() as $ress){ 
	
	$subskl_dtl= $this->main_model->get_detail('master_skill','skill_id',$ress->subskill_id);
	$comp2++;
	?>
                  <?php if($wid!=$ress->week_id || $comp2==1){
	
	$query1=$this->db->query('select count(*) as "ct" from syllabus_week_subskill where week_id="'.$ress->week_id.'" and term_id="'.$ress->term_id.'" and year_id="'.$ress->year_id.'"');
	$res1=$query1->row();
	$ct= $res1->ct;
	
	$comp=0;

	$week_dtl= $this->main_model->get_detail('master_weeks','week_id',$ress->week_id);
	$this->db->select('*'); 
	$this->db->from('master_goal');
	$this->db->where('term_id',$result->term_id);
	$this->db->where('year_id',$result->class_id);
	$this->db->where('week_id',$ress->week_id);
	$goal= $this->db->get()->row();
	$color_class=explode(',' ,$ress->week_id);
	$color_class=$color_class[0];
	
	?>
                  <div class="col-xs-12 col-sm-12 col-md-4 col-lg-4">
                    <div class="box-syllabus ">
                      <div class="text-content">
                        <ul>
                          <li>
                            <div class="row">
                              <div class="col-xs-8 col-sm-8 col-md-6 col-lg-8 col-8"><strong><?php echo $goal->goal_name;?></strong></div>
                              <div class="col-xs-4 col-sm-4 col-md-6 col-lg-4 col-4">
                                <h4 class="cyan_bg color-<?php echo $color_class;?>"><?php echo $week_dtl->week_name;?></h4>
                              </div>
                            </div>
                          </li>
                          <?php } $comp++; ?>
                          <a href="<?php echo base_url().strtolower($year_dtl->class_slug).'/'.$subskl_dtl->skill_slug;?>">
                          <li><strong><?php echo $order_arr[$result->skill_order].'.'.$ress->subskill_order;?></strong> <?php echo $subskl_dtl->skill_name;?></li>
                          </a>
                          <?php if(($ct==$comp) || ($ct2==$comp2)){?>
                        </ul>
                      </div>
                    </div>
                  </div>
                  <?php } $wid=$ress->week_id;?>
                  <?php } ?>
                </div>
              </div>
            </div>
            <?PHP } ?>
          </div>
        </div>
        <?PHP } ?>
      
      </div>
    </div>
  </div>
</section>
<?php include('footer.php'); ?>
