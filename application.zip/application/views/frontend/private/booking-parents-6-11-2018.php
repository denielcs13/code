<?php include('header.php'); ?>


<section id="title-inner" class="bgcolor-text">
<canvas id="demo-canvas"></canvas>
<div class="container">
<div class="text-tit">
<h1>
<span>Parents Information</span>
</h1>
</div>

</div>
</section>

<!-- Page Content inner -->
<div class="login-page signup-page">

<div class="container">
<div class="row">


<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 space-75">
<div class="row">
<div class="col-xs-12 col-sm-7 col-md-7 col-lg-7">
<form class="cmxform" id="signupForm" method="post" action="">
<div class="row">
<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
<p>Student Name : <?php echo $userinfo->first_name.' '.$userinfo->Last_name;?></p>
<p>Your Eligible Year : <?php echo $elg_yearname;?></p>




<div class="row">
<div class="col-lg-12">
<div class="input-field">
<label>Mother Name*</label>
<span class="input input--hoshi">
					<input type="text" name="mother_name" value="<?php //echo $userinfo->mother_name;?>" placeholder="Mother Name" />
				</span>
</div>
<div class="input-field">
<label>Father Name*</label>
<span class="input input--hoshi">
					<input type="text" name="father_name" value="<?php //echo $userinfo->last_name;?>" placeholder="Father Name" />
				</span>
</div>
<div class="input-field">
<label>Email*</label>
<span class="input input--hoshi">
					<input type="text" name="email" value="<?php //echo $userinfo->email;?>" placeholder="Email" />
				</span>
</div>
<div class="input-field">
<label>Phone*</label>
<span class="input input--hoshi">
					<input type="text" name="phone" value="<?php //echo $userinfo->phone;?>" placeholder="Phone" />
				</span>
</div>

<div class="input-field">
<label>Occupation</label>
<span class="input input--hoshi">
					<input type="text" name="occupation" value="<?php //echo $userinfo->address;?>" placeholder="Occupation" />
				</span>
</div>


</div>

</div>





<input type="hidden" name="elg_yearid" value="<?php echo $elg_yearid;?>" />

<button class="orange_btn"  id="booknow">Book Now</button>





</div>


</div>
</form>


</div>

</div>
</div>

</div>
</div>

</div>

 <!-- Page Content End -->
 <?php include('footer.php'); ?>
 
