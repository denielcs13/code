<?php include('header.php'); ?>

<!-- Page Content inner -->
<section id="title-inner" class="bgcolor-text">
<canvas id="demo-canvas"></canvas>
<div class="container">
<div class="text-tit">
<h1>
<span>Dashboard</span>
</h1>
</div>

</div>
</section>

 
 <section class="about_content content-text page-dashboard space-75">
 <div class="container">
 <div class="row">
 
 <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12" >

   <?php
  if($this->session->userdata('user_type')=='3')
	{?>
	 <h2 align="center">You have Successfully registered as a tutor with us for 
	 <?php 
	 
	 $years=explode(',',$this->session->userdata('loginyear'));
			
		?>

		<?php foreach($years as $year){
			
			$year_dtl=$this->main_model->get_detail('master_class','class_id',$year);
			$years[]=$year_dtl->class_name;
			
			}
			
			echo implode(', ',$years);
			?>
	 </h2>
 <p align="center">Please visit your  registered year's pages.</p>

		
	<?php }
	else{
   
 if($aatcount==0)
 {?>
 <h2 align="center">You have Successfully registered with us for  <?php echo $year_name;?></h2>
 <p align="center">Please give Academic Assessment Test to join the classes.</p>
<p align="center"> <a href="<?php echo BASE_URL.'assessment';?>" target="_blank" class="btn-mn btn-3 btn-3e  button-org aat-btn"><strong>Start Academic Assessment Test</strong></a></p>
<p>This is an Admission Assessment Test (AAT) for all our students prior admitting into MY UNI. The purpose of this test is to assess the best academic year for you to start in MY UNI with our classmates at similar level. This test consists of 30 questions with a time limit of 45 minutes. Once it’s started, you are not allowed to save the progress or go back. You may start your AAT now or you are always welcome to come back for it later.
<br>
<br>
<h3>Instructions:</h3>
<ul>
<li>Please find a time and location that you can focus.</li>
<li>Please work on your own and choose the correct answer. Some of the questions maybe at a more advance level than your current academic year. You may or may not come across this before. If you don't know, just click "I don't know".</li>
<li>Please be reminded that the time limit is 45min, so please do not drill on a specific question.
Cheers!</li>
</ul>
</p>

 <?php
 }
 else
 {
 ?>

 <h3 class="text-center">
 <?php
 if($this->session->userdata('lastlogedin')!='')
 {?>
 Last login : <?php echo $this->session->userdata('lastlogedin');?>
 <?php 
 } else { ?>
 This is your First Login
 <?php } ?>
 </h3>

  <div class="row">
<div class="col-xs-12 col-sm-6 col-md-4 col-lg-3">
<div class="box-show">
<a href="">
<img src="<?php echo base_url().'assets/images/year.png';?>" alt="" />
<span>Your Year</span></a>
</div> 
</div>
<div class="col-xs-12 col-sm-6 col-md-4 col-lg-3">
<div class="box-show">
<a href="<?php echo base_url();?><?php echo lcfirst($year_slug);?>">
<img src="<?php echo base_url().'assets/images/syllabus.png';?>" alt="" />
<span>Syllabus</span></a>
</div>
</div>
<div class="col-xs-12 col-sm-6 col-md-4 col-lg-3">
<div class="box-show">

<a href="<?php echo base_url();?>classroom-exercise">
<img src="<?php echo base_url().'assets/images/classroom.png';?>" alt="" />
<span>Classroom Exercise</span></a>
</div>
</div>
<div class="col-xs-12 col-sm-6 col-md-4 col-lg-3">
<div class="box-show">
<a href="<?php echo base_url();?>homework">
<img src="<?php echo base_url().'assets/images/homework.png';?>" alt="" />
<span>Home Work</span></a>
</div>
</div>

<div class="col-xs-12 col-sm-6 col-md-4 col-lg-3">
<div class="box-show">
<a href="<?php echo base_url();?>analysis-report">
<img src="<?php echo base_url().'assets/images/analysis-report.png';?>" alt="" />
<span>Analysis Report</span></a>
</div>
</div>
<div class="col-xs-12 col-sm-6 col-md-4 col-lg-3">
<div class="box-show">
<a href="<?php echo base_url();?>certificate-award">
<img src="<?php echo base_url().'assets/images/certificate.png';?>" alt="" />
<span>Certificate</span></a>
</div>
</div>
<div class="col-xs-12 col-sm-6 col-md-4 col-lg-3">
<div class="box-show">
<a href="<?php echo base_url();?>exam">
<img src="<?php echo base_url().'assets/images/exam.png';?>" alt="" />
<span>Exam Details</span></a>
</div>
</div>
<div class="col-xs-12 col-sm-6 col-md-4 col-lg-3">
<div class="box-show">
<a href="">
<img src="<?php echo base_url().'assets/images/university.png';?>" alt="" /> 
<span>University Comments</span></a>
</div>
</div>
</div>
 <?php
 }
 ?>
<?php } ?>


 
 </div>
 
 
 
 
 </div>
 </div>
 </section>
 
 
   
   
   
   
   
   
    
 <!-- Page Content End -->
<?php include('footer.php'); ?>