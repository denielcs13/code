<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<link rel="shortcut icon" href="<?= base_url('assets/images/favicon.png')?>" />
<link href="<?= base_url('assets/images/60x60.png')?>" rel="apple-touch-icon" />
<link href="<?= base_url('assets/images/76x76.png')?>" rel="apple-touch-icon" sizes="76x76" />
<link href="<?= base_url('assets/images/120x120.png')?>" rel="apple-touch-icon" sizes="120x120" />
<link href="<?= base_url('assets/images/152x152.png')?>" rel="apple-touch-icon" sizes="152x152" />
<meta name="description" content="">
<meta name="author" content="">
<title>The University Of English </title>

<!-- Bootstrap core CSS -->
<link href="<?= base_url('assets/css/bootstrap.min.css')?>" rel="stylesheet">
<link href="<?= base_url('assets/css/font-awesome.min.css')?>" rel="stylesheet" />
<link href="<?= base_url('assets/css/font-awesome.css')?>" rel="stylesheet" />
<link href="<?= base_url('assets/css/animate.css')?>" rel="stylesheet" />
<link href="<?= base_url('assets/css/404.css')?>" rel="stylesheet" />
<link href="<?= base_url('assets/css/title.css')?>" rel="stylesheet" />
<link href="<?= base_url('assets/css/owl.carousel.min.css')?>" rel="stylesheet" />
<link href="<?= base_url('assets/css/owl.carousel.css')?>" rel="stylesheet" />
<script src="https://cdnjs.cloudflare.com/ajax/libs/modernizr/2.6.2/modernizr.min.js"></script>
<script src="<?= base_url('assets/js/wow.min.js')?>"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
<script src='<?= base_url('assets/js/unispeech.js')?>'></script>
<script src=''></script>


<!-- Custom styles for this template -->
<link href="<?= base_url('assets/style.css')?>" rel="stylesheet">
</head>

<body>
<header class="header fadeInDown">
  <div id="topbar">
    <div class="container">
      <div class="row">
        <div class="col-lg-2"><a class="text-logo" href="<?= base_url();?>">The University of English</a></div>
        <div class="col-lg-10">
          <ul class="ml-auto top_menu float-right" id="menu">
            <li><a href="<?= base_url('about-us');?>">About us</a></li>
            <li><a href="<?= base_url('admissions');?>">Admissions</a></li>
            <li><a href="<?= base_url('parents');?>">Message to Parents</a></li>
            <li><a href="<?= base_url('curriculum');?>">Curriculum</a></li>
            <li><a href="<?= base_url('booking-payment');?>">Booking Payment</a></li>
            <!--<li><a href="<?= base_url('media-event');?>">Media & Events</a></li>-->
				<?php
		if($this->session->userdata('username')!='' && $this->session->userdata('username')!=null)
		{ ?>
			 <li><a href="<?= base_url('logout');?>" class="btn-mn btn-3 btn-3e">Logout</a></li>
            
			<?php
		}
		else
		{
			?>
			<li><a href="<?= base_url('register');?>" class="btn-mn btn-3 btn-3e">New Membership</a></li>
			<?php
		}
		?>
          </ul>
        </div>
      </div>
    </div>
  </div>
  <div class="container">
    <div class="row">
      <div class="col-xs-12 col-sm-12 col-md-2 col-lg-2 logo-sect">
        <div class="logo"> <a href="<?= base_url();?>"><img src="<?= base_url('assets/images/logo.png')?>" alt="" title="" /></a> </div>
</div>
      <div class="col-xs-12 col-sm-12 col-md-10 col-lg-10">
        <div class="login_form float-right">
          <?php
		if($this->session->userdata('username')!='' && $this->session->userdata('username')!=null)
		{
			?>
          <p class="logedinname">
          <ul class="loged">
            <li><?php echo $this->session->userdata('fullname');?> <a href="<?php echo BASE_URL.'dashboard';?>"><i class="fa fa-user-circle-o" aria-hidden="true"></i></a>
              <ul>
               <li><a href="<?php echo BASE_URL.'dashboard';?>">Dashboard</a></li> 
	
                <li><a href="<?php echo BASE_URL.'booking-payment';?>">Order History</a></li>
                <!--<li><a href="<?php echo  BASE_URL.'exams-report';?>">Grades</a></li>-->
                <!--<li>-->
                  <?php
$checktest_query=$this->db->query("select reg_year from student_promoted  where user_id='".$this->session->userdata('user_id')."' order by pid desc ");
$num_checktest=$checktest_query->num_rows();
if($num_checktest > 0)
{
	$row_checktest=$checktest_query->row();
	$assmenttestyear=$row_checktest->reg_year;
	if($assmenttestyear==1)
	{
		$asstestyearname_slug='kindergarten';
	}
	else
	{
		$asstestyearname_slug='year-'.$asstestyearname_slug;
	}
}
else
{
	 
   $uquery= "select year_id from user_details  where user_id='".$this->session->userdata('user_id')."' ";
	$sinfo_query=$this->db->query($uquery);
	$result_sinfo=$sinfo_query->row();	
	$assmenttestyear=$result_sinfo->year_id;
	if($assmenttestyear==1)
	{
		$asstestyearname_slug='kindergarten';
	}
	else
	{
		$asstestyearname_slug='year-'.$asstestyearname_slug;
	}
}	
	?>
                 <!-- <a href="<?php echo BASE_URL.$asstestyearname_slug.'/assessment';?>">Assessment Test</a></li>
                <li><a href="<?php echo  BASE_URL.'assessment-report';?>">Assessment Report</a></li>-->

                
				
				<?php if($user_id=$this->session->userdata('user_type')=='1'){?>
				<li><a href="<?php echo BASE_URL_ADMIN.'logout';?>" >Logout</a></li>
				<?php
				}else{
					?>
				<li><a href="<?php echo BASE_URL.'changepassword';?>" >Change Password</a></li>
                <li><a href="<?php echo BASE_URL.'logout';?>" >Logout</a></li>
				<?php }?>

			 </ul>
            </li>
            <!--<a href="<?php echo BASE_URL.'changepassword';?>" >Change Password</a>  <a href="<?php echo BASE_URL.'logout';?>" >Logout</a>-->
          </ul>
          </p>
          <?php
		}
		else
		{
			?>
          <form action="<?php echo BASE_URL.'login';?>" method="post">
            <input type="text" placeholder="login ID" name="username" />
            <input type="password" placeholder="Password" name="password" />
            <button type="submit" class="orange_btn">Log In</button>
            <a href="<?= base_url('forgot-password');?>">Forgotten Password?</a>
          </form>
          <?php
		}
		?>
        </div>
      </div>
    </div>
  </div>
  <nav id="navbar" class="navbar navbar-expand-lg navbar-dark">
    <div class="container">
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation"><i class="fa fa-bars" aria-hidden="true"></i> Select Year</button>
      <div class="collapse navbar-collapse float-right private-header" id="navbarResponsive">
   
	
		<ul class="menu ml-auto float-right">
        <li><a href="<?php echo base_url();?><?php echo lcfirst($year_slug);?>">Syllabus</a></li>
          <li><a href="<?php echo base_url();?>classroom-exercise">Classroom Exercise</a></li>
          <li><a href="<?php echo base_url();?>homework">Homework</a></li>
          <li><a href="<?php echo base_url();?>analysis-report">Analysis Report</a></li>
          <li><a href="<?php echo base_url();?>certificate-award">Certificate & Award</a></li>
          <li><a href="<?php echo base_url();?>exam">Exam</a></li>
        </ul>
		
      
	
	<?php 	
	if($this->session->userdata('user_type')=='3')
		{
			$years=explode(',',$this->session->userdata('loginyear'));
			
		?>
		<ul class="menu ml-auto float-right">
		<?php foreach($years as $year){
			
			$year_dtl=$this->main_model->get_detail('master_class','class_id',$year);
			
			?>
        <li><a href="<?php echo base_url();?><?php echo lcfirst($year_dtl->class_slug);?>"><?php echo $year_dtl->class_name;?></a></li>
         <?php
		}
		?>	 
        </ul>
		<?php
	}
	?>		
	  
	  
	  
	  
	  </div>
    </div>
  </nav>
</header>
