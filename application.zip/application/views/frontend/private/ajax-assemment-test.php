<?php
$htmdata='<form  name="myForm" id="assemment"  method="post" action="" onsubmit="return validateForm()">';	

			if($data['Questionlist'] != null && $data['Questionlist'] != "")
			{
				
			  foreach($data['Questionlist'] as $result)
			  {
			
				$query_ques=$this->db->query("select * from manage_question_".$result->ass_year_id." where ques_id='".$result->ass_question."' ");
				$ques_result=$query_ques->row();
				
				if($ques_result->ques_type==1){  
					
					$htmdata .= $ques_result->ques_name;
					$htmdata .='<br>';
					
				
					$answers=$this->questions_model->get_answers1($data['year_id'],$ques_result->ques_id);
					foreach($answers as $answer){
						
					$htmdata .='<a id ="a1" href="javascript:alert(default functionality)"  style="height: 77px; width: 77px; line-height: 77px; font-size: 50px;background-color: #1fb2e4;color:#FFF" ><input name="answerid" value="'.$answer->ans_id.'" name="rb" type="radio" id="rb1" style="height: 77px; width: 77px; line-height: 77px; font-size: 50px;background-color: #1fb2e4;color:#FFF">'.$answer->ans_name.'</a>&nbsp;&nbsp;&nbsp;';
					}
					
				
				}
				elseif($ques_result->ques_type==3){ 
					
					$htmdata .=$ques_result->ques_name;
					$htmdata .='<br>';
					$imgs=$this->main_model->getall('ques_img','ques_id',$ques_result->ques_id);

					
					$htmdata .='<br>';
					$answers=$this->questions_model->get_answers1($data['year_id'],$ques_result->ques_id);
					foreach($answers as $answer){
						
					$htmdata .='<a id ="a1" href="javascript:alert(default functionality)"  style="height: 77px; width: 77px; line-height: 77px; font-size: 50px;background-color: #1fb2e4;color:#FFF" ><input name="answerid" value="'.$answer->ans_id.'" name="rb" type="radio" id="rb1" style="height: 77px; width: 77px; line-height: 77px; font-size: 50px;background-color: #1fb2e4;color:#FFF">'.$answer->ans_name.'</a>&nbsp;&nbsp;&nbsp;';
					}
					
				
				}
				elseif($ques_result->ques_type==4){ 
					
					$htmdata .=$ques_result->ques_name;
					$htmdata .='<br>';
					$imgs=$this->main_model->getall('ques_img','ques_id',$ques_result->ques_id);

					foreach($imgs as $img){

					$htmdata .='<img src="/assets/uploads/ans/'.$img->img.'"/>';
					}
					$htmdata .='<br>';
					$answers=$this->questions_model->get_answers1($data['year_id'],$ques_result->ques_id);
					foreach($answers as $answer){
						
					$htmdata .='<a id ="a1" href="javascript:alert(default functionality)"  style="height: 77px; width: 77px; line-height: 77px; font-size: 50px;background-color: #1fb2e4;color:#FFF" ><input name="answerid" value="'.$answer->ans_id.'" name="rb" type="radio" id="rb1" style="height: 77px; width: 77px; line-height: 77px; font-size: 50px;background-color: #1fb2e4;color:#FFF">'.$answer->ans_name.'</a>&nbsp;&nbsp;&nbsp;';
					}
					
				
				}
				elseif($ques_result->ques_type==5)
				{
					$htmdata .=$ques_result->ques_name;
					$htmdata .='<br>';
					$imgs=$this->main_model->getall('ques_img','ques_id',$ques_result->ques_id);

				
					$htmdata .='<br>';
					
					$answers=$this->questions_model->get_answers1($data['year_id'],$ques_result->ques_id);
					foreach($answers as $answer){
					
					if($answer->has_image==1){
						
					
						
					$htmdata .='<label class="anslabel"><input name="answerid" value="'.$answer->ans_id.'" name="rb" type="radio" id="rb1"><img src="/assets/uploads/ans/'.$answer->ans_name.'"/></label>&nbsp;&nbsp;&nbsp;';
					}
						
					}
					
				}
				elseif($ques_result->ques_type==6)
				{
					$htmdata .=$ques_result->ques_name;
					$htmdata .='<br>';
					$imgs=$this->main_model->getall('ques_img','ques_id',$ques_result->ques_id);
					foreach($imgs as $img){
					for($i=0;$i<$img->repeat;$i++){
					$htmdata .='<img src="/assets/uploads/ans/'.$img->img.'"/>';
					}
					$htmdata .='<br>';
					}
				
					$htmdata .='<br>';
					
					$answers=$this->questions_model->get_answers1($data['year_id'],$ques_result->ques_id);
					foreach($answers as $answer){
					
					$htmdata .='<label class="anslabel"><input name="answerid" value="'.$answer->ans_id.'" name="rb" type="radio" id="rb1"><div>'.$answer->ans_name.'</div></label>&nbsp;&nbsp;&nbsp;';
						
					}
					
				}
				
				elseif($ques_result->ques_type==25){ 
					
					$htmdata .=$ques_result->ques_name;
					$htmdata .='<br>';
					$imgs=$this->main_model->getall('ques_img','ques_id',$ques_result->ques_id);

					
					$htmdata .='<br>';
					$answers=$this->questions_model->get_answers1($data['year_id'],$ques_result->ques_id);
					foreach($answers as $answer){
						
					$htmdata .='<a id ="a1" href="javascript:alert(default functionality)"  style="height: 77px; width: 77px; line-height: 77px; font-size: 50px;background-color: #1fb2e4;color:#FFF" ><input name="answerid" value="'.$answer->ans_id.'" name="rb" type="radio" id="rb1" style="height: 77px; width: 77px; line-height: 77px; font-size: 50px;background-color: #1fb2e4;color:#FFF">'.$answer->ans_name.'</a>&nbsp;&nbsp;&nbsp;';
					}
					
				
				}
				
				elseif($ques_result->ques_type==26)
				{
					$QuesDecoded = base64_decode($ques_result->ques_name); 
					$htmdata .=$QuesDecoded;
					$htmdata .='<br>';
					
				
				}
				
				$htmdata .='<input type="hidden" name="ass_year_id" value="'.$result->ass_year_id.'"/>';
				
				
				}
				if($completed!=1){
				$htmdata .='
				<div>
					<input type="hidden" name="questionid" value="'.$ques_result->ques_id.'"/>
					<input type="hidden" name="action" value="submitanswer"/>	
					<input type="hidden" name="ques_type" value="'.$ques_result->ques_type.'"/>
					<input type="hidden" name="year_id" value="'.$data['year_id'].'"/>
					
					<input type="submit" name="submit" value="Submit">
				</div>';
				}
			 }
				else
				{


				} 
				
				
		$htmdata .='</form>';



