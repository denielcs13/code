<?php include('header.php'); ?>
<?php
    /*Just for your server-side code*/
    header('Content-Type: text/html; charset=ISO-8859-1');
?>

<script src="<?php echo base_url().'assets/ckeditor2/ckeditor.js';?>"></script>
<section id="title-inner" class="bgcolor-text">
<canvas id="demo-canvas"></canvas>
<div class="container">
<div class="text-tit">
<h1>
<span><?php echo $year_dtl->class_name;?> - Exam</span>
</h1>
</div>

</div>
</section>

 <!-- Page Content inner -->
 <?php if($no_exam){
 if($no_exam==1){

	 ?>
	  <section class="about_content content-text syllabus-page space-75">
 <div class="container">
 <div class="row">
  <div class="col-md-12">
  No exam scheduled today
 </div>
 </div>
 </div>
 </section>

 <?php } }
 else{ 
?>
 
 <section class="about_content content-text syllabus-page space-75  page-answer">
 <div class="container">
 <div class="row">
<!-- Bootstrap Tabs -->
	<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
	<div class="tab-content">
											

		<form  name="myForm"  method="post"  id="myForm" action="" onsubmit="return validateForm()">	
		<div class="row">
<!-- Bootstrap Tabs -->
	<div class="col-xs-12 col-sm-12 col-md-9 col-lg-9">
			<div id="question_list">	
			
			<?php 

			if($FirstQuestion != null && $FirstQuestion != "")
			{
				
			
			
				$query_ques=$this->db->query("select * from manage_question_".$year_id." where ques_id='".$FirstQuestion."' ");
				$result=$query_ques->row();
				echo get_question($year_id,$result->ques_id);
				
				?>
				<div>
					<input type="hidden" name="questionid" value="<?php echo $result->ques_id;?>"/>
					<input type="hidden" name="action" value="submitanswer"/>	
					<input type="hidden" name="ques_type" value="<?php echo $result->ques_type;?>"/>
					<input type="hidden" name="year_id" value="<?php echo $year_id;?>"/>
					<input type="hidden" name="ques_class" value="<?php echo $result->ques_class;?>"/>
					<input type="hidden" name="term_id" value="<?php echo $term_id;?>"/>
					<input type="hidden" name="attempt" value="<?php echo $attempt;?>"/>
				</div>
				</div>
				
			
				<button  class="btn-mn btn-3 btn-3e button-org" id="btntestexam">Submit</button>
			
				<?php }
				else
				{ ?>
				  No Question found
				<?php } ?>
			</div>
		<div class="col-xs-12 col-sm-4 col-md-3 col-lg-3" id="timer">
		   <div class="sidebar-play">
		   <h3>Time<br>elapsed</h3>
			<div  class="timeing">
			<ul id="showtimer" style="font-weight:bold: color:green;"></ul> 
			<input type="hidden" name="duration" value="" id="duration" />
			<script>
			// Set the date we're counting down to
			var d1 = new Date (),
				d2 = new Date ( d1 );
			d2.setMinutes ( d1.getMinutes() + 30 );

			var countDownDate = d2.getTime();

			// Update the count down every 1 second
			var x = setInterval(function() {

			  // Get todays date and time
			  var now = new Date().getTime();

			  // Find the distance between now and the count down date
			  var distance = countDownDate - now;

			  // Time calculations for days, hours, minutes and seconds
			  var days = Math.floor(distance / (1000 * 60 * 60 * 24));
			  var hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
			  var minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
			  var seconds = Math.floor((distance % (1000 * 60)) / 1000);

			  // Display the result in the element with id="demo"
			/*  document.getElementById("demo").innerHTML = days + "d " + hours + "h "
			  + minutes + "m " + seconds + "s ";*/
				 document.getElementById("showtimer").innerHTML = '<li><input type="text" placeholder="'+hours+'" /><label>hr</label></li><li><input type="text" placeholder="'+minutes+'" /><label>min</label></li><li><input type="text" placeholder="'+seconds+'" /><label>sec</label></li>';
				$("#duration").val(hours+":"+minutes+":"+seconds);

			  // If the count down is finished, write some text
			  if (distance < 0) {
				clearInterval(x);
				document.getElementById("showtimer").innerHTML = "Time is Over!";
				$("#btntestexam").click();
			  }
			}, 1000);
			</script>
			
			</div>	

		
			</div>			
			</div>			
			</div>			
						
		</form>

</div>

 </div>
 </div>
 </div>
 </section>
 <style>
 .anslabel > input{ /* HIDE RADIO */
  visibility: hidden; /* Makes input not-clickable */
  position: absolute; /* Remove input from document flow */
}
.anslabel > input + img{ /* IMAGE STYLES */
  cursor:pointer;
  border:2px solid transparent;
  border-radius:10px;
  padding:0px;
}
.anslabel > input:checked + img{ /* (RADIO CHECKED) IMAGE STYLES */
  border:2px solid #1278a6;
   padding:0px;
}

.anslabel > input + div{ /* IMAGE STYLES */
  cursor:pointer;
  border:2px solid #00a7dc;
  border-radius:10px;
  padding:10px;
}
.anslabel > input:checked + div{ /* (RADIO CHECKED) IMAGE STYLES */
  border:2px solid #1278a6;
   padding:10px;
}
 </style>
 <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script>  
 <script>

 $('#btntestexam').click(function(event) {
     for (instance in CKEDITOR.instances) {
        CKEDITOR.instances[instance].updateElement();
    }
	 form = $("#myForm").serialize();
		// form = new FormData(this);

	var ques_type=$('input[name="ques_type"]').val();
	ques_type = "["+ques_type+"]";
	parsedText = JSON.parse(ques_type)

	if(parsedText[0]=='1'){
		var x = document.forms["myForm"]["answerid"].value;
		if (x==""){
		   return false;
		}
	}
	else if(parsedText[0]=='22'){
		var val = [];
		$("input[name='answerid[]']:checked").each( function (i) {
          val[i] = $(this).val();
        });
		if(val==""){
			return false;
		}
		
	}	
	else if(parsedText[0]=='26' || parsedText[0]=='32'){
		var x = document.forms["myForm"]["input1"].value;
		if (x==""){
		   return false;
		}
		
	  var atr = $("input[name='input1']").attr('type');
	  if(atr=='checkbox'){
		 var val = [];
		$("input[type='checkbox']:checked").each( function (i) {
          val[i] = $(this).val();
        });
		if(val==""){
			return false;
		}
	  }
	}

     $.ajax({
       type: "POST",
       url: "<?php echo site_url('testajaxcall/ajax_exam'); ?>",
       data: form,

       success: function(data){
         
		    $('#question_list').html(data);
       }

     });
     event.preventDefault();
     return false;  //stop the actual form post !important!

  });
</script>
 <script>
  $("#a1").click(function(event) {
    this.removeAttribute("href");            
    anchorClicked("a1");
  });
  
  $( document ).ready(function() {
    $("#infor").delay(3000).fadeOut("slow");
});

function validateForm() {
    var x = document.forms["myForm"]["answerid"].value;
	
    if (x == "") {
        var r = confirm("You did not complete the question.Are you sure you want to submit?!");
		if (r == true) {
			return true;
		} else {
			return false;
		}
    }
}
 </script>

 <?php
 }

 ?>
   
   
   
   
    
 <!-- Page Content End -->
<?php include('footer.php'); ?>