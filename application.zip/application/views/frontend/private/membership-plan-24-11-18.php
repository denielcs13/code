<?php include('header.php'); ?>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.2/jquery.min.js"></script>
<section id="title-inner" style="background-image:url(<?= base_url('assets/images/contact-bg.jpg')?>);">
<div id="large-header">   
<canvas id="demo-canvas"></canvas>
<div class="container">
<div class="text-tit">
 <div class="bb"></div>
<span class="lefttop-icon"></span>
<h1>
<span>Membership-Plans</span>
</h1>
<span class="rightbotm-icon"></span>
</div>

</div></div>

</section>

<!-- Page Content inner -->
<div  class="about_content login-page forgot-password change-password content-text space-75">

<div class="container">
<div class="row">

<form class="cmxform" id="signupForm" method="post" action="<?php echo  base_url();?>paynow/">

<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">

<div class="row">
<?php
if($planlist)
{
	$userid=$this->session->userdata('user_id');
	
	
	$query_chkpro=$this->db->query("select * from student_promoted  where user_id='".$userid."' and pay_status='pending' order by  pid desc ");
	$num_chkpro=$query_chkpro->num_rows();
	if($num_chkpro > 0)
	{
		$yearchk=$query_chkpro->row();
		$payyear=$yearchk->promote_year;
	}
	else
	{
			$query_chkpro=$this->db->query("select promote_year from student_promoted  where user_id='".$userid."'  ");
			$yearchk=$query_chkpro->row();
			$payyear=$yearchk->promote_year;
	}
	
	$query_chkord=$this->db->query("select * from orders  where userid='".$userid."' and pay_status='confirm' and order_status='active' and year_id='".$payyear."' order by  orderid desc ");
	$num_chkord=$query_chkord->num_rows();
	foreach($planlist as $rowplan)
	{
		if($rowplan->planid==1)
		{
?>	
	<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12"> 
	<div class="box-syllabus">
	<div class="text-content">
	  <ul>
	  <li>
	  <h2><?php echo $rowplan->plan_name;?> Charge $<?php echo number_format($rowplan->plan_price);?></h2>
	  </li>
	 
	  
	  <!-- <li>
	  <?php
	  if($num_chkord > 0)
	  {
		  
?>
<a href="<?php echo  base_url();?>renew-payment/<?php echo $rowplan->planid;?>/<?php echo $payyear;?>" class="button">Buy Now</a>
<?php
	  }
else
{
?>	
	  <a href="<?php echo  base_url();?>paynow/<?php echo $rowplan->planid;?>/<?php echo $payyear;?>" class="button">Buy Now</a>
	  <?php
}
?>
	  <li> -->
	  </ul>
	  <input type="hidden" name="planid" value="<?php echo $rowplan->planid;?>" />
	  <?php
	   $sql_terms=$this->db->query("select * from master_terms order by term_id limit 0,4"); 
	   $row_terms=$sql_terms->result();
	   foreach($row_terms as $termrow)
	   {
		 ?>
	  	<div class="text-content" style="padding:10px;">
		<h3 style="background-color:#f4f4f4;"><input type="checkbox" id="select_all<?php echo $termrow->term_id;?>" name="term_id[]" value="<?php echo $termrow->term_id;?>" /> Term <?php echo $termrow->term_id;?> </h3>
		
		 <div class="row">
		 <?php
		 for($week=1;$week <=10;$week++)
		 {
			 ?>
		  <div class="col-xs-2 col-sm-2 col-md-2 col-lg-2 col-2" style="padding:10px;">
		  <input class="checkbox<?php echo $termrow->term_id;?>" type="checkbox" name="week_id[<?php echo $termrow->term_id;?>][]" value="<?php echo $week;?>" /> Week <?php echo $week;?> 
		  </div>
		  <?php
		 }
		 ?>
		</div>
		
		</div>
		<script type="text/javascript">
$(document).ready(function(){
    $('#select_all<?php echo $termrow->term_id;?>').on('click',function(){
        if(this.checked){
            $('.checkbox<?php echo $termrow->term_id;?>').each(function(){
                this.checked = true;
            });
        }else{
             $('.checkbox<?php echo $termrow->term_id;?>').each(function(){
                this.checked = false;
            });
        }
    });
    
    $('.checkbox<?php echo $termrow->term_id;?>').on('click',function(){
        if($('.checkbox<?php echo $termrow->term_id;?>:checked').length == $('.checkbox<?php echo $termrow->term_id;?>').length){
            $('#select_all<?php echo $termrow->term_id;?>').prop('checked',true);
        }else{
            $('#select_all<?php echo $termrow->term_id;?>').prop('checked',false);
        }
    });
});
</script>
	<?php
	   }
?>	   
	</div>
	<input type="hidden" name="payyear" value="<?php echo $payyear;?>" />

<div class="text-center"><button class="btn-mn btn-3 btn-3e button-org"  id="booknow">Book Now</button></div>
	</div>
	</div>


<?php
		}
	}
}
?>

</div>
</div>
</form>
</div>
</div>

</div>

 <!-- Page Content End -->
 <?php include('footer.php'); ?>
 
 <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>

<script type="text/javascript">
jQuery(document).ready(function(){

    jQuery('#reg_year').change(function(){
		
      var yearid=$('#reg_year').val();
            jQuery.ajax({
                type : 'POST',
                url : '<?php echo BASE_URL.'ajaxcall/yearsprice';?>',
                data : {yearid:yearid}
				,	
        success: function(result){
           // alert(result);
           jQuery( "#priceshow" ).html('Price $'+result);
		    jQuery("#yearprice").val(result);
        }


    });
    });    
});

</script>
