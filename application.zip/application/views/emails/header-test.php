<?php

//$this->session->userdata('login_status');
if($this->session->userdata('profile_update')=='no')
{
    $table="temp_main_user";
}
else
{
    $table="main_user";
}
$usertable=$this->main_model->get_detail($this->db,$table,array('user_id'=>$this->session->userdata('user_id'),'user_type'=>'6'),'single');

if($usertable)
{
    if($usertable->login_status!=$this->session->userdata('login_status'))
    {
      redirect(base_url('logout'));  
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<link rel="shortcut icon" href="<?= base_url('assets/images/favicon.png')?>" />

<link href="<?= base_url('assets/images/60x60.png')?>" rel="apple-touch-icon" />
<link href="<?= base_url('assets/images/76x76.png')?>" rel="apple-touch-icon" sizes="76x76" />
<link href="<?= base_url('assets/images/120x120.png')?>" rel="apple-touch-icon" sizes="120x120" />
<link href="<?= base_url('assets/images/152x152.png')?>" rel="apple-touch-icon" sizes="152x152" />

<meta name="description" content="">
<meta name="author" content="">
<title>The University Of Education </title>

<!-- Bootstrap core CSS -->
<link href="<?= base_url('assets/css/bootstrap.min.css')?>" rel="stylesheet">
<link href="<?= base_url('assets/css/font-awesome.min.css')?>" rel="stylesheet" />
<link href="<?= base_url('assets/css/font-awesome.css')?>" rel="stylesheet" />
<link href="<?= base_url('assets/css/animate.css')?>" rel="stylesheet" />
<link href="<?= base_url('assets/css/404.css')?>" rel="stylesheet" />
<link href="<?= base_url('assets/css/title.css')?>" rel="stylesheet" /> 
<link href="<?= base_url('assets/css/owl.carousel.min.css')?>" rel="stylesheet" />
<link href="<?= base_url('assets/css/owl.carousel.css')?>" rel="stylesheet" />
<script src="https://cdnjs.cloudflare.com/ajax/libs/modernizr/2.6.2/modernizr.min.js"></script>
<script src="<?= base_url('assets/js/wow.min.js')?>"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
<script src='<?= base_url('assets/js/unispeech.js')?>'></script>
<!-- Custom styles for this template -->
<link href="<?= base_url('assets/style.css')?>" rel="stylesheet">
</head>

<body>
	<header class="header fadeInDown" >
		<div class="container">
			<div class="row">
				<div class="col-xs-12 col-sm-4 col-md-2 col-lg-2 logo-sect">
					<div class="logo text">
						<a href="index.php"><img src="images/logo.png"></a>
					</div>
				</div>
				<div class="col-xs-12 col-sm-8 col-md-10 col-lg-10 text-right">
					<div class="btnButton">
						<ul>
							<li class="hoveMenu">
								<a href="#">Courses</a>
								<ul class="hoMenu">
									<li><a href="#">Kindergarten</a></li>
									<li><a href="#">Year 1</a></li>									
									<li><a href="#">Year 2</a></li>									
									<li><a href="#">Year 3</a></li>									
									<li><a href="#">Year 4</a></li>									
									<li><a href="#">Year 5</a></li>									
								</ul>
							</li>
							<li>
								<a href="#">Country</a>
							</li>
							<li>
								<a href="#">Login</a>
							</li>
							<li>
								<a href="#" class="btnBox">Sign up</a>
							</li>
						</ul>
					</div>
				</div>
			</div>
		</div>
	</header>
