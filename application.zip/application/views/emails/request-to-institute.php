<!DOCTYPE HTML>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>My Uni Education Group Ltd</title>
<style>
* {
	margin:0px;
	padding:0px;
}
html, body {
	margin:0px;
	padding:0px;
	font-size:18px;
	line-height:20px;
	font-family:Arial, Helvetica, sans-serif; 
	color:#000;
}
img {
	max-width:100%;
}
h3 {
	font-size:24px;
	font-weight:normal;
}
.container {
	width:80%;
	margin:0 auto;
	max-width:600px;
	padding:0px;
}

.btn {
	background:#005e82;
	padding:5px;
	display: inline-block;
	color: #fff;
	text-decoration: none;
	width:120px;
}
.footer {
	text-align:left;
	font-size:12px;
	font-weight:bolder;
	line-height:18px;
	width:100%;
	float:left;
	background: #000;
	color: #fff;
	padding:15px;
	box-sizing: border-box;
}
.footer .detail strong {
	font-size:16px;
	font-weight:bolder;
	line-height:22px;
}
.footer .detail strong i {
	font-size:12px;
	text-transform:uppercase;
}

strong {
	font-weight:bold;
}
 .tableBox tr:nth-child(even) {
 background:#f2f2f2;
}
table {
	font-size:14px; 
}
table p {
	font-size:12pt;
	line-height:25px;
	padding-bottom:5px;
}
table h2 {
	padding: 0 0 12px 0;
	font-weight: 400;
	font-size:22px;
}
.footer .detail td p {
	padding-bottom:0px;
	font-size:14px; 
	line-height:20px;
}
table .tableBox {
	font-size:14px;
}
 
table .tableBox td {
	padding-left:8px;
	line-height:32px;
}

table .tableBox td  p{ padding-bottom:0px; font-size:14px;}

table h3 {
	font-size:24px;
	line-height: 32px;
	color:#FFF;
	font-weight:700;
}
.footer-text{ padding:0 10px;}
.footer-text p{color:#fff; padding-bottom:0px; font-size:10pt; line-height:17px;}
.footer-text p a{color:#fff;}
table p{ padding:0 15px;}
.footer-text p{ padding:0px;}
.left-padding-15{ padding-left:15px;}
 @media only screen and (max-width:400px) {
	 .btn{ margin-bottom:15px;}
	 .container {
	width:70%;
	margin:0 auto;
	max-width:320px;
	padding:0px;
}


}
</style>
</head>

<body style="background:#d0d0d0;">
<table width="100%" border="0" cellspacing="0" cellpadding="0" class="container" bgcolor="#ffffff">
  <tr bgcolor="#d0d0d0">
    <td height="15"></td>
  </tr>
  <tr>
    <td><table width="100%" border="0" cellspacing="15" cellpadding="0">
        <tr>
          <td align="center"><a href="<?= base_url();?>"><img src="<?= base_url();?>assets/images/logo.png" alt="" width="156" height="134" /></a></td>
        </tr>
      </table></td>
  </tr>

  <tr>
    <td align="center" valign="top" bgcolor="#f4f4f4"><table width="90%" border="0" align="center" cellpadding="0" cellspacing="0">
      <tr>
        <td height="10"></td>
      </tr>
      <tr>
        <td>&nbsp;</td>
      </tr>
      <tr>
        <td><p>Dear Institute</p></td>
      </tr>
      <tr>
        <td height="15"></td>
      </tr>
      <tr>
        <td><p>I'm <?php echo ucfirst($first_name);?> here, Please add me in your Institute, details are as follows: 
          </p></td>
      </tr>
      <tr>
        <td height="15"></td>
      </tr>
      <tr>
        <td class="left-padding-15"><table width="400" border="0" cellspacing="0" cellpadding="0">
          <tr>
            <td width="143"><strong>Student&rsquo;s Name : </strong></td>
            <td width="257"><?php echo ucfirst($first_name);?></td>
            </tr>
          <tr>
            <td><strong>Student&rsquo;s  Email ID : </strong></td>
            <td><?php echo $email;?></td>
            </tr>
          
          </table></td>
      </tr>
      <tr class="container">
        <td height="15" align="center"></td>
      </tr>
      
      
      <tr>
        <td>&nbsp;</td>
      </tr>
      <tr>
        <td height="10"></td>
      </tr>
    </table></td>
  </tr>
  
  <tr bgcolor="#69c4a9">
    <td height="15" align="center" bgcolor="#485052"></td>
  </tr>
  <tr bgcolor="#69c4a9">
    <td height="15" align="left" bgcolor="#485052"  style="padding:10px;"><img src="https://www.myunieducation.com/wp-content/themes/myunieducation/images/logo.png" alt="" width="111" height="111" /></td>
  </tr>
  <tr bgcolor="#69c4a9">
    <td align="left" bgcolor="#485052" style="padding:10px;"><h3>MY UNI EDUCATION GROUP LIMITED</h3></td>
  </tr>
  <tr bgcolor="#485052">
    <td align="center" style="padding:0px;"><table width="100%" border="0" align="center" cellpadding="0" cellspacing="0">
      <tr>
        <td align="left" bgcolor="#485052" class="footer-text"><p><strong>Tel:</strong> (+64) 022 645 8491</p>
          <p><strong>Email:</strong> <a href="mailto:ask@myunieducation.com">ask@myunieducation.com</a></p>
          <p><strong>Headquarters  Address:</strong> 2A Wagener Place, Mt Albert, Auckland, 1025, New Zealand</p>
          <p><strong>Website:</strong> <a href="<?php echo base_url();?>">www.myunieducation.com</a></p></td>
      </tr>
      <tr>
        <td align="left" bgcolor="#485052" class="footer-text">&nbsp;</td>
      </tr>
      </table></td>
  </tr>
 
</table>
</body>
</html>
