<!DOCTYPE HTML>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Change Password - The University of Maths</title>
<style>


@font-face {
  font-family: 'Verlag-Bold';
  src: url('fonts/Verlag-Bold.eot') format('embedded-opentype');
  font-weight: normal;
  font-style: normal;
}

@font-face {
  font-family: 'Verlag-Bold';
  src:  url('fonts/Verlag-Bold.otf')  format('opentype'),
	     url('fonts/Verlag-Bold.woff') format('woff'), url('fonts/Verlag-Bold.ttf')  format('truetype'), url('fonts/Verlag-Bold.svg#Verlag-Bold') format('svg');
  font-weight: normal;
  font-style: normal;
}

@font-face {
  font-family: 'Verlag-Book';
  src: url('fonts/Verlag-Book.eot') format('embedded-opentype');
  font-weight: normal;
  font-style: normal;
}

@font-face {
  font-family: 'Verlag-Book'; 
  src:  url('fonts/Verlag-Book.otf')  format('opentype'),
	     url('Verlag-Book.woff') format('woff'), url('fonts/Verlag-Book.ttf')  format('truetype'), url('fonts/Verlag-Book.svg#Verlag-Book') format('svg');
  font-weight: normal;
  font-style: normal;
}

* {
	margin:0px;
	padding:0px;
}
html, body {
	margin:0px;
	padding:0px;
	font-size:18px;
	line-height:32px;
	  font-family: 'Verlag-Book'; 
	color:#000;
}
img {
	max-width:100%;
}
h3 {
	font-size:24px;
	font-weight:normal;
}
.container {
	width:80%;
	margin:0 auto;
	max-width:600px;
	padding:0px;
}

.btn {
	background:#005e82;
	padding:5px;
	display: inline-block;
	color: #fff;
	text-decoration: none;
	width:120px;
}
.footer {
	text-align:left;
	font-size:12px;
	font-weight:bolder;
	line-height:18px;
	width:100%;
	float:left;
	background: #000;
	color: #fff;
	padding:15px;
	box-sizing: border-box;
}
.footer .detail strong {
	font-size:16px;
	font-weight:bolder;
	line-height:22px;
}
.footer .detail strong i {
	font-size:12px;
	text-transform:uppercase;
}

strong {
	font-weight:bold;
}
 .tableBox tr:nth-child(even) {
 background:#f2f2f2;
}
table {
	font-size:14px; 
}
table p {
	font-size:12pt;
	line-height:25px;
	padding-bottom:15px;
}
table h2 {
	padding: 0 0 12px 0;
	font-weight: 400;
	font-size:22px;
}
.footer .detail td p {
	padding-bottom:0px;
	font-size:14px; 
	line-height:20px;
}
table .tableBox {
	font-size:14px;
}
 
table .tableBox td {
	padding-left:8px;
	line-height:32px;
}

table .tableBox td  p{ padding-bottom:0px; font-size:14px;}

table h3 {
	font-size:24px;
	line-height: 32px;
	color:#FFF;
	  font-family: 'Verlag-Bold';
}

 @media only screen and (max-width:400px) {
	 .btn{ margin-bottom:15px;}
}
</style>
</head>

<body style="background:#d0d0d0;">
<table width="100%" border="0" cellspacing="0" cellpadding="0" class="container" bgcolor="#ffffff">
  <tr bgcolor="#d0d0d0">
    <td height="15"></td>
  </tr>
  <tr>
    <td><table width="100%" border="0" cellspacing="15" cellpadding="0">
        <tr>
          <td><a href="<?= base_url();?>"><img src="<?= base_url('assets/images/logo.png')?>" alt="" /></a></td>
        </tr>
      </table></td>
  </tr>

  <tr>
    <td align="center" valign="top" bgcolor="#e7f6f1"><table width="85%" border="0" align="center" cellpadding="0" cellspacing="0">
      <tr>
        <td height="10"></td>
      </tr>
      <tr>
        <td><p>Hi <?php echo $fullname;?>,</p></td>
      </tr>
      <tr>
        <td>
		<p>Password Reset Successfully!</p>
		<p>Your password has been changed to: <?php echo $password;?></p>
          <p>Login with your new password to access your account.</p>
         </td>
      </tr>
      <tr>
        <td height="10"></td>
      </tr>
    </table></td>
  </tr>
  
  <tr bgcolor="#69c4a9">
    <td height="15" align="center"></td>
  </tr>
  <tr bgcolor="#69c4a9">
    <td align="center"><h3>The University of Maths</h3></td>
  </tr>
  <tr bgcolor="#69c4a9">
    <td align="center"><table width="100%" border="0" align="center" cellpadding="0" cellspacing="12">
        <tr>
          <td width="100%" align="center"><a href="<?= base_url();?>" class="btn">Log In</a></td>
        </tr>
      </table></td>
  </tr>
  <tr bgcolor="#69c4a9">
    <td height="15" align="center"></td>
  </tr>
  <tr bgcolor="#69c4a9">
    <td align="center"></td>
  </tr>
  <tr bgcolor="#122f57" class="footer">
    <td valign="top"><table width="100%" border="0" cellspacing="0" cellpadding="0" class="detail">
        <tr>
          <td width="420" valign="top"><table width="100%" border="0" cellspacing="0" cellpadding="0">
              <tr>
                <td><strong>My Uni Education - <i>HEADQUARTERS</i></strong></td>
              </tr>
              <tr>
                <td height="5"></td>
              </tr>
              <tr>
                <td><p>2A Wagener Place, Mt Albert,</p>
                  <p>Auckland</p>
                  <p>Phone: +64 0226458491</p>
                  <p>ask@myunieducation.com</p></td>
              </tr>
            </table></td>
          <td width="422" valign="top"><table width="100%" border="0" cellspacing="0" cellpadding="0">
              <tr>
                <td align="right"><table width="50%" border="0" cellspacing="0" cellpadding="0">
                    <tr>
                      <td width="79%" align="right" valign="top">Follow us on</td>
                      <td width="21%" align="center"><a href="" target="_blank"><img src="" alt="facebook" width="20" height="20" border="0" /></a></td>
                    </tr>
                  </table></td>
              </tr>
              
            </table></td>
        </tr>
      </table></td>
  </tr>
  <tr bgcolor="#d0d0d0">
    <td>&nbsp;</td>
  </tr>
</table>
</body>
</html>
