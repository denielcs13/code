<?php 
defined('BASEPATH') OR exit('No direct script access allowed');
//include 'header.php';

 ?>
<div class="counterBox"></div>

<!-- Main Content -->
<div class="page-wrapper">
<?php 
	if($this->session->flashdata('success_msg') != null && $this->session->flashdata('success_msg') != "")
		{ 
		?>
		<div class="row">
			<div class="col-md-12">
				<div style="margin-top:18px;" class="alert alert-success fade in">
					<?php echo $this->session->flashdata('success_msg');?>
				</div>
			</div>
		</div>
	<?php 
		} 
	?>
    


<!-- Main Content -->		
<?php //include 'footer.php'; ?>        