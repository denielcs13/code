
  
		   <div class="page-wrapper page-container dashboard-section depertment-sec">
		   <div class="container-fluid page-content-wrapper">
                <!-- BEGIN CONTENT BODY -->
                <!-- Breadcrumb -->
				<div class="row heading-bg headingMain">
					<div class="col-lg-12 col-md-12">
					  <ol class="breadcrumb">
						<li><a href="<?php echo BASE_URL_MATH_ADMIN;?>">Dashboard</a></li>
						<li class="active"><span>Syllabus</span></li>
					  </ol>
					</div>
				</div>
					<!-- /Breadcrumb -->
					
				<div class="row">
                    <div class="col-md-12">
						
                            <!-- CONTENT HEAR -->    
                            <div class="tab-pane" id="tab_2">
                                <?php 
								if($this->session->flashdata('success_msg') != null && $this->session->flashdata('success_msg') != "")
								{ 
								?>
								<div class="row">
									<div class="col-md-12">
										<div style="margin-top:18px;" class="alert alert-success fade in">
											<?php echo $this->session->flashdata('success_msg');?>
										</div>
									</div>
								</div>
								<?php 
								} 
								?>	
                                <form action="<?=base_url('math-admin/adminmgmt/syllabus-order/'.$year_dtl->class_name)?>" method="post">
								<div class="panel panel-default card-view">	
									
									<!-- <div class="heading_title">
										<i class="fa fa-gift"></i> Edit/Delete Departmeant
                                    </div>-->
                                           
									
										<div class="panel-heading sidebox">
											<div class="pull-left caption">
											<h6 class="panel-title txt-dark titleP">syllabus-order <?php echo $year_dtl->class_name;?></h6>
											</div>
											
										<div class="pull-right">
												<!--<a href="<?php echo BASE_URL_MATH_ADMIN;?>/syllabus/add_syllabus_pre">
													<button type="submit" class="btn btn-success edit  pull-right">Add New</button>
													
												</a>-->
												
											</div>
											<div class="clearfix"></div>
										</div>
											
											  <!-- BEGIN FORM-->
                                        <div class="panel-wrapper collapse in portlet-body">
											<div class="panel-body styBox">
												<div class="table-wrap sortable" id="sortable">
													<?PHP 
                                                    $i=1;
                                                    foreach($SylList as $SylListDetail):
                                                     ?>
													<div class="colBox2">
                                                          <span skillid="<?=$SylListDetail->skill_id?>" id="<?=$i;?>" ><?=$SylListDetail->skill_name?></span>
                                                    </div>
                                                    <?PHP
                                                     $i++;
                                                    endforeach;
                                                    ?>
												</div>
                                                
                                                <?PHP 
                                                    $i=1;
                                                    foreach($SylList as $SylListDetail):
                                                     ?>
													<div class="colBox2 colBoxInput">
                                                        <input type="text" hidden="" id="<?='input'.$i?>" name="<?=$i?>"  value="" />
                                                    </div>
                                                    <?PHP
                                                     $i++;
                                                    endforeach;
                                                    ?>                                                    
													</div>
													<button class="btn btn-primary" type="submit">Save Order</button>
                                            </div>			 
                                        </div>
                                        
                                        </form>
										<!-- END FORM-->
                                    
                               
                            </div>
						</div>	
                        <!-- END CONTENT HEAR -->                               
                    </div>
                </div>
			<script>
   $(function(){
   $("#sortable").sortable({
   
    start: function(e, ui) {
        $(this).attr('data-previndex', ui.item.index());
    },
    stop: function(e, ui) {
        var newIndex = ui.item.index();
        var validex  = newIndex+1;
        var oldIndex = $(this).attr('data-previndex');
        var element_id = ui.item.children().text();
        var $i=1;
        $.map($(this).children('.colBox2 ').find('span'), function(el) {
                 
                 //console.log(el.id + ' = '+i + $(el).text());
                 $('#input'+$i).val($(el).attr('skillid'));
                 $i++;
                 
            });
        $(this).removeAttr('data-previndex');
    }
});
$("#sortable").disableSelection(); 
   })
 
  </script>	
              