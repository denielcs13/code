<style>

   .pagin{

   }

   .pagin strong {

   text-decoration: none;

   color: #212121;

   font-weight: bold;

   border: 1px solid;

   color: white;

   background: blueviolet;

   }

   .pagin a {

   padding: 10px;

   border: 1px solid;

   }

   .add_answer_row{

    padding-left:15px;

    padding-right:15px;

    

   }

</style>

<div class="basic-form-area mg-b-15">
 <div class="container-fluid">

  <!-- /Title -->

   <?php 
 
     //var_dump($userdetails);die;
      if($this->session->flashdata('success_msg') != null && $this->session->flashdata('success_msg') != "")

      		{ 

      		?>

   <div class="row">

      <div class="col-md-12">

         <div style="margin-top:18px;" class="alert alert-success fade in">

            <?php echo $this->session->flashdata('success_msg');?>

         </div>

      </div>

   </div>

   <?php 

      }else if($this->session->flashdata('pflupd') != null && $this->session->flashdata('pflupd') != "")

      		{ 

      		?>

   <div class="row">

      <div class="col-md-12">

         <div style="margin-top:18px;" class="alert alert-success fade in">

            <?php echo $this->session->flashdata('pflupd');?>

         </div>

      </div>

   </div>

   <?php 

      } 

      ?>	

   <div class="row">

      <!-- Bordered Table -->

      <div class="col-sm-12">

         <div class="sparkline12-list">
	  <div class="sparkline12-hd">
                                <div class="main-sparkline12-hd">
                                    <h1><?=ucwords(str_replace('-',' ',$this->uri->segment(3)))?></h1>
                                </div>
                            </div> 

         <div class="sparkline12-graph">
          <div class="basic-login-form-ad">

               <div class="panel-body">

                  <div class="panel-body">

                     <div class="table-wrap">

                        <div class="">

                          <form method="post" action="<?=base_url(MAIN_ADMIN.'/edit-user/'.$this->uri->segment(4))?>">

                           

                           <div class="mainskill">

                               <div style="margin-bottom: 10px;"  class="row">
 
                                    <div class="col-lg-1">

                                        <label>Email</label>

                                   </div>
								   
                                    <div class="col-lg-4">

                                        <input class="form-control" name="email" value="<?=$userdetails->email;?>" type="text" placeholder="Enter email" />
                                   
                                   </div>
								   <?php if($userdetails->user_type=='6'){?>
								   <div class="col-lg-1">

                                        <label>Class</label>

                                   </div>

                                   <div class="col-lg-4">

                                        <select class="form-control custom-select" data-placeholder="Select Class" name="class_name" tabindex="1">
				 <option value="">Select</option>
				<option value="<?= $userdetails->class_name; ?>" <?= ((isset($userdetails->class_name) && $userdetails->class_name == $userdetails->class_name) || ($userdetails->class_name == set_value('class_name'))) ? 'selected' : ''; ?>><?php 
				if(!empty($userdetails->class_name)){
					if($userdetails->class_name=='1'){
					echo "Kindergarten";
				}else
				{
					echo "Year ".($userdetails->class_name - 1);
					
				}
				}else{
				echo "";	
				} ?></option>
				<option value="1">Kindergarten</option>

                      
                      <option value="2">Year 1</option>

                      
                      <option value="3">Year 2</option>

                      
                      <option value="4">Year 3</option>

                      
                      <option value="5">Year 4</option>

                      
                      <option value="6">Year 5</option>

                      
                      <option value="7">Year 6</option>

                      
                      <option value="8">Year 7</option>

                      
                      <option value="9">Year 8</option>

                      
                      <option value="10">Year 9</option>

                      
                      <option value="11">Year 10</option>

                      
                      <option value="12">Year 11</option>

                      
                      <option value="13">Year 12</option>

                      
                      <option value="14">Year 13</option>
				</select>

                                   </div>
								   <?php } ?>	
								   
								   <?php if($userdetails->user_type=='7'){?>
                                   <div class="col-lg-1">

                                        <label>#Childrens</label>

                                   </div> 
								<div class="col-lg-4">								   
								<input class="form-control" name="chldr_num" type="text" value="<?=$userdetails->chldr_num;?>" placeholder="#Childrens" />
							    </div>
            
		                     <?php } ?>	

                                   <div class="col-lg-2">

                                        <!--<button class="btn btn-primary Sub-Skill" type="button">Add More Sub-Skill</button>

                                   -->

                                   </div>

                               

                               </div>
							   
							   <div style="margin-bottom: 10px;"  class="row">

                                    <div class="col-lg-1">

                                        <label>Name</label>

                                   </div>

                                   <div class="col-lg-4">

                                        <input class="form-control" name="first_name" type="text" value="<?=$userdetails->first_name;?>" placeholder="Enter Name" />
                                    <span class="danger-error"><?=form_error('first_name')?></span>
                                   </div>
                                    <div class="col-lg-1">

                                        <label>Phone</label>

                                   </div>
								   
                                    <div class="col-lg-4">

                                        <input class="form-control phone" name="phone" value="<?=$userdetails->phone;?>" type="text" placeholder="Enter phone" />
                                    <span class="danger-error"><?=form_error('phone')?></span>
                                   </div>

                                   <div class="col-lg-2">

                                        <!--<button class="btn btn-primary Sub-Skill" type="button">Add More Sub-Skill</button>

                                   -->

                                   </div>

                               

                               </div>
							   <?php if($userdetails->user_type=='8'){?>
                                   <div style="margin-bottom: 10px;"  class="row">

                                    <div class="col-lg-1">

                                        <label>Institute Name</label>

                                   </div>

                                   <div class="col-lg-4">

                                        <input class="form-control" name="inst_name" type="text" value="<?=($userdetails->inst_name)?$userdetails->inst_name:set_value('inst_name')?>" placeholder="Enter Name" />

                                   </div>
                                    <div class="col-lg-1">

                                        <label>Type</label>

                                   </div>
								   
                                    <div class="col-lg-4">

                                        <select class="form-control custom-select" data-placeholder="Select Type" name="inst_type" tabindex="1">
										<option value="" >Type</option>
										<option value="<?= $userdetails->inst_type; ?>" <?= ((isset($userdetails->inst_type) && $userdetails->inst_type == $userdetails->inst_type) || ($userdetails->inst_type == set_value('inst_type'))) ? 'selected' : ''; ?>><?= $userdetails->inst_type; ?></option>
										 <option value="School">School</option>
										 <option value="College">College</option>
										 <option value="Tutoring Center">Tutoring Center</option>
								 </select>

                                   </div>

                                   <div class="col-lg-2">

                                        <!--<button class="btn btn-primary Sub-Skill" type="button">Add More Sub-Skill</button>

                                   -->

                                   </div>

                               

                               </div>
							   <div style="margin-bottom: 10px;"  class="row">

                                    <div class="col-lg-1">

                                        <label>Designation</label>

                                   </div>

                                   <div class="col-lg-4">
                                        <select class="form-control custom-select" data-placeholder="Select Country" name="dsgn_name" tabindex="1">                     <option value="" >Select</option>                     <option value="<?= $userdetails->dsgn_name; ?>" <?= ((isset($userdetails->dsgn_name) && $userdetails->dsgn_name == $userdetails->dsgn_name) || ($userdetails->dsgn_name == set_value('dsgn_name'))) ? 'selected' : ''; ?>><?= $userdetails->dsgn_name; ?></option>
                                        <option value="Admin">Admin</option>
										<option value="Principal">Principal</option>
										<option value="Teacher">Teacher</option>
										</select>

                                   </div>
                                    
								   
								</div>
            
		                     <?php } ?>	
							   <div style="margin-bottom: 10px;"  class="row">

                                    <div class="col-lg-1">

                                        <label>Country</label>

                                   </div>

                                   <div class="col-lg-4">
                                <select id="country3" name ="country" class="form-control custom-select countries">
							   <option value="">Select Country</option>
							   <?php
							if(!empty($country_list))
							{
								foreach($country_list as $countries)
								{
									?>
							   <option value="<?= $countries->id; ?>" <?= ((isset($userdetails->country) && $countries->id == $userdetails->country) || ($countries->id == set_value('country'))) ? 'selected' : ''; ?>><?= $countries->name; ?></option>
							   <?php
								}
							}
							?>
							   
				              </select>
                                        
                                    <span class="danger-error"><?=form_error('country')?></span>
                                   </div>
                                    <div class="col-lg-1">

                                        <label>City</label>

                                   </div>
								   
                                    <div class="col-lg-4">

                                        <input class="form-control" name="city" value="<?=$userdetails->city;?>" type="text" placeholder="Enter city" />
                                    <span class="danger-error"><?=form_error('city')?></span>
                                   </div>

                                   <div class="col-lg-2">

                                        <!--<button class="btn btn-primary Sub-Skill" type="button">Add More Sub-Skill</button>

                                   -->

                                   </div>

                               

                               </div>							   
							   <div style="margin-bottom: 10px;"  class="row">

                                    <div class="col-lg-1">

                                        <label>State</label>

                                   </div>

                                   <div class="col-lg-4">
                                 <select name ="state" id ="state3" class="form-control custom-select states" >
							   <option value="">Select State</option>
							   
							   <?php
							if(!empty($state_list))
							{
								foreach($state_list as $states)
								{
									?>
							   <option value="<?= $states->id; ?>" <?= ((isset($userdetails->state) && $states->id == $userdetails->state) || ($states->id == set_value('state'))) ? 'selected' : ''; ?>><?= $states->name; ?></option>
							   <?php
								}
							}
							?>
				               </select>                                        
                                <span class="danger-error"><?=form_error('state')?></span>
                                   </div>
                                    <div class="col-lg-1">

                                        <label>Zip Code</label>

                                   </div>
								   
                                    <div class="col-lg-4">

                                        <input class="form-control" name="zipcode" value="<?=$userdetails->zipcode;?>" type="text" placeholder="Enter zipcode" />
                                     <span class="danger-error"><?=form_error('zipcode')?></span>
                                   </div>

                                   <div class="col-lg-2">

                                        <!--<button class="btn btn-primary Sub-Skill" type="button">Add More Sub-Skill</button>

                                   -->

                                   </div>

                               

                               </div>

                               

                           </div>

                           <div class="pull-right" style="padding-right:108px ;">
                               <input type="hidden" name="user_id" value="<?=$userdetails->user_id;?>">
							   <input type="hidden" name="user_type" value="<?=$userdetails->user_type;?>">
							   
                               <input type="submit" class="btn btn-success" name="skillupadte" value="Update" />

                               </div>

                          

                          </form> 

                     </div>

                  </div>

               </div>

            </div>
			 </div>

      </div>

      <!-- /Bordered Table -->

   </div>

</div>
</div>

<script>
function ajaxCall() {
        this.send = function(data, url, method, success, type) {
          type = type||'json';
          var successRes = function(data) {
              success(data);
          }

          var errorRes = function(e) {
              console.log(e);
              alert("Error found \nError Code: "+e.status+" \nError Message: "+e.statusText);
          }
            $.ajax({
                url: url,
                type: method,
                data: data,
                success: successRes,
                error: errorRes,
                dataType: type,
                timeout: 60000
            });

          }

        }

function locationInfo() {
    //var rootUrl = "apiv1.php";
    var call = new ajaxCall();
	
    this.getStates = function(id) {
        $(".states option:gt(0)").remove();       
        var url1 = '<?=base_url('unieducation/all_states_list/');?>';
        var method = "post";
        var data = {country_id:id};
        $('.states').find("option:eq(0)").html("Please wait..");
        call.send(data, url1, method, function(data) {
            $('.states').find("option:eq(0)").html("Select State");
            if(data.success == true){
                $.each(data.state_lst, function (item, i) {
                                $('.states').append('<option value="' + i.id + '">' + i.name +'</option>');
                            });
                $(".states").prop("disabled",false);
            }
            else{
                alert(data.msg);
            }
        }); 
    };

    this.getCountries = function() {
        var url = '<?=base_url('unieducation/all_country_list');?>';
        var method = "post";
        var data = {};
        $('.countries').find("option:eq(0)").html("Please wait..");
        call.send(data, url, method, function(data) {
            $('.countries').find("option:eq(0)").html("Select Country");
            console.log(data);
            if(data.success == true){
                $.each(data.country_lst, function (item, i) {
                                $('.countries').append('<option value="' + i.id + '">' + i.name +'</option>');
                            });
                $(".countries").prop("disabled",false);
            }
            else{
                alert(data.msg);
            }
        }); 
    };

}

$(function() {
var loc = new locationInfo();
loc.getCountries();
 $(".countries").on("change", function(ev) {
        var countryId = $(this).val()
        if(countryId != ''){
        loc.getStates(countryId);
        }
        else{
            $(".states option:gt(0)").remove();
        }
    });
 // $(".states").on("change", function(ev) {
        // var stateId = $(this).val()
        // if(stateId != ''){
        // loc.getCities(stateId);
        // }
        // else{
            // $(".cities option:gt(0)").remove();
        // }
    // });
});

</script>
<script type="text/javascript">
$(".phone").keyup(function() {
	//var number = $(this).val().replace(/[^\d]/g, '');
    //$(this).val(number.replace(/^(\d{3})(\d{3})(\d)+$/, "$1-$2-$3"));
	
	var number = $(this).val().replace(/[^\d]/g, '')
    if (number.length == 7) {
      number = number.replace(/(\d{3})(\d{4})/, "$1-$2");
    } else if (number.length == 10) {
      number = number.replace(/(\d{3})(\d{3})(\d{4})/, "$1-$2-$3");
     
    }
    $(this).val(number)
    $(".phone").attr({ maxLength : 10 });
});
</script>