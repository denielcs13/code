<div class="data-table-area mg-b-15">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                        <div class="sparkline13-list">
                            <div class="sparkline13-hd">
                                <div class="main-sparkline13-hd">
                                    <h1><?=$page?>  <span class="table-project-n">List</span> </h1>
                                </div>
                            </div>
                            <div class="sparkline13-graph">
                                <div class="datatable-dashv1-list custom-datatable-overright">
                                    <div id="toolbar">
                                        <select class="form-control dt-tb">
											<option value="">Export Basic</option>
											<option value="all">Export All</option>
											<option value="selected">Export Selected</option>
										</select>
                                    </div>
                                    <table id="table" data-toggle="table" data-pagination="true" data-search="true" data-show-columns="true" data-show-pagination-switch="true" data-show-refresh="true" data-key-events="true" data-show-toggle="true" data-resizable="true" data-cookie="true"
                                        data-cookie-id-table="saveId" data-show-export="true" data-click-to-select="true" data-toolbar="#toolbar">
                                        <thead>
                                            <tr>
                                                <th data-field="state" data-checkbox="true"></th>
                                                <th data-field="id">#</th>
                                                <th data-field="name" data-editable="true">Name</th>
                                                <th data-field="email" data-editable="true">Email</th>
												<?php if($role_lst!='user'){?>
                                                                    <th>No. Students</th>
                                                                     <?php }?>
                                                <th data-field="complete">Status</th>
												<th data-field="action">Action</th>
                                            </tr>
                                        </thead>
                                        <tbody>
										<?PHP 
													
                                                    $i=1;                                                   
                                                    foreach($userlists as $userlist):
													?>
                                            <tr>
                                                <td></td>
                                                <td><?=$i?></td>
                                                <td><?=$userlist->first_name?></td>
                                                <td><?=$userlist->email?></td>
                                                <?php if($role_lst!='user'){?>						 
						 <td><?php //$rtp=$userlist->role_type;
                            $count=$this->main_model->num_student('main_user',$userlist->user_id);
							if($count==0){
                            echo $count;
							}else{?>
							<a href="<?=base_url(MAIN_ADMIN.'/student-list/'.$userlist->user_id)?>" target="_blank"><?=$count?></a>	
							<?php }
							
						 ?>
						 
						 </td>
						<?php  } ?>
                                                <td><a class="pull-left"  href="<?=base_url(MAIN_ADMIN.'/active-user/'.$userlist->user_id.'/'.$userlist->status)?>">
						 	                                        <?php if($userlist->status=='1'){?>
                                                                     Active
                                                                 <?php } else { ?>
                                                                 	Inactive
                                                             <?php  } ?>
                                                                  </a>
                                                              </td>
                                                
                                                <td>
                                                                  <a href="<?=base_url(MAIN_ADMIN.'/edit-user/'.$userlist->user_id)?>" target="_blank" class="mr-25" data-toggle="tooltip" data-original-title="Edit">
                                                               <i class="fa fa-pencil" aria-hidden="true"></i></a> | <a href="<?=base_url(MAIN_ADMIN.'/delete-user/'.$userlist->user_id)?>" data-toggle="tooltip"  data-original-title="Delete">
                                                               <i class="fa fa-trash text-danger" aria-hidden="true"></i></a>
                                                              </td>
                                            </tr>
											<?PHP
                                                     $i++;
                                                    endforeach;
                                                    ?>
                                            
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>