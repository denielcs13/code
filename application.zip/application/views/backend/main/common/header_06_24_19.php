<?php
if($this->session->userdata('role_type')=="super_admin")
            {
               
            }else{
                 //echo 'dffd';
                 $this->session->set_flashdata('error','You are not authorized to access!!!');
                 redirect(base_url('adminmgmt'));
            }
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
	<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
	<title>The University Of Maths</title>
	
	<!-- Favicon -->
	<link rel="shortcut icon" href="favicon.ico">
	<link rel="icon" href="favicon.ico" type="image/x-icon">
	<!-- Custom CSS -->
	<link href="<?= base_url('assets/admin/dist/css/style.css')?>" rel="stylesheet" type="text/css">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
   <script src="<?=base_url('assets/ckeditor4/ckeditor.js')?>"></script>
</head>

<body>
	<!-- Preloader -->
	<div class="preloader-it">
		<div class="la-anim-1"></div>
	</div>
	<!-- /Preloader -->
    <div class="wrapper box-layout theme-1-active pimary-color-blue">
		<!-- Top Menu Items -->
		<nav class="navbar navbar-inverse navbar-fixed-top">
			<div class="mobile-only-brand pull-left">
				<div class="nav-header pull-left">
					<div class="logo-wrap">
						<a href="index.php" class="barndBox">
							<img class="brand-img" src="<?= base_url(LOGO_ICON)?>" alt="brand"/>
							<span class="brand-text"><?=PROJECT_NAME?></span>
						</a>
					</div>
				</div>	
				<a id="toggle_nav_btn" class="toggle-left-nav-btn inline-block ml-20 pull-left leftBar" href="javascript:void(0);"><i class="zmdi zmdi-menu"></i></a>
				<a id="toggle_mobile_search" data-toggle="collapse" data-target="#search_form" class="mobile-only-view" href="javascript:void(0);"><i class="zmdi zmdi-search"></i></a>
				<a id="toggle_mobile_nav" class="mobile-only-view" href="javascript:void(0);"><i class="zmdi zmdi-more"></i></a>
				
			</div>
			<div id="mobile_only_nav" class="mobile-only-nav pull-right">
				<ul class="nav navbar-right top-nav pull-right">
				
					<li class="dropdown auth-drp">
						<a href="#" class="dropdown-toggle pr-0" data-toggle="dropdown"><img src="<?= base_url(ADMIN_IMG.'user1.png')?>" alt="user_auth" class="user-auth-img img-circle"/><span class="user-online-status"></span></a>
						<ul class="dropdown-menu user-auth-dropdown" data-dropdown-in="flipInX" data-dropdown-out="flipOutX">
							<li>
								<a href="<?php echo BASE_URL_MATH_ADMIN;?>"><i class="zmdi zmdi-account"></i><span>Dashboard</span></a>
							</li>
							<li>
								<!--<a href="<?php echo BASE_URL_MATH_ADMIN;?>myaccount"><i class="zmdi zmdi-card"></i><span>My Account</span></a>
							--></li>
							
							<li class="divider"></li>
							
							<li>
								<a href="<?php echo BASE_URL_MATH_ADMIN;?>logout"><i class="zmdi zmdi-power"></i><span>Log Out</span></a>
							</li>
						</ul>
					</li>
				</ul>
			</div>	
		</nav>
		<!-- /Top Menu Items -->
		
		<!-- Left Sidebar Menu -->
		<?php include ("sidebar.php") ?>
		<!-- /Left Sidebar Menu -->
		
		
		