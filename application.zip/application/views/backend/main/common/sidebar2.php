<div class="fixed-sidebar-left">
		<ul class="nav navbar-nav side-nav nicescroll-bar">
				<li class="navigation-header">
					<span>Main</span> 
					<i class="zmdi zmdi-more"></i>
				</li>
				<li>
					<a href="<?php echo BASE_URL_MATH_ADMIN;?>"><div class="pull-left"><i class="zmdi zmdi-landscape mr-20"></i><span class="right-nav-text">Dashboard</span></div><div class="clearfix"></div></a>
				</li>
                
                <!--multi level menu-->
                <li>
					<a href="javascript:void(0);" data-toggle="collapse" data-target="#questions">
					<div class="pull-left">
						<i class="zmdi zmdi-book mr-20"></i>
						<span class="right-nav-text">Questions & Exams</span>
					</div>
					<div class="pull-right"><i class="zmdi zmdi-caret-down"></i></div>
					<div class="clearfix"></div>
					</a>
					<ul id="questions" class="collapse collapse-level-1 two-col-list">
					<?php 
                    $master_class=$this->main_model->getall($obj,'master_class','*');
                    foreach($master_class as $class):
                    ?>
                    <li><a href="<?=base_url('math-admin/adminmgmt/questions/'.$class->class_slug)?>"><?=$class->class_name?></a></li>	
					<?php endforeach; ?>
                    </ul>
				</li>
                
                
                <li>
					<a href="javascript:void(0);" data-toggle="collapse" data-target="#Syllabus_Notes">
					<div class="pull-left">
						<i class="zmdi zmdi-book mr-20"></i>
						<span class="right-nav-text">Syllabus & Notes </span>
					</div>
					<div class="pull-right"><i class="zmdi zmdi-caret-down"></i></div>
					<div class="clearfix"></div>
					</a>
					<ul id="Syllabus_Notes" class="collapse collapse-level-1 two-col-list">
					<?php 
                    $master_class=$this->main_model->getall($obj,'master_class','*');
                    foreach($master_class as $class):
                    ?>
                    <li><a href="<?=base_url('math-admin/adminmgmt/syllabus/'.$class->class_slug)?>"><?=$class->class_name?></a></li>	
					<?php endforeach; ?>
                    </ul>
				</li>
                <!--multi level menu-->
			</ul>
		</div>