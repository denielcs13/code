<div class="left-sidebar-pro">
        <nav id="sidebar" class="">
            <div class="sidebar-header">
                <a href="/"><img class="main-logo" style="width: 200px;" src="<?= base_url('assets/admin/img/logo/logo_icon.png')?>" alt="" /></a>
                <strong><a href="index.html"><img src="<?= base_url('assets/admin/img/logo/logo_icon.png')?>" alt="" /></a></strong>
            </div>
            <div class="left-custom-menu-adp-wrap comment-scrollbar">
                <nav class="sidebar-nav left-sidebar-menu-pro">
                    <ul class="metismenu" id="menu1">
                        <li class="active">
                            <a aria-expanded="false" href="<?php echo BASE_URL_MAIN_ADMIN;?>">
								   <span class="educate-icon educate-home icon-wrap" aria-hidden="true"></span>
								   <span class="mini-click-non">Dashboard</span>
								</a>
                            
                        </li>
                        
                        <li>
                            <a class="has-arrow" href="all-students.html" aria-expanded="false"><span class="educate-icon educate-student icon-wrap"></span> <span class="mini-click-non">Users List</span></a>
                            <ul class="submenu-angle" aria-expanded="false">
                                <li><a title="All Students" href="<?=base_url(MAIN_ADMIN.'/student')?>"><span class="mini-sub-pro">Students</span></a></li>
                                <li><a title="Parents" href="<?=base_url(MAIN_ADMIN.'/parent')?>"><span class="mini-sub-pro">Parent</span></a></li>
                                <li><a title="Institute" href="<?=base_url(MAIN_ADMIN.'/institute')?>"><span class="mini-sub-pro">Institute</span></a></li>
                              </ul>
                        </li>
                      </ul>
                </nav>
            </div>
        </nav>
    </div>