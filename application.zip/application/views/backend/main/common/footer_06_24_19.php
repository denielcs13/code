	<!-- Footer -->
			<footer class="footer container-fluid pl-30 pr-30">
				<div class="row">
					<div class="col-sm-12">
						<p>&copy; 2018 - <?php echo date('Y');?> The University Of Maths.</p>
					</div>
				</div>
			</footer>
			<!-- /Footer -->
			
		</div>
        <!-- /Main Content -->

    </div>
    <!-- /#wrapper -->
	
	<!-- JavaScript -->
	
    <!-- jQuery -->
<script>
function removeAnswer($this)
{
   if (!confirm('Are you sure want to remove?')) {
		return false;
	}
	$this.parent('div').parent('div').html('');
    
}
var count=1;
function addAnswer($this)
{
   var html='';
    html+='<div class="add_answer_row"><div class="col-md-4 col-sm-5 col-xs-12"><input type="text" class="form-control" value="" name="answersr['+count+']" placeholder="Enter Answer Title"></div><div class="col-md-2 col-sm-3 col-xs-12  text-center tb_margin"><input type="hidden" name="answers['+count+']" value="0"><input type="checkbox" name="answers['+count+']" value="1"></div><div class="col-md-4 col-sm-4 col-xs-12 pr-0 text-center" style="padding:5px;"><button type="button" onclick="removeAnswer($(this));" data-toggle="tooltip" title="Remove" class="btn btn-danger pull-right mb-10 rovoveBtn">Remove</button></div></div>';
   $('#add_answer').append(html);
count++;
}

</script>
    <script src="<?=base_url('assets/admin/vendors/bower_components/jquery/dist/jquery.min.js')?>"></script>
    <script src="https://code.jquery.com/jquery-1.12.4.js"></script>
  <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
    <!-- Bootstrap Core JavaScript -->
    <script src="<?=base_url('assets/admin/vendors/bower_components/bootstrap/dist/js/bootstrap.min.js')?>"></script>
    
	
	<!-- Slimscroll JavaScript -->
	<script src="<?=base_url('assets/admin/dist/js/jquery.slimscroll.js')?>"></script>
	
	<!-- Progressbar Animation JavaScript -->
	<script src="<?=base_url('assets/admin/vendors/bower_components/waypoints/lib/jquery.waypoints.min.js')?>"></script>
	<script src="<?=base_url('assets/admin/vendors/bower_components/jquery.counterup/jquery.counterup.min.js')?>"></script>
	
	<!-- Fancy Dropdown JS -->
   
	
	<!-- Sparkline JavaScript -->
	<script src="<?=base_url('assets/admin/vendors/jquery.sparkline/dist/jquery.sparkline.min.js')?>"></script>
	
	<!-- Owl JavaScript -->
	
	
	<!-- EChartJS JavaScript -->
	<script src="<?=base_url('assets/admin/vendors/bower_components/echarts/dist/echarts-en.min.js')?>"></script>
	<script src="<?=base_url('assets/admin/vendors/echarts-liquidfill.min.js')?>"></script>
	
	
	<!-- Init JavaScript -->
	<script src="<?=base_url('assets/admin/dist/js/init.js')?>"></script>
	<script src="<?=base_url('assets/admin/dist/js/dashboard-data.js')?>"></script>
</body>

</html>