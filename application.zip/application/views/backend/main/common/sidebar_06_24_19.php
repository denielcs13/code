<div class="fixed-sidebar-left">
		<ul class="nav navbar-nav side-nav nicescroll-bar">
				<li class="navigation-header">
					<span>Main</span> 
					<i class="zmdi zmdi-more"></i>
				</li>
				<li>
					<a href="<?php echo BASE_URL_MAIN_ADMIN;?>"><div class="pull-left"><i class="zmdi zmdi-landscape mr-20"></i><span class="right-nav-text">Dashboard</span></div><div class="clearfix"></div></a>
				</li>
                
                <!--multi level menu-->
                
				<!-- user list -->
				<!-- <li>
					<a href="<?//=base_url('main-admin/adminmgmt/users')?>"><div class="pull-left"><i class="zmdi zmdi-landscape mr-20"></i><span class="right-nav-text">Users List</span></div><div class="clearfix"></div></a>
				</li> -->
				 <li>
					<a href="javascript:void(0);" data-toggle="collapse" data-target="#Syllabus_Notes">
					<div class="pull-left">
						<i class="zmdi zmdi-book mr-20"></i>
						<span class="right-nav-text">Users List </span>
					</div>
					<div class="pull-right"><i class="zmdi zmdi-caret-down"></i></div>
					<div class="clearfix"></div>
					</a>
					<ul id="Syllabus_Notes" class="collapse collapse-level-1 two-col-list">
					
                    <li><a href="<?=base_url('main-admin/adminmgmt/student')?>">Student</a></li>
                    <li><a href="<?=base_url('main-admin/adminmgmt/parent')?>">Parent</a></li>	
                    <li><a href="<?=base_url('main-admin/adminmgmt/institute')?>">Institute</a></li>		
					
                    </ul>
				</li>
			</ul>
		</div>