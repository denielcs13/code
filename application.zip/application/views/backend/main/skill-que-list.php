<div class="page-wrapper">
			<div class="container-fluid">
				
				<!-- Title -->
				<div class="row heading-bg headingMain">
					<!-- Breadcrumb -->
					<div class="col-lg-12 col-md-12">
					  <ol class="breadcrumb">
						<li><a href="<?php echo BASE_URL_MATH_ADMIN;?>">Dashboard</a></li>
						<li class="active"><span>Syllabus</span></li>
					  </ol>
					</div>
					<!-- /Breadcrumb -->
				</div>
				<!-- /Title -->
				 <?php 
						if($this->session->flashdata('success_msg') != null && $this->session->flashdata('success_msg') != "")
								{ 
								?>
								<div class="row">
									<div class="col-md-12">
										<div style="margin-top:18px;" class="alert alert-success fade in">
											<?php echo $this->session->flashdata('success_msg');?>
										</div>
									</div>
								</div>
								<?php 
							} 
							?>	
				<div class="row">
					
					<!-- Bordered Table -->
					<div class="col-sm-12">
						<div class="panel panel-default card-view">
							<div class="panel-heading">
								<div class="pull-left">
									<ol style="font-size: 18px;" class="breadcrumb">
										
										<li><a href="<?php echo BASE_URL_MATH_ADMIN.'syllabus/'.$year;?>"><?=$year_dtl->class_name?></a></li>
										<li class="active"><span><?=$skill->skill_name?></span></li>
									  </ol>
									
									
								</div>



								



								<div class="clearfix"></div>
							</div>
							<div class="panel-wrapper collapse in">
								<div class="panel-body">
									<div class="table-wrap">
										<div class="table-responsive">
                                        
										  <table class="table table-hover table-bordered mb-0">
											<?php 
                                            if($DepList):
                                            
                                            ?>
                                            <thead>
											 <tr>
												<th>ID</th>
												<th>Title</th>
												<th>Year</th>
												<th >Type</th>
												<!--<th class="text-nowrap">Action</th>-->
												<th class="text-nowrap">Pre-view</th>
                                                        
											 </tr>
											 
											</thead>
											<tbody>
											 <?php 
                                                 foreach($DepList as $result):
											     $ques_type_ar=array_map('trim',explode(',',$result->ques_type));
													if(in_array('26',$ques_type_ar)){
													$ques_name=  base64_decode($result->ques_name); 
													
													}
													else{ $ques_name= $result->ques_name;}
                                                  ?>
													
													
												
                                                      <tr>
													  <td data-th="Movie Title"><?php echo $result->ques_id;?></td>
                                                        <td data-th="Movie Title"><?php echo $ques_name;?></td>
														 <td data-th="Movie Title">
                                                         
                                                         <?php 
													  
													  foreach($ques_type_ar as $key=>$val){
														$query = $obj->query("select ques_type from ques_type where id IN('".$val."')");
														foreach ($query->result() as $row)
															{
																	$ques_type[]= $row->ques_type;
																	
															}
													  }
													   echo implode(',',$ques_type);
													   $ques_type=array();
													   ?>
                                                         </td>
                                                         <td data-th="Movie Title"><?php echo $year_dtl->class_name;?></td>
                                                         <td><a class="btn btn-info" href="<?='javascrip:void(0)'; //base_url('pre-view/'.$year_dtl->class_id.'/'.$result->ques_id) ?>">Pre-view</a></td>
														
                                                       </tr> 
													<?php	endforeach;
													
													?>   
													  
											  
											  
											</tbody>
                                            <?php else: 
                                          echo "<th style='font-size: 21px;text-align: center;'>Questions Not Found</th>";
                                          endif; ?>
										  </table>
										  
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
					<!-- /Bordered Table -->
					
				</div>
			</div>
		
<script type="text/javascript">
    var url="<?php echo BASE_URL_MATH_ADMIN;?>";
    var slg="<?php echo $year_dtl->class_slug;?>";
    function deletedata(id){
       var r=confirm("Do you want to delete this?")
        if (r==true)
          window.location = url+"questions/delete-question/"+slg+"/"+id;
        else
          return false;
        } 
</script>