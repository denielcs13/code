<style>
   .pagin{
   }
   .pagin strong {
   text-decoration: none;
   color: #212121;
   font-weight: bold;
   border: 1px solid;
   color: white;
   background: blueviolet;
   }
   .pagin a {
   padding: 10px;
   border: 1px solid;
   }
   .add_answer_row{
    padding-left:15px;
    padding-right:15px;
    
   }
</style>
<div class="page-wrapper">
<div class="container-fluid">
   <!-- Title -->
   <div class="row heading-bg headingMain">
      <!-- Breadcrumb -->
      <div class="col-lg-12 col-md-12">
         <ol class="breadcrumb">
            <li><a href="<?php echo BASE_URL_MATH_ADMIN;?>">Dashboard</a></li>
            <li ><a href="<?=base_url(uri_string())?>"><span><?=$this->uri->segment(3)?></span></a></li>
            <li class="active"><span><?=$this->uri->segment(4)?></span></li>
         </ol>
      </div>
      <!-- /Breadcrumb -->
   </div>
   <!-- /Title -->
   <?php 
      if($this->session->flashdata('success_msg') != null && $this->session->flashdata('success_msg') != "")
      		{ 
      		?>
   <div class="row">
      <div class="col-md-12">
         <div style="margin-top:18px;" class="alert alert-success fade in">
            <?php echo $this->session->flashdata('success_msg');?>
         </div>
      </div>
   </div>
   <?php 
      } 
      ?>	
   <div class="row">
      <!-- Bordered Table -->
      <div class="col-sm-12">
         <div class="panel panel-default card-view">
            <div class="panel-heading">
               <div class="pull-left">
                  <ol style="font-size: 18px;" class="breadcrumb">
                     <li class="active"><?=$year_dtl->class_name?></li>
                  </ol>
               </div>
               <div class="pull-right">
               </div>
               <div class="clearfix"></div>
            </div>
            <div class="panel-wrapper collapse in">
               <div class="panel-body">
                  <div class="panel-body">
                     <div class="table-wrap">
                        <div class="">
                           <form action="<?=base_url('math-admin/adminmgmt/add-question/'.$year_dtl->class_slug)?>" name="frm" enctype="multipart/form-data" method="post" accept-charset="utf-8">
                              <div class="form-body">
                                 <div class="row">
                                    <div class="col-md-12">
                                       <div class="form-group">
                                          <label class="control-label col-md-2 mb-10">Skill</label>
                                          <div class="col-md-10">
                                          <input type="text" hidden="" name="quetype" value="html" />
                                             <select name="ques_skillid" id="ques_skillid" class="col-md-12 col-sm-12 col-xs-12 pa-5">
                                                <option value="" style="display: none;" >Select Skill</option>
                                                <?php 
                                                foreach($SylList as $ques_skillid):
                                                
                                                ?>
                                                <option value="<?=$ques_skillid->skill_id?>"><?=$ques_skillid->skill_name?></option>
                                                <?php
                                                endforeach;
                                                ?>
                                             </select>
                                             <span class="help-block">  </span>
                                          </div>
                                       </div>
                                    </div>
                                 </div>
                                 <div class="row">
                                    <div class="col-md-12">
                                       <div class="form-group">
                                          <label class="control-label col-md-2 mt-10 mb-10">Sub Skill</label>
                                          <div class="col-md-10">
                                             <div id="subskills">
                                                <select name="subskill">
                                                   
                                                </select>
                                             </div>
                                          </div>
                                       </div>
                                    </div>
                                 </div>
                                 <div id="addrow_question">
                                    <div class="row">
                                       <div class="col-md-12 mb-10">
                                          <div class="form-group">
                                             <label class="control-label col-md-2">Question Title</label>
                                             <div class="col-md-10">
                                                <textarea id="question_name" name="question_name"  >	
                                                </textarea>
                                             </div>
                                          </div>
                                       </div>
                                    </div>
                                 </div>
                                 <div id="addrow_question">
                                    <div class="row">
                                       <div class="col-md-12 mb-10">
                                          <div class="form-group">
                                             <label class="control-label col-md-2">Question Title</label>
                                                <div class="col-md-10">
                                                <div id="add_answer" class="row">
                                                 <div class="add_answer_row">
                                                 <div class="col-md-4 col-sm-5 col-xs-12">
                                                 <input type="text" class="form-control" value="" name="answersr[0]" placeholder="Enter Answer Title">
                                                 </div>
                                                 <div class="col-md-2 col-sm-3 col-xs-12  text-center tb_margin">
                                                 <input type="hidden" name="answers[0]" value="0">
                                                 <input type="checkbox" name="answers[0]" value="1">
                                                 </div>
                                                 <div class="col-md-4 col-sm-4 col-xs-12 pr-0 text-center" style="padding:5px;">
                                                  <button type="button" onclick="removeAnswer($(this));" data-toggle="tooltip" title="Remove" class="btn btn-danger pull-right mb-10 rovoveBtn">Remove</button>
                                                 </div>
                                                 </div>
                                             </div>
                                             </div>
                                          </div>
                                       </div>
                                    </div>
                                    <div class="row">
									<div class="col-md-12">
									<div class="form-group">
									<div class="form-actions right">
									<p class="pull-right rovoveBtn">
									<a onclick="addAnswer($(this))" class="btn btn-primary mb-10">Add Answer</a> &nbsp; &nbsp;
									</p>
									</div>
									</div>
									</div>
									</div>
                                 </div>
                                 <div id="addrow_question">
                                    <div class="row">
                                       <div class="col-md-12 mb-10">
                                          <div class="form-group">
                                             <label class="control-label col-md-2">explanation</label>
                                             <div class="col-md-10">
                                                <textarea id="explanation" name="explanation"  >	
                                                </textarea>
                                             </div>
                                          </div>
                                       </div>
                                    </div>
                                 </div>
                                 
                                 
                                 <div class="form-actions">
                                    <div class="">
                                       <div class=" col-md-12 pr-25 padBox text-center">
                                          <button type="submit" class="btn btn-success pull-right rovoveBtn" onclick="return validateForm();">Save</button>
                                       </div>
                                       <div class="col-md-6"> </div>
                                    </div>
                                 </div>
                                 <div class="clearfix"></div>
                                 <div style="text-align:center;margin:0 auto;"></div>
                              </div>
                        </div>
                        </form>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </div>
      <!-- /Bordered Table -->
   </div>
</div>
<script>
        
    CKEDITOR.replace( 'question_name', {
        height: 300,
        filebrowserUploadUrl: '<?php echo base_url("adminmgmt/questions/upload/".$year_dtl->class_name)?>',
        
    } );
    CKEDITOR.replace( 'explanation', {
        height: 300,
        filebrowserUploadUrl: '<?php echo base_url("adminmgmt/questions/upload/".$year_dtl->class_name)?>',
        
    } );
    
    
    $('select[name=ques_skillid]').change(function(){
    var skill=$(this).val();
    var year='<?=$year_id?>';
    var url="<?=base_url('math-admin/adminmgmt/get-subskill/')?>"+skill+'/'+year;
    $.get(url,function(data){
       if(data)
       {
        $('select[name=subskill]').html(data)
       } 
    });
});




</script>