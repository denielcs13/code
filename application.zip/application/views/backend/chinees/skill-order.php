<style>

.card-view {
    background: #fff;
    margin-bottom: 20px;
	border-radius: 0;
    box-shadow: none;
    padding: 15px 15px 0;
    margin-left: -5px;
    margin-right: -5px;
}
.card-view.panel > .panel-heading {
    border: none;
    color: inherit;
    border-radius: 0;
    margin: -15px -15px 0;
    padding: 20px 15px;
}
.card-view.panel.panel-default > .panel-heading {
    background: #f4f4f4;
}
.pull-left.caption {
    line-height: 40px;
}
h6, .panel-title {
    font-size: 16px;
    line-height: 24px;
    text-transform: capitalize;
    line-height: 42px;
}
.txt-dark {
    color: #212121 !important;
}
.panel .panel-heading a {
    position: relative;
}
.clearfix {
    overflow: hidden;
    clear: both;
    float: none;
}
.panel-wrapper.collapse.in.portlet-body {
    padding-bottom: 20px;
}
.card-view.panel .panel-body {
    padding: 20px 0 20px;
}
.d-flexBox {
    display: flex !important;
}
.ma-5 {
    margin: 5px !important;
}
.borderBox {
    border: 1px solid #e9e9e9;
    padding: 10px;
}
.mr-5 {
    margin-right: 5px !important;
}
.colBox1, .colBox2, .colBox3, .colBox4, .colBox5 {
    width: 100%;
    float: left;
}
.colBox2 {
    margin-top: 10px;
}
.colBox2 h4 {
    color: #667add;
    font-weight: 500;
}
h4 {
    font-size: 24px;
    line-height: 30px;
    text-transform: capitalize;
}
.btn.btn-success, .wizard > .actions a.btn-success, .wizard > .actions a.fc-prev-button, .wizard > .actions a.fc-next-button, .wizard > .actions a.fc-today-button, .dt-buttons .btn-success.dt-button, .dt-buttons .dt-button.fc-prev-button, .dt-buttons .dt-button.fc-next-button, .dt-buttons .dt-button.fc-today-button, .tablesaw-sortable th.tablesaw-sortable-head button.btn-success, .tablesaw-sortable th.tablesaw-sortable-head button.fc-prev-button, .tablesaw-sortable th.tablesaw-sortable-head button.fc-next-button, .tablesaw-sortable th.tablesaw-sortable-head button.fc-today-button, .sweet-alert button.btn-success, .sweet-alert button.fc-prev-button, .sweet-alert button.fc-next-button, .sweet-alert button.fc-today-button, .owl-theme .owl-nav .btn-success[class*="owl-"], .owl-theme .owl-nav [class*="owl-"].fc-prev-button, .owl-theme .owl-nav [class*="owl-"].fc-next-button, .owl-theme .owl-nav [class*="owl-"].fc-today-button, button.btn-success.fc-agendaDay-button.fc-state-default.fc-corner-right, button.fc-agendaDay-button.fc-state-default.fc-corner-right.fc-prev-button, button.fc-agendaDay-button.fc-state-default.fc-corner-right.fc-next-button, button.fc-agendaDay-button.fc-state-default.fc-corner-right.fc-today-button, button.btn-success.fc-month-button.fc-state-default.fc-corner-left, button.fc-month-button.fc-state-default.fc-corner-left.fc-prev-button, button.fc-month-button.fc-state-default.fc-corner-left.fc-next-button, button.fc-month-button.fc-state-default.fc-corner-left.fc-today-button, button.btn-success.fc-agendaWeek-button, button.fc-agendaWeek-button.fc-prev-button, button.fc-agendaWeek-button.fc-next-button, button.fc-agendaWeek-button.fc-today-button, .fc-prev-button, .fc-next-button, .fc-today-button{
	background: #4aa23c !important;
    border: solid 1px #4aa23c;
	color: #fff;
}
.btn, .wizard > .actions .disabled a, .wizard > .actions .disabled a:hover, .wizard > .actions .disabled a:active, .wizard > .actions a, .wizard > .actions a:hover, .wizard > .actions a:active, .dt-buttons .dt-button, .tablesaw-sortable th.tablesaw-sortable-head button, .sweet-alert button, .owl-theme .owl-nav [class*="owl-"], button.fc-agendaDay-button.fc-state-default.fc-corner-right, button.fc-month-button.fc-state-default.fc-corner-left, button.fc-agendaWeek-button, .fc-prev-button, .fc-next-button, .fc-today-button{
	    color: #fff;
    padding: 10px 20px;
    text-transform: capitalize;
    border-radius: 2px;
    outline: none;
    box-shadow: none;
    border: none;
    -webkit-transition: all 0.3s ease;
    -moz-transition: all 0.3s ease;
    transition: all 0.3s ease;
}
.colBox5 {
    margin-left: 15px;
}
.colBox5 span {
    color: #212121;
    font-size: 18px;
    float: left;
    margin-right: 5px;
}
.colBox5 h5 {
    color: #212121;
    padding-right: 15px;
}
h5 {
    font-size: 18px;
    line-height: 26px;
    text-transform: capitalize;
}
a.btn-success {
    margin-top: 0;
}

.panel-body a{
	margin-top:0;
	font-size:18px;
}
.styBox .colBox2.ui-sortable-handle {
    border: 1px solid #ccc;
    padding: 7px;
    width: 100%;
}
.styBox #sortable {
    width: 50%;
}







</style>
<div class="data-table-area mg-b-15">
            <div class="container-fluid">			
			<div class="row">
                        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                            <div class="breadcome-list">
                                <div class="row">
                                    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                        <ul class="breadcome-menu">
                                            <li><a href="<?php echo BASE_URL_CHINEES_ADMIN;?>">Dashboard</a> <span class="bread-slash">/</span>
                                            </li>
											<li class="active"><span>Syllabus</span></li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
            </div>
			
                <div class="row">
                    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                        <div class="sparkline12-list">
                            
                            <div class="sparkline12-graph">
							<div class="tab-pane" id="tab_2">
                                <?php 
								if($this->session->flashdata('success_msg') != null && $this->session->flashdata('success_msg') != "")
								{ 
								?>
								<div class="row">
									<div class="col-md-12">
										<div style="margin-top:18px;" class="alert alert-success fade in">
											<?php echo $this->session->flashdata('success_msg');?>
										</div>
									</div>
								</div>
								<?php 
								} 
								?>	
                                <form action="<?=base_url(CHINEES_ADMIN.'/syllabus-order/'.$year_dtl->class_slug)?>" method="post">
									
								<div class="sparkline13-hd">
                                <div class="panel-heading">
								<div class="main-sparkline13-hd">
                                    <h1>syllabus-order <span class="table-project-n"> </span><?php echo $year_dtl->class_name;?> </h1>
                                </div>
                                <div class="main-sparkline13-hd pull-right">
								</div>
                             <div class="clearfix"></div>
							</div>
                            </div>
											
											  <!-- BEGIN FORM-->
                                        <div class="panel-wrapper collapse in portlet-body">
											<div class="panel-body styBox">
												<div class="table-wrap sortable" id="sortable">
													<?PHP 
                                                    $i=1;
                                                    foreach($SylList as $SylListDetail):
                                                     ?>
													<div class="colBox2">
                                                          <span skillid="<?=$SylListDetail->skill_id?>" id="<?=$i;?>" ><?=$SylListDetail->skill_name?></span>
                                                    </div>
                                                    <?PHP
                                                     $i++;
                                                    endforeach;
                                                    ?>
												</div>
                                                
                                                <?PHP 
                                                    $i=1;
                                                    foreach($SylList as $SylListDetail):
                                                     ?>
													<div class="colBox2 colBoxInput">
                                                        <input type="text" hidden="" id="<?='input'.$i?>" name="<?=$i?>"  value="" />
                                                    </div>
                                                    <?PHP
                                                     $i++;
                                                    endforeach;
                                                    ?>                                                    
													</div>
													<button class="btn btn-primary" type="submit">Save Order</button>
                                            </div>			 
                                        
                                        
                                        </form>
										<!-- END FORM-->
                                    
                               
                            </div>
                             
                            </div>							
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
		
<script>
   $(function(){
   $("#sortable").sortable({
   
    start: function(e, ui) {
        $(this).attr('data-previndex', ui.item.index());
    },
    stop: function(e, ui) {
        var newIndex = ui.item.index();
        var validex  = newIndex+1;
        var oldIndex = $(this).attr('data-previndex');
        var element_id = ui.item.children().text();
        var $i=1;
        $.map($(this).children('.colBox2 ').find('span'), function(el) {
                 
                 //console.log(el.id + ' = '+i + $(el).text());
                 $('#input'+$i).val($(el).attr('skillid'));
                 $i++;
                 
            });
        $(this).removeAttr('data-previndex');
    }
});
$("#sortable").disableSelection(); 
   })
 
  </script>	