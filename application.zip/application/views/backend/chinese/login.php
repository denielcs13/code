<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="UTF-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
		<title><?=PROJECT_NAME?></title>
		
		<!-- Favicon -->
		<link rel="shortcut icon" href="favicon.ico">
		<link rel="icon" href="favicon.ico" type="image/x-icon">
		
		<!-- vector map CSS -->
		<link href="<?= base_url('assets/admin/vendors/bower_components/jasny-bootstrap/dist/css/jasny-bootstrap.min.css" rel="stylesheet" type="text/css"')?>"/>
		
		
		
		<!-- Custom CSS -->
		<link href="<?= base_url('assets/admin/dist/css/style.css" rel="stylesheet" type="text/css"')?>">
	</head>
	<body>
		<!--Preloader-->
		<div class="preloader-it">
			<div class="la-anim-1"></div>
		</div>
		<!--/Preloader-->
		
		<div class="wrapper box-layout pa-0 logoPage table-struct full-width full-height">
			<div class="table-cell vertical-align-middle">
			<header class="">
				<div class="text-center">
					<a href="<?php echo BASE_URL;?>">
						<img class="brand-img" src="<?= base_url(LOGO_PATH)?>" alt="brand"/>
					</a>
				</div>
				<div class="clearfix"></div>
			</header>
			
			<!-- Main Content -->
			<div class="page-wrapper pa-0 ma-0 auth-page">
				<div class="container-fluid">
					<!-- Row -->
					<div class="table-struct full-width full-height">
						<div class="pt-25">
							<div class="auth-form  ml-auto mr-auto no-float">
								<div class="row">
									<div class="col-sm-12 col-xs-12">
										<div class="mb-30">
											<h6 class="text-center nonecase-font txt-grey">Enter your details below</h6>
										</div>	
										<?php if (validation_errors()) : ?>
											<div class="col-md-12">
												<div class="alert alert-danger" role="alert">
													<?= validation_errors() ?>
												</div>
											</div>
											<?php endif; ?>
										<?php if ($error!=''){ ?>
											<div class="col-md-12">
												<div class="alert alert-danger" role="alert">
													<?= $error ?>
												</div>
											</div>
										<?php } ?>
										<div class="form-wrap">
											 <?= form_open( BASE_URL_ADMIN.'adminmgmt/login' ); ?>
												<div class="form-group">
													<label class="control-label mb-10" for="exampleInputEmail_2">Username</label>
													<input type="text" class="form-control" required="" id="exampleInputEmail_2" placeholder="Enter username" name="username">
												</div>
												<div class="form-group">
													<label class="pull-left control-label mb-10" for="exampleInputpwd_2">Password</label>
													<!--<a class="capitalize-font txt-primary block mb-10 pull-right font-12" href="<?php echo BASE_URL_ADMIN;?>recover-password">forgot password ?</a>-->
													<div class="clearfix"></div>
													<input type="password" class="form-control" required="" id="exampleInputpwd_2" placeholder="Enter password" name="password">
												</div>
												
												<div class="form-group">
													<div class="checkbox checkbox-primary pr-10 pull-left">
														<input id="checkbox_2"  type="checkbox" class="ml-0">
														<label for="checkbox_2"> Keep me logged in</label>
													</div>
													<div class="clearfix"></div>
												</div>
												<div class="form-group text-center">
													<button type="submit" class="btn btn-primary">sign in</button>
												</div>
											</form>
										</div>
									</div>	
								</div>
							</div>
						</div>
					</div>
					<!-- /Row -->	
				</div>
				
			</div>
			<!-- /Main Content -->
			</div>
		</div>
		<!-- /#wrapper -->
		
		<!-- JavaScript -->
		
		<!-- jQuery -->
		<script src="<?= base_url('assets/admin/vendors/bower_components/jquery/dist/jquery.min.js')?>"></script>
		
		<!-- Bootstrap Core JavaScript -->
		<script src="<?= base_url('assets/admin/vendors/bower_components/bootstrap/dist/js/bootstrap.min.js')?>"></script>
		<script src="<?= base_url('assets/admin/vendors/bower_components/jasny-bootstrap/dist/js/jasny-bootstrap.min.js')?>"></script>
		
		<!-- Slimscroll JavaScript -->
		<script src="<?= base_url('assets/admin/dist/js/jquery.slimscroll.js')?>"></script>
		
		<!-- Init JavaScript -->
		<script src="<?= base_url('assets/admin/dist/js/init.js')?>"></script>
	</body>
</html>
