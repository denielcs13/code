<?php 
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<div class="counterBox"></div>
<!-- Main Content -->
<div class="page-wrapper">
<div class="col-sm-12">
						<div class="panel panel-default card-view">
							<div class="panel-heading">
								<div class="pull-left">
									<h6 class="panel-title txt-dark titleP">  
												Manage Skill
                                                </h6>
								</div>
								
								
								<div class="clearfix"></div>
							</div>
							<div class="panel-wrapper collapse in">
								<div class="panel-body">
									<div class="table-wrap">
										<div class="">
                                        <?php
                                        
                                        print_r(validation_errors());
                                        ?>
										<form action="<?=base_url('adminmgmt/add-sklill/'.$subject.'/'.$year)?>" name="frm" method="post" accept-charset="utf-8">
	

										
										
												 <div class="form-body"> 
													<div class="row">
                                                         
                                                            <!--/span-->
                                                            <div class="col-md-12">
                                                                <div class="form-group">
																	<a onclick="addSkill();" class="btn btn-primary pull-right mb-10">Add more skill</a>
                                                                    <span class="help-block"></span>
                                                                </div>
                                                            </div>
                                                            <!--/span-->
                                                        </div>												 
                                                        <div id="room-row0" class="">
															<div class="row">
																
																	<div class="form-group">
																		<label class="control-label col-md-12 mb-10">Skill Name</label>
																		<div class="col-md-12"><input type="text" class="form-control" value="" name="addskills[0][skill_name]" placeholder="Enter Skill Title">
																		</div>
																	</div>
																
																<div class="col-md-12">
																	<div id="addrow_subskill_0">
																</div></div>
															</div>
															<div class="row mt-10">
																<div class="col-md-12">
																	<div class="form-group">
																		<div class="form-actions right">
																			<p style="text-align:right">
																			</p>
																			<p class="pull-right">
																			<a onclick="addSubskill('0');" class="btn btn-primary mb-10">Add Sub-Skill</a> &nbsp; &nbsp;<button type="button" onclick="removeRow('0');" data-toggle="tooltip" class="btn btn-danger mb-10" data-original-title="" title="">Remove</button></p>
																		</div>
																	</div>
																</div>
															</div>
													
													</div>
                                                  
														
														
														<div id="addrow_skills"></div>
                                                        <!--/row-->
														
														
														<!---End of List of Skill Subsill-->
														<div class="form-actions">
															<div class="row">
																<div class="col-md-12 mt-10">
																	<div class="row">
																		<div class=" col-md-12">
																			<button type="submit" class="btn btn-success pull-right" onclick="return validateForm();">Save</button>
																		  
																		</div>
																	</div>
																</div>
																<div class="col-md-6"> </div>
															</div>
														</div>																	
                                                       

													   
                                                    </div>
													  
										<input type="hidden" name="add_subskill" value="1">
										</form>
										<div style="text-align:center;margin:0 auto;"></div>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
    

<script type="text/javascript">

var module_row = 1;

function addSkill() {

	html = '<div id="room-row' + module_row + '" class="" >';
	html += '<div class="row">';
	html += '<div class="col-md-12">';
	html += '<div class="form-group"><label class="control-label col-md-12 mb-10">Skill Name</label><div class="col-md-12 pr-0">';
	html += '<input type="text" class="form-control" value="" name="addskills[' + module_row + '][skill_name]" placeholder="Enter Skill Title">';
	html += '</div>';
	html += '</div>';
	html += '</div>';
	/*---Add Answer----*/
	html += '<div class="col-md-12">';
	html += '<div id="addrow_subskill_' + module_row + '">';	
	html += '</div>';
	
	html += '</div>';
	/*--End of add answer---*/
	
	
	html += '</div>';

	html += '<div class="row">';
	html += '<div class="col-md-12 pr-0">';
	html += '<div class="form-group">';
	html += '<div class="form-actions right">';
	html += '<p style="text-align:right"><p class="col-md-12 mt-10" style="text-align:right"> <a onclick="addSubskill(\''+ module_row +'\');" class="btn btn-primary mb-10">Add Sub-Skill</a> &nbsp; &nbsp;';
	
	html += '<button type="button" onclick="removeRow(\''+ module_row +'\');" data-toggle="tooltip" class="btn btn-danger mb-10">Remove</button></p>';
	html += '</div>';
	html += '</div>';
	html += '</div>';
	html += '</div>';

	
	html += '</div>';
	jQuery('#addrow_skills').before(html);

	module_row++;
	
}
function removeRow(module_row){
	if (!confirm('Are you sure want to remove?')) {
		return false;
	}
	$('#room-row' + module_row  + '').remove();
}

var answer_row = 0;

function addSubskill(module_row) {

	
	
	html = '<div id="subskill-row' + module_row + '-' + answer_row + '"  >';
	html += '<div class="col-md-12 mt-20 pr-0">';
	html += '<div class="form-group"><label class="control-label col-md-12 mb-10">Sub Skill </label><div class="col-md-12 pr-0">';
	html += '<input type="text" class="form-control" value="" name="addskills[' + module_row + '][subskill][' + answer_row + '][skill_name]" placeholder="Enter  Title">';
	var remove_row=module_row+'-'+answer_row;
	html += '</div><div class="col-md-12 mt-10 pr-0"><button type="button" onclick="removeSubskill(\''+ remove_row +'\');" data-toggle="tooltip" class="btn btn-danger pull-right mb-10">Remove</button></div>';
	html += '</div>';
	html += '</div>';
	
	
	html += '</div>';
	jQuery('#addrow_subskill_'+module_row).before(html);

	answer_row++;
	
	
}



function removeSubskill(module_row){
	if (!confirm('Are you sure want to remove?')) {
		return false;
	}
	$('#subskill-row' + module_row  + '').remove();
}

</script> 
<!-- Main Content -->		
     