<?php 
   defined('BASEPATH') OR exit('No direct script access allowed');
   //include 'header.php';
   
    ?>
<div class="counterBox"></div>
<!-- Main Content -->
<div class="page-wrapper">
   <div class="panel-heading">
      <!--<div class="pull-left">
         <h6 class="panel-title txt-dark titleP">Years</h6>
         </div>-->
      <div class="row">
         <form method="post" action="">
            <div class="col-lg-2 col-md-5">
            </div>
            <div class="col-lg-4 col-md-4">
               <label>Select Subject </label>
               <select name="Subject" >
                  <option style="display: none;" value="">Select Subject</option>
                  <?php
                  foreach($subject as $row)
                      {
                        echo '<option value="'.$row->slug.'">'.$row->name.'</option>';
                      }
                  ?>
               </select>
            </div>
            
            <div class="col-lg-4 col-md-4">
               <label>Select Year </label>
               <select name="year" >
                  
               </select>
            </div>
            
            <div class="col-lg-1 col-md-6">
               <label></label>
               <button type="button" id="subject-Submit" class="btn btn-primary">Submit</button>
            </div>
         </form>
      </div>
      <div class="clearfix"></div>
   </div>
<script>
$('select[name=Subject]').change(function(){
    var subject=$(this).val();
    var url="<?=base_url('adminmgmt/get-class/')?>"+subject;
    $.get(url,function(data){
       if(data)
       {
        $('select[name=year]').html(data)
       } 
    });
});

$('#subject-Submit').click(function(){
    var subject =$('select[name=Subject]').val();
    var year =$('select[name=year]').val();
    if(subject)
    {
        window.location.href='<?=base_url('adminmgmt/'.$url.'/')?>'+subject+'/'+year;
    }
});

</script>
<!-- Main Content -->		
<?php //include 'footer.php'; ?>