<div class="footer-copyright-area">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="footer-copy-right">
                            <p>&copy; 2018 - <?php echo date('Y');?> The Eduplexpro.</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- jquery
		============================================ -->
    <script src="<?= base_url('assets/admin/js/vendor/jquery-1.12.4.min.js')?>"></script>
    <!-- bootstrap JS
		============================================ -->
    <script src="<?= base_url('assets/admin/js/bootstrap.min.js')?>"></script>
    <!-- wow JS
		============================================ -->
    <script src="<?= base_url('assets/admin/js/wow.min.js')?>"></script>
    <!-- price-slider JS
		============================================ -->
    <script src="<?= base_url('assets/admin/js/jquery-price-slider.js')?>"></script>
    <!-- meanmenu JS
		============================================ -->
    <script src="<?= base_url('assets/admin/js/jquery.meanmenu.js')?>"></script>
    <!-- owl.carousel JS
		============================================ -->
    <script src="<?= base_url('assets/admin/js/owl.carousel.min.js')?>"></script>
    <!-- sticky JS
		============================================ -->
    <script src="<?= base_url('assets/admin/js/jquery.sticky.js')?>"></script>
    <!-- scrollUp JS
		============================================ -->
    <script src="<?= base_url('assets/admin/js/jquery.scrollUp.min.js')?>"></script>
    <!-- counterup JS
		============================================ -->
    <script src="<?= base_url('assets/admin/js/counterup/jquery.counterup.min.js')?>"></script>
    <script src="<?= base_url('assets/admin/js/counterup/waypoints.min.js')?>"></script>
    <script src="<?= base_url('assets/admin/js/counterup/counterup-active.js')?>"></script>
    <!-- mCustomScrollbar JS
		============================================ -->
    <script src="<?= base_url('assets/admin/js/scrollbar/jquery.mCustomScrollbar.concat.min.js')?>"></script>
    <script src="<?= base_url('assets/admin/js/scrollbar/mCustomScrollbar-active.js')?>"></script>
    <!-- metisMenu JS
		============================================ -->
    <script src="<?= base_url('assets/admin/js/metisMenu/metisMenu.min.js')?>"></script>
    <script src="<?= base_url('assets/admin/js/metisMenu/metisMenu-active.js')?>"></script>
    <!-- morrisjs JS
		============================================ -->
    <script src="<?= base_url('assets/admin/js/morrisjs/raphael-min.js')?>"></script>
    <script src="<?= base_url('assets/admin/js/morrisjs/morris.js')?>"></script>
    <script src="<?= base_url('assets/admin/js/morrisjs/morris-active.js')?>"></script>
    <!-- morrisjs JS
		============================================ -->
    <script src="<?= base_url('assets/admin/js/sparkline/jquery.sparkline.min.js')?>"></script>
    <script src="<?= base_url('assets/admin/js/sparkline/jquery.charts-sparkline.js')?>"></script>
    <script src="<?= base_url('assets/admin/js/sparkline/sparkline-active.js')?>"></script>
    <!-- calendar JS
		============================================ -->
    <script src="<?= base_url('assets/admin/js/calendar/moment.min.js')?>"></script>
    <script src="<?= base_url('assets/admin/js/calendar/fullcalendar.min.js')?>"></script>
    <script src="<?= base_url('assets/admin/js/calendar/fullcalendar-active.js')?>"></script>
	<!-- data table JS
		============================================ -->
    <script src="<?= base_url('assets/admin/js/data-table/bootstrap-table.js')?>"></script>
    <script src="<?= base_url('assets/admin/js/data-table/tableExport.js')?>"></script>
    <script src="<?= base_url('assets/admin/js/data-table/data-table-active.js')?>"></script>
    <script src="<?= base_url('assets/admin/js/data-table/bootstrap-table-editable.js')?>"></script>
    <script src="<?= base_url('assets/admin/js/data-table/bootstrap-editable.js')?>"></script>
    <script src="<?= base_url('assets/admin/js/data-table/bootstrap-table-resizable.js')?>"></script>
    <script src="<?= base_url('assets/admin/js/data-table/colResizable-1.5.source.js')?>"></script>
    <script src="<?= base_url('assets/admin/js/data-table/bootstrap-table-export.js')?>"></script>
    <!--  editable JS
		============================================ -->
    <script src="<?= base_url('assets/admin/js/editable/jquery.mockjax.js')?>"></script>
    <script src="<?= base_url('assets/admin/js/editable/mock-active.js')?>"></script>
    <script src="<?= base_url('assets/admin/js/editable/select2.js')?>"></script>
    <script src="<?= base_url('assets/admin/js/editable/moment.min.js')?>"></script>
    <script src="<?= base_url('assets/admin/js/editable/bootstrap-datetimepicker.js')?>"></script>
    <script src="<?= base_url('assets/admin/js/editable/bootstrap-editable.js')?>"></script>
    <script src="<?= base_url('assets/admin/js/editable/xediable-active.js')?>"></script>
    <!-- plugins JS
		============================================ -->
    <script src="<?= base_url('assets/admin/js/plugins.js')?>"></script>
    <!-- main JS
		============================================ -->
    <script src="<?= base_url('assets/admin/js/main.js')?>"></script>
    <!-- tawk chat JS
		============================================ -->
    <!--script src="<//?= base_url('assets/admin/js/tawk-chat.js')?>"></script-->
	<!-- jQuery -->
<!--script src="https://code.jquery.com/jquery-1.12.4.js"></script-->
  <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
<script>
function removeAnswer($this)
{
   if (!confirm('Are you sure want to remove?')) {
		return false;
	}
	$this.parent('div').parent('div').html('');
    
}
var count=1;
function addAnswer($this)
{
   var html='';
    html+='<div class="add_answer_row"><div class="col-md-8 col-sm-5 col-xs-12"><input type="text" class="form-control" value="" name="answersr['+count+']" placeholder="Enter Answer Title"></div><div class="col-md-2 col-sm-3 col-xs-12  text-center tb_margin"><input type="hidden" name="answers['+count+']" value="0"><input type="checkbox" name="answers['+count+']" value="1"></div><div class="col-md-2 col-sm-4 col-xs-12 pr-0 text-center" style="padding:5px;"><button type="button" onclick="removeAnswer($(this));" data-toggle="tooltip" title="Remove" class="btn btn-danger pull-right mb-10 rovoveBtn">Remove</button></div></div>';
   $('#add_answer').append(html);
count++;
}

</script>
</body>

</html>