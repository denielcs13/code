<style>

.card-view {
    background: #fff;
    margin-bottom: 20px;
	border-radius: 0;
    box-shadow: none;
    padding: 15px 15px 0;
    margin-left: -5px;
    margin-right: -5px;
}
.card-view.panel > .panel-heading {
    border: none;
    color: inherit;
    border-radius: 0;
    margin: -15px -15px 0;
    padding: 20px 15px;
}
.card-view.panel.panel-default > .panel-heading {
    background: #f4f4f4;
}
.pull-left.caption {
    line-height: 40px;
}
h6, .panel-title {
    font-size: 16px;
    line-height: 24px;
    text-transform: capitalize;
    line-height: 42px;
}
.txt-dark {
    color: #212121 !important;
}
.panel .panel-heading a {
    position: relative;
}
.clearfix {
    overflow: hidden;
    clear: both;
    float: none;
}
.panel-wrapper.collapse.in.portlet-body {
    padding-bottom: 20px;
}
.card-view.panel .panel-body {
    padding: 20px 0 20px;
}
.d-flexBox {
    display: flex !important;
}
.ma-5 {
    margin: 5px !important;
}
.borderBox {
    border: 1px solid #e9e9e9;
    padding: 10px;
}
.mr-5 {
    margin-right: 5px !important;
}
.colBox1, .colBox2, .colBox3, .colBox4, .colBox5 {
    width: 100%;
    float: left;
}
.colBox2 {
    margin-top: 10px;
}
.colBox2 h4 {
    color: #667add;
    font-weight: 500;
}
h4 {
    font-size: 24px;
    line-height: 30px;
    text-transform: capitalize;
}
.btn.btn-success, .wizard > .actions a.btn-success, .wizard > .actions a.fc-prev-button, .wizard > .actions a.fc-next-button, .wizard > .actions a.fc-today-button, .dt-buttons .btn-success.dt-button, .dt-buttons .dt-button.fc-prev-button, .dt-buttons .dt-button.fc-next-button, .dt-buttons .dt-button.fc-today-button, .tablesaw-sortable th.tablesaw-sortable-head button.btn-success, .tablesaw-sortable th.tablesaw-sortable-head button.fc-prev-button, .tablesaw-sortable th.tablesaw-sortable-head button.fc-next-button, .tablesaw-sortable th.tablesaw-sortable-head button.fc-today-button, .sweet-alert button.btn-success, .sweet-alert button.fc-prev-button, .sweet-alert button.fc-next-button, .sweet-alert button.fc-today-button, .owl-theme .owl-nav .btn-success[class*="owl-"], .owl-theme .owl-nav [class*="owl-"].fc-prev-button, .owl-theme .owl-nav [class*="owl-"].fc-next-button, .owl-theme .owl-nav [class*="owl-"].fc-today-button, button.btn-success.fc-agendaDay-button.fc-state-default.fc-corner-right, button.fc-agendaDay-button.fc-state-default.fc-corner-right.fc-prev-button, button.fc-agendaDay-button.fc-state-default.fc-corner-right.fc-next-button, button.fc-agendaDay-button.fc-state-default.fc-corner-right.fc-today-button, button.btn-success.fc-month-button.fc-state-default.fc-corner-left, button.fc-month-button.fc-state-default.fc-corner-left.fc-prev-button, button.fc-month-button.fc-state-default.fc-corner-left.fc-next-button, button.fc-month-button.fc-state-default.fc-corner-left.fc-today-button, button.btn-success.fc-agendaWeek-button, button.fc-agendaWeek-button.fc-prev-button, button.fc-agendaWeek-button.fc-next-button, button.fc-agendaWeek-button.fc-today-button, .fc-prev-button, .fc-next-button, .fc-today-button{
	background: #4aa23c !important;
    border: solid 1px #4aa23c;
	color: #fff;
}
.btn, .wizard > .actions .disabled a, .wizard > .actions .disabled a:hover, .wizard > .actions .disabled a:active, .wizard > .actions a, .wizard > .actions a:hover, .wizard > .actions a:active, .dt-buttons .dt-button, .tablesaw-sortable th.tablesaw-sortable-head button, .sweet-alert button, .owl-theme .owl-nav [class*="owl-"], button.fc-agendaDay-button.fc-state-default.fc-corner-right, button.fc-month-button.fc-state-default.fc-corner-left, button.fc-agendaWeek-button, .fc-prev-button, .fc-next-button, .fc-today-button{
	    color: #fff;
    padding: 10px 20px;
    text-transform: capitalize;
    border-radius: 2px;
    outline: none;
    box-shadow: none;
    border: none;
    -webkit-transition: all 0.3s ease;
    -moz-transition: all 0.3s ease;
    transition: all 0.3s ease;
}
.colBox5 {
    margin-left: 15px;
}
.colBox5 span {
    color: #212121;
    font-size: 18px;
    float: left;
    margin-right: 5px;
}
.colBox5 h5 {
    color: #212121;
    padding-right: 15px;
}
h5 {
    font-size: 18px;
    line-height: 26px;
    text-transform: capitalize;
}
a.btn-success {
    margin-top: 0;
}

.panel-body a{
	margin-top:0;
	font-size:18px;
}









</style>
<div class="data-table-area mg-b-15">
            <div class="container-fluid">			
			<div class="row">
                        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                            <div class="breadcome-list">
                                <div class="row">
                                    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                        <ul class="breadcome-menu">
                                            <li><a href="<?php echo BASE_URL_MATH_ADMIN;?>">Dashboard</a> <span class="bread-slash">/</span>
                                            </li>
											<li class="active"><span>Syllabus</span></li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
            </div>

								
		<?= form_open('',array('name'=>'frm','enctype'=>'multipart/form-data')) ?>	
                <div class="row">
                    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
					<div class="sparkline13-list">
                        <div class="tab-pane" id="tab_2">
                                <?php 
								if($this->session->flashdata('success_msg') != null && $this->session->flashdata('success_msg') != "")
								{ 
								?>
								<div class="row">
									<div class="col-md-12">
										<div style="margin-top:18px;" class="alert alert-success fade in">
											<?php echo $this->session->flashdata('success_msg');?>
										</div>
									</div>
								</div>
								<?php 
								} 
								?>	

								<div class="panel card-view">	
									
									<!-- <div class="heading_title">
										<i class="fa fa-gift"></i> Edit/Delete Departmeant
                                    </div>-->
                                <div class="sparkline13-hd">
                                <div class="panel-heading">
								<div class="main-sparkline13-hd">
                                    <h1>Syllabus <span class="table-project-n"><?php echo $year_dtl->class_name;?> </span> </h1>
                                </div>
                                <div class="main-sparkline13-hd pull-right">
								<a href="<?=base_url(MATH_ADMIN.'/syllabus-order/'.$year_dtl->class_slug);?>" class="btn btn-success">Set Main Skill Order</a> <a href="<?=base_url(MATH_ADMIN.'/add-skill/'.$year_dtl->class_slug);?>" class="btn btn-success">Add Skill</a>
                                
                                </div>
                             <div class="clearfix"></div>
							</div>
                            </div>
							
											
											  <!-- BEGIN FORM-->
                                        <div class="panel-wrapper collapse in portlet-body">
											<div class="panel-body">
												<div class="table-wrap">
													<?PHP 
                                                    $i=0;
                                                    $x='A';
                                                    foreach($SylList as $SylListDetail):
                                                    if($i%2==0):
                                                    
                                                    ?>
													<div class="row ma-5 d-flexBox">
														<div class="col-md-6 col-sm-6 col-xs-12 borderBox mr-5">
                                                              
                                                               <div class="colBox2">
                                                                  <h4 class="pull-left"><?=$x.' '.$SylListDetail->skill_name?></h4>
                                                                  <a href="<?=base_url(MATH_ADMIN.'/syllabus-order/'.$year_dtl->class_slug.'/'.$SylListDetail->skill_slug);?>" class="btn btn-success pull-right">Set Sub-Skill Order</a>
                                                               </div>
                                                               
                                                               
                                                               <?php 
                                                               $parent_skill=$SylListDetail->skill_id;
                                                               $subskill=$this->main_model->get_detail($obj,'master_skill',array('skill_class'=>$year_id,'skill_parent'=>$parent_skill),$insgle=null,'skill_order','asc');
                                                               $j=1;
                                                               foreach($subskill as $subskilldatail):
                                                               ?>
                                                               <div class="colBox5 pull-left">
                                                                  <span><?=$x.'.'.$j?></span>
                                                                  <h5><a class="pull-left"  href="<?=base_url(uri_string()).'/'.$subskilldatail->skill_slug?>">
                                                                     
                                                                     <?=$subskilldatail->skill_name?>
                                                                  </a><a class="pull-right" href="<?=base_url(MATH_ADMIN.'/edit-skill/'.$year_dtl->class_slug.'/'.$subskilldatail->skill_slug)?>">
                                                                     edit
                                                                  </a><!--<span class="pull-right" style="margin:0 2px;">|</span><a class="pull-right" href="#">
                                                                     delete
                                                                  </a>-->
                                                                  
                                                                  </h5>
                                                               </div>
                                                               
                                                               <?php
                                                               $j++; 
                                                               endforeach;
                                                               ?>
                                                               
                                                            </div>
													   <?php 
                                                       else:
                                                       ?>
														<div class="col-md-6 col-sm-6 col-xs-12 borderBox mr-5">
                                                              
                                                               <div class="colBox2">
                                                                  <h4 class="pull-left"><?=$x.' '.$SylListDetail->skill_name?></h4>
                                                                  <a href="<?=base_url(MATH_ADMIN.'/syllabus-order/'.$year_dtl->class_slug.'/'.$SylListDetail->skill_slug);?>" class="btn btn-success pull-right">Set Sub-Skill Order</a>
                                                               </div>
                                                               
                                                               
                                                               <?php 
                                                               $parent_skill=$SylListDetail->skill_id;
                                                               $subskill=$this->main_model->get_detail($obj,'master_skill',array('skill_class'=>$year_id,'skill_parent'=>$parent_skill),$insgle=null,'skill_order','asc');
                                                               $j=1;
                                                               foreach($subskill as $subskilldatail):
                                                               ?>
                                                               <div class="colBox5">
                                                                  <span><?=$x.'.'.$j?></span>
                                                                  <h5><a class="pull-left"  href="<?=base_url(uri_string()).'/'.$subskilldatail->skill_slug?>">
                                                                     
                                                                     <?=$subskilldatail->skill_name?>
                                                                  </a><a class="pull-right" href="<?=base_url(MATH_ADMIN.'/edit-skill/'.$year_dtl->class_slug.'/'.$subskilldatail->skill_slug)?>">
                                                                     edit
                                                                  </a><!--<span class="pull-right" style="margin:0 2px;">|</span><a class="pull-right" href="#">
                                                                     delete
                                                                  </a>-->
                                                                  
                                                                  </h5>
                                                               </div>
                                                               <?php
                                                               $j++; 
                                                               endforeach;
                                                               ?>
                                                               
                                                            </div>
													
													</div>
													<?PHP
                                                     endif;
                                                    $x++;
                                                    $i++;
                                                    endforeach;
                                                    ?>
													
													
													
													
													
													
													
                                                    
												</div>
                                            </div>			 
                                        </div>
										<!-- END FORM-->
                                    
                               
                            </div>
						</div>
						</div>
                        </div>
                    </div>
					</form>
                </div>
            </div>
        </div>
		
<script type="text/javascript">
    var url="<?php echo BASE_URL_MATH_ADMIN;?>";
    function deletedata(id){
       var r=confirm("Do you want to delete this?")
        if (r==true)
          window.location = url+"syllabus/delete_syllabus/"+id;
        else
          return false;
        } 
</script>	

<script type="text/javascript">
    var url="<?php echo BASE_URL_MATH_ADMIN;?>";
    function deletedata1(id){
       var r=confirm("Do you want to delete this?")
        if (r==true)
          window.location = url+"syllabus/delete_syllabus_subskill/"+id;
        else
          return false;
        } 
</script>