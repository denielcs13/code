 
		   <div class="page-wrapper page-container dashboard-section depertment-sec">
		   <div class="container-fluid page-content-wrapper">
                <!-- BEGIN CONTENT BODY -->
                <!-- Breadcrumb -->
				<div class="row heading-bg headingMain">
					<div class="col-lg-12 col-md-12">
					  <ol class="breadcrumb">
						<li><a href="<?php echo BASE_URL_MATH_ADMIN;?>">Dashboard</a></li>
						<li class="active"><span>Users</span></li>
					  </ol>
					</div>
				</div>
					<!-- /Breadcrumb -->
						<?= form_open('',array('name'=>'frm','enctype'=>'multipart/form-data')) ?>	
				<div class="row">
                    <div class="col-md-12">
						
                            <!-- CONTENT HEAR -->    
                            <div class="tab-pane" id="tab_2">
                                <?php 
								if($this->session->flashdata('success_msg') != null && $this->session->flashdata('success_msg') != "")
								{ 
								?>
								<div class="row">
									<div class="col-md-12">
										<div style="margin-top:18px;" class="alert alert-success fade in">
											<?php echo $this->session->flashdata('success_msg');?>
										</div>
									</div>
								</div>
								<?php 
								}else if($this->session->flashdata('msgdel') != null && $this->session->flashdata('msgdel') != "")
								{ 
								?>
								<div class="row">
									<div class="col-md-12">
										<div style="margin-top:18px;" class="alert alert-success fade in">
											<?php echo $this->session->flashdata('msgdel');?>
										</div>
									</div>
								</div>
								<?php 
								} 
								?>	

								<div class="panel panel-default card-view">	
									
									<!-- <div class="heading_title">
										<i class="fa fa-gift"></i> Edit/Delete Departmeant
                                    </div>-->
                                           
									
										<div class="panel-heading sidebox">
											<div class="pull-left caption">
											<h6 class="panel-title txt-dark titleP">Users List </h6>
											</div>
											<!--div class="pull-right caption">
											<a href="<//?=base_url('math-admin/adminmgmt/syllabus-order/'.$year_dtl->class_slug);?>" class="btn btn-success">Set Main Skill Order</a>
											
                                            <a href="<//?=base_url('math-admin/adminmgmt/add-skill/'.$year_dtl->class_slug);?>" class="btn btn-success">Add Skill</a>
                                            </div-->
										<div class="pull-right">
												<!--<a href="<//?php echo BASE_URL_MATH_ADMIN;?>/syllabus/add_syllabus_pre">
													<button type="submit" class="btn btn-success edit  pull-right">Add New</button>
													
												</a>-->
												
											</div>
											<div class="clearfix"></div>
										</div>
											
											  <!-- BEGIN FORM-->
                                        <div class="panel-wrapper collapse in portlet-body">
											<div class="panel-body">
												<div class="table-wrap">
												<div class="row">
														<div class="col-md-12 col-sm-12 col-xs-12 borderBox">       
														<div class="">
												<table class="table table-bordered nowrap display">         			
										<thead>
																<tr>
																	<th>#</th>
																    <th>Username</th>
																	<th>Email</th>
                                                                   <th>Name</th>
																   <th>Role Type</th>
																   <th>Action</th>
																</tr>
										   </thead>
										   <tbody>
													<?PHP 
													
                                                    $i=1;                                                   
                                                    foreach($userlists as $userlist):
													?>
													          <tr>
         				<td><?=$i?></td>
         				<td><?=$userlist->user_name?></td>
         				 <td><?=$userlist->email?></td>
						 <td><?=$userlist->first_name?></td>
						 <td><?=$userlist->role_type?></td>
						 <td><a class="pull-left" href="<?=base_url('math-admin/adminmgmt/edit-user/'.$userlist->user_id)?>">
                                                                     edit
                                                                  </a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; | <a class="pull-right" href="<?=base_url('math-admin/adminmgmt/delete-user/'.$userlist->user_id)?>">
                                                                     delete
                                                                  </a></td>
                         </tr>						 
                                                                  
                                                             									
													
													<?PHP
                                                     $i++;
                                                    endforeach;
                                                    ?>
													</tbody>						
         		</table>
												</div>
                                                             </div>
													    </div>	     
												</div>
                                            </div>			 
                                        </div>
										<!-- END FORM-->
                                    
                               
                            </div>
						</div>	
                        <!-- END CONTENT HEAR -->                               
                    </div>
                </div>
				</form>
              
<script type="text/javascript">
    var url="<?php echo BASE_URL_MATH_ADMIN;?>";
    function deletedata(id){
       var r=confirm("Do you want to delete this?")
        if (r==true)
          window.location = url+"syllabus/delete_syllabus/"+id;
        else
          return false;
        } 
</script>	

<script type="text/javascript">
    var url="<?php echo BASE_URL_MATH_ADMIN;?>";
    function deletedata1(id){
       var r=confirm("Do you want to delete this?")
        if (r==true)
          window.location = url+"syllabus/delete_syllabus_subskill/"+id;
        else
          return false;
        } 
</script>