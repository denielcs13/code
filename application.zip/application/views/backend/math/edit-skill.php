<style>
   .pagin{
   }
   .pagin strong {
   text-decoration: none;
   color: #212121;
   font-weight: bold;
   border: 1px solid;
   color: white;
   background: blueviolet;
   }
   .pagin a {
   padding: 10px;
   border: 1px solid;
   }
   .add_answer_row{
    padding-left:15px;
    padding-right:15px;
    
   }
</style>
<div class="data-table-area mg-b-15"> <div class="container-fluid">
   <!-- Title -->
   <div class="row">                        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">                            <div class="breadcome-list">                                <div class="row">                                    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">                                        <ul class="breadcome-menu">                                            <li><a href="<?php echo BASE_URL_MATH_ADMIN;?>">Dashboard</a> <span class="bread-slash">/</span>                                            </li>                                            <li><span class="bread-blod"><a href="<?=base_url(uri_string())?>"><span><?=$this->uri->segment(3)?></span></a></span>											<span class="bread-slash">/</span>                                            </li>											<li class="active"><span><?=$this->uri->segment(4)?></span></li>                                        </ul>                                    </div>                                </div>                            </div>                        </div>            </div>
   <!-- /Title -->
   <?php 
      if($this->session->flashdata('success_msg') != null && $this->session->flashdata('success_msg') != "")
      		{ 
      		?>
   <div class="row">
      <div class="col-md-12">
         <div style="margin-top:18px;" class="alert alert-success fade in">
            <?php echo $this->session->flashdata('success_msg');?>
         </div>
      </div>
   </div>
   <?php 
      } 
      ?>	
   <div class="row">
      <!-- Bordered Table -->
      <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">         <div class="sparkline12-list">         <div class="sparkline13-hd">                                <div class="panel-heading">								<div class="main-sparkline13-hd">                                    <h1><?=ucwords(str_replace('-',' ',$this->uri->segment(3)))?><span class="table-project-n"> </span> </h1>                                </div>                                <div class="main-sparkline13-hd pull-right">								 								 <a href="<?=base_url(MATH_ADMIN.'/add-subskill/'.$year_dtl->class_slug);?>" class="btn btn-success">Add Sub-Skill</a>                                                                </div>                             <div class="clearfix"></div>							</div>            </div>
            <div class="panel-wrapper collapse in">
               <div class="panel-body">
                  <div class="panel-body">
                     <div class="table-wrap">
                        <div class="">
                          <form method="post" action="<?=base_url(MATH_ADMIN.'/edit-skill/'.$year_dtl->class_slug.'/'.$skillid)?>">
                           
                           <div class="mainskill">
                               <div style="margin-bottom: 10px;"  class="row">
                                    <div class="col-lg-1">
                                        <label>Skill</label>
                                   </div>
                                   <div class="col-lg-4">
                                        <input class="form-control" name="skill_name" type="text" value="<?=$subskilldefault->skill_name;?>" placeholder="Enter Skill Name" />
                                   </div>
                                    <div class="col-lg-4">
                                        <input class="form-control" name="skill_dec" value="<?=$subskilldefault->skill_descri;?>" type="text" placeholder="Enter Skill Videos link" />
                                   </div>
                                   <div class="col-lg-2">
                                        <!--<button class="btn btn-primary Sub-Skill" type="button">Add More Sub-Skill</button>
                                   -->
                                   </div>
                               
                               </div>
                               
                           </div>
                           <div class="pull-right" style="padding-right:108px ;">
                               <input type="submit" class="btn btn-success" name="skill-upadte" value="Update" />
                               </div>
                          
                          </form> 
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </div>
      <!-- /Bordered Table -->
   </div>
</div>
<script>

var cont=1;
 $('.Sub-Skill').click(function(){
    var html='<div style="margin-bottom: 10px;" class="row"> <div class="col-lg-1"> <label>Sub Skill</label> </div><div class="col-lg-4"> <input class="form-control" placeholder="Enter Sub Skill Name" name="subskill_name[]" type="text"/> </div><div class="col-lg-4"> <input class="form-control" placeholder="Enter Sub Skill Videos link" name="subskill_dec[]" type="text"/> </div><div class="col-lg-2"> <button class="btn btn-danger" onclick="removethis($(this))" title="Remove this row" type="button">remove</button> </div></div>';
$('.mainskill').append(html);
cont++;
});
   
function removethis($this)
{
if (!confirm('Are you sure want to remove?')) {
	return false;
}
 $this.parent('div').parent('.row').remove();   
}   
   
   
 
     
CKEDITOR.replace( 'question_name', {
    height: 300,
    filebrowserUploadUrl: '<?php echo base_url("adminmgmt/questions/upload/".$year_dtl->class_name)?>',
    
} );
CKEDITOR.replace( 'explanation', {
    height: 300,
    filebrowserUploadUrl: '<?php echo base_url("adminmgmt/questions/upload/".$year_dtl->class_name)?>',
    
} );
    





</script>