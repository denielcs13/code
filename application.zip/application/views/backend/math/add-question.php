<div class="data-table-area mg-b-15">
            <div class="container-fluid">			
			<div class="row">
                        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                            <div class="breadcome-list">
                                <div class="row">
                                    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                        <ul class="breadcome-menu">
                                            <li><a href="<?php echo BASE_URL_MATH_ADMIN;?>">Dashboard</a> <span class="bread-slash">/</span>
                                            </li>
                                            <li><span class="bread-blod"><a href="<?=base_url(uri_string())?>"><span><?=$this->uri->segment(3)?></span></a></span>
											<span class="bread-slash">/</span>
                                            </li>
											<li class="active"><span><?=$this->uri->segment(4)?></span></li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
            </div>
			<?php 
      if($this->session->flashdata('success_msg') != null && $this->session->flashdata('success_msg') != "")
      		{ 
      		?>
   <div class="row">
      <div class="col-md-12">
         <div style="margin-top:18px;" class="alert alert-success fade in">
            <?php echo $this->session->flashdata('success_msg');?>
         </div>
      </div>
   </div>
   <?php 
      } 
      ?>
                <div class="row">
                    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                        <div class="sparkline12-list">
                            <div class="sparkline12-hd">
                                <div class="main-sparkline12-hd">
                                    <h1><?=$year_dtl->class_name?></h1>
                                </div>
                            </div>
                            <div class="sparkline12-graph">
                             <div class="basic-login-form-ad">
                                    <div class="row">
									<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                            <div class="all-form-element-inner">
                                                <form action="<?=base_url(MATH_ADMIN.'/add-question/'.$year_dtl->class_slug)?>" name="frm" enctype="multipart/form-data" method="post" accept-charset="utf-8">
									<div class="form-group-inner">			
									<div class="row">
                                   <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12">
                                  <label class="login2 pull-right pull-right-pro">Skill</label>
                                      </div>
                             <div class="col-lg-9 col-md-9 col-sm-9 col-xs-12">
                            <input type="text" hidden="" name="quetype" value="html" />
					<div class="form-select-list">
                    <select class="form-control custom-select-value" name="ques_skillid" id="ques_skillid">
			        <option value="" style="display: none;" >Select Skill</option>
				   <?php 
                    foreach($SylList as $ques_skillid):
                                                
                   ?>
                   <option value="<?=$ques_skillid->skill_id?>"><?=$ques_skillid->skill_name?></option>
                   <?php
                   endforeach;
                    ?>
	            </select>
                     </div>
                       </div>
                      </div>
					  </div>
					  <div class="form-group-inner">
					  <div class="row">
                                   <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12">
                                  <label class="login2 pull-right pull-right-pro">Sub Skill</label>
                                      </div>
                             <div class="col-lg-9 col-md-9 col-sm-9 col-xs-12">
							 <div class="form-select-list" id="subskills">
                    <select class="form-control custom-select-value" name="subskill">
			        
	                </select>
                     </div>
                       </div>
                      </div>
					  </div>
					  <div class="form-group-inner">
					  <div class="row">
                                   <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12">
                                  <label class="login2 pull-right pull-right-pro">Question Title</label>
                                   </div>
                             <div class="col-lg-9 col-md-9 col-sm-9 col-xs-12">
							 <textarea id="question_name" name="question_name"  >	
                            </textarea>
                       </div>
                      </div>
					  </div>
					  <div class="form-group-inner">
					  <div id="addrow_question">
					  <div class="row">
                                   <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12">
                                  <label class="login2 pull-right pull-right-pro">Question Title</label>
                                   </div>
                             <div class="col-lg-9 col-md-9 col-sm-9 col-xs-12">
							 <div id="add_answer" class="row">
                                                 <div class="add_answer_row">
                                                 <div class="col-md-8 col-sm-8 col-xs-12">
                                                 <input type="text" class="form-control" value="" name="answersr[0]" placeholder="Enter Answer Title">
                                                 </div>
                                                 <div class="col-md-2 col-sm-3 col-xs-12  text-center tb_margin">
                                                 <input type="hidden" name="answers[0]" value="0">
                                                 <input type="checkbox" name="answers[0]" value="1">
                                                 </div>
                                                 <div class="col-md-2 col-sm-2 col-xs-12 pr-0 text-center" style="padding:5px;">
                                                  <button type="button" onclick="removeAnswer($(this));" data-toggle="tooltip" title="Remove" class="btn btn-danger pull-right mb-10 rovoveBtn">Remove</button>
                                                 </div>
                                                 </div>
                                             </div>
                       </div>
                      </div>
					  <div class="row">
                                   
                             <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
							 <div class="form-group">
									<div class="form-actions right">
									<p class="pull-right rovoveBtn">
									<a onclick="addAnswer($(this))" class="btn btn-primary mb-10">Add Answer</a> &nbsp; &nbsp;
									</p>
									</div>
									</div>
                       </div>
                      </div>
					  </div>
					  </div>
					  <div class="form-group-inner">
					  <div class="row">
                                   <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12">
                                  <label class="login2 pull-right pull-right-pro">Explanation</label>
                                   </div>
                             <div class="col-lg-9 col-md-9 col-sm-9 col-xs-12">
							 <textarea id="explanation" name="explanation"  >	
                              </textarea>
                       </div>
                      </div>
					  </div>
					  <div class="form-group-inner">
					  <div class="row">
                      <div class="col-lg-3"></div>
                      <div class="col-lg-9">
                      <div class="login-horizental cancel-wp pull-right form-bc-ele">
                                                                        
                     <button class="btn btn-sm btn-primary login-submit-cs" type="submit" onclick="return validateForm();">Save</button>
                             </div>
                                                                </div>
                     </div>
					 </div>
					  
					  
					  
					  
                                                    </div>
													
												</form>
										    </div>
                                     </div>											
                                     </div>
                            </div>							
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
		
<script>
        
    CKEDITOR.replace( 'question_name', {height: 300, 

/* filebrowserUploadUrl: '<?php echo base_url("adminmgmt/questions/upload/" . $year_dtl->class_name) ?>', */
filebrowserUploadUrl : '<?=base_url("adminmgmt/questions/upload/". $year_dtl->class_slug);?>?CKEditor=question_name&CKEditorFuncNum=1&langCode=en', 
} ); 
CKEDITOR.replace( 'explanation',{ height: 300,
/* filebrowserUploadUrl: '<?php echo base_url("adminmgmt/questions/upload/" . $year_dtl->class_name) ?>', */
/* filebrowserUploadUrl: '<?php echo base_url("adminmgmt/questions/upload/" . $year_dtl->class_name) ?>', */
filebrowserUploadUrl : '<?=base_url("adminmgmt/questions/upload/". $year_dtl->class_slug);?>?CKEditor=explanation&CKEditorFuncNum=1&langCode=en', 
} );
    
    
    $('select[name=ques_skillid]').change(function(){
    var skill=$(this).val();
    var year='<?=$year_id?>';
    var url="<?=base_url(MATH_ADMIN.'/get-subskill/')?>"+skill+'/'+year;
    $.get(url,function(data){
       if(data)
       {
        $('select[name=subskill]').html(data)
       } 
    });
});




</script>