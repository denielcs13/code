<div class="data-table-area mg-b-15">
            <div class="container-fluid">			
			<div class="row"> 
                        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                            <div class="breadcome-list">
                                <div class="row">
                                    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                        <ul class="breadcome-menu">
                                            <li><a href="<?php echo BASE_URL_ENGLISH_ADMIN;?>">Dashboard</a> <span class="bread-slash">/</span>
                                            </li>
                                            <li class="active"><span>Syllabus</span></li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
            </div>
			<?php 
						if($this->session->flashdata('success_msg') != null && $this->session->flashdata('success_msg') != "")
								{ 
								?>
								<div class="row">
									<div class="col-md-12">
										<div style="margin-top:18px;" class="alert alert-success fade in">
											<?php echo $this->session->flashdata('success_msg');?>
										</div>
									</div>
								</div>
								<?php 
							} 
							?>
                <div class="row">
                    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                        <div class="sparkline13-list">
                            <div class="sparkline13-hd">
                                <div class="panel-heading">
								<div class="main-sparkline13-hd">
                                    <h1><a href="<?php echo BASE_URL_ENGLISH_ADMIN.'syllabus/'.$year;?>"><?=$year_dtl->class_name?></a> <span class="bread-slash">/</span><span class="table-project-n"> <?=$skill->skill_name?> </span> </h1>
                                </div>
                                
                             <div class="clearfix"></div>
							</div>
                            </div>
                            <div class="sparkline13-graph">
                                <div class="datatable-dashv1-list custom-datatable-overright">
                                    <div id="toolbar">
                                        <select class="form-control dt-tb">
											<option value="">Export Basic</option>
											<option value="all">Export All</option>
											<option value="selected">Export Selected</option>
										</select>
                                    </div>
                                    <table id="table" data-toggle="table" data-pagination="true" data-search="true" data-show-columns="true" data-show-pagination-switch="true" data-show-refresh="true" data-key-events="true" data-show-toggle="true" data-resizable="true" data-cookie="true"
                                        data-cookie-id-table="saveId" data-show-export="true" data-click-to-select="true" data-toolbar="#toolbar">
										<?php 
                                            if($DepList):
                                            
                                            ?>
                                        <thead>
                                            <tr>
                                                <th data-field="state" data-checkbox="true"></th>
                                                <th data-field="id">ID</th>
                                                <th>Title</th>
                                                <th>Year</th>
												<th>Type</th>
                                                <!--th data-field="action">Action</th-->
												<th>Pre-view</th>
                                            </tr>
                                        </thead>
                                        <tbody>
										<?php 
                                                 foreach($DepList as $result):
											     $ques_type_ar=array_map('trim',explode(',',$result->ques_type));
													if(in_array('26',$ques_type_ar)){
													$ques_name=  base64_decode($result->ques_name); 
													
													}
													else{ $ques_name= $result->ques_name;}
                                                  ?>
                                            <tr>
                                                <td></td>
                                                <td><?php echo $result->ques_id;?></td>
                                                <td><?php echo $ques_name;?></td>
                                                <td><?php echo $year_dtl->class_name;?></td>
												<td><?php 
													  
													  foreach($ques_type_ar as $key=>$val){
														$query = $obj->query("select ques_type from ques_type where id IN('".$val."')");
														foreach ($query->result() as $row)
															{
																	$ques_type[]= $row->ques_type;
																	
															}
													  }
													   echo implode(',',$ques_type);
													   $ques_type=array();
													   ?></td>
                                                						 
						 
						 
						
                                                <td><a class="btn btn-info" href="<?='javascrip:void(0)'; //base_url('pre-view/'.$year_dtl->class_id.'/'.$result->ques_id) ?>">Pre-view</a>
                                                </td>
                                                
                                                
                                            </tr>
											<?php	endforeach;
													
													?> 
                                            
                                        </tbody>
										 <?php else: 
                                          echo "<th style='font-size: 21px;text-align: center;'>Questions Not Found</th>";
                                          endif; ?>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>