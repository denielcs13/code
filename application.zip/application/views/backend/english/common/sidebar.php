<div class="left-sidebar-pro">
        <nav id="sidebar" class="">
            <div class="sidebar-header">
                <a href="/"><img class="main-logo" style="width: 200px;" src="<?= base_url('assets/admin/img/logo/logo_icon.png')?>" alt="" /></a>
                <strong><a href="index.html"><img src="<?= base_url('assets/admin/img/logo/logo_icon.png')?>" alt="" /></a></strong>
            </div>
            <div class="left-custom-menu-adp-wrap comment-scrollbar">
                <nav class="sidebar-nav left-sidebar-menu-pro">
                    <ul class="metismenu" id="menu1">
                        <li class="active">
                            <a aria-expanded="false" href="<?php echo BASE_URL_ENGLISH_ADMIN;?>">
								   <span class="educate-icon educate-home icon-wrap" aria-hidden="true"></span>
								   <span class="mini-click-non">Dashboard</span>
								</a>
                            
                        </li>
                        
                        <li>
                            <a class="has-arrow" href="javascript:void(0);" aria-expanded="false"><span class="educate-icon educate-form icon-wrap"></span> <span class="mini-click-non">Question & Exam</span></a>
                            <ul class="submenu-angle" aria-expanded="false">
							<?php 
                    $master_class=$this->main_model->getall($obj,'master_class','*');
                    foreach($master_class as $class):
                    ?>
                                <li><a title="All Students" href="<?=base_url(ENGLISH_ADMIN.'/questions/'.$class->class_slug)?>"><span class="mini-sub-pro"><?=$class->class_name?></span></a></li>
								<?php endforeach; ?>
                                
                              </ul>
                        </li>
						
						<li>
                            <a class="has-arrow" href="javascript:void(0);" aria-expanded="false"><span class="educate-icon educate-apps icon-wrap"></span> <span class="mini-click-non">Syllabus & Notes</span></a>
                            <ul class="submenu-angle app-mini-nb-dp" aria-expanded="false">
							<?php 
                    $master_class=$this->main_model->getall($obj,'master_class','*');
                    foreach($master_class as $class):
                    ?>
                                <li><a title="Notifications" href="<?=base_url(ENGLISH_ADMIN.'/syllabus/'.$class->class_slug)?>"><span class="mini-sub-pro"><?=$class->class_name?></span></a></li>
						<?php endforeach; ?>
                                
                            </ul>
                        </li>
                      </ul>
                </nav>
            </div>
        </nav>
    </div>