<script>
function validateForm()

{
  
 var syllabuscsv=document.forms["frm"]["syllabuscsv"];
 if (syllabuscsv.value=="")
   {
  alert("Please select syllabus name.");
  syllabuscsv.focus();
  return false;
   }
}
</script>
<?php //include 'header.php';
//$row=$ques_detail;



 ?>
	<div class="page-wrapper">
		<div class="container-fluid">
			<!-- Title -->
			<div class="row heading-bg headingMain ma-0">
				<!-- Breadcrumb -->
				<div class="col-lg-12 col-md-12 pr-0">
					<ol class="breadcrumb">
						<li><a href="<?php echo BASE_URL_ADMIN;?>">Dashboard</a></li>
						<li class="active"><span>Question</span></li>
					</ol>
				</div>
				<!-- /Breadcrumb -->
			</div>
			<!-- /Title -->
 
        <!-- BEGIN CONTAINER -->
        <div class="page-container">
            <!-- BEGIN CONTENT -->
            <div class="page-content-wrapper add-Center">
                <!-- BEGIN CONTENT BODY -->
                <div class="page-content">
                    <!-- BEGIN PAGE HEADER-->                    
                    
                    <!-- BEGIN PAGE TITLE-->
                    <h3 class="page-title"></h3>
                

				   <!-- END PAGE TITLE-->
                    <!-- END PAGE HEADER-->
                    <div class="row">
                        <div class="col-md-12">
                            
							 <?php 
								if($this->session->flashdata('success_msg') != null && $this->session->flashdata('success_msg') != "")
								{ 
								?>
								<div class="row">
									<div class="col-md-12">
										<div style="margin-top:18px;" class="alert alert-success fade in">
											<?php echo $this->session->flashdata('success_msg');?>
										</div>
									</div>
								</div>
								<?php 
								} 
								?>	
							<div class="panel panel-default card-view">
							
								<div class="panel-heading">
							<!-- CONTENT HEAR -->    
                               
                                            <div class="portlet-title">
                                               Import
												
                                            </div>
											</div>
											<div class="panel-wrapper collapse in">
											<div class="panel-body">
                                            <div class="col-md-12 portlet-body form">
												
											   <!-- BEGIN FORM-->
                                                
                                                 <?= form_open('',array('name'=>'frm','enctype'=>'multipart/form-data')) ?>	

												 <div class="form-body">                                                        
                                                  
														<div class="row">
														
                                                            <div class="col-md-12">
                                                                <div class="form-group">
                                                                    <label class="control-label col-md-2">Select File</label>
                                                                    <div class="col-md-10">
																		<input type="file" class="form-control"  name="syllabuscsv" value="" >
                                                                        <span class="help-block"> <br/>
																		
																	<!--	<a href="<?php  echo  BASE_URL_DATA?>sample-staff.csv" target="_blank">Sample CSV</a> 
																	-->
																		
																		</span>
                                                                        <span class="help-block">  </span>
                                                                    </div>
                                                                </div>
                                                            </div>
															</div>
															
														
															<!---loop of Question--->
														
																	
													
																												
														<input type="hidden" name="action" value="Add_Update" />				
																														
                                                       

													   
                                                    </div>
                                                    <div class="form-actions">
                                                        <div class="row">
                                                            <div class="col-md-12">
                                                             
                                                                    <div class=" col-md-12">
                                                                        <button type="submit" class="btn btn-success pull-right rovoveBtn" onclick="return validateForm();" >Save</button>
                                                                      
                                                                    </div>
                                                                
                                                            </div>
                                                            <div class="col-md-6"> </div>
                                                        </div>
                                                    </div>
                                                </form>
                                                <!-- END FORM-->
                                            </div>
                                        </div>
										</div>
										</div>
										</div>
                                    
                                    
                            <!-- END CONTENT HEAR -->                               
                                
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            
<?php //include 'footer.php'; ?>    
   