
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<link rel="shortcut icon" href="https://www.theuniversityofenglish.com/assets/images/favicon.png" />
<link href="https://www.theuniversityofenglish.com/assets/images/60x60.png" rel="apple-touch-icon" />
<link href="https://www.theuniversityofenglish.com/assets/images/76x76.png" rel="apple-touch-icon" sizes="76x76" />
<link href="https://www.theuniversityofenglish.com/assets/images/120x120.png" rel="apple-touch-icon" sizes="120x120" />
<link href="https://www.theuniversityofenglish.com/assets/images/152x152.png" rel="apple-touch-icon" sizes="152x152" />
<meta name="description" content="">
<meta name="author" content="">
<title>The University Of English </title>

<!-- Bootstrap core CSS -->
<link href="https://www.theuniversityofenglish.com/assets/css/bootstrap.min.css" rel="stylesheet">
<link href="https://www.theuniversityofenglish.com/assets/css/font-awesome.min.css" rel="stylesheet" />
<link href="https://www.theuniversityofenglish.com/assets/css/font-awesome.css" rel="stylesheet" />
<link href="https://www.theuniversityofenglish.com/assets/css/animate.css" rel="stylesheet" />
<link href="https://www.theuniversityofenglish.com/assets/css/404.css" rel="stylesheet" />
<link href="https://www.theuniversityofenglish.com/assets/css/title.css" rel="stylesheet" />
<link href="https://www.theuniversityofenglish.com/assets/css/owl.carousel.min.css" rel="stylesheet" />
<link href="https://www.theuniversityofenglish.com/assets/css/owl.carousel.css" rel="stylesheet" />
<script src="https://cdnjs.cloudflare.com/ajax/libs/modernizr/2.6.2/modernizr.min.js"></script>
<script src="https://www.theuniversityofenglish.com/assets/js/wow.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
<script src='https://www.theuniversityofenglish.com/assets/js/unispeech.js'></script>
<script src=''></script>


<!-- Custom styles for this template -->
<link href="https://www.theuniversityofenglish.com/assets/style.css" rel="stylesheet">
</head>

<body>
<header class="header fadeInDown">
  <div id="topbar">
    <div class="container">
      <div class="row">
        <div class="col-lg-2"><a class="text-logo" href="https://www.theuniversityofenglish.com/">The University of English</a></div>
        
      </div>
    </div>
  </div>
  <div class="container">
    <div class="row">
      <div class="col-xs-12 col-sm-12 col-md-2 col-lg-2 logo-sect">
        <div class="logo"> <a href="https://www.theuniversityofenglish.com/"><img src="https://www.theuniversityofenglish.com/assets/images/logo.png" alt="" title="" /></a> </div>
</div>
      
    </div>
  </div>
  <nav id="navbar" class="navbar navbar-expand-lg navbar-dark">
    <div class="container">
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation"><i class="fa fa-bars" aria-hidden="true"></i> Select Year</button>
      <div class="collapse navbar-collapse float-right private-header" id="navbarResponsive">
   
	
		
		
      
	
			
	  
	  
	  
	  
	  </div>
    </div>
  </nav>
</header>

<!-- Bootstrap core JavaScript --> 
<script src="https://www.theuniversityofenglish.com/assets/js/jquery.min.js"></script> 
<script src="https://www.theuniversityofenglish.com/assets/js/bootstrap.bundle.min.js"></script> 
<script src="https://www.theuniversityofenglish.com/assets/js/main.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1/jquery.min.js"></script>
<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
<script src="https://www.theuniversityofenglish.com/assets/js/jquery.slicknav.js"></script>
<script src="https://www.theuniversityofenglish.com/assets/js/demo-2.js"></script>

<script src="https://www.theuniversityofenglish.com/assets/js/owl.carousel.js"></script>
<script src="https://www.theuniversityofenglish.com/assets/js/owl.carousel.min.js"></script> 

<script>
            $(document).ready(function() {
              var owl = $('.owl-carousel');
              owl.owlCarousel({
				items: 1,
                margin: 10,
                nav: true,
                loop: true,
				 autoplay: true,
                responsive: {
                  0: {
                    items: 1
                  },
                  600: {
                    items: 2
                  },
                  1000: {
                    items: 3
                  }
                }
              })
            })
          </script> 
		 
</body>
</html> 