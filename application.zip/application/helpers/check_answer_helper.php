<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

if(!function_exists('check_answer'))
{
function check_answer($postdata,$obj){
		
			$CI =& get_instance();
			$CI->load->model('main_model');
			//$CI->load->model('questions_model');
			
			$questionid=$postdata['questionid'];
			$answerid=$postdata['answerid'];
			$ques_year_id=$postdata['ques_class'];
			
			//$ques_dtl = $CI->main_model->get_detail('manage_question_'.$ques_year_id,'ques_id',$questionid);
            $ques_dtl = $CI->main_model->get_detail($obj,'manage_question_'.$ques_year_id,array('ques_id'=>$questionid),'single');
            //$ques_dtl = $CI->main_model->get_detail();
			
            $ques_type=explode(',',$ques_dtl->ques_type);
			
			
			
			if(in_array(1,$ques_type) || in_array(4,$ques_type) || in_array(6,$ques_type)){ 
							if($ques_dtl->ques_rightanswer==$answerid){
								$answer_truthness=true;
							}
							else{ $answer_truthness=false;}
						}
			elseif(in_array(22,$ques_type))
							{
								
							$answerid= implode(',',$answerid);
							if($ques_dtl->ques_rightanswer==$answerid){
								$answer_truthness=true;
							}
							else{ $answer_truthness=false;}
						}
						
						elseif(in_array(33,$ques_type))
							{
								
							//$all_answer = $CI->main_model->getall('manage_answer_'.$ques_year_id,'ans_quesid',$questionid);
                            $all_answer = $CI->main_model->get_detail($obj,'manage_answer_'.$ques_year_id,array('ans_quesid'=>$questionid),'single');
							
							$answer_truthness=false;
							$crct_ans=array();
						
							for($i=0;$i<count($all_answer);$i++){
								
								$incount=$i+1;
								if($all_answer[$i]->ans_correct=='1')
								{ 
									$crct_ans[]=$all_answer[$i]->ans_name;
									
								}
							}
							if(count($all_answer)==0){
								$answer_truthness=false;
							}
							
							if($postdata['input1']!=""){
								if(in_array($postdata['input1'],$crct_ans))
								{
									$answer_truthness=true;
								}else{
									$answer_truthness=false;
								}
							
							}
							
							if($postdata['input2']!=""){
								if(in_array($postdata['input2'],$crct_ans))
								{
									$answer_truthness=true;
								}else{
									$answer_truthness=false;
								}
							
							}
								
						}
						elseif(in_array(27,$ques_type))
							{
								
							//$all_answer = $CI->main_model->getall('manage_answer_'.$ques_year_id,'ans_quesid',$questionid);
                            $all_answer = $CI->main_model->get_detail($obj,'manage_answer_'.$ques_year_id,array('ans_quesid'=>$questionid));
							$crct_ans=array();
							$answer_truthness=false;
							
						
							for($i=0;$i<count($all_answer);$i++){
								
								$incount=$i+1;
								if($all_answer[$i]->ans_correct=='1')
								{ 
									$crct_ans[]=$all_answer[$i]->ans_name;
									
								}
							}
							if($postdata['input1']!=""){
								if(in_array($postdata['input1'],$crct_ans))
								{
									$answer_truthness=true;
								}
							
							}
							
							
								
						}
						elseif(in_array(32,$ques_type)||in_array(34,$ques_type))
					    {
							
							//$all_answer = $CI->main_model->getall('manage_answer_'.$ques_year_id,'ans_quesid',$questionid);
                            $all_answer = $CI->main_model->get_detail($obj,'manage_answer_'.$ques_year_id,array('ans_quesid'=>$questionid));
							$answer_truthness=true;
							if($postdata['input1']==""){
								$answer_truthness=false;
							}
							if(count($all_answer)==0){
								$answer_truthness=false;
							}
							
						
							for($i=0;$i<count($all_answer);$i++){
								
								$incount=$i+1;
								if($all_answer[$i]->ans_type=='2')
								{
									 $ans_encode=base64_encode(trim($postdata['input'.$incount]));
								
									if($all_answer[$i]->ans_name!=$ans_encode)
									{ 
										$answer_truthness=false;
										
									}
								}
								else{
									if($all_answer[$i]->ans_name!=trim($postdata['input'.$incount]))
										{ 
											$answer_truthness=false;
											
										}
								}
							}
					 					
						}
						elseif(in_array(26,$ques_type))
					    {
							
							//$all_answer = $CI->main_model->getall('manage_answer_'.$ques_year_id,'ans_quesid',$questionid);
                            $all_answer = $CI->main_model->get_detail($obj,'manage_answer_'.$ques_year_id,array('ans_quesid'=>$questionid));
							
                            
                            $answer_truthness=true;
							if($postdata['input1']==""){
								$answer_truthness=false;
							}
							if(count($all_answer)==0){
								$answer_truthness=false;
							}
							
						
							for($i=0;$i<count($all_answer);$i++){
								
								$incount=$i+1;
								
								
								if($all_answer[$i]->ans_type=='2')
								{
									 $ans_encode=base64_encode(trim($postdata['input'.$incount]));
								
									if($all_answer[$i]->ans_name!=$ans_encode)
									{ 
										$answer_truthness=false;
										
									}									
                                    else									
                                    {										
                                                                        
                                                                            $answer_truthness=true;									}
								}
								else{
								$ans_name=trim($all_answer[$i]->ans_name);
								$ans_name=implode('',explode(' ',$ans_name));
								
								$posted_input=trim($postdata['input'.$incount]);
								$posted_input=implode('',explode(' ',$posted_input));

								if($ans_name!=$posted_input)
								{ 
									$answer_truthness=false;
									
								}								
                                else									
                                {										
                                    $answer_truthness=true;									}
								}
							
							
							
							}
					 					
						}
					
			return $answer_truthness;			
    }
}
						?>