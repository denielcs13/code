<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

if(!function_exists('get_counter'))
{
		date_default_timezone_set('Pacific/Auckland');
function get_counter(){
		
			$CI =& get_instance();
			$CI->load->model('main_model');
			$row_counter = $CI->main_model->get_detail('get_counter','id','1');
			$current_date_time=date('Y-m-d H:i:s');	
			$counter=$row_counter->counter;
			$hourdiff = round((strtotime($current_date_time)-strtotime($row_counter->date))/3600, 1);
			$dif_var=0.5;
			if($hourdiff>.5){
				
				$counter=$counter+345;
				
				$data=array(
							'counter'=>$counter,
							'date'=>$current_date_time
								);
					$CI->main_model->Update('get_counter',$data,'id','1');
					
					
					
					return $counter;
							
							
							}
			
			
			return $counter;			
}
}
						?>