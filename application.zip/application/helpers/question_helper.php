<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

if (!function_exists('get_question'))
{
function get_question($obj,$year_id,$question_id){
		
			
            $CI =& get_instance();
			$CI->load->model('main_model');
			if($year_id != null && $question_id != "")
				{
					$year_dtl = $CI->main_model->get_detail($obj,'master_class',array('class_id'=>$year_id),'single');
				    
					$result=$CI->main_model->get_detail($obj,'manage_question_'.$year_id,array('ques_id'=>$question_id),'single');
                    //$CI->db->query("select * from manage_question_".$year_id." where ques_id='".$question_id."' ");
//					$result=$query_ques->row();
				   
					$skill_dtl =$CI->main_model->get_detail($obj,'master_skill',array('skill_id'=>$result->ques_subskillid,'skill_class'=>$year_id),'single');
					
					  
					$ques_type=array_map('trim',explode(',',$result->ques_type));
                    
				    $htmdata='<div class="'.$year_dtl->class_slug.'-'.$skill_dtl->skill_slug.'  cls-'.$year_id.'-'.$question_id.'">'; 
						$htmdata.= '<script src="'.base_url().'assets/ckeditor2/ckeditor.js"></script><script>window.MathJax = { MathML: { extensions: ["mml3.js", "content-mathml.js"]}};</script><script type="text/javascript" async src="https://cdnjs.cloudflare.com/ajax/libs/mathjax/2.7.0/MathJax.js?config=MML_HTMLorMML"></script>';
					if(in_array(32,$ques_type)){
					$CI->load->library('ckeditor');
					$CI->load->library('ckfinder');
					$CI->ckeditor->basePath = base_url().'asset/ckeditor/';
					$CI->ckeditor->config['toolbar'] = array(
					array( 'Source', '-', 'Bold', 'Italic', 'Underline', '-','Cut','Copy','Paste','PasteText','PasteFromWord','-','Undo','Redo','-','NumberedList','BulletedList' )
														);
					$CI->ckeditor->config['language'] = 'it';
					$CI->ckeditor->config['width'] = '730px';
					$CI->ckeditor->config['height'] = '300px';  	




					
					$htmdata.= '<script>$(document).ready(function() {CKEDITOR.replace("input1", {
            height: 30,
			toolbarCanCollapse : true,                  
			allowedContent: true, 
            toolbar: [            
            ["ckeditor_wiris_formulaEditor", "ckeditor_wiris_formulaEditorChemistry", "ckeditor_wiris_CAS"]],}); });</script>';
					}
					
			if(in_array(34,$ques_type)){
					$CI->load->library('ckeditor');
					$CI->load->library('ckfinder');
					$CI->ckeditor->basePath = base_url().'asset/ckeditor/';
					$CI->ckeditor->config['toolbar'] = array(
					array( 'Source', '-', 'Bold', 'Italic', 'Underline', '-','Cut','Copy','Paste','PasteText','PasteFromWord','-','Undo','Redo','-','NumberedList','BulletedList' )
														);
					$CI->ckeditor->config['language'] = 'it';
					$CI->ckeditor->config['width'] = '730px';
					$CI->ckeditor->config['height'] = '300px';  	




					
					$htmdata.= '<script>$(document).ready(function() {CKEDITOR.replace("input1", {
            height: 30,
			toolbarCanCollapse : true,                  
			allowedContent: true, 
            toolbar: [            
            ["ckeditor_wiris_formulaEditor", "ckeditor_wiris_formulaEditorChemistry", "ckeditor_wiris_CAS"]],});
CKEDITOR.replace("input2", {
            height: 30,
			toolbarCanCollapse : true,                  
			allowedContent: true, 
            toolbar: [            
            ["ckeditor_wiris_formulaEditor", "ckeditor_wiris_formulaEditorChemistry", "ckeditor_wiris_CAS"]],});
CKEDITOR.replace("input3", {
            height: 30,
			toolbarCanCollapse : true,                  
			allowedContent: true, 
            toolbar: [            
            ["ckeditor_wiris_formulaEditor", "ckeditor_wiris_formulaEditorChemistry", "ckeditor_wiris_CAS"]],});});</script>';
					}	
					
					
					if(in_array(1,$ques_type)){  
				
						if(in_array(26,$ques_type))
						{
						$QuesDecoded = base64_decode($result->ques_name); 
						
						$htmdata.= $QuesDecoded;
						}else{
						$htmdata.= '<p>'.$result->ques_name.'</p>';
						}
						$htmdata.= '<br>';
						
					//$CI->main_model->get_detail($obj,'master_class',array('class_id'=>$year_id),'single');
						$answers=$CI->main_model->get_answers($obj,$result->ques_id,$year_id);
						$htmdata.= '<div>';
						foreach($answers as $answer){
						
						if($answer->has_image==1){
						$htmdata.= '<a id ="a1" class="quiz-btn" href="javascript:alert(default functionality)"><input name="answerid"  required value="'.$answer->ans_id.'" name="rb" type="radio" id="rb1"><label><img src="'.$answer->ans_name.'" /></label></a>&nbsp;&nbsp;&nbsp;';	
						
						}
						else if($answer->ans_type=='2')
								{
									 $ans_decode=base64_decode(trim($answer->ans_name));
								
						
						$htmdata.= '<a id ="a1" class="quiz-btn" href="javascript:alert(default functionality)"><input name="answerid" required value="'.$answer->ans_id.'" name="rb" type="radio" id="rb1"><label>'.$ans_decode.'</label></a>&nbsp;&nbsp;&nbsp;';
								
						}
						
						else{
						$htmdata.= '<a id ="a1" class="quiz-btn" href="javascript:alert(default functionality)"><input name="answerid" required value="'.$answer->ans_id.'" name="rb" type="radio" id="rb1"><label>'.$answer->ans_name.'</label></a>&nbsp;&nbsp;&nbsp;';
						}
						
						}
						$htmdata.= '</div>';
						$htmdata.= '<br>';
				}
				
				
				elseif(in_array(25,$ques_type)){ 
					
					$htmdata.='<p>'.$result->ques_name.'</p>';
					$htmdata.= '<br>';
					$imgs=$CI->main_model->get_detail('ques_img','ques_id',$result->ques_id);
                   

					
					$htmdata.= '<br>';
					$answers=$CI->main_model->get_answers($obj,$result->ques_id,$year_id);;
					foreach($answers as $answer){
						
					$htmdata.= '<a id ="a1" class="quiz-btn" href="javascript:alert(default functionality)"><input name="answerid" value="'.$answer->ans_id.'" name="rb" type="radio" id="rb1"><label>'.$answer->ans_name.'</label></a>&nbsp;&nbsp;&nbsp;';
					}
					
				
				}
				
			
				elseif(in_array(22,$ques_type))
				{ 
					if(in_array(26,$ques_type)){
					$QuesDecoded = base64_decode($result->ques_name); 
					}
					else{$QuesDecoded =$result->ques_name; }
					$htmdata.= $QuesDecoded;
					$htmdata.= '<br>';
					$answers=$CI->main_model->get_answers($obj,$result->ques_id,$year_id);
					$htmdata.= '<div>';
					foreach($answers as $answer){
					if($answer->ans_type=='2'){
					$answer->ans_name = base64_decode($answer->ans_name); 
					}
					if($answer->has_image==1){
					$htmdata.= '<a id ="a1" class="quiz-btn" href="javascript:alert(default functionality)"><input name="answerid[]" value="'.$answer->ans_id.'" name="rb" type="checkbox" id="rb1"><label><img src="'.$answer->ans_name.'" /></label></a>&nbsp;&nbsp;&nbsp;';	
					
					}
					else{
					$htmdata.= '<a id ="a1" class="quiz-btn" href="javascript:alert(default functionality)"><input name="answerid[]" value="'.$answer->ans_id.'" name="rb" type="checkbox" id="rb1"><label>'.$answer->ans_name.'</label></a>&nbsp;&nbsp;&nbsp;';
					}
					
					}
					$htmdata.= '</div>';
					
					
				
				}
				elseif(in_array(26,$ques_type))
				{   
					$QuesDecoded = base64_decode($result->ques_name); 
					$htmdata.= $QuesDecoded;
					$htmdata.= '<br>';
					
				}
				else{ 
				$htmdata.= '<p>'.$result->ques_name.'</p>';
				
					
				}
							
							
						$htmdata.='<div>
									<input type="hidden" name="questionid" value="'.$result->ques_id.'"/>
									<input type="hidden" name="action" value="submitanswer"/>	
									<input type="hidden" name="ques_type" value="'.$result->ques_type.'"/>
									<input type="hidden" name="ques_class" value="'.$result->ques_class.'"/>
					<input type="hidden" name="year_id" value="'. $year_id.'"/>
					<input type="hidden" name="subskill" value="'.$skill_dtl->skill_slug.'"/>
					<input type="hidden" name="skill_id" value="'.$skill_dtl->skill_id.'"/>
					</div>'	;
				$htmdata.='<div style="float:right;font-size:12px;color:#666;">'. $year_dtl->class_name. ' - #'.$result->ques_id.'</div>';
				$htmdata.='</div>';			
				return $htmdata;			
							
		}
				
}
}